# Prüfung der GitHub-Pages-Version

Stand: 12. Oktober 2026. Grundlage: Territory-Lab-Standalone-5.0.0.zip.

**Ergebnis: Alle durchgeführten Prüfungen bestanden.** Die Version ist als statisches Veröffentlichungspaket vorbereitet. Sie wurde noch nicht in ein GitHub-Repository hochgeladen oder auf einer öffentlichen GitHub-Pages-Adresse getestet.

| Bereich | Ergebnis |
|---|---|
| Originaldaten | Alle 298 Dateien aus `assets` vorhanden; Dateigrößen und SHA-256-Prüfsummen stimmen mit dem Original überein. |
| Karten | Alle 21 Karten im Browser geladen und zwischen 2D und 3D umgeschaltet. |
| Bestehende Funktionstests | Alle 72 Tests aus der ursprünglichen Testliste bestanden, einschließlich der Tests mit sämtlichen Karten. |
| Neue Ladefunktion | Gzip, Unicode, mitgelieferte Ersatzlösung, aufgeteilte Datenströme, bereits vom HTTP-Server entpackte Daten, Wiederholung nach vorübergehendem Fehler, 404, beschädigte Daten, Abbruch und Zeitlimit geprüft. |
| Routenplaner | Echter Hintergrundprozess lädt komprimierte Originaldaten, berechnet eine Route auf Shifting Gears und übernimmt Flaggen. Rückgängig und Wiederholen geprüft. Weitere Karten- und Routenfälle sind in den ursprünglichen Funktionstests enthalten. |
| Kriegsbauer | Echter Hintergrundprozess auf Shifting Gears: 997 geprüfte Sprungpaare für beide Richtungen. Abbruch, erneuter Start, Filter, Wiederverwendung der geladenen Karte und unveränderter Plan geprüft. |
| Allianzen und Koalitionen | Im Browser erstellt und bearbeitet. |
| Sprachen | Deutsch, Englisch und Französisch im Browser umgeschaltet. |
| Pläne | Export, anschließender Import und Speichern über einen Seitenneustart hinweg geprüft. |
| Excel | Gesamte Karte und sichtbarer Ausschnitt heruntergeladen; Dateistruktur anschließend geprüft. |
| PNG | Gesamte Karte und sichtbarer Ausschnitt heruntergeladen; Bilddateien anschließend geprüft. |
| Zusatzseiten | Bildvorlagen, Kartenabgleich, beide Terrain-Prüfseiten und Landschaftsansicht geladen. |
| Terrain-Berichte | Beide Prüfungen ausgeführt und vollständige Berichte mit Messwerten und Bildern heruntergeladen; auch mit dem bisherigen Parameter `localExport=1`. |
| Hosting-Pfade | `/territory-lab/`, `/` und `/planung/territory/` geprüft. |
| Browserfehler | Keine JavaScript-Fehler, keine erfassten WebGL-Fehler und keine fehlgeschlagenen HTTP-Dateianfragen in der Hauptprüfung. |
| Website-Größe | 792.462.155 Bytes, etwa 792 MB beziehungsweise 755,75 MiB. Unter dem 1-GB-Limit von GitHub Pages. |

Die Browserprüfungen liefen in Chromium mit einem vollständig statischen HTTP-Server. Dieser Server enthält weder die bisherige JSON-zu-Gzip-Umleitung noch Server-APIs. Damit wurde gerade die für GitHub Pages notwendige serverunabhängige Auslieferung geprüft. Die Hauptprüfung erfolgte in einer Desktop-Ansicht; eine separate Prüfung auf echten Mobilgeräten und in jedem anderen Browser wurde nicht durchgeführt.

Die Planungsregeln und die Originaldaten wurden beibehalten. Die historischen Prüfeingaben für vier Tests wurden aus der ursprünglichen ZIP übernommen. Der isolierte Test für den Solver-Neustart erhielt zusätzlich eine Dateipfad-Hilfsfunktion, die durch den Umbau nun benötigt wird; seine bestehenden Funktionsprüfungen bleiben erhalten.

Die detaillierten Ergebnisse stehen in `verification/core-results.json`, `browser-results.json`, `browser-extra-results.json`, `hosting-results.json` und `package-results.json`. Dort liegen außerdem Ansichten aus der Browserprüfung. Große erzeugte Testdownloads sind nicht Teil des Veröffentlichungspakets.

Vor der Veröffentlichung in GitHub laufen die Ladeprüfung, die 72 bestehenden Funktionstests und die Datenprüfung erneut. Zur Einrichtung siehe `README-GITHUB-PAGES.md`.
