# Territory Lab 5.0.0 für GitHub Pages

Diese Version basiert auf `Territory-Lab-Standalone-5.0.0.zip`. Alle 21 Karten und alle 298 ursprünglichen Dateien aus `assets` sind vollständig und unverändert enthalten. Die Karten-, Kollisions-, Kosten-, Produktions- und Planungsdaten wurden nicht reduziert. Die bestehende Oberfläche und die Planungsregeln bleiben erhalten.

## Auf GitHub veröffentlichen

1. Die ZIP vollständig entpacken.
2. Ein GitHub-Repository mit dem Hauptzweig `main` erstellen. Ein beliebiger Repository-Name ist möglich.
3. Das Repository lokal öffnen, beispielsweise mit GitHub Desktop. **Die Inhalte des entpackten Ordners in die Repository-Wurzel kopieren.** Dort müssen `index.html`, `web`, `assets`, `tests`, `tools`, `analysis`, `asset-manifest.json` und `.github` liegen. Nicht nur die ZIP hochladen und keinen zusätzlichen äußeren Ordner anlegen. Bei diesem großen Paket empfiehlt sich die Übertragung mit GitHub Desktop oder Git.
4. Unter **Settings → Pages → Build and deployment → Source** die Option **GitHub Actions** auswählen.
5. Die Dateien committen und auf GitHub pushen. Unter **Actions** den Lauf „Territory Lab auf GitHub Pages veröffentlichen“ beobachten. Falls die Dateien schon vor Schritt 4 hochgeladen wurden, den Workflow über **Run workflow** erneut starten.
6. Nach dem erfolgreichen Lauf zeigt GitHub unter **Settings → Pages** die Adresse der Website an: normalerweise `https://DEINNAME.github.io/REPOSITORY/`.

Der Workflow reagiert auf `main` und `master`; bei einem anderen Hauptzweig muss die entsprechende Zeile in `.github/workflows/pages.yml` angepasst werden. Die erste Prüfung und Übertragung dieses großen Pakets kann einige Minuten dauern. Die Website benötigt anschließend keine laufende Python- oder Node-Anwendung und keine kostenpflichtige API.

## Was angepasst wurde

- Die Startseite leitet innerhalb der eigenen Website zur vollständigen Anwendung weiter und erhält URL-Parameter und Sprungmarken.
- Dateipfade funktionieren unter einer Repository-Unteradresse sowie unter einer eigenen Domain.
- Kartenansicht, Routenplaner, Kriegsbauer und Prüfseiten laden die Originaldateien `.json.gz` direkt und entpacken sie im Browser.
- Eine mitgelieferte Gzip-Ersatzlösung unterstützt Browser ohne native Gzip-Entpackung. Dafür wird kein externer Dienst aufgerufen.
- Texturen und Symbole werden auch dann korrekt gefunden, wenn ihre Originalpfade innerhalb der Kartendaten stehen.
- Die lokale Python-Serverüberwachung wurde entfernt.
- Die Terrain-Prüfseiten speichern vollständige Berichte einschließlich Bildern über Downloads; auch der bisherige Parameter `localExport=1` führt zu einem Download. Eine Website schreibt diese Dateien nicht mehr direkt in ein Python-Serververzeichnis.
- Netzwerkfehler werden angezeigt; vorübergehend fehlgeschlagene Anfragen werden einmal wiederholt. Berechnungsdaten haben ein längeres Ladezeitlimit.

## Daten und bestehende Pläne

Alle Ordner unter `assets` bleiben erhalten, einschließlich `audit255`, `audit256`, Geländetexturen, Referenzbildern und Landmarken. Die normalen Kartenansichten verwenden ebenfalls Dateien aus diesen Ordnern. Die veröffentlichte Website umfasst etwa 792 MB und liegt unter dem 1-GB-Limit von GitHub Pages.

`asset-manifest.json` enthält Dateigrößen und SHA-256-Prüfsummen sämtlicher ursprünglicher Datendateien. Vor jedem automatischen Veröffentlichen werden die Datendateien dagegen geprüft. Fehlende oder veränderte Dateien führen zum Abbruch der Veröffentlichung.

Pläne werden weiterhin im Browser und über „Plan speichern“ als Datei gesichert. **Bestehende Pläne aus der lokalen Standalone-Version vorher als Datei exportieren und auf der neuen Website mit „Plan laden“ importieren.** Browser übertragen ihren lokalen Speicher nicht automatisch auf eine neue Adresse. Die Website fügt keine gemeinsame Cloud-Speicherung oder gleichzeitige Zusammenarbeit hinzu.

## Prüfung und Entwicklung

Die Ergebnisse dieser Lieferung stehen unter `verification`. Die Website wurde mit einem rein statischen Server unter `/territory-lab/` geprüft, ohne Python-Sonderauslieferung für Kartendaten. Die Originaltests, benötigte historische Testeingaben und Entwicklungsquellen sind für spätere Prüfungen enthalten. Nicht benötigte historische Bildschirmfotos und Analysearchive bleiben in der unveränderten ursprünglichen ZIP.

Der Veröffentlichungsworkflow führt den Test der neuen Ladefunktion, alle 72 Tests aus dem ursprünglichen Paket und die Vollständigkeitsprüfung aus. **Er veröffentlicht nur `index.html`, `.nojekyll`, die Lizenzdateien sowie `web` und `assets`.** Entwicklungsquellen, Testberichte und Prüfeingaben werden nicht als Website ausgeliefert.

Optional lokal prüfen (Node.js ab Version 24 und Python ab Version 3.11):

```text
node tests/pages-runtime.mjs
node tools/verify-core.mjs
python tools/verify-package.py
python tools/preview.py --open
```

Die Vorschau öffnet `http://127.0.0.1:8895/territory-lab/`. Im Vorschauterminal beendet Strg+C den Server. Bei einem belegten Port ist zum Beispiel `python tools/preview.py --port 8896 --open` möglich.

Optionale wiederholbare Browserprüfung:

```text
npm install
npx playwright install chromium
```

Anschließend die lokale Vorschau laufen lassen und in einem zweiten Terminal ausführen:

```text
npm run test:browser
```

Die Browserprüfung prüft alle 21 Karten in 2D und 3D, die tatsächlichen Berechnungsprozesse, Allianzen und Koalitionen, Sprachen, Planimport/-export, Browserspeicherung, Rückgängig/Wiederholen, Excel- und PNG-Exporte sowie Zusatzseiten und Terrain-Berichte.

## Quellen und Lizenzen

Die ursprünglichen Lizenzdateien sind enthalten; zusätzlich liegt die Lizenz der Gzip-Ersatzlösung unter `LICENSE-PAKO`. Das Originalpaket auf deinem Computer wird durch diesen Umbau nicht verändert.

GitHub-Dokumentation: [Pages-Veröffentlichung](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site), [Pages-Limits](https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits).
