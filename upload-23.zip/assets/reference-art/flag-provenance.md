# Allianzflagge für Territory Lab 1.6

Verwendet wurde die integrierte Bildbearbeitung (`image_gen`, Edit-Modus, transparenter Hintergrund), keine CLI. Die Darstellung wurde aus dem Screenshot rekonstruiert und ist kein unverändertes Original-Spielmodell.

Vorlage: D:/ShareX Screenshots/Screenshots/2026-09/kEuRYktUQn.png

Gespeicherte Datei: Territory-Lab-1.6-Flagge.png; im ZIP: assets/reference-art/flag.png. Die magentafarbene Bannerfläche wird in der Anwendung vollständig durch die gewählte Allianzfarbe ersetzt.

## Vollständiger Prompt

Use case: background-extraction. Edit target: supplied game screenshot. Extract ONLY the complete ALLIANCE FLAG on the RIGHT side: a slim dark grey carved stone pedestal with four feet and gold trim at its square base, gold rim at the top, short dark flagpole and a broad vertical cloth banner with gently curved pointed bottom. Match the reference object's exact proportions, silhouette, 3/4 isometric viewing angle and stylized polished game material. Remove crystal mine, other objects, ground and all background. Output one centered high-resolution game sprite on genuine transparent alpha background with tight framing and small padding. Preserve all original pedestal shapes and gold decorations, sharpen blurred detail conservatively. The ENTIRE cloth banner must be saturated MAGENTA (#e000e0) with subtle folds/shading and no emblem, for runtime recolouring. Do not colour stone or gold magenta. No cast shadow extending far outside the base, no words, no border, no UI. This is a sprite asset for the user's existing Territory Lab map.
