from pathlib import Path
import json,cv2,numpy as np,gzip

root=Path(__file__).resolve().parents[2]
out=root/'analysis/calibration400';out.mkdir(parents=True,exist_ok=True)
screens=Path('D:/ShareX Screenshots/Screenshots/2026-10')
# Centres/axes mark the ground rings visible in the supplied photographs,
# not roofs, symbols, shadows or the filled placement-error glow.
annotations=[
 ('UCOoizNkul.png','flag',(407,396),(112,80),'red'),
 ('UCOoizNkul.png','resource',(407,396),(165,123),'red'),
 ('UCOoizNkul.png','cave',(694,348),(132,93),'white'),
 ('c27jvrTxNc.png','flag',(377,432),(107,75),'red'),
 ('c27jvrTxNc.png','fortress',(377,432),(164,120),'red'),
 ('EVTAF0a4Vn.png','flag',(310,290),(121,89),'red'),
 ('nRg1rkfGP3.png','fortress',(527,482),(173,143),'red'),
 ('E7ecv8P41y.png','resource',(329,390),(155,110),'white'),
 ('E7ecv8P41y.png','cave',(596,335),(111,80),'white'),
 ('E7ecv8P41y.png','smallNode',(154,65),(99,60),'white'),
 ('W8Oml7at8A.png','stone',(380,335),(163,125),'white'),
]
rows=[]
for file,kind,centre,axes,colour in annotations:
 p=screens/file;im=cv2.imdecode(np.fromfile(p,dtype=np.uint8),cv2.IMREAD_COLOR)
 if im is None:raise RuntimeError(str(p))
 hsv=cv2.cvtColor(im,cv2.COLOR_BGR2HSV);yy,xx=np.indices(im.shape[:2])
 norm=np.sqrt(((xx-centre[0])/axes[0])**2+((yy-centre[1])/axes[1])**2)
 if colour=='red':mask=((hsv[:,:,0]<9)|(hsv[:,:,0]>173))&(hsv[:,:,1]>145)&(hsv[:,:,2]>155)
 else:
  # The white dashed ring is a local bright edge on the grassy ground.
  gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY).astype(float)
  contrast=gray-cv2.GaussianBlur(gray,(0,0),3)
  mask=(hsv[:,:,1]<100)&(hsv[:,:,2]>175)&(contrast>7)
 mask&=(norm>.94)&(norm<1.06)
 y,x=np.where(mask);points=np.column_stack([x,y]).astype('float32')
 if len(points)<30:raise RuntimeError((file,kind,len(points)))
 ellipse=cv2.fitEllipse(points.reshape(-1,1,2));cx,cy=ellipse[0];a,b=np.array(ellipse[1])/2
 major,minor=max(a,b),min(a,b)
 row=dict(file=file,kind=kind,centre=[cx,cy],semiAxesPixels=[major,minor],axisRatio=minor/major,edgePixels=len(points),seedCentre=centre,seedAxes=axes)
 rows.append(row)
 cv2.ellipse(im,ellipse,(255,80,30),2)
 cv2.imwrite(str(out/(kind+'-'+file)),im)

def get(file,kind):return next(r for r in rows if r['file']==file and r['kind']==kind)
ratios={}
for file,other in [('UCOoizNkul.png','resource'),('UCOoizNkul.png','cave')]:
 f=get(file,'flag');r=get(file,other)
 ratios[other+'ToFlag']=[r['semiAxesPixels'][i]/f['semiAxesPixels'][i] for i in range(2)]
# Absolute scale anchor: corresponding gold node and cave in Preparation 1.
# Circular rings correct the Y foreshortening; XY distance is rotation invariant.
d=json.loads(gzip.decompress((root/'assets/data/Sever_Map_G1_1_v2.json.gz').read_bytes()))
gold=next(q for q in d['resources'] if q['id']==21085)
cave=next(q for q in d['landmarks'] if q['id']=='caves:11085')
nativeDistance=np.hypot(gold['x']-cave['x'],gold['y']-cave['y'])
scales=[]
for file in ['UCOoizNkul.png','E7ecv8P41y.png']:
 g=get(file,'resource');c=get(file,'cave');pitch=np.median([g['axisRatio'],c['axisRatio']])
 delta=np.array(g['centre'])-c['centre'];unprojected=np.hypot(delta[0],delta[1]/pitch)
 scale=unprojected/nativeDistance
 scales.append(dict(file=file,pixelsPerNativeUnit=scale,axisRatio=float(pitch),resourceRadiusGame=g['semiAxesPixels'][0]/scale/6,caveRadiusGame=c['semiAxesPixels'][0]/scale/6,flagRadiusGame=get(file,'flag')['semiAxesPixels'][0]/scale/6 if file.startswith('UCO')else None))
# The nested fortress rings in c27 are not an unambiguous independent scale.
for row in rows:
 row['usedForCalibration']=row['file']!='c27jvrTxNc.png' and row['kind']!='smallNode'
 if row['file']=='c27jvrTxNc.png':row['exclusionReason']='Overlapping red placement rings cannot identify two independent physical footprints.'
chosen={'resource':1,'flag':.67,'fortress':.97,'village':.75,'cave':.75}
flag=get('UCOoizNkul.png','flag');res=get('UCOoizNkul.png','resource');c=get('UCOoizNkul.png','cave')
photoArea={k:float(np.prod(q['semiAxesPixels'])/np.prod(res['semiAxesPixels'])) for k,q in [('flag',flag),('cave',c)]}
# Orange stripe energy and edge-connected components, sensitivity at two
# thresholds. This interval is NOT a statistical confidence interval.
stone=get('W8Oml7at8A.png','stone');im=cv2.imdecode(np.fromfile(screens/'W8Oml7at8A.png',dtype=np.uint8),cv2.IMREAD_COLOR)
rg=im[:,:,2].astype('float32')-im[:,:,1].astype('float32')
responses=[]
for phase in [0,np.pi/2]:
 k=cv2.getGaborKernel((81,81),18,np.deg2rad(55),44,.4,phase,ktype=cv2.CV_32F);k-=k.mean()
 responses.append(cv2.filter2D(rg,-1,k))
energy=cv2.GaussianBlur(np.hypot(*responses),(0,0),5)
yy,xx=np.indices(im.shape[:2]);cx,cy=stone['centre'];a,b=stone['semiAxesPixels']
# Near-horizontal ground ellipse: angle differences below a few degrees are
# smaller than the segmentation uncertainty in this comparison.
inside=((xx-cx)/a)**2+((yy-cy)/b)**2<=1
shares=[]
for threshold in [14000,18000]:
 n,labels,stats,_=cv2.connectedComponentsWithStats((energy>threshold).astype('uint8'))
 ids=[i for i in range(1,n) if stats[i,cv2.CC_STAT_TOP]<5 or stats[i,cv2.CC_STAT_TOP]+stats[i,cv2.CC_STAT_HEIGHT]>=im.shape[0]-5]
 mask=np.isin(labels,ids);shares.append(dict(threshold=threshold,blockedShare=float(np.count_nonzero(mask&inside)/np.count_nonzero(inside))))
 cv2.imwrite(str(out/f'stone-hatch-threshold-{threshold}.png'),(mask.astype('uint8')*255))
report=dict(chosenRadiiGame=chosen,chosenAreaRatios={k:r*r for k,r in chosen.items()},photoAreaRatios=photoArea,fortressEstimateNote='0.97 is a conservative estimate consistent with the user-specified slightly smaller diameter than resources; exact fortress engine constants cannot be read from the ambiguous rings.',hatchSegmentation=dict(method='Gabor stripe energy, edge-connected masks',samples=shares,intervalIsStatistical=False),measurements=rows,ratios=ratios,absoluteEstimates=scales,anchor=dict(gold=gold,cave=cave,nativeDistance=nativeDistance),limitations=['Photographs constrain visible ground rings; they do not expose engine collision constants.','The image-to-map scale assumes the identified Preparation 1 gold/cave pair and a locally flat ground plane.','Partial/occluded dashed rings and perspective produce uncertainty; use rounded estimates, not fitted pixel precision.','The level-7 small node is not used as a village scale anchor: its type and corresponding source position are not established.'])
(out/'photo-measurements.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(dict(ratios=ratios,absoluteEstimates=scales),indent=2))
