import fs from 'node:fs';import zlib from 'node:zlib';import {MapModel,newPlan} from '../../web/core/model.js';
const d=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/data/Sever_Map_G1_1_v2.json.gz'))),m=new MapModel(d);m.setPlan(newPlan(d.catalog.map));
for(const n of d.resources.filter(n=>[30969,21085].includes(n.id))){const fractions=[];for(const r of [3,4,4.5,5,6,7,8,9,10,12,15,18]){let total=0,blocked=0;for(let y=-r;y<=r;y+=.2)for(let x=-r;x<=r;x+=.2)if(x*x+y*y<r*r){total++;if(m.terrainCollision(n.x+x,n.y+y,0))blocked++;}fractions.push({r,game:r/6,fraction:blocked/total});}console.log(n,fractions);}
const n=d.resources.find(q=>q.id===30969),tris=m.triangles.filter(t=>Math.max(t[0],t[2],t[4])>n.x-80&&Math.min(t[0],t[2],t[4])<n.x+80&&Math.max(t[1],t[3],t[5])>n.y-80&&Math.min(t[1],t[3],t[5])<n.y+80);
fs.writeFileSync('analysis/calibration400/stone-reference.json',JSON.stringify({node:n,triangles:tris}));

