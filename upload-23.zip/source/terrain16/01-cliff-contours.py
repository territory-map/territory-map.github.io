from pathlib import Path
import gzip,json,base64,cv2,numpy as np
root=Path(__file__).resolve().parents[2];reports=[]
for p in (root/'assets/data').glob('*.gz'):
 d=json.loads(gzip.decompress(p.read_bytes()));t=d['terrain15'];a,b,c,e=d['catalog']['bounds'];W=round(4096*(c-a)/max(c-a,e-b));H=round(4096*(e-b)/max(c-a,e-b));im=cv2.resize(cv2.imread(str(root/'assets/maps'/f"{d['catalog']['map']}.webp")),(W,H),interpolation=cv2.INTER_AREA)
 # Same border-label sampling as both render modes. Only repeated printed labels.
 yy,xx=np.mgrid[:H,:W];u=xx/(W-1);v=yy/(H-1);sx=xx.copy();sy=yy.copy()
 for center in (.22,.5,.78):
  q=(abs(u-center)<.053)&((v<.026)|(v>.974));sx[q]=np.minimum(W-1,xx[q]+round(W*.115))
  q=(abs(v-center)<.053)&((u<.026)|(u>.974));sy[q]=np.minimum(H-1,yy[q]+round(H*.115))
 im=im[sy,sx];raw=np.frombuffer(base64.b64decode(t['hatching']),np.uint8);hm=(np.unpackbits(raw)[:t['hatchingWidth']*t['hatchingHeight']]*255).reshape(t['hatchingHeight'],t['hatchingWidth']);blocked=cv2.resize(hm,(W,H),interpolation=cv2.INTER_NEAREST)
 allowed=cv2.erode(blocked,np.ones((3,3),np.uint8),borderType=cv2.BORDER_CONSTANT,borderValue=0)
 def raster(ps):return np.rint([[(x-a)/(c-a)*(W-1),(e-y)/(e-b)*(H-1)] for x,y in ps]).astype(np.int32)
 water=np.zeros((H,W),np.uint8)
 for i,poly in enumerate(t['waterPolygons']):
  if len(poly)<3:continue
  cv2.fillPoly(water,[raster(poly)],255)
  for hole in t.get('waterHoles',{}).get(str(i),[]):cv2.fillPoly(water,[raster(hole)],0)
 allowed[cv2.dilate(water,np.ones((11,11),np.uint8))>0]=0
 passmask=np.zeros_like(allowed)
 for site in d['sites']:
  if site['kind']=='pass':
   radius=43;pts=raster([[site['x']-radius,site['y']-radius],[site['x']+radius,site['y']+radius]]);cv2.rectangle(passmask,tuple(pts[0]),tuple(pts[1]),255,-1)
 allowed[passmask>0]=0
 blue,green,red=[ch.astype(np.float32) for ch in cv2.split(im)];local=cv2.GaussianBlur(green,(0,0),4);hsv=cv2.cvtColor(im,cv2.COLOR_BGR2HSV);snow=(hsv[:,:,1]<60)&(hsv[:,:,2]>155)
 dark=(green<local-4)&((green<174)|snow)&(red<green*1.18)
 # Trace native cliff lines; clean sub-pixel gaps in the scanned line only.
 # Native blocked-area openings, water and pass clearances remain excluded.
 ridge=cv2.dilate(dark.astype(np.uint8)*255,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5)));ridge=cv2.morphologyEx(ridge,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8));ridge[allowed==0]=0;ridge=cv2.morphologyEx(ridge,cv2.MORPH_OPEN,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3)))
 n,labels,stats,_=cv2.connectedComponentsWithStats(ridge);keep=np.zeros(n,np.uint8);keep[1:]=(stats[1:,cv2.CC_STAT_AREA]>=32)*255;ridge=keep[labels]
 contours,hierarchy=cv2.findContours(ridge,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE);polys=[]
 def coords(cnt):
  approx=cv2.approxPolyDP(cnt,1.0,True)[:,0,:]
  return [[round(a+x/(W-1)*(c-a),3),round(e-y/(H-1)*(e-b),3)] for x,y in approx]
 for i,cnt in enumerate(contours):
  if hierarchy[0,i,3]>=0 or cv2.contourArea(cnt)<2:continue
  x,y,w,h=cv2.boundingRect(cnt);is_snow=float(snow[y:y+h,x:x+w].mean())>.3;long=max(w*(c-a)/W,h*(e-b)/H)>600;zone=long
  holes=[];j=hierarchy[0,i,2]
  while j>=0:
   hole=coords(contours[j])
   if len(hole)>=3:
    fill=False
    if (zone or is_snow) and cv2.contourArea(contours[j])<40:
     hx,hy,hw,hh=cv2.boundingRect(contours[j]);patch=np.zeros((hh,hw),np.uint8);cv2.fillPoly(patch,[contours[j]-[hx,hy]],255)
     fill=bool(np.all(allowed[hy:hy+hh,hx:hx+hw][patch>0]>0))
    if not fill:holes.append(hole)
   j=hierarchy[0,j,0]
  outer=coords(cnt)
  if len(outer)>=3:polys.append({'outer':outer,'holes':holes,'height':24 if is_snow else 16 if zone else 9,'zone':bool(zone),'snow':bool(is_snow)})
 d['terrain16']={'ridges':polys,'method':'Native 2D cliff contours clipped to the same hatching. Open paths and holes retained; no filled blocked-area pillows.','sourceResolution':[W,H]}
 p.write_bytes(gzip.compress(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode(),compresslevel=5,mtime=0))
 report={'map':d['catalog']['map'],'ridgeComponents':len(polys),'holes':sum(len(q['holes'])for q in polys),'raisedOutsideHatching':int(((ridge>0)&(blocked==0)).sum()),'raisedPassPixels':int(((ridge>0)&(passmask>0)).sum()),'raisedWaterPixels':int(((ridge>0)&(water>0)).sum())};assert report['raisedOutsideHatching']==report['raisedPassPixels']==report['raisedWaterPixels']==0;reports.append(report);print(report,flush=True)
(root/'tests/terrain-v16.json').write_text(json.dumps({'passed':True,'maps':reports},indent=2),encoding='utf-8')
