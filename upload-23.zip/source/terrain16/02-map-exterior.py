"""Classify the exterior from native 2D pixels, without moving map coordinates."""
from pathlib import Path
import gzip,json,base64,cv2,numpy as np
root=Path(__file__).resolve().parents[2];reports=[]
for path in sorted((root/'assets/data').glob('*.gz')):
 d=json.loads(gzip.decompress(path.read_bytes()));t=d['terrain15'];name=d['catalog']['map']
 im=cv2.imread(str(root/'assets/maps'/f'{name}.webp'));im=cv2.resize(im,(1024,1024),interpolation=cv2.INTER_AREA)
 # Match the renderer's removal of repeated printed labels before classifying.
 yy,xx=np.mgrid[:1024,:1024];sx=xx.copy();sy=yy.copy();u=xx/1023;v=yy/1023
 for center in (.22,.5,.78):
  q=(abs(u-center)<.053)&((v<.026)|(v>.974));sx[q]=np.minimum(1023,xx[q]+118)
  q=(abs(v-center)<.053)&((u<.026)|(u>.974));sy[q]=np.minimum(1023,yy[q]+118)
 im=im[sy,sx];blue,green,red=[x.astype(float) for x in cv2.split(im)];hsv=cv2.cvtColor(im,cv2.COLOR_BGR2HSV)
 seaCandidate=((blue>red*1.12)&(green>red*1.08)&(red<150)).astype(np.uint8)
 n,labels,stats,_=cv2.connectedComponentsWithStats(seaCandidate)
 edgeIds=np.unique(np.concatenate((labels[0],labels[-1],labels[:,0],labels[:,-1])))
 sea=np.isin(labels,[int(k) for k in edgeIds if k and stats[k,cv2.CC_STAT_AREA]>1000]).astype(np.uint8)
 # Pale foothills delimit the exterior. Fill from that contour outward, including
 # dark peaks and any tiny background-colour rim; never bridge into coastal sea.
 pale=(hsv[:,:,1]<75)&(hsv[:,:,2]>145)&(blue>red*.92)&(sea==0)
 if name=='LostLand_Map_10':pale=(hsv[:,:,1]<90)&(hsv[:,:,2]>85)&(sea==0)
 edge=np.zeros((1024,1024),np.uint8);limit=42
 for row in range(1024):
  for reverse in (False,True):
   line=pale[row,::-1] if reverse else pale[row];hits=np.flatnonzero(line[:limit])
   if len(hits)>=3:
    stop=int(hits[-1])+1
    if reverse:edge[row,1024-stop:]=1
    else:edge[row,:stop]=1
 for col in range(1024):
  for reverse in (False,True):
   line=pale[::-1,col] if reverse else pale[:,col];hits=np.flatnonzero(line[:limit])
   if len(hits)>=3:
    stop=int(hits[-1])+1
    if reverse:edge[1024-stop:,col]=1
    else:edge[:stop,col]=1
 edge=cv2.morphologyEx(edge,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8));edge[sea>0]=0
 kind='rock' if name=='LostLand_Map_10' else 'snow'
 rgba=np.zeros((1024,1024,4),np.uint8);rgba[:,:,0]=edge*255;rgba[:,:,1]=edge*255 if kind=='snow' else 0;rgba[:,:,2]=sea*255;rgba[:,:,3]=255
 rgba=cv2.resize(rgba,(512,512),interpolation=cv2.INTER_AREA)
 d['terrain16']['edge']={'size':512,'rgba':base64.b64encode(rgba.tobytes()).decode(),'mountainMaterial':kind,'seaColour':{'LostLand_Map_20_v2':'#408aa3','LostLand_Map_19_2':'#446760','LostLand_Map_3_2_v2':'#408aa3'}.get(name,'#408aa3'),'hasCoast':bool(sea.any()),'source':'Native detailed 2D map; pale foothill contour extended outward to map bounds, coastal sea excluded.'}
 path.write_bytes(gzip.compress(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode(),compresslevel=5,mtime=0))
 report={'map':name,'mountainMaterial':kind,'seaColour':{'LostLand_Map_20_v2':'#408aa3','LostLand_Map_19_2':'#446760','LostLand_Map_3_2_v2':'#408aa3'}.get(name,'#408aa3'),'coastalSeaPixels':int(sea.sum()),'exteriorPixels':int(edge.sum()),'seaMountainOverlap':int((sea&edge).sum())};reports.append(report);print(report,flush=True)
 assert report['seaMountainOverlap']==0 and report['exteriorPixels']>0
(root/'tests/edge-v16.json').write_text(json.dumps({'passed':True,'maps':reports},indent=2))
