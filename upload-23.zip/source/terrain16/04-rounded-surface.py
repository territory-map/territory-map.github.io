from pathlib import Path
import gzip,json,base64,cv2,numpy as np
root=Path(__file__).resolve().parents[2]
for path in (root/'assets/data').glob('*.gz'):
 d=json.loads(gzip.decompress(path.read_bytes()));t=d['terrain15'];a,b,c,e=d['catalog']['bounds'];W=t['hatchingWidth'];H=t['hatchingHeight']
 blocked=np.unpackbits(np.frombuffer(base64.b64decode(t['hatching']),np.uint8))[:W*H].reshape(H,W);ridge=np.zeros((H,W),np.uint8);zones=np.zeros_like(ridge)
 def raster(poly):return np.rint([[(x-a)/(c-a)*(W-1),(e-y)/(e-b)*(H-1)]for x,y in poly]).astype(np.int32)
 # Large enclosing rings first: their holes must not erase nested hill islands.
 for q in sorted(d['terrain16']['ridges'],key=lambda q:abs(cv2.contourArea(raster(q['outer']))),reverse=True):
  p=raster(q['outer']);cv2.fillPoly(ridge,[p],16 if q['zone'] else 9);cv2.fillPoly(zones,[p],int(q['zone']))
  for hole in q['holes']:cv2.fillPoly(ridge,[raster(hole)],0);cv2.fillPoly(zones,[raster(hole)],0)
 snow=np.unpackbits(np.frombuffer(base64.b64decode(d['terrain16']['snowMask']),np.uint8))[:W*H].reshape(H,W)
 ridge[(blocked==0)|(snow>0)]=0
 for site in d['sites']:
  if site['kind']=='pass':
   x,y=site['x'],site['y'];ps=raster([[x-43,y-43],[x+43,y+43]]);cv2.rectangle(ridge,tuple(ps[0]),tuple(ps[1]),0,-1)
 dist=cv2.distanceTransform((ridge>0).astype(np.uint8),cv2.DIST_L2,5)
 profile=np.minimum(1,dist/1.8);profile=profile*profile*(3-2*profile)
 clearance=cv2.distanceTransform(blocked,cv2.DIST_L2,5)
 edge=np.clip((clearance-3)/3,0,1);edge=edge*edge*(3-2*edge)
 height=ridge.astype(np.float32)*profile*edge
 step=2;ys=np.arange(0,H,step);xs=np.arange(0,W,step);yy,xx=np.meshgrid(ys,xs,indexing='ij')
 heights=height[yy,xx]*(.88+.12*np.cos(xx*.75+yy*.61)+.06*np.sin(xx*.033)*np.sin(yy*.046));safe=cv2.erode(blocked,np.ones((5,5),np.uint8),borderType=cv2.BORDER_CONSTANT,borderValue=0)[yy,xx]>0
 high=heights>.05;valid=safe[:-1,:-1]&safe[1:,:-1]&safe[:-1,1:]&safe[1:,1:]&(high[:-1,:-1]|high[1:,:-1]|high[:-1,1:]|high[1:,1:])
 jj,ii=np.nonzero(valid);used=np.zeros(heights.shape,bool);used[jj,ii]=1;used[jj+1,ii]=1;used[jj,ii+1]=1;used[jj+1,ii+1]=1
 ids=np.full(heights.shape,-1,np.int32);ids[used]=np.arange(used.sum());j,i=np.nonzero(used)
 vertices=np.column_stack((a+xs[i]/(W-1)*(c-a),heights[j,i],-(e-ys[j]/(H-1)*(e-b)))).astype('<f4')
 v0=ids[jj,ii];v1=ids[jj+1,ii];v2=ids[jj+1,ii+1];v3=ids[jj,ii+1]
 indices=np.column_stack((v0,v1,v2,v0,v2,v3)).astype('<u4').ravel();zone=zones[ys[j],xs[i]].astype('uint8')
 enc=lambda arr:base64.b64encode(arr.tobytes()).decode()
 d['terrain16']['mesh']={'positions':enc(vertices),'indices':enc(indices),'zones':enc(zone),'vertices':len(vertices),'triangles':len(indices)//3,'method':'Rounded native cliff ridges on a two-source-pixel grid, clipped to the original hatching; shared smooth normals.'}
 path.write_bytes(gzip.compress(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode(),compresslevel=5,mtime=0));print(path.name,len(vertices),len(indices)//3,flush=True)
