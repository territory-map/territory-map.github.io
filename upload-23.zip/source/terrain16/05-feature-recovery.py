"""Version 1.7: audit/recover native inland water and shallow monument contours.
No positions, collision triangles, map bounds or original map images are changed.
"""
from pathlib import Path
import gzip,json,base64,cv2,numpy as np
root=Path(__file__).resolve().parents[2];reports=[]
enc=lambda arr:base64.b64encode(arr.tobytes()).decode()
for path in sorted((root/'assets/data').glob('*.gz')):
 d=json.loads(gzip.decompress(path.read_bytes()));
 for recoveredSite in json.loads((Path(__file__).parent/'ruins17.json').read_text()):
  if recoveredSite['map']==d['catalog']['map'] and not any(s['id']==recoveredSite['id'] for s in d['sites']):d['sites'].append({k:v for k,v in recoveredSite.items() if k!='map'})
 t=d['terrain15'];a,b,c,e=d['catalog']['bounds'];slug=d['catalog']['map'];W=t['hatchingWidth'];H=t['hatchingHeight']
 native=cv2.imread(str(root/'assets/maps'/f'{slug}.webp'));im=cv2.resize(native,(W,H),interpolation=cv2.INTER_AREA)
 def raster(poly):return np.rint([[(x-a)/(c-a)*(W-1),(e-y)/(e-b)*(H-1)]for x,y in poly]).astype(np.int32)
 def world(cnt):return [[round(a+int(x)/(W-1)*(c-a),3),round(e-int(y)/(H-1)*(e-b),3)]for x,y in cnt.reshape(-1,2)]
 water=np.zeros((H,W),np.uint8)
 for i,poly in enumerate(t['waterPolygons']):
  cv2.fillPoly(water,[raster(poly)],255)
  for hole in t.get('waterHoles',{}).get(str(i),[]):cv2.fillPoly(water,[raster(hole)],0)
 edge=d['terrain16']['edge'];edgePixels=np.frombuffer(base64.b64decode(edge['rgba']),np.uint8).reshape(edge['size'],edge['size'],4)
 exterior=cv2.resize(np.maximum(edgePixels[:,:,0],edgePixels[:,:,2]),(W,H),interpolation=cv2.INTER_NEAREST)
 exterior=cv2.dilate(exterior,np.ones((11,11),np.uint8))
 blue,green,red=[x.astype(np.float32)for x in cv2.split(im)];hsv=cv2.cvtColor(im,cv2.COLOR_BGR2HSV)
 candidates=((green-red>18)&(blue-red>25)&(blue>green*.90)&(hsv[:,:,1]>70)&(exterior<64)).astype(np.uint8)*255
 candidates=cv2.morphologyEx(candidates,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
 n,labels,stats,centers=cv2.connectedComponentsWithStats(candidates);recovered=[];polys=list(t['waterPolygons']);holes=dict(t.get('waterHoles',{}))
 for i in range(1,n):
  x,y,w,h,area=stats[i]
  if area<9 or area>W*H*.01:continue
  component=(labels[y:y+h,x:x+w]==i).astype(np.uint8);coverage=np.count_nonzero(water[y:y+h,x:x+w][component>0])/area
  if coverage>.5:continue
  contours,hierarchy=cv2.findContours(component,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
  for j,q in enumerate(contours):
   if hierarchy[0,j,3]>=0 or cv2.contourArea(q)<5:continue
   q=cv2.approxPolyDP(q,.35,True)+[x,y];poly=world(q)
   if len(poly)<3:continue
   idx=len(polys);polys.append(poly);cv2.fillPoly(water,[q],255);inner=[];child=hierarchy[0,j,2]
   while child>=0:
    hole=contours[child]+[x,y]
    if cv2.contourArea(hole)>3:inner.append(world(hole));cv2.fillPoly(water,[hole],0)
    child=hierarchy[0,child,0]
   if inner:holes[str(idx)]=inner
   recovered.append({'x':round(a+centers[i,0]/(W-1)*(c-a),3),'y':round(e-centers[i,1]/(H-1)*(e-b),3),'areaPixels':int(area),'index':idx})
 # Merge overlapping old/new fragments before triangulation: a partial detection
 # must not draw a second shoreline through the middle of an existing lake.
 contours,hierarchy=cv2.findContours(water,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
 polys=[];holes={}
 if hierarchy is not None:
  for j,q in enumerate(contours):
   if hierarchy[0,j,3]>=0 or cv2.contourArea(q)<1:continue
   poly=world(cv2.approxPolyDP(q,.35,True))
   if len(poly)<3:continue
   idx=len(polys);polys.append(poly);inner=[];child=hierarchy[0,j,2]
   while child>=0:
    hole=world(cv2.approxPolyDP(contours[child],.35,True))
    if len(hole)>=3:inner.append(hole)
    child=hierarchy[0,child,0]
   if inner:holes[str(idx)]=inner
 for rec in recovered:rec.pop('index',None)
 d['terrain17']={'waterPolygons':polys,'waterHoles':holes,'recoveredLakes':recovered,'method':'Native inland chroma contours; coast/snow excluded, original lakes retained in union mask. Shallow monument relief follows native local edges.'}
 # All vertices in a buffered water footprint meet the ground; the safety buffer
 # also prevents neighbouring triangles and runtime smoothing entering a pond.
 wet=cv2.dilate(water,np.ones((13,13),np.uint8))
 mesh=d['terrain16']['mesh'];pos=np.frombuffer(base64.b64decode(mesh['positions']),'<f4').copy().reshape(-1,3)
 px=np.clip(np.rint((pos[:,0]-a)/(c-a)*(W-1)).astype(int),0,W-1);py=np.clip(np.rint((e+pos[:,2])/(e-b)*(H-1)).astype(int),0,H-1)
 flattened=int(np.count_nonzero((wet[py,px]>0)&(pos[:,1]>.1)));pos[wet[py,px]>0,1]=0
 # Ruin and camp footprints are kept separate from generic 9/16-unit hills.
 # Do not invent a wall where the native detailed map contains no contour.
 protected=np.zeros((H,W),np.uint8);siteRecords=[]
 for site in d['sites']:
  if site['kind']!='ancient-battlefield' and site.get('strongholdType')not in[29,30]:continue
  x,y=raster([[site['x'],site['y']]])[0];radius=110 if site['kind']=='ancient-battlefield'else 100;rx=round(radius/(c-a)*(W-1));ry=round(radius/(e-b)*(H-1));cv2.ellipse(protected,(int(x),int(y)),(rx,ry),0,0,360,255,-1)
  siteRecords.append({'id':site['id'],'kind':site['kind'],'type':site.get('strongholdType'),'x':site['x'],'y':site['y'],'radius':radius})
 pos[protected[py,px]>0,1]=np.minimum(pos[protected[py,px]>0,1],3.5)
 mesh['positions']=enc(pos)
 # Fine raised edges carry the original map colour instead of a generic hill cap.
 local=cv2.GaussianBlur(green,(0,0),2);dark=(green<local-8)&(green<165)&(red<green*1.24)
 detail=(dark&(protected>0)&(wet==0)&(exterior<64)).astype(np.uint8)
 # Leave pass openings and monument centres clear.
 for site in d['sites']:
  if site['kind']=='pass':
   ps=raster([[site['x']-43,site['y']-43],[site['x']+43,site['y']+43]]);cv2.rectangle(detail,tuple(ps[0]),tuple(ps[1]),0,-1)
  elif site['kind']=='ancient-battlefield' or site.get('strongholdType')in[29,30]:
   x,y=raster([[site['x'],site['y']]])[0];cv2.circle(detail,(int(x),int(y)),max(2,round(15/(c-a)*W)),0,-1)
 detail=cv2.dilate(detail,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3)))
 detail[(protected==0)|(wet>0)|(exterior>=64)]=0
 height=cv2.GaussianBlur(detail.astype(np.float32),(0,0),.65)*4.2
 yy,xx=np.nonzero(height>.12);ids=np.full((H,W),-1,np.int32);ids[yy,xx]=np.arange(len(xx));valid=(ids[:-1,:-1]>=0)&(ids[1:,:-1]>=0)&(ids[1:,1:]>=0)&(ids[:-1,1:]>=0);j,i=np.nonzero(valid)
 positions=np.column_stack((a+xx/(W-1)*(c-a),height[yy,xx],-(e-yy/(H-1)*(e-b)))).astype('<f4')
 indices=np.column_stack((ids[j,i],ids[j+1,i],ids[j+1,i+1],ids[j,i],ids[j+1,i+1],ids[j,i+1])).astype('<u4').ravel()
 d['terrain17']['details']={'positions':enc(positions),'indices':enc(indices),'vertices':len(positions)}
 for rec in siteRecords:
  x,y=raster([[rec['x'],rec['y']]])[0];rx=round(rec['radius']/(c-a)*(W-1));ry=round(rec['radius']/(e-b)*(H-1));rec['nativeContourPixels']=int(detail[max(0,y-ry):min(H,y+ry+1),max(0,x-rx):min(W,x+rx+1)].sum());rec['sourceDetail']='native-contours'if rec['nativeContourPixels']>30 else 'symbol-and-original-ground'
 d['terrain17']['siteAudit']=siteRecords
 # Index every ridge, lake and semantic site so none silently drops out of review.
 features=[]
 for i,q in enumerate(d['terrain16']['ridges']):
  points=np.asarray(q['outer']);features.append({'kind':'wall'if q['zone']else'rock','index':i,'x':float(points[:,0].mean()),'y':float(points[:,1].mean()),'bounds':[float(points[:,0].min()),float(points[:,1].min()),float(points[:,0].max()),float(points[:,1].max())]})
 for i,poly in enumerate(polys):
  points=np.asarray(poly);features.append({'kind':'lake','index':i,'x':float(points[:,0].mean()),'y':float(points[:,1].mean()),'bounds':[float(points[:,0].min()),float(points[:,1].min()),float(points[:,0].max()),float(points[:,1].max())]})
 for rec in siteRecords:features.append({'kind':'ruin'if rec['kind']=='ancient-battlefield'else'camp','index':rec['id'],'x':rec['x'],'y':rec['y'],'bounds':[rec['x']-110,rec['y']-110,rec['x']+110,rec['y']+110]})
 d['terrain17']['features']=features
 path.write_bytes(gzip.compress(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode(),compresslevel=5,mtime=0))
 report={'map':slug,'name':d['catalog']['name'],'recoveredLakes':len(recovered),'totalLakes':len(polys),'flattenedWaterVertices':flattened,'detailVertices':len(positions),'ruins':sum(s['kind']=='ancient-battlefield'for s in siteRecords),'camps':sum(s['kind']!='ancient-battlefield'for s in siteRecords),'sitesWithoutNativeContours':[s['id']for s in siteRecords if s['sourceDetail']!='native-contours'],'indexedFeatures':len(features)};reports.append(report);print(report,flush=True)
(root/'tests/feature-audit-v17.json').write_text(json.dumps({'maps':reports,'coverage':'All native ridge/lake contours and all supplied ruin/camp sites indexed and processed; semantic reconstruction limited by source resolution.'},indent=2),encoding='utf-8')
