"""Recover the dark part of seeded native lakes; keep all source topology/positions.
Only native blue/cyan colour regions connected to an existing water seed qualify.
The footprint is constrained to 18 source pixels around that seed. All resulting
water and a bank margin are projected to ground level in both relief meshes.
"""
from pathlib import Path
import gzip,json,base64,cv2,numpy as np
root=Path(__file__).resolve().parents[2];reports=[];passTypes={10:1,11:2,15:3,45:4,46:5,47:6,51:7,52:8,53:9,54:10}
for path in sorted((root/'assets/data').glob('*.gz')):
 d=json.loads(gzip.decompress(path.read_bytes()));t=d['terrain15'];a,b,c,e=d['catalog']['bounds'];W,H=t['hatchingWidth'],t['hatchingHeight'];slug=d['catalog']['map']
 def raster(poly):return np.rint([[(x-a)/(c-a)*(W-1),(e-y)/(e-b)*(H-1)]for x,y in poly]).astype(np.int32)
 def world(q):return [[round(a+float(x)/(W-1)*(c-a),3),round(e-float(y)/(H-1)*(e-b),3)]for x,y in q.reshape(-1,2)]
 water=np.zeros((H,W),np.uint8)
 for i,p in enumerate(d['terrain17']['waterPolygons']):
  cv2.fillPoly(water,[raster(p)],255)
  for hole in d['terrain17'].get('waterHoles',{}).get(str(i),[]):cv2.fillPoly(water,[raster(hole)],0)
 im=cv2.resize(cv2.imread(str(root/'assets/maps'/f'{slug}.webp')),(W,H),interpolation=cv2.INTER_AREA);blue,green,red=[v.astype(np.float32)for v in cv2.split(im)];hsv=cv2.cvtColor(im,cv2.COLOR_BGR2HSV)
 edge=d['terrain16']['edge'];ep=np.frombuffer(base64.b64decode(edge['rgba']),np.uint8).reshape(edge['size'],edge['size'],4);exterior=cv2.resize(ep[:,:,:3].max(axis=2),(W,H),interpolation=cv2.INTER_NEAREST)
 near=cv2.dilate(water,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(37,37)))
 allowed=((blue-red>4)&(green-red>3)&(blue>green*.78)&(hsv[:,:,0]>=70)&(hsv[:,:,0]<=125)&(hsv[:,:,1]>34)&(exterior<64)&(near>0)).astype(np.uint8)*255
 allowed=cv2.morphologyEx(allowed,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8));allowed[exterior>=64]=0
 n,labels,stats,_=cv2.connectedComponentsWithStats(allowed);seedLabels=np.unique(labels[water>0]);keep=np.zeros(n,np.uint8)
 for k in seedLabels:
  if k and stats[k,cv2.CC_STAT_AREA]<W*H*.005:keep[k]=255
 recovered=keep[labels];expanded=int(np.count_nonzero((water==0)&(recovered>0)));water=np.maximum(water,recovered)
 polys=[];holes={};contours,h=cv2.findContours(water,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
 if h is not None:
  for j,q in enumerate(contours):
   if h[0,j,3]>=0 or cv2.contourArea(q)<1:continue
   poly=world(cv2.approxPolyDP(q,.25,True))
   if len(poly)<3:continue
   ix=len(polys);polys.append(poly);child=h[0,j,2];inside=[]
   while child>=0:
    hp=world(cv2.approxPolyDP(contours[child],.25,True))
    if len(hp)>=3:inside.append(hp)
    child=h[0,child,0]
   if inside:holes[str(ix)]=inside
 wet=cv2.dilate(water,np.ones((13,13),np.uint8));changes={}
 for name,mesh in [('ridge',d['terrain16']['mesh']),('detail',d['terrain17']['details'])]:
  pos=np.frombuffer(base64.b64decode(mesh['positions']),'<f4').copy().reshape(-1,3)
  px=np.clip(np.rint((pos[:,0]-a)/(c-a)*(W-1)).astype(int),0,W-1);py=np.clip(np.rint((e+pos[:,2])/(e-b)*(H-1)).astype(int),0,H-1)
  selected=wet[py,px]>0;changes[name]=int(np.count_nonzero(selected&(pos[:,1]>.1)));pos[selected,1]=0;mesh['positions']=base64.b64encode(pos.tobytes()).decode()
  assert not np.any(pos[selected,1]>.1)
 d['terrain17']['waterPolygons']=polys;d['terrain17']['waterHoles']=holes
 features=[f for f in d['terrain17']['features']if f['kind']!='lake']
 for i,p in enumerate(polys):
  q=np.asarray(p);features.append({'kind':'lake','index':i,'x':float(q[:,0].mean()),'y':float(q[:,1].mean()),'bounds':[float(q[:,0].min()),float(q[:,1].min()),float(q[:,0].max()),float(q[:,1].max())]})
 d['terrain17']['features']=features
 passes=[]
 for s in d['sites']:
  if s['kind']!='pass':continue
  level=s.get('level');expected=passTypes.get(s.get('strongholdType'));passes.append({'id':s['id'],'level':level,'typeLevel':expected,'source':s.get('source'),'status':'unresolved'if not level or level<1 else 'conflict'if expected and expected!=level else 'source-consistent'})
 result={'map':slug,'name':d['catalog']['name'],'waterPixelsAdded':expanded,'waterPolygons':len(polys),'groundedVertices':changes,'featuresChecked':len(features),'passes':passes,'ruinsWithUnifiedArt':sum(s['kind']=='ancient-battlefield'and s.get('strongholdType')==39 and 'Ra'not in s.get('label','')for s in d['sites']),'nativeImageUnchanged':True,'shapeXZUnchanged':True}
 d['terrain18']={'waterMethod':'Seeded native blue/cyan region completion; bounded to 18 native pixels. Ground-level lake and bank clearance.','expandedPixels':expanded}
 path.write_bytes(gzip.compress(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode(),compresslevel=5,mtime=0));reports.append(result);print(slug,'expanded',expanded,'lakes',len(polys),'passes',len(passes),flush=True)
(root/'tests/map-audit-v18.json').write_text(json.dumps({'maps':reports,'manualEveryContour':False},indent=2),encoding='utf-8')
