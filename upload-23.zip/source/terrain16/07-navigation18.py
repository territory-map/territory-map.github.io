"""Build ground-connected regions from the displayed native obstruction mask.
Close each known pass aperture while labelling; openings are graph edges that
require explicit alliance capture. No changes to native map images/positions.
"""
from pathlib import Path
import gzip,json,base64,cv2,numpy as np
root=Path(__file__).resolve().parents[2];report=[]
for path in sorted((root/'assets/data').glob('*.gz')):
 d=json.loads(gzip.decompress(path.read_bytes()));t=d['terrain15'];w,h=t['hatchingWidth'],t['hatchingHeight'];a,b,c,e=d['catalog']['bounds'];raw=np.frombuffer(base64.b64decode(t['hatching']),np.uint8)
 mask=np.unpackbits(raw)[:w*h].reshape(h,w).astype(np.uint8) if t.get('hatchingPacked') else (raw.reshape(h,w)>0).astype(np.uint8)
 def px(x,y):return round((x-a)/(c-a)*(w-1)),round((e-y)/(e-b)*(h-1))
 # The completed water footprint is blocked in the same mask that is displayed.
 for i,poly in enumerate(d['terrain17']['waterPolygons']):
  lake=np.zeros_like(mask);cv2.fillPoly(lake,[np.array([px(x,y) for x,y in poly],np.int32)],1)
  for hole in d['terrain17'].get('waterHoles',{}).get(str(i),[]):cv2.fillPoly(lake,[np.array([px(x,y)for x,y in hole],np.int32)],0)
  mask|=lake
 t['hatching']=base64.b64encode(np.packbits(mask.reshape(-1)).tobytes()).decode();t['hatchingPacked']=True
 closed=mask.copy();passes=[s for s in d['sites'] if s['kind']=='pass']
 for s in passes:cv2.rectangle(closed,px(s['x']-55,s['y']+55),px(s['x']+55,s['y']-55),1,-1)
 closed=cv2.morphologyEx(closed,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8));closed[:2]=closed[-2:]=1;closed[:,:2]=closed[:,-2:]=1
 # Never connect outside the playable boundary.
 edge=d['terrain16']['edge'];ed=np.frombuffer(base64.b64decode(edge['rgba']),np.uint8).reshape(edge['size'],edge['size'],4)
 exterior=cv2.resize(ed[:,:,:3].max(axis=2),(w,h),interpolation=cv2.INTER_NEAREST);closed[exterior>=64]=1
 n,labels,stats,_=cv2.connectedComponentsWithStats(1-closed,connectivity=4);ids=np.zeros(n,np.uint16);kept=[k for k in range(1,n) if stats[k,4]>=max(40,w*h*.000025)]
 for j,k in enumerate(kept):ids[k]=j+1
 labels=ids[labels];edges={};unresolved=[]
 for s in passes:
  cx,cy=px(s['x'],s['y']);rx=round(105/(c-a)*w);ry=round(105/(e-b)*h);lo,hi=max(0,cx-rx),min(w,cx+rx+1);top,bot=max(0,cy-ry),min(h,cy+ry+1)
  yy,xx=np.mgrid[top:bot,lo:hi];dx=(xx-cx)*(c-a)/w;dy=(yy-cy)*(e-b)/h;ring=(np.maximum(abs(dx),abs(dy))>=57)&(np.maximum(abs(dx),abs(dy))<=100)
  vals,counts=np.unique(labels[top:bot,lo:hi][ring],return_counts=True);rank=sorted([(int(ct),int(v)) for v,ct in zip(vals,counts) if v and ct>8],reverse=True)
  regions=[v for ct,v in rank[:2]];edges[s['id']]=regions
  if len(regions)!=2:unresolved.append(s['id'])
 d['navigation18']={'width':w,'height':h,'bounds':[a,b,c,e],'regions':base64.b64encode(labels.astype('<u2').tobytes()).decode(),'passes':edges,'regionCount':len(kept),'method':'Native obstruction components, closed known pass apertures, explicit capture edges; no province-grid boundary inference.'}
 path.write_bytes(gzip.compress(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode(),compresslevel=5,mtime=0))
 item={'map':d['catalog']['map'],'regions':len(kept),'passes':len(passes),'unresolvedEdges':unresolved};report.append(item);print(item,flush=True)
(root/'tests/navigation-v18.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
