"""The worker needs collisions and navigation, never rendering meshes/textures."""
from pathlib import Path
import gzip,json
root=Path(__file__).resolve().parents[2];out=root/'assets/solver';out.mkdir(exist_ok=True)
for p in sorted((root/'assets/data').glob('*.gz')):
 d=json.loads(gzip.decompress(p.read_bytes()));keys=['catalog','sites','resources','definitions','instances','province','passRotations','navigation18'];small={k:d[k]for k in keys if k in d};small['terrain15']={k:d['terrain15'][k]for k in ['hatching','hatchingWidth','hatchingHeight','hatchingPacked']}
 (out/p.name).write_bytes(gzip.compress(json.dumps(small,separators=(',',':'),ensure_ascii=False).encode(),compresslevel=6,mtime=0));print(d['catalog']['map'],flush=True)
