"""Second audit pass: native water colour, including previously unseeded lobes.
Exclude exterior/snow shadows. Flatten every terrain mesh at water and banks.
"""
from pathlib import Path
import gzip,json,base64,cv2,numpy as np
root=Path(__file__).resolve().parents[2];report=[]
for path in sorted((root/'assets/data').glob('*.gz')):
 d=json.loads(gzip.decompress(path.read_bytes()));t=d['terrain15'];w,h=t['hatchingWidth'],t['hatchingHeight'];a,b,c,e=d['catalog']['bounds'];im=cv2.resize(cv2.imread(str(root/'assets/maps'/f"{d['catalog']['map']}.webp")),(w,h));blue,green,red=[v.astype(np.float32)for v in cv2.split(im)];hsv=cv2.cvtColor(im,cv2.COLOR_BGR2HSV)
 raw=np.frombuffer(base64.b64decode(t['hatching']),np.uint8);hatch=np.unpackbits(raw)[:w*h].reshape(h,w)
 edge=d['terrain16']['edge'];ed=np.frombuffer(base64.b64decode(edge['rgba']),np.uint8).reshape(edge['size'],edge['size'],4);exterior=cv2.resize(ed[:,:,:3].max(axis=2),(w,h),interpolation=cv2.INTER_NEAREST)
 # Dark blue snow shadows can have the same hue as water. Reject their
 # immediate pale surroundings as well as the classified outer terrain.
 pale=((hsv[:,:,1]<65)&(hsv[:,:,2]>110)).astype(np.uint8)
 edgeNeighbour=cv2.dilate((exterior>=16).astype(np.uint8),np.ones((101,101),np.uint8))>0
 excluded=cv2.dilate(((exterior>=32)|((pale>0)&edgeNeighbour)).astype(np.uint8),np.ones((25,25),np.uint8))>0
 # All significant native blue-green components in obstructed terrain. White
 # snow, olive shadows and isolated blue decoration on grass are not lakes.
 seeds=((blue-red>5)&(green-red>3)&(blue>green*.78)&(hsv[:,:,0]>=70)&(hsv[:,:,0]<=118)&(hsv[:,:,1]>40)&(~excluded)&(hatch>0))
 # Follow the complete blue-green shore, including darker/antialiased lobes
 # outside the older obstruction mask. A component needs a confirmed seed.
 wet=((blue-red>-3)&(green-red>2)&(blue>green*.65)&(hsv[:,:,0]>=68)&(hsv[:,:,0]<=118)&(hsv[:,:,1]>25)&(~excluded)).astype(np.uint8)
 wet=cv2.morphologyEx(wet,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8));wet[excluded]=0
 n,labels,stats,_=cv2.connectedComponentsWithStats(wet);keep=np.zeros(n,np.uint8);seeded=np.bincount(labels[seeds],minlength=n)>0
 for k in range(1,n):
  if 6<=stats[k,4]<w*h*.005 and seeded[k]:keep[k]=1
 wet=keep[labels];contours,hierarchy=cv2.findContours(wet,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE);polys=[];holes={}
 def world(q):return [[round(a+float(x)/(w-1)*(c-a),3),round(e-float(y)/(h-1)*(e-b),3)]for x,y in q.reshape(-1,2)]
 if hierarchy is not None:
  for j,q in enumerate(contours):
   if hierarchy[0,j,3]>=0 or cv2.contourArea(q)<3:continue
   p=world(cv2.approxPolyDP(q,.25,True))
   if len(p)<3:continue
   ix=len(polys);polys.append(p);inside=[];child=hierarchy[0,j,2]
   while child>=0:
    hp=world(cv2.approxPolyDP(contours[child],.25,True))
    if len(hp)>=3:inside.append(hp)
    child=hierarchy[0,child,0]
   if inside:holes[str(ix)]=inside
 bank=cv2.dilate(wet,np.ones((17,17),np.uint8));changed={}
 for name,mesh in [('ridge',d['terrain16']['mesh']),('details',d['terrain17']['details']),('snow',d['terrain16']['snowMesh'])]:
  encoded=isinstance(mesh['positions'],str);pos=(np.frombuffer(base64.b64decode(mesh['positions']),'<f4').copy() if encoded else np.array(mesh['positions'],dtype=np.float32)).reshape(-1,3)
  px=np.clip(np.rint((pos[:,0]-a)/(c-a)*(w-1)).astype(int),0,w-1);py=np.clip(np.rint((e+pos[:,2])/(e-b)*(h-1)).astype(int),0,h-1);sel=bank[py,px]>0;changed[name]=int(np.count_nonzero(sel&(pos[:,1]>.1)));pos[sel,1]=0
  mesh['positions']=base64.b64encode(pos.astype('<f4').tobytes()).decode() if encoded else pos.reshape(-1).tolist()
 previous=len(d['terrain17']['waterPolygons']);d['terrain17']['waterPolygons']=polys;d['terrain17']['waterHoles']=holes
 f=[q for q in d['terrain17']['features']if q['kind']!='lake']
 for i,p in enumerate(polys):
  q=np.array(p);f.append({'kind':'lake','index':i,'x':float(q[:,0].mean()),'y':float(q[:,1].mean()),'bounds':[float(q[:,0].min()),float(q[:,1].min()),float(q[:,0].max()),float(q[:,1].max())]})
 d['terrain17']['features']=f;d['terrain18']['nativeWaterRevalidation']=True;d['terrain18']['waterMethod']='Complete native blue-green components within obstruction footprint; snow/exterior excluded, all relief flattened at water and bank.'
 path.write_bytes(gzip.compress(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode(),compresslevel=5,mtime=0));item={'map':d['catalog']['map'],'previousLakes':previous,'nativeLakes':len(polys),'additionalGroundedVertices':changed,'exteriorWaterPixels':int(np.count_nonzero((wet>0)&(exterior>=32)))};report.append(item);print(item,flush=True)
(root/'tests/water-native-v18.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
