"""Colour genuine internal zone barriers using ground-region adjacency.
Mesh positions and triangle indices are unchanged. Small enclosed rock pockets
are excluded, so ordinary hills keep their native palette.
"""
from pathlib import Path
import gzip,json,base64,cv2,numpy as np
root=Path(__file__).resolve().parents[2];report=[]
for path in sorted((root/'assets/data').glob('*.gz')):
 d=json.loads(gzip.decompress(path.read_bytes()));nav=d['navigation18'];w,h=nav['width'],nav['height'];a,b,c,e=d['catalog']['bounds'];labels=np.frombuffer(base64.b64decode(nav['regions']),'<u2').reshape(h,w);counts=np.bincount(labels.ravel());near=np.zeros((h,w),np.uint8)
 radius=max(3,round(43/(c-a)*(w-1)));kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(radius*2+1,radius*2+1))
 for k in range(1,len(counts)):
  if counts[k]>=w*h*.001:near+=cv2.dilate((labels==k).astype(np.uint8),kernel)
 def pixels(p):return np.clip(np.rint((p[:,0]-a)/(c-a)*(w-1)).astype(int),0,w-1),np.clip(np.rint((e-p[:,1])/(e-b)*(h-1)).astype(int),0,h-1)
 mesh=d['terrain16']['mesh'];pos=np.frombuffer(base64.b64decode(mesh['positions']),'<f4').reshape(-1,3);old=np.frombuffer(base64.b64decode(mesh['zones']),np.uint8);px,py=pixels(np.column_stack((pos[:,0],-pos[:,2])));zones=np.maximum(old,(near[py,px]>=2).astype(np.uint8));mesh['zones']=base64.b64encode(zones.tobytes()).decode()
 promoted=0
 for ridge in d['terrain16']['ridges']:
  q=np.asarray(ridge['outer']);px,py=pixels(q)
  if np.mean(near[py,px]>=2)>.15 and not ridge['zone']:ridge['zone']=True;promoted+=1
 for feature in d['terrain17']['features']:
  if feature['kind'] in ['wall','rock'] and feature['index']<len(d['terrain16']['ridges']):feature['kind']='wall'if d['terrain16']['ridges'][feature['index']]['zone']else'rock'
 d['terrain18']['zoneColourMethod']='Native ground-region adjacency (large regions), combined with original zone barriers; no geometry movement.'
 path.write_bytes(gzip.compress(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode(),compresslevel=5,mtime=0));r={'map':d['catalog']['map'],'previousZoneVertices':int(np.count_nonzero(old)),'zoneVertices':int(np.count_nonzero(zones)),'promotedRidges':promoted};report.append(r);print(r,flush=True)
(root/'tests/zone-colours-v18.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
