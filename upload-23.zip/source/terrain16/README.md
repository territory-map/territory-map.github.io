# Gelände 1.6 neu berechnen

Die vier Python-Dateien in ihrer nummerierten Reihenfolge ausführen. Nur die Entwicklung benötigt NumPy und OpenCV; der normale Start benötigt Python und einen Browser.

1. Native Felskonturen innerhalb der originalen Schraffierung bestimmen.
2. Außenrand aus der detaillierten 2D-Karte klassifizieren. Der helle Vorlandsaum wird bis zur äußeren Kartengrenze fortgesetzt; zusammenhängendes Küstenmeer wird ausgeschlossen. Orléans verwendet Fels, die übrigen detaillierten Kartenvorlagen verschneite Randberge. Die unterschiedlichen Meerfarben von Troy und den Britain-Varianten stammen aus den zusätzlich gelieferten Übersichtskarten.
3. Randgebirge als kontinuierliche Oberfläche mit wechselnden Höhen erzeugen. Durchgänge und Wasser bleiben frei.
4. Innere Felsflächen auf einem Raster von zwei Originalbildpunkten aufbauen. Umschließende Ringe werden zuerst gezeichnet, damit ihre Innenräume keine eingebetteten Hügel löschen. Beim Laden werden Höhen und Bodenkontaktnormalen geglättet; die Kartenkoordinaten bleiben unverändert.

Die Übersichtsbilder und ZIP-Ausschnitte dienen als Referenz für Kartenaufbau und Farben. Ihre nicht registrierten Bildkoordinaten ersetzen keine nativen Konturen. `reference-maps.json` dokumentiert die Zuordnung, Dateigrößen und Prüfsummen der 19 Bilder und 6 Archive. Diese zusätzlichen Referenzdateien sind nicht im Paket dupliziert; die für die Neuberechnung benötigten nativen Detailkarten sind enthalten.

Höhen sind rekonstruierte Darstellungswerte, keine aus dem Spiel exportierten Höhen. Die automatische Geometrieprüfung kontrolliert alle 21 Karten auf freie Pässe, Grenzen der Schraffierung und erhaltene innere Felsnetze. Die Außenrandprüfung kontrolliert Küsten und Materialzuordnung.
