# Gelände für 2.3.0 erzeugen

Ausgangsdaten: vollständige 2.2.0-Daten. Python mit NumPy und OpenCV wird nur für die Entwicklung benötigt.

In dieser Reihenfolge ausführen:

1. `python source/terrain230/exterior.py`
2. `python source/terrain230/exterior-mesh.py`
3. `python source/terrain230/rebuild.py`
4. `python tests/terrain230.py --baseline PFAD_ZUR_2.2.0.zip`
5. `node tests/run230.mjs`

Keine kartenspezifische Ausnahme für die neuen Konturen: lokale Helligkeitsunterschiede erkennen Felsen auch auf braunem Sand. Native Schraffierung, registrierte Gewässer und Passkerne begrenzen die Höhen. Geschlossene Wandoberseiten werden nur gefüllt, wenn jeder eingeschlossene Pixel innerhalb der erlaubten Reliefmaske liegt. Keine offenen Laufwege oder Seen werden gefüllt. Die Darstellung verwendet an jeder Position die ursprünglichen Bildkoordinaten, einschließlich Quellenbeschriftung am Rand.

Die Höhen sind eine Rekonstruktion aus 2D-Konturen, keine exportierten Höhenmessungen des Spiels. Maßstab, Koordinaten, Bauverbote und Solver-Daten bleiben erhalten. Die historischen Generatoren in terrain16 dokumentieren ältere Versionen und sollen nicht über den aktuellen Daten ausgeführt werden.
