from pathlib import Path
import gzip,json,base64,cv2,numpy as np
root=Path(__file__).resolve().parents[2];reports=[]
for path in (root/'assets/data').glob('*.gz'):
 d=json.loads(gzip.decompress(path.read_bytes()));t=d['terrain15'];a,b,c,e=d['catalog']['bounds'];W=t['hatchingWidth'];H=t['hatchingHeight']
 blocked=np.unpackbits(np.frombuffer(base64.b64decode(t['hatching']),np.uint8))[:W*H].reshape(H,W)
 snow=cv2.resize(np.array(t['snowGrid'],np.uint8).reshape(256,256),(W,H),interpolation=cv2.INTER_LINEAR)
 edge_data=d['terrain16']['edge'];edge_rgba=np.frombuffer(base64.b64decode(edge_data['rgba']),np.uint8).reshape(edge_data['size'],edge_data['size'],4)
 snow_zone=(cv2.resize(edge_rgba[:,:,0],(W,H),interpolation=cv2.INTER_LINEAR)>127).astype(np.uint8)
 mask=(snow_zone&(blocked>0)).astype(np.uint8)
 # Exterior mountains follow native foothills; pass openings and water stay flat.
 def pixel(x,y):return (int(round((x-a)/(c-a)*(W-1))),int(round((e-y)/(e-b)*(H-1))))
 for site in d['sites']:
  if site['kind']=='pass':cv2.rectangle(mask,pixel(site['x']-18,site['y']-18),pixel(site['x']+18,site['y']+18),0,-1)
 for poly in t['waterPolygons']:
  if len(poly)>2:cv2.fillPoly(mask,[np.array([pixel(x,y) for x,y in poly],np.int32)],0)
 dist=cv2.distanceTransform(mask,cv2.DIST_L2,5)
 safe=cv2.erode(mask,np.ones((7,7),np.uint8),borderType=cv2.BORDER_CONSTANT,borderValue=0)
 step=4;ys=np.arange(0,H,step);xs=np.arange(0,W,step);yy,xx=np.meshgrid(ys,xs,indexing='ij')
 im=cv2.imread(str(root/'assets/maps'/f"{d['catalog']['map']}.webp"));gray=cv2.resize(cv2.cvtColor(im,cv2.COLOR_BGR2GRAY),(W,H));gray=cv2.GaussianBlur(gray,(0,0),5)
 edge=np.clip((dist[yy,xx]-5)/14.0,0,1);edge=edge*edge*(3-2*edge)
 shade=np.clip((210-gray[yy,xx].astype(float))/80,0,1)
 height=edge*np.maximum(0,18+shade*26+12*np.sin(xx*.024+yy*.031)+7*np.sin(xx*.071-yy*.048))
 height=np.minimum(height,np.maximum(0,dist[yy,xx]-5)*min((c-a)/(W-1),(e-b)/(H-1))*1.3)
 active=safe[yy,xx]>0;valid=active[:-1,:-1]&active[1:,:-1]&active[:-1,1:]&active[1:,1:]
 # Each cell is fully within an eroded native mask, not only its corner samples.
 ids={};verts=[];indices=[]
 def vertex(j,i):
  key=(j,i)
  if key not in ids:
   ids[key]=len(verts)//3;verts.extend([round(a+xs[i]/(W-1)*(c-a),3),round(float(height[j,i]),3),round(-(e-ys[j]/(H-1)*(e-b)),3)])
  return ids[key]
 for j,i in np.argwhere(valid):
  q=[vertex(j,i),vertex(j+1,i),vertex(j+1,i+1),vertex(j,i+1)];indices.extend([q[0],q[2],q[1],q[0],q[3],q[2]])
 d['terrain16']['snowMesh']={'positions':verts,'indices':indices}
 d['terrain16']['snowMask']=base64.b64encode(np.packbits(snow_zone.ravel()).tobytes()).decode()
 for ridge in d['terrain16']['ridges']:
  values=[snow[min(H-1,max(0,pixel(x,y)[1])),min(W-1,max(0,pixel(x,y)[0]))] for x,y in ridge['outer']]
  ridge['snow']=bool(np.mean(values)>80)
 path.write_bytes(gzip.compress(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode(),compresslevel=5,mtime=0))
 report={'map':d['catalog']['map'],'snowVertices':len(verts)//3,'snowTriangles':len(indices)//3};reports.append(report);print(report,flush=True)
(root/'tests/snow-v230.json').write_text(json.dumps({'passed':True,'maps':reports},indent=2))
