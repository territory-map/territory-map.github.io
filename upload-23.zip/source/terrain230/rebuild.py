"""Rebuild native relief for every biome, keeping gameplay and source art intact.

Requires Python, numpy and opencv-python. Run from any directory. No network.
The 2.2.0 gameplay masks, water, navigation and site coordinates are authoritative.
"""
from pathlib import Path
import gzip, json, base64, cv2, numpy as np

ROOT = Path(__file__).resolve().parents[2]
enc = lambda a: base64.b64encode(a.tobytes()).decode()

def rebuild(path):
 d = json.loads(gzip.decompress(path.read_bytes()))
 t = d['terrain15']; a,b,c,e = d['catalog']['bounds']
 W,H = t['hatchingWidth'],t['hatchingHeight']
 im = cv2.resize(cv2.imread(str(ROOT/'assets/maps'/f"{d['catalog']['map']}.webp")), (W,H), interpolation=cv2.INTER_AREA)
 blocked = np.unpackbits(np.frombuffer(base64.b64decode(t['hatching']),np.uint8))[:W*H].reshape(H,W)
 def raster(poly):
  return np.rint([[(x-a)/(c-a)*(W-1),(e-y)/(e-b)*(H-1)] for x,y in poly]).astype(np.int32)
 def contours(mask):
  cs,hi = cv2.findContours(mask,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
  return cs,hi
 def world(cnt):
  pts=cv2.approxPolyDP(cnt,.65,True).reshape(-1,2)
  return [[round(a+float(x)/(W-1)*(c-a),3),round(e-float(y)/(H-1)*(e-b),3)] for x,y in pts]
 water=np.zeros((H,W),np.uint8)
 wt=d['terrain17']
 for i,p in enumerate(wt['waterPolygons']):
  cv2.fillPoly(water,[raster(p)],1)
  for hole in wt.get('waterHoles',{}).get(str(i),[]):cv2.fillPoly(water,[raster(hole)],0)
 wet=cv2.dilate(water,np.ones((13,13),np.uint8))
 passmask=np.zeros_like(blocked)
 for site in d['sites']:
  if site['kind']=='pass':
   # Keep the passage core flat; native hatching supplies the full real opening.
   # The old +/-43 square erased the wall shoulders as well as the passage.
   ps=raster([[site['x']-18,site['y']-18],[site['x']+18,site['y']+18]])
   cv2.rectangle(passmask,tuple(ps[0]),tuple(ps[1]),1,-1)
 snow=np.unpackbits(np.frombuffer(base64.b64decode(d['terrain16']['snowMask']),np.uint8))[:W*H].reshape(H,W)
 allowed=cv2.erode(blocked,np.ones((3,3),np.uint8),borderType=cv2.BORDER_CONSTANT,borderValue=0)
 allowed[(wet>0)|(passmask>0)|(snow>0)]=0
 # Local luminance contrast is independent of grass/sand hue. Green/red gates
 # formerly discarded the Nile's brown cliffs, despite matching native hatching.
 gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY).astype(np.float32)
 local=cv2.GaussianBlur(gray,(0,0),4)
 dark=((local-gray)>4).astype(np.uint8)
 ridge=cv2.dilate(dark,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5)))
 ridge=cv2.morphologyEx(ridge,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5)))
 ridge[allowed==0]=0
 n,labels,stats,_=cv2.connectedComponentsWithStats(ridge)
 keep=np.zeros(n,np.uint8);keep[1:]=(stats[1:,cv2.CC_STAT_AREA]>=32)
 ridge=keep[labels]
 # Large ground regions on both sides distinguish a zone barrier from a hill.
 nav=d['navigation18'];nw,nh=nav['width'],nav['height']
 regions=np.frombuffer(base64.b64decode(nav['regions']),'<u2').reshape(nh,nw)
 sizes=np.bincount(regions.ravel());near=np.zeros((nh,nw),np.uint8)
 radius=max(3,round(43/(c-a)*(nw-1)))
 kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*radius+1,2*radius+1))
 for k in range(1,len(sizes)):
  if sizes[k]>=nw*nh*.001:near+=cv2.dilate((regions==k).astype(np.uint8),kernel)
 zones=cv2.resize((near>=2).astype(np.uint8),(W,H),interpolation=cv2.INTER_NEAREST)
 # Follow a barrier's connected native footprint to its pass shoulders. Region
 # adjacency alone stops too early at the opening and leaves grey, lower ends.
 footprint=blocked.copy();footprint[(snow>0)|(wet>0)|(passmask>0)]=0
 nc,cc,st,_=cv2.connectedComponentsWithStats(footprint)
 hits=np.bincount(cc.ravel(),weights=zones.ravel(),minlength=nc)
 wall=np.zeros(nc,np.uint8)
 span=np.maximum(st[:,cv2.CC_STAT_WIDTH]*(c-a)/W,st[:,cv2.CC_STAT_HEIGHT]*(e-b)/H)
 wall[1:]=((hits[1:]/np.maximum(1,st[1:,cv2.CC_STAT_AREA])>.035)&(span[1:]>140))
 zones=np.maximum(zones,wall[cc])
 # A dark outline around a solid wall top is not a hole in that wall. Close
 # enclosed tops only when EVERY enclosed pixel is still forbidden dry terrain.
 # Real traversable clearings, ponds and pass openings therefore remain open.
 cs,hi=contours(ridge)
 if hi is not None:
  for k,q in enumerate(cs):
   if hi[0,k,3]<0 or zones[q[:,0,1],q[:,0,0]].mean()<.5:continue
   x,y,w,h=cv2.boundingRect(q);inside=np.zeros((h,w),np.uint8)
   cv2.fillPoly(inside,[q-[x,y]],1)
   if np.all(allowed[y:y+h,x:x+w][inside>0]):
    patch=ridge[y:y+h,x:x+w];patch[inside>0]=1
 cs,hi=contours(ridge);polys=[]
 for i,q in enumerate(cs):
  if hi[0,i,3]>=0 or cv2.contourArea(q)<2:continue
  x,y,w,h=cv2.boundingRect(q)
  zone=bool(max(w*(c-a)/W,h*(e-b)/H)>600 or zones[q[:,0,1],q[:,0,0]].mean()>.15)
  if zone:cv2.drawContours(zones,cs,i,1,-1)
  holes=[];child=hi[0,i,2]
  while child>=0:
   hole=world(cs[child])
   if len(hole)>=3:holes.append(hole)
   child=hi[0,child,0]
  outer=world(q)
  if len(outer)>=3:polys.append({'outer':outer,'holes':holes,'height':16 if zone else 9,'zone':zone,'snow':False})
 dist=cv2.distanceTransform(ridge,cv2.DIST_L2,5)
 profile=np.minimum(1,dist/2);profile=profile*profile*(3-2*profile)
 clearance=cv2.distanceTransform(allowed,cv2.DIST_L2,5)
 edge=np.clip((clearance-2)/2,0,1);edge=edge*edge*(3-2*edge)
 height=(9+7*zones)*profile*edge
 # Existing special-site relief stays shallow; do not turn ruins into walls.
 protected=np.zeros_like(blocked)
 for site in d['sites']:
  if site['kind']=='ancient-battlefield' or site.get('strongholdType') in [29,30]:
   x,y=raster([[site['x'],site['y']]])[0];r=110 if site['kind']=='ancient-battlefield' else 100
   cv2.ellipse(protected,(int(x),int(y)),(round(r/(c-a)*(W-1)),round(r/(e-b)*(H-1))),0,0,360,1,-1)
 height[protected>0]=np.minimum(height[protected>0],3.5)
 step=2;ys=np.arange(0,H,step);xs=np.arange(0,W,step);yy,xx=np.meshgrid(ys,xs,indexing='ij')
 heights=height[yy,xx]*(.93+.055*np.cos(xx*.35+yy*.29))
 safe=cv2.erode(blocked,np.ones((5,5),np.uint8),borderType=cv2.BORDER_CONSTANT,borderValue=0)[yy,xx]>0
 high=heights>.05
 valid=safe[:-1,:-1]&safe[1:,:-1]&safe[:-1,1:]&safe[1:,1:]&(high[:-1,:-1]|high[1:,:-1]|high[:-1,1:]|high[1:,1:])
 jj,ii=np.nonzero(valid);used=np.zeros(heights.shape,bool)
 used[jj,ii]=1;used[jj+1,ii]=1;used[jj,ii+1]=1;used[jj+1,ii+1]=1
 # Explicit boundary contacts. This is topology, not a triangle-valence guess.
 cellCount=np.zeros(heights.shape,np.uint8)
 for dy,dx in [(0,0),(1,0),(0,1),(1,1)]:cellCount[dy:dy+valid.shape[0],dx:dx+valid.shape[1]]+=valid
 heights[cellCount<4]=0
 ids=np.full(heights.shape,-1,np.int32);ids[used]=np.arange(used.sum());j,i=np.nonzero(used)
 pos=np.column_stack((a+xs[i]/(W-1)*(c-a),heights[j,i],-(e-ys[j]/(H-1)*(e-b)))).astype('<f4')
 v0,v1,v2,v3=ids[jj,ii],ids[jj+1,ii],ids[jj+1,ii+1],ids[jj,ii+1]
 indices=np.column_stack((v0,v1,v2,v0,v2,v3)).astype('<u4').ravel()
 d['terrain16'].update(ridges=polys,sourceResolution=[W,H],method='Native luminance contours in all biomes; original hatching and openings retained, continuous source UVs.')
 d['terrain16']['mesh']={'positions':enc(pos),'indices':enc(indices),'zones':enc(zones[ys[j],xs[i]].astype(np.uint8)),'vertices':len(pos),'triangles':len(indices)//3,'groundContacts':True,'method':'Shared two-pixel heightfield, explicit ground boundaries, native passage shoulders.'}
 # Keep lake/ruin/camp indices and replace only the rebuilt ridge index.
 features=[f for f in d['terrain17']['features'] if f['kind'] not in ['wall','rock']]
 for k,q in enumerate(polys):
  p=np.asarray(q['outer']);features.append({'kind':'wall' if q['zone'] else 'rock','index':k,'x':float(p[:,0].mean()),'y':float(p[:,1].mean()),'bounds':[float(p[:,0].min()),float(p[:,1].min()),float(p[:,0].max()),float(p[:,1].max())]})
 d['terrain17']['features']=features
 d['terrain230']={'passCoreHalfWidth':18,'sourceUv':'identity','heightSource':'local-luminance-contrast','gameplayUnchanged':True}
 sand=im[:,:,2].astype(float)>im[:,:,1]*1.15
 raised=pos[:,1]>1;px,py=xs[i],ys[j]
 report={'map':d['catalog']['map'],'name':d['catalog']['name'],'vertices':len(pos),'triangles':len(indices)//3,'ridges':len(polys),'raisedVertices':int(raised.sum()),'raisedSandVertices':int(np.count_nonzero(raised&sand[py,px])),'raisedInPassCore':int(np.count_nonzero(raised&(passmask[py,px]>0))),'raisedInWater':int(np.count_nonzero(raised&(water[py,px]>0))),'raisedOutsideHatching':int(np.count_nonzero(raised&(blocked[py,px]==0)))}
 assert report['raisedInPassCore']==report['raisedInWater']==report['raisedOutsideHatching']==0
 path.write_bytes(gzip.compress(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode(),compresslevel=5,mtime=0))
 return report

if __name__=='__main__':
 reports=[]
 for p in sorted((ROOT/'assets/data').glob('*.gz')):
  r=rebuild(p);reports.append(r);print(json.dumps(r),flush=True)
 (ROOT/'tests/terrain-v230.json').write_text(json.dumps({'passed':True,'maps':reports},indent=2),encoding='utf8')
