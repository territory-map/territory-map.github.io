# Reproduzierbarer 2D-/3D-Abgleich

Die Anwendung selbst benötigt diese Analysepakete nicht. Die ausgelieferten Gelände- und Prüfdateien sind bereits erzeugt. Nur zum erneuten Erzeugen: Python und `python -m pip install -r source/terrain255/requirements.txt`. Die Schriftanalyse verwendet die unter Windows vorhandene Schrift Verdana Bold; die fertigen Masken benötigen keine Schriftinstallation.

Alle folgenden Befehle im Projektordner ausführen. `BASELINE.zip` bezeichnet die unveränderte 2.5.4-ZIP. Originalbilder und Gameplay-Daten werden nicht überschrieben. Der Generator liest Höhen immer aus der angegebenen Ausgangs-ZIP; wiederholte Durchläufe glätten daher nicht immer weiter.

```powershell
python source/terrain255/analyze.py --baseline BASELINE.zip --phase before
python source/terrain255/rebuild.py --baseline BASELINE.zip
python source/terrain255/water.py
python source/terrain255/edges.py
python source/terrain255/text_masks.py
python source/terrain255/analyze.py --phase after
python source/terrain255/verify.py --baseline BASELINE.zip
```

`analyze.py` und `rebuild.py` akzeptieren als optionales erstes Argument eine Kartenkennung. `--root` und `--out` erlauben andere Projekt- und Analyseordner. Analyse-NPZ-Dateien sind temporäre Zwischenprodukte und werden durch den ersten Befehl erstellt. Die Konturen werden aus den 2D-Daten ermittelt, nicht aus dem korrigierten Mesh.

Für den echten WebGL-Vergleich Territory Lab starten und unter derselben lokalen Adresse `/web/terrain-audit255.html` öffnen. **Alle 21 Karten prüfen** rendert die unveränderte Vorlage und die 3D-Meshes mit identischen Grenzen und einer echten orthografischen Kamera. **Vergleichsbilder und Messwerte speichern** exportiert PNGs als JSON-Paket. Keine perspektivische Kamera wird für den Grundrissvergleich benutzt.

Alternativ kann die Analyse ihr Paket direkt in einen lokalen Ordner schreiben: `python source/terrain255/compare_server.py --port 8928` starten und `http://127.0.0.1:8928/web/terrain-audit255.html?localExport=1` öffnen. Nach dem Prüfen **Vergleich lokal speichern** wählen. Der optionale Helfer bindet ausschließlich 127.0.0.1, verlangt dieselbe Browser-Origin und schreibt nur die feste Ausgabedatei `analysis/terrain255/last-export.json`. `--output` erlaubt einen beim Start explizit angegebenen anderen Ausgabepfad. Der normale Anwendungsstart bleibt unverändert.

Die normale 3D-Planung behält ihre perspektivische Ansicht. Im bisherigen Einzelstrukturvergleich `/web/map-audit.html` ist „3D von oben“ jetzt ebenfalls orthografisch und die linke Referenz hat denselben Ausschnitt und dasselbe Seitenverhältnis.

Prüfung der Anwendung: `npm test` bzw. die unter `package.json` genannten Node-Befehle. Die neuen Prüfungen `tests/terrain255.mjs` und `tests/border255.mjs` kontrollieren Höhenunabhängigkeit der orthografischen X/Y-Projektion, Wasserflächen und die ausschließliche Änderung maskierter Schriftpixel.

## Messgrenzen

Die Originalbilder und gespeicherten nativen Konturen besitzen Pixelauflösung; eine farbige Schattenkante liefert keine vermessene Höhenlinie. Native Rasterüberdeckung, projizierte Vektorfläche und gerenderte Konturen werden deshalb getrennt dokumentiert. Übersichtsfotos haben 1024 Pixel an der längsten Seite; semantische Konturenmasken werden in nativer Auflösung bis 4096 Pixel gerendert. Canvas- und WebGL-Kantenglättung können die binäre Pixelüberdeckung verändern; „beyondOnePixel“ meldet Abweichungen außerhalb eines nativen Vergleichspixels. Farbdifferenzen sind ausdrücklich keine Geometriemessung.

Selbstberührende Außenkonturen werden vor der Triangulierung repariert. Löcher werden anschließend ausdrücklich subtrahiert, damit ein außerhalb liegendes Loch niemals zu einer erfundenen positiven Insel wird. Passkerne, Wasser und native Hatching-Grenzen bleiben ausgespart. Ein kleiner zusätzlicher Schnitt an Rasterecken verhindert, dass Float32-Rundung Gelände in freigegebenen Bereich schiebt.

Höhen stammen aus den bestehenden Meshes. Innerhalb des alten Abtastrasters wird bilinear interpoliert; fehlende Randwerte verwenden vorhandene Höhen nur innerhalb von zwölf Quellpixeln. Komponenten ohne geeignete Werte bleiben flach. Ihre Weltgrenzen stehen pro Karte in `terrain255.ridge.withoutReliableHeightAreas` und `terrain255.exterior.withoutReliableHeightAreas`. Es gibt kein vermessenes DEM im Projekt.
