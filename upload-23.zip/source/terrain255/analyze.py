import gzip,json,base64,cv2,numpy as np,sys,time,argparse,zipfile
from pathlib import Path
import shapely
from shapely.geometry import Polygon
root=Path(__file__).resolve().parents[2]
out=root/'analysis/terrain255';out.mkdir(parents=True,exist_ok=True)
parser=argparse.ArgumentParser();parser.add_argument('map',nargs='?');parser.add_argument('--baseline',type=Path);parser.add_argument('--phase',default='after');parser.add_argument('--root',type=Path);parser.add_argument('--out',type=Path);args=parser.parse_args()
if args.root:root=args.root
if args.out:out=args.out;out.mkdir(parents=True,exist_ok=True)
archive=zipfile.ZipFile(args.baseline) if args.baseline else None
prefix=archive.namelist()[0].split('/')[0] if archive else None
reports=[]
for path in sorted((root/'assets/data').glob('*.gz')):
 if args.map and args.map not in path.name:continue
 d=json.loads(gzip.decompress(archive.read(prefix+'/assets/data/'+path.name) if archive else path.read_bytes()));t=d['terrain15'];W,H=t['hatchingWidth'],t['hatchingHeight'];a,b,c,e=d['catalog']['bounds']
 def raster(p):return np.rint([[(x-a)/(c-a)*(W-1),(e-y)/(e-b)*(H-1)] for x,y in p]).astype(np.int32)
 ref=np.zeros((H,W),np.uint8)
 for q in sorted(d['terrain16']['ridges'],key=lambda q:abs(cv2.contourArea(raster(q['outer']))),reverse=True):
  cv2.fillPoly(ref,[raster(q['outer'])],1)
  for hole in q['holes']:cv2.fillPoly(ref,[raster(hole)],0)
 blocked=np.unpackbits(np.frombuffer(base64.b64decode(t['hatching']),np.uint8))[:W*H].reshape(H,W)
 snow=np.unpackbits(np.frombuffer(base64.b64decode(d['terrain16']['snowMask']),np.uint8))[:W*H].reshape(H,W)
 water=np.zeros_like(ref)
 for i,q in enumerate(d['terrain17']['waterPolygons']):
  cv2.fillPoly(water,[raster(q)],1)
  for hole in d['terrain17']['waterHoles'].get(str(i),[]):cv2.fillPoly(water,[raster(hole)],0)
 ref[(blocked==0)|(snow>0)|(water>0)]=0
 for s in d['sites']:
  if s['kind']=='pass':
   x,y=s['x'],s['y'];p=raster([[x-18,y-18],[x+18,y+18]]);cv2.rectangle(ref,tuple(p[0]),tuple(p[1]),0,-1)
 m=d['terrain16']['mesh'];pos=np.frombuffer(base64.b64decode(m['positions']),'<f4').reshape(-1,3);tri=np.frombuffer(base64.b64decode(m['indices']),'<u4').reshape(-1,3)
 px=(pos[:,0]-a)/(c-a)*(W-1);py=(e+pos[:,2])/(e-b)*(H-1)
 contours=np.rint(np.stack((px,py),axis=1)[tri]).astype(np.int32)
 rendered=np.zeros_like(ref);raised=np.zeros_like(ref)
 for i in range(0,len(tri),20000):
  cv2.fillPoly(rendered,list(contours[i:i+20000]),1)
  sel=pos[tri[i:i+20000],1].max(axis=1)>.15
  cv2.fillPoly(raised,list(contours[i:i+20000][sel]),1)
 missing=(ref>0)&(rendered==0);extra=(ref==0)&(rendered>0)
 report={'map':d['catalog']['map'],'referencePixels':int(ref.sum()),'meshPixels':int(rendered.sum()),'missingPixels':int(missing.sum()),'extraPixels':int(extra.sum()),'iou':float(np.count_nonzero(ref&rendered)/np.count_nonzero(ref|rendered)), 'flatReferencePixels':int(np.count_nonzero((ref>0)&(raised==0)))}
 reports.append(report);print(report,flush=True)
 np.savez_compressed(out/(path.stem.replace('.json','')+'-'+args.phase+'.npz'),reference=ref,mesh=rendered,water=water,raised=raised)
 rgb=cv2.resize(cv2.imread(str(root/'assets/maps'/f"{d['catalog']['map']}.webp")),(W,H))
 rgb[missing]=rgb[missing]*.35+np.array([0,100,160]);rgb[extra]=rgb[extra]*.35+np.array([160,0,100])
 cv2.imwrite(str(out/(path.stem.replace('.json','')+'-'+args.phase+'-deviation.png')),cv2.resize(rgb,(1024,round(H/W*1024))))
 # Runtime comparison masks at an equal world scale (longest side 1024).
 target=root/'assets/audit255';target.mkdir(exist_ok=True)
 size=(round(W/max(W,H)*1024),round(H/max(W,H)*1024))
 exterior=snow.copy();exterior[(blocked==0)|(water>0)]=0
 for s in d['sites']:
  if s['kind']=='pass':
   x,y=s['x'],s['y'];p=raster([[x-18,y-18],[x+18,y+18]]);cv2.rectangle(exterior,tuple(p[0]),tuple(p[1]),0,-1)
 cv2.imwrite(str(target/(d['catalog']['map']+'-reference.png')),cv2.resize(np.dstack((water,exterior,ref))*255,size,interpolation=cv2.INTER_AREA))
 def vector(mask):
  contours,hierarchy=cv2.findContours(mask,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE);regions=[]
  if hierarchy is None:return regions
  for i,q in enumerate(contours):
   if hierarchy[0,i,3]>=0 or len(q)<3:continue
   holes=[];j=hierarchy[0,i,2]
   while j>=0:
    if len(contours[j])>=3:holes.append(contours[j].reshape(-1,2).tolist())
    j=hierarchy[0,j,0]
   if cv2.contourArea(q)<=0:continue
   def parts(geom):
    if geom.geom_type=='Polygon':return [geom]
    return [p for g in getattr(geom,'geoms',[]) for p in parts(g)]
   shell=shapely.make_valid(Polygon(q.reshape(-1,2)));region=shapely.difference(shell,shapely.union_all([shapely.make_valid(Polygon(h)) for h in holes]))
   for poly in parts(region):
    regions.append({'outer':np.array(poly.exterior.coords)[:-1].tolist(),'holes':[np.array(r.coords)[:-1].tolist() for r in poly.interiors]})
  return regions
 (target/(d['catalog']['map']+'-contours.json')).write_text(json.dumps({'width':W,'height':H,'ridge':vector(ref),'exterior':vector(exterior),'water':d['terrain17']['waterPolygons'],'waterHoles':d['terrain17']['waterHoles'],'bounds':d['catalog']['bounds'],'source':'Independent native 2D contours; does not read the 3D mesh.'},separators=(',',':')),encoding='utf8')
(out/(args.phase+'.json')).write_text(json.dumps(reports,indent=2),encoding='utf8')
