"""Native-aspect exterior/coast masks; no square-image preprocessing."""
from pathlib import Path
import gzip,json,base64,numpy as np,cv2
root=Path(__file__).resolve().parents[2];out=root/'assets/audit255';out.mkdir(exist_ok=True)
for path in sorted((root/'assets/data').glob('*.gz')):
 d=json.loads(gzip.decompress(path.read_bytes()));t=d['terrain15'];W,H=t['hatchingWidth'],t['hatchingHeight'];edge=d['terrain16']['edge'];name=d['catalog']['map']
 exterior=np.unpackbits(np.frombuffer(base64.b64decode(d['terrain16']['snowMask']),np.uint8))[:W*H].reshape(H,W)
 sea=np.zeros_like(exterior)
 if edge['hasCoast']:
  im=cv2.resize(cv2.imread(str(root/'assets/maps'/f'{name}.webp')),(W,H),interpolation=cv2.INTER_AREA);blue,green,red=[v.astype(float) for v in cv2.split(im)]
  candidate=((blue>red*1.12)&(green>red*1.08)&(red<150)).astype(np.uint8)
  n,labels,stats,_=cv2.connectedComponentsWithStats(candidate)
  ids=np.unique(np.r_[labels[0],labels[-1],labels[:,0],labels[:,-1]])
  sea=np.isin(labels,[int(k) for k in ids if k and stats[k,4]>W*H*.0009]).astype(np.uint8)
 exterior[sea>0]=0
 rgba=np.zeros((H,W,4),np.uint8);rgba[:,:,2]=exterior*255;rgba[:,:,1]=exterior*255 if edge['mountainMaterial']=='snow' else 0;rgba[:,:,0]=sea*255;rgba[:,:,3]=255
 cv2.imwrite(str(out/f'{name}-edge.png'),rgba)
 print(name,'coastal pixels',int(sea.sum()),flush=True)
