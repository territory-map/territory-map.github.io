"""Independent preservation, topology and native-boundary checks."""
from pathlib import Path
import argparse,zipfile,gzip,json,base64,hashlib,cv2,numpy as np
import sys
import shapely
from shapely.geometry import Polygon
def polygon_area_parts(geom):
 if geom.geom_type=='Polygon':return geom.area
 return sum(polygon_area_parts(g) for g in getattr(geom,'geoms',[]))
def canonical_area(mask):
 cs,hr=cv2.findContours(mask,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE);total=0
 for i,co in enumerate(cs):
  if hr[0,i,3]>=0 or len(co)<3 or cv2.contourArea(co)<=0:continue
  holes=[];j=hr[0,i,2]
  while j>=0:
   if len(cs[j])>=3 and cv2.contourArea(cs[j])>0:holes.append(cs[j].reshape(-1,2))
   j=hr[0,j,0]
  shell=shapely.make_valid(Polygon(co.reshape(-1,2)));region=shapely.difference(shell,shapely.union_all([shapely.make_valid(Polygon(h)) for h in holes]));total+=polygon_area_parts(region)
 return total
parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2]);parser.add_argument('--baseline',type=Path,required=True);parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[2]/'analysis/terrain255');args=parser.parse_args()
archive=zipfile.ZipFile(args.baseline);prefix=archive.namelist()[0].split('/')[0];reports=[]
for path in sorted((args.root/'assets/data').glob('*.gz')):
 original=json.loads(gzip.decompress(archive.read(prefix+'/assets/data/'+path.name)));d=json.loads(gzip.decompress(path.read_bytes()));name=d['catalog']['map'];assert d.get('terrain255'),name+' not corrected'
 t=d['terrain15'];W,H=t['hatchingWidth'],t['hatchingHeight'];a,b,c,e=d['catalog']['bounds'];hatch=np.unpackbits(np.frombuffer(base64.b64decode(t['hatching']),np.uint8))[:W*H].reshape(H,W)
 reference=np.load(args.out/(name+'-before.npz'))
 exterior=np.unpackbits(np.frombuffer(base64.b64decode(d['terrain16']['snowMask']),np.uint8))[:W*H].reshape(H,W);exterior[(hatch==0)|(reference['water']>0)]=0
 for s in d['sites']:
  if s['kind']=='pass':
   px=np.rint([[(s['x']-18-a)/(c-a)*(W-1),(e-s['y']+18)/(e-b)*(H-1)],[(s['x']+18-a)/(c-a)*(W-1),(e-s['y']-18)/(e-b)*(H-1)]]).astype(int);cv2.rectangle(exterior,tuple(px[0]),tuple(px[1]),0,-1)
 meshes=[]
 for field in ['mesh','snowMesh']:
  m=d['terrain16'][field];pos=(np.frombuffer(base64.b64decode(m['positions']),'<f4') if isinstance(m['positions'],str) else np.array(m['positions'],np.float32)).reshape(-1,3);tri=(np.frombuffer(base64.b64decode(m['indices']),'<u4') if isinstance(m['indices'],str) else np.array(m['indices'],np.uint32)).reshape(-1,3)
  assert np.isfinite(pos).all() and len(tri)>0 and tri.max()<len(pos)
  edges=np.vstack((tri[:,[0,1]],tri[:,[1,2]],tri[:,[2,0]])).astype(np.uint64);edges.sort(axis=1);keys=edges[:,0]*len(pos)+edges[:,1];unique,count=np.unique(keys,return_counts=True);assert count.max()==2,name+' non-manifold'
  border=unique[count==1];ix=np.unique(np.r_[border//len(pos),border%len(pos)]).astype(int);assert not np.any(pos[ix,1]>.0001),name+' floating edge'
  def outside(q):
   q=q.astype(np.float64);px=np.clip(np.floor((q[:,0]-a)/(c-a)*(W-1)+.5).astype(int),0,W-1);py=np.clip(np.floor((e+q[:,2])/(e-b)*(H-1)+.5).astype(int),0,H-1);return np.count_nonzero(hatch[py,px]==0)
  verticesOutside=int(outside(pos));centresOutside=int(outside(pos[tri].astype(float).mean(axis=1)));assert verticesOutside==0 and centresOutside==0,name+' outside native boundary'
  q=pos[tri];up=(q[:,1,2]-q[:,0,2])*(q[:,2,0]-q[:,0,0])-(q[:,1,0]-q[:,0,0])*(q[:,2,2]-q[:,0,2]);assert not np.any(up<-.0001),name+' inverted face'
  expected=canonical_area(reference['reference'] if field=='mesh' else exterior)*(c-a)/(W-1)*(e-b)/(H-1)
  q=q.astype(np.float64);actual=np.abs((q[:,1,2]-q[:,0,2])*(q[:,2,0]-q[:,0,0])-(q[:,1,0]-q[:,0,0])*(q[:,2,2]-q[:,0,2])).sum()/2
  # Boundary faces crossing nearest-texel hatching corners are deliberately
  # clipped. Bound the resulting area loss rather than demanding zero aliasing.
  areaError=abs(actual-expected)/max(1,expected);assert areaError<.0002,name+' '+field+' native vector area mismatch '+str((expected,actual,areaError))
  meshes.append({'kind':field,'vertices':len(pos),'triangles':len(tri),'verticesOutsideHatching':verticesOutside,'triangleCentresOutsideHatching':centresOutside,'nonManifoldEdges':int((count>2).sum()),'floatingBoundaryVertices':0,'invertedFaces':0,'maximumExistingHeight':float(pos[:,1].max()),'native2DVectorArea':expected,'projected3DVectorArea':actual,'relativeVectorAreaError':areaError})
 # The only allowed map-data edits are the two visual terrain meshes and audit metadata.
 new=dict(d);new.pop('terrain255');new['terrain16']=dict(new['terrain16']);old=dict(original);old['terrain16']=dict(old['terrain16'])
 for field in ['mesh','snowMesh']:new['terrain16'].pop(field);old['terrain16'].pop(field)
 assert old==new,name+' changed gameplay, sites, native contours or water'
 for relative in ['assets/maps/'+name+'.webp','assets/solver/'+name+'.json.gz']:
  assert archive.read(prefix+'/'+relative)==(args.root/relative).read_bytes(),relative+' modified'
 reports.append({'map':name,'meshes':meshes,'sourceImageByteIdentical':True,'solverDataByteIdentical':True,'otherMapDataIdentical':True,'unknownRidgeHeightAreas':d['terrain255']['ridge']['withoutReliableHeight'],'unknownExteriorHeightAreas':d['terrain255']['exterior']['withoutReliableHeight']});print(name,'passed',flush=True)
assert len(reports)==21;args.out.mkdir(parents=True,exist_ok=True);(args.out/'validation.json').write_text(json.dumps({'passed':True,'maps':reports},indent=2),encoding='utf8')
