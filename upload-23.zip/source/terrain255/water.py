"""Robust native shoreline triangulation, including self-touching source contours."""
from pathlib import Path
import sys,json,gzip,base64,numpy as np
import shapely
from shapely.geometry import Polygon
root=Path(__file__).resolve().parents[2]
def parts(geom):
 if geom.geom_type=='Polygon':return [geom]
 return [q for g in getattr(geom,'geoms',[]) for q in parts(g)]
for path in sorted((root/'assets/data').glob('*.gz')):
 d=json.loads(gzip.decompress(path.read_bytes()));p=[];indices=[];contours=[];area=0;repaired=[]
 for i,outer in enumerate(d['terrain17']['waterPolygons']):
  raw=Polygon(outer,d['terrain17']['waterHoles'].get(str(i),[]))
  if not raw.is_valid:repaired.append(i)
  shell=shapely.make_valid(Polygon(outer));region=shapely.difference(shell,shapely.union_all([shapely.make_valid(Polygon(h)) for h in d['terrain17']['waterHoles'].get(str(i),[])]))
  for region in parts(region):
   if region.area<1e-8:continue
   area+=region.area;contours.append({'outer':list(map(list,region.exterior.coords))[:-1],'holes':[list(map(list,h.coords))[:-1] for h in region.interiors]})
   for face in shapely.get_parts(shapely.constrained_delaunay_triangles(region)):
    points=np.array(face.exterior.coords)[:3];offset=len(p);p.extend([[float(x),.12,float(-y)] for x,y in points]);indices.extend([offset,offset+1,offset+2])
 positions=np.asarray(p,'<f4');ix=np.asarray(indices,'<u4');enc=lambda ar:base64.b64encode(ar.tobytes()).decode()
 d['terrain255']['waterMesh']={'positions':enc(positions),'indices':enc(ix),'contours':contours,'expectedVectorArea':area,'repairedContourIndices':repaired,'source':'Original 2D shoreline vertices and holes; GEOS validity repair only for self-touching contours.'}
 path.write_bytes(gzip.compress(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode(),compresslevel=5,mtime=0));print(d['catalog']['map'],'water regions',len(contours),'repaired',len(repaired),flush=True)
