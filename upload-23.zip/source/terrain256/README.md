# Reproduzierbare Geländeprüfung 2.5.6

Die laufende Anwendung verwendet die fertig berechneten Assets. Diese Werkzeuge sind optional und benötigen Python, numpy, opencv-python, scipy und shapely >= 2.1.

Für eine Karte, vom Projektordner aus:

```
python source/terrain256/rebuild.py LostLand_Map_9_2_v2 --baseline PFAD/ZUR/Territory-Lab-Standalone-2.5.5.zip
python source/terrain256/verify.py LostLand_Map_9_2_v2 --baseline PFAD/ZUR/Territory-Lab-Standalone-2.5.5.zip
```

Beide Schritte sind nötig. Der erste berechnet Bildkörper und trianguliert sie. Der zweite schließt Fundamente und Passkerne endgültig aus, glättet ausschließlich Höhen und prüft die Erhaltung aller anderen Kartendaten. Alle Kartenschlüssel sind im Abschlussbericht aufgeführt; dieselben Schritte werden je Schlüssel ausgeführt.

Der Browservergleich ist mit der Anwendung unter `/web/terrain-audit256.html` erreichbar. Er zeigt originale und orthografische Ansichten, Maskendifferenzen und Detailpaare. Zum lokalen JSON-Export den zusätzlichen, ausschließlich lokalen Vergleichsserver starten:

```
python source/terrain256/compare_server.py --port 8936 --output vergleich.json
```

Dann `/web/terrain-audit256.html?localExport=1` öffnen. Die gespeicherten Daten bleiben auf dem PC. Die geometrische Maskenüberdeckung bewertet die Triangulation gegenüber der neuen Bildklassifikation; sie beweist weder die fehlerfreie Interpretation jedes Felsens noch metrisch korrekte Höhen.
