"""Optional local comparison exporter. Standard library only; no gameplay writes."""
from pathlib import Path
import argparse,json,mimetypes,sys
from http.server import ThreadingHTTPServer

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
import server as application

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8928);parser.add_argument('--output',type=Path,default=ROOT/'analysis/terrain255/last-export.json');args=parser.parse_args()
 output=args.output.resolve()
 class ComparisonHandler(application.Handler):
  def do_POST(self):
   if self.path!='/api/terrain-audit-save':return super().do_POST()
   if self.headers.get('Origin')!=f'http://127.0.0.1:{self.server.server_port}':self.send_error(403);return
   try:
    length=int(self.headers.get('Content-Length',0))
    print('Vergleichsexport:',length,'Bytes',flush=True)
    if not 0<length<1024*1024*1024:raise ValueError('Invalid size')
    raw=self.rfile.read(length);data=json.loads(raw)
    if data.get('version')not in ('2.5.5','2.5.6') or not 1<=len(data['maps'])<=21:raise ValueError('Invalid comparison')
    allowed={m['map'] for m in json.loads((ROOT/'assets/maps.json').read_text(encoding='utf8'))['maps']}
    if any(row['metrics']['map'] not in allowed for row in data['maps']):raise ValueError('Unknown map')
    output.parent.mkdir(parents=True,exist_ok=True);temporary=output.with_suffix('.pending');temporary.write_bytes(raw);temporary.replace(output)
   except (ValueError,KeyError,TypeError,OSError):self.send_error(400);return
   body=json.dumps({'saved':True,'maps':len(data['maps']),'path':str(output)}).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 mimetypes.add_type('text/javascript','.js')
 http=ThreadingHTTPServer(('127.0.0.1',args.port),ComparisonHandler);http.lifetime=None
 print(f'Lokaler Vergleich: http://127.0.0.1:{args.port}/web/terrain-audit256.html?localExport=1',flush=True)
 try:http.serve_forever()
 except KeyboardInterrupt:pass
 finally:http.server_close()

if __name__=='__main__':main()
