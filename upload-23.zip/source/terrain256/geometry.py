from pathlib import Path
import sys,base64
import numpy as np,cv2
import shapely
from shapely.geometry import Polygon
from scipy.spatial import Delaunay
from scipy.ndimage import distance_transform_edt,map_coordinates
def polygon_parts(geometry):
 if geometry.geom_type=='Polygon':return [geometry]
 return [p for child in getattr(geometry,'geoms',[]) for p in polygon_parts(child)]

def polygons(mask):
 contours,hierarchy=cv2.findContours(mask,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
 result=[]
 if hierarchy is None:return result
 for i,c in enumerate(contours):
  if hierarchy[0,i,3]>=0 or len(c)<3 or cv2.contourArea(c)<=0:continue
  holes=[];j=hierarchy[0,i,2]
  while j>=0:
   if len(contours[j])>=3 and cv2.contourArea(contours[j])>0:holes.append(contours[j].reshape(-1,2))
   j=hierarchy[0,j,0]
  # Repair the shell and subtract repaired holes explicitly. Repairing an
  # invalid polygon-with-holes in one operation can turn an outlying hole into
  # a positive island; that island does not exist in the 2D raster.
  shell=shapely.make_valid(Polygon(c.reshape(-1,2)))
  p=shapely.difference(shell,shapely.union_all([shapely.make_valid(Polygon(h)) for h in holes]))
  result.extend(q for q in polygon_parts(p) if q.area>0)
 return result

def rebuild(mask,old,bounds,W,H,zones=None,blocked=None,height_override=None):
 a,b,c,e=bounds
 p=(np.frombuffer(base64.b64decode(old['positions']),'<f4') if isinstance(old['positions'],str) else np.array(old['positions'],np.float32)).reshape(-1,3)
 px=np.clip(np.rint((p[:,0]-a)/(c-a)*(W-1)).astype(int),0,W-1);py=np.clip(np.rint((e+p[:,2])/(e-b)*(H-1)).astype(int),0,H-1)
 height=np.zeros((H,W),np.float32);height[py,px]=p[:,1]
 # Original mesh samples occur on a two/four-pixel grid. Interpolate without
 # adding a synthetic height profile or random relief.
 step=2 if isinstance(old['positions'],str) else 4
 sampled=height[::step,::step]
 yy,xx=np.indices((H,W),np.float32)
 height=map_coordinates(sampled,[yy/step,xx/step],order=1,mode='nearest')
 near,nearest=distance_transform_edt(height<=.05,return_indices=True)
 interior=cv2.distanceTransform(mask,cv2.DIST_L2,5)
 missing=(mask>0)&(height<=.05)&(near<=12)
 height[missing]=height[nearest[0,missing],nearest[1,missing]]*np.minimum(1,interior[missing]/2)
 if height_override is not None:height=height_override
 parts=polygons(mask);allpos=[];alltri=[];offset=0;unknown=0;unknownAreas=[]
 for poly in parts:
  shapely.prepare(poly)
  minx,miny,maxx,maxy=poly.bounds
  gy,gx=np.meshgrid(np.arange(np.ceil(miny/2)*2,maxy,2),np.arange(np.ceil(minx/2)*2,maxx,2),indexing='ij')
  inside=shapely.contains_xy(poly,gx.ravel(),gy.ravel());grid=np.column_stack((gx.ravel()[inside],gy.ravel()[inside]))
  boundary=np.vstack([np.array(poly.exterior.coords)[:-1],*[np.array(r.coords)[:-1] for r in poly.interiors]])
  coords=np.unique(np.vstack((boundary,grid)),axis=0)
  if len(coords)<3:continue
  # Delaunay with interior samples, followed by exact clipping at concavities
  # and islands. Plain unconstrained Delaunay would bridge openings.
  try:tri=Delaunay(coords).simplices
  except Exception:
   faces=shapely.get_parts(shapely.constrained_delaunay_triangles(poly));points=np.concatenate([np.array(f.exterior.coords)[:3] for f in faces]);coords,inverse=np.unique(points,axis=0,return_inverse=True);tri=inverse.reshape(-1,3)
  faces=shapely.polygons(coords[tri]);full=shapely.covers(poly,faces);kept=coords[tri[full]]
  cut=shapely.intersection(faces[~full],poly)
  extra=[]
  for item in cut:
   for geom in polygon_parts(item):
    if geom.area<1e-8:continue
    for face in shapely.get_parts(shapely.constrained_delaunay_triangles(geom)):
     extra.append(np.array(face.exterior.coords)[:3])
  if extra:kept=np.concatenate((kept,np.array(extra)))
  if not len(kept):continue
  # Shared vertices prevent floating seams and preserve a manifold surface.
  vertices,inverse=np.unique(np.round(kept.reshape(-1,2),7),axis=0,return_inverse=True);indices=inverse.reshape(-1,3)
  heights=map_coordinates(height,[vertices[:,1],vertices[:,0]],order=1,mode='nearest')
  edges=np.vstack((indices[:,[0,1]],indices[:,[1,2]],indices[:,[2,0]]));edges.sort(axis=1);keys=edges[:,0]*len(vertices)+edges[:,1];unique,count=np.unique(keys,return_counts=True)
  if count.max()>2:raise RuntimeError('non-manifold contour')
  border=unique[count==1];heights[np.unique(np.r_[border//len(vertices),border%len(vertices)])]=0
  unknown+=int(heights.max()<.15)
  if heights.max()<.15:unknownAreas.append({'bounds':[round(a+minx/(W-1)*(c-a),3),round(e-maxy/(H-1)*(e-b),3),round(a+maxx/(W-1)*(c-a),3),round(e-miny/(H-1)*(e-b),3)],'sourcePixelArea':round(poly.area,2)})
  v=np.column_stack((a+vertices[:,0]/(W-1)*(c-a),heights,-(e-vertices[:,1]/(H-1)*(e-b)))).astype('<f4')
  # Face upward: signed XY source image area is reversed relative to X/Z.
  q=vertices[indices];area=(q[:,1,0]-q[:,0,0])*(q[:,2,1]-q[:,0,1])-(q[:,1,1]-q[:,0,1])*(q[:,2,0]-q[:,0,0]);indices[area>0]=indices[area>0][:,[0,2,1]]
  allpos.append(v);alltri.append((indices+offset).astype('<u4'));offset+=len(v)
 v=np.concatenate(allpos);indices=np.concatenate(alltri)
 # Float32 and nearest-texel sampling can put a handful of half-pixel boundary
 # triangles across a forbidden-mask corner. Remove only those subpixel faces.
 if blocked is not None:
  def lookup(q):
   q=q.astype(np.float64)
   ix=np.clip(np.floor((q[:,0]-a)/(c-a)*(W-1)+.5).astype(int),0,W-1)
   iy=np.clip(np.floor((e+q[:,2])/(e-b)*(H-1)+.5).astype(int),0,H-1)
   return blocked[iy,ix]>0
  keep=lookup(v)[indices].all(axis=1)&lookup(v[indices].astype(float).mean(axis=1))
  indices=indices[keep];used,inverse=np.unique(indices,return_inverse=True);v=v[used];indices=inverse.reshape(-1,3).astype('<u4')
  edges=np.vstack((indices[:,[0,1]],indices[:,[1,2]],indices[:,[2,0]])).astype(np.uint64);edges.sort(axis=1);keys=edges[:,0]*len(v)+edges[:,1];unique,count=np.unique(keys,return_counts=True);border=unique[count==1];v[np.unique(np.r_[border//len(v),border%len(v)]).astype(int),1]=0
 px=np.clip(np.rint((v[:,0]-a)/(c-a)*(W-1)).astype(int),0,W-1);py=np.clip(np.rint((e+v[:,2])/(e-b)*(H-1)).astype(int),0,H-1)
 enc=lambda ar:base64.b64encode(ar.tobytes()).decode()
 mesh={'positions':enc(v),'indices':enc(indices),'zones':enc(zones[py,px] if zones is not None else np.zeros(len(v),np.uint8)),'vertices':len(v),'triangles':len(indices),'groundContacts':True,'method':'2D contour-constrained triangulation; existing interior heights, exact clipped boundaries and holes.'}
 return mesh,{'parts':len(parts),'withoutReliableHeight':unknown,'withoutReliableHeightAreas':unknownAreas,'vertices':len(v),'triangles':len(indices)}
