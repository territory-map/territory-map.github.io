"""Rebuild visual relief from native image bodies, never site illustrations."""
from pathlib import Path
import sys,json,gzip,base64,hashlib,time,argparse,zipfile
import cv2,numpy as np
from segment import classify
from geometry import rebuild,polygons
from scipy.ndimage import distance_transform_edt,map_coordinates
root=Path(__file__).resolve().parents[2];out=root/'analysis/terrain256';out.mkdir(parents=True,exist_ok=True)
parser=argparse.ArgumentParser();parser.add_argument('map');parser.add_argument('--baseline',type=Path,required=True);args=parser.parse_args()
path=root/'assets/data'/f'{args.map}.json.gz'
# Always rebuild from pristine 2.5.5, including repeated correction passes.
with zipfile.ZipFile(args.baseline) as z:
 prefix=z.namelist()[0].split('/')[0];d=json.loads(gzip.decompress(z.read(prefix+'/assets/data/'+path.name)))
start=time.time();slug=d['catalog']['map'];res=classify(d,cv2.imread(str(root/'assets/maps'/f'{slug}.webp')));body,exterior=res['body'],res['exterior'];H,W=body.shape;bounds=d['catalog']['bounds'];a,b,c,e=bounds
zones=np.zeros_like(body)
for q in d['terrain16']['ridges']:
 if q['zone']:
  p=np.rint([[(x-a)/(c-a)*(W-1),(e-y)/(e-b)*(H-1)] for x,y in q['outer']]).astype(np.int32);cv2.fillPoly(zones,[p],1)
def heights(mask,old,exterior=False):
 p=(np.frombuffer(base64.b64decode(old['positions']),'<f4') if isinstance(old['positions'],str) else np.array(old['positions'],np.float32)).reshape(-1,3)
 px=np.clip(np.rint((p[:,0]-a)/(c-a)*(W-1)).astype(int),0,W-1);py=np.clip(np.rint((e+p[:,2])/(e-b)*(H-1)).astype(int),0,H-1)
 sampled=np.zeros((H,W),np.float32);sampled[py,px]=p[:,1]
 yy,xx=np.indices((H,W),np.float32);prior=map_coordinates(sampled[::2,::2],[yy/2,xx/2],order=1,mode='nearest')
 dist,near=distance_transform_edt(prior<=.15,return_indices=True);missing=(mask>0)&(prior<=.15)&(dist<14);prior[missing]=prior[near[0,missing],near[1,missing]]
 # Relative heights remain based on existing classes. New minor image features
 # get conservative relief, not invented metric elevations.
 prior[(mask>0)&(prior<=.15)]=3.5 if not exterior else 9
 if not exterior:prior=np.minimum(prior,np.where(zones>0,9.25,8.3))
 distance=cv2.distanceTransform(mask,cv2.DIST_L2,5)
 thickness=cv2.dilate(distance,np.ones((25,25),np.uint8))
 profile=np.sin(np.clip(distance/np.maximum(thickness,.01),0,1)*np.pi/2)**.7
 texture=np.clip((res['gray']-res['local'])/80,-.18,.18)
 # Retain class height range, round only within the true image footprint.
 height=prior*profile*(1+texture);height[mask==0]=0
 return height.astype(np.float32)
mesh,report=rebuild(body,d['terrain16']['mesh'],bounds,W,H,zones,res['hatch'],heights(body,d['terrain16']['mesh']))
mesh['nativeSurface256']=True;mesh['method']='Native-image rock chroma and contour relief; no footprint dilation, source-driven cap details.';d['terrain16']['mesh']=mesh
sm,sreport=rebuild(exterior,d['terrain16']['snowMesh'],bounds,W,H,blocked=res['hatch'],height_override=heights(exterior,d['terrain16']['snowMesh'],True))
d['terrain16']['snowMesh']={'positions':np.frombuffer(base64.b64decode(sm['positions']),'<f4').tolist(),'indices':np.frombuffer(base64.b64decode(sm['indices']),'<u4').tolist(),'method':sm['method'],'groundContacts':True,'nativeSurface256':True}
details=d['terrain17']['details'];points=np.frombuffer(base64.b64decode(details['positions']),'<f4').copy().reshape(-1,3);points[:,1]=0;details['positions']=base64.b64encode(points.tobytes()).decode();details['flatSiteArtwork256']=True
meta={'map':slug,'sourceImageSha256':hashlib.sha256((root/'assets/maps'/f'{slug}.webp').read_bytes()).hexdigest(),'reference':'Native image colour, rock edges and original blocked-area mask. Historical 255 masks are not a ground truth.','ridge':report,'exterior':sreport,'flatSiteAreas':res['siteAreas'],'bodyPixels':int(body.sum()),'exteriorPixels':int(exterior.sum()),'heightLimitation':'Existing relative heights with bounded source-texture relief; 2D image is not a physical DEM.','nativeWidth':W,'nativeHeight':H}
d['terrain256']=meta
path.write_bytes(gzip.compress(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode(),compresslevel=5,mtime=0))
np.savez_compressed(out/(slug+'-source.npz'),body=body,exterior=exterior,flat=res['flat'],water=res['water'])
# Native body masks and vector rings used by orthographic renderer comparison.
target=root/'assets/audit256';target.mkdir(exist_ok=True)
def vectors(mask):
 return [{'outer':np.array(q.exterior.coords)[:-1].tolist(),'holes':[np.array(r.coords)[:-1].tolist() for r in q.interiors]} for q in polygons(mask)]
(target/(slug+'-contours.json')).write_text(json.dumps({'width':W,'height':H,'ridge':vectors(body),'exterior':vectors(exterior)},separators=(',',':')))
cv2.imwrite(str(out/(slug+'-classes.png')),cv2.resize(np.dstack((res['water'],exterior,body))*255,(1024,round(H/W*1024)),interpolation=cv2.INTER_AREA))
# Three representative native closeups: wall, highest feature, flat site.
p=np.frombuffer(base64.b64decode(mesh['positions']),'<f4').reshape(-1,3);q=p[np.argmax(p[:,1])];samples=[('highest',q[0],-q[2])]
if res['siteAreas']:
 area=res['siteAreas'][0]['bounds'];samples.append(('site',(area[0]+area[2])/2,(area[1]+area[3])/2))
long=[q for q in d['terrain16']['ridges'] if q['zone']]
if long:
 q=max(long,key=lambda q:len(q['outer']));v=q['outer'][len(q['outer'])//2];samples.append(('wall',*v))
for name,x,y in samples:
 px=round((x-a)/(c-a)*(W-1));py=round((e-y)/(e-b)*(H-1));r=100;x0,y0=max(0,px-r),max(0,py-r);x1,y1=min(W,px+r),min(H,py+r);im=res['image'][y0:y1,x0:x1].copy();sel=body[y0:y1,x0:x1]>0;im[sel]=im[sel]*.65+np.array([0,70,0]);cv2.imwrite(str(out/(slug+'-'+name+'-overlay.png')),cv2.resize(im,(600,600),interpolation=cv2.INTER_NEAREST))
meta['seconds']=round(time.time()-start);(out/(slug+'-report.json')).write_text(json.dumps(meta,indent=2));print(slug,meta['bodyPixels'],report['vertices'],sreport['vertices'],meta['seconds'],flush=True)
