"""Independent native-image terrain classification; no previous ridge masks."""
from pathlib import Path
import numpy as np,cv2,base64

def classify(d,image):
 t=d['terrain15'];W,H=t['hatchingWidth'],t['hatchingHeight'];a,b,c,e=d['catalog']['bounds']
 im=cv2.resize(image,(W,H),interpolation=cv2.INTER_AREA);blue,green,red=[im[:,:,i].astype(np.float32) for i in range(3)]
 gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY).astype(np.float32);local=cv2.GaussianBlur(gray,(0,0),9)
 ratio=blue/np.maximum(green,1);warm=red/np.maximum(green,1)
 hatch=np.unpackbits(np.frombuffer(base64.b64decode(t['hatching']),np.uint8))[:W*H].reshape(H,W)
 oldExterior=np.unpackbits(np.frombuffer(base64.b64decode(d['terrain16']['snowMask']),np.uint8))[:W*H].reshape(H,W)
 water=((blue>red*1.14)&(green>red*1.055)&(ratio>.89)&(green>42)).astype(np.uint8)
 # Cold neutral edge-connected rock/snow, not an upscaled 512-square proxy.
 exteriorCandidate=((ratio>.82)&(warm<1.17)&(warm>.70)&(water==0)).astype(np.uint8)
 n,labels,stats,_=cv2.connectedComponentsWithStats(exteriorCandidate)
 contacts=np.unique(np.r_[labels[0],labels[-1],labels[:,0],labels[:,-1]]);keep=np.zeros(n,np.uint8);keep[contacts]=1;keep[0]=0
 exterior=keep[labels];exterior[(hatch==0)|(oldExterior==0)]=0
 # Image texture contrast and rock chroma identify actual bodies. Dark cast
 # shadows alone are not a raised footprint; no two-pixel dilation is used.
 colourBody=((ratio>.67)|((ratio>.55)&(ratio>cv2.GaussianBlur(ratio,(0,0),25)+.045)))&(gray>local-12)
 grassyBody=(gray>local+7)&(ratio>.62)
 body=((colourBody|grassyBody)&(hatch>0)&(water==0)&(oldExterior==0)).astype(np.uint8)
 closed=cv2.morphologyEx(body,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
 body|=(closed&(gray>local-10)).astype(np.uint8)
 # Tiny dark rock seams may be filled; broad traversable clearings stay holes.
 holes,hi=cv2.findContours(body,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
 if hi is not None:
  for i,q in enumerate(holes):
   if hi[0,i,3]>=0 and cv2.contourArea(q)<=18:cv2.drawContours(body,[q],0,1,-1)
 flat=np.zeros((H,W),np.uint8);siteAreas=[]
 def pixel(x,y):return (round((x-a)/(c-a)*(W-1)),round((e-y)/(e-b)*(H-1)))
 for s in d['sites']:
  if s['kind']=='pass':
   lo=pixel(s['x']-36,s['y']+36);hi=pixel(s['x']+36,s['y']-36);cv2.rectangle(flat,lo,hi,1,-1);continue
  if s['kind']=='bastion':continue
  rule=d['catalog']['structureRules'].get(str(s.get('strongholdType')),{}).get('collision',{})
  half=rule.get('halfSize',(rule.get('radiusInCells',1)*2+1)*9)
  # Preserve the 2D site paving and illustration on a flat foundation. The
  # small margin covers painted masonry; it is not the whole territory square.
  radius=max(half+18,63 if s['kind']=='ancient-battlefield' else (90 if s.get('strongholdType') in [31,32,38] else 63))
  lo=pixel(s['x']-radius,s['y']+radius);hi=pixel(s['x']+radius,s['y']-radius);cv2.rectangle(flat,lo,hi,1,-1)
  siteAreas.append({'id':s['id'],'bounds':[s['x']-radius,s['y']-radius,s['x']+radius,s['y']+radius]})
 body[(hatch==0)|(flat>0)|(water>0)|(oldExterior>0)]=0;exterior[(flat>0)|(water>0)]=0
 n,labels,stats,_=cv2.connectedComponentsWithStats(body);keep=np.zeros(n,np.uint8);keep[1:]=(stats[1:,cv2.CC_STAT_AREA]>=12);body=keep[labels]
 return {'body':body,'exterior':exterior,'water':water,'flat':flat,'siteAreas':siteAreas,'gray':gray,'local':local,'hatch':hatch,'image':im}

if __name__=='__main__':
 import json,gzip,argparse
 parser=argparse.ArgumentParser();parser.add_argument('map');parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2]);parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[2]/'analysis/terrain256');args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
 d=json.loads(gzip.decompress((args.root/'assets/data'/f'{args.map}.json.gz').read_bytes()));result=classify(d,cv2.imread(str(args.root/'assets/maps'/f'{args.map}.webp')))
 cv2.imwrite(str(args.out/(args.map+'-source-mask.png')),result['body']*255);cv2.imwrite(str(args.out/(args.map+'-source-classes.png')),np.dstack((result['water'],result['exterior'],result['body']))*255)
 # Native colour itself is never altered; this is a diagnostic overlay.
 overlay=result['image'].copy();sel=result['body']>0;overlay[sel]=overlay[sel]*.55+np.array([0,90,0]);cv2.imwrite(str(args.out/(args.map+'-source-overlay.png')),overlay)
 print(args.map,{k:int(result[k].sum()) for k in ['body','exterior','water','flat']},'sites',len(result['siteAreas']))
