"""Second pass: exact flat site/pass exclusion, renderer footprint QA and preservation."""
from pathlib import Path
import sys,gzip,json,base64,zipfile,hashlib
import cv2,numpy as np
from segment import classify
from geometry import polygons
from scipy.ndimage import distance_transform_edt,map_coordinates
import argparse
parser=argparse.ArgumentParser();parser.add_argument('map',nargs='?');parser.add_argument('--baseline',type=Path,required=True);args=parser.parse_args()
root=Path(__file__).resolve().parents[2];out=root/'analysis/terrain256';reports=[]
with zipfile.ZipFile(args.baseline) as baseline:
 prefix=baseline.namelist()[0].split('/')[0]
 for path in sorted((root/'assets/data').glob('*.gz')):
  d=json.loads(gzip.decompress(path.read_bytes()));slug=d['catalog']['map'];
  if args.map and slug!=args.map:continue
  assert 'terrain256' in d,slug
  old=json.loads(gzip.decompress(baseline.read(prefix+'/assets/data/'+path.name)))
  res=classify(d,cv2.imread(str(root/'assets/maps'/f'{slug}.webp')));H,W=res['body'].shape;a,b,c,e=d['catalog']['bounds'];stats=[]
  for kind in ['mesh','snowMesh']:
   m=d['terrain16'][kind];encoded=isinstance(m['positions'],str);p=(np.frombuffer(base64.b64decode(m['positions']),'<f4') if encoded else np.array(m['positions'],np.float32)).reshape(-1,3).copy();tri=(np.frombuffer(base64.b64decode(m['indices']),'<u4') if encoded else np.array(m['indices'],np.uint32)).reshape(-1,3).copy()
   def pixel(q):return np.clip(np.floor((q[:,0].astype(float)-a)/(c-a)*(W-1)+.5).astype(int),0,W-1),np.clip(np.floor((e+q[:,2].astype(float))/(e-b)*(H-1)+.5).astype(int),0,H-1)
   px,py=pixel(p);forbidden=res['flat'][py,px]>0;cent=p[tri].astype(float).mean(axis=1);cx,cy=pixel(cent);bodyMask=res['body' if kind=='mesh' else 'exterior'];keep=~forbidden[tri].any(axis=1)&(res['flat'][cy,cx]==0)&(bodyMask[py,px][tri]>0).all(axis=1)&(bodyMask[cy,cx]>0);tri=tri[keep]
   used,inv=np.unique(tri,return_inverse=True);p=p[used];tri=inv.reshape(-1,3).astype('<u4');px,py=pixel(p);cx,cy=pixel(p[tri].astype(float).mean(axis=1));assert np.isfinite(p).all();assert not (res['hatch'][py,px]==0).any();assert not (res['hatch'][cy,cx]==0).any();assert not (res['flat'][py,px]>0).any()
   # Smooth the existing Z field in source-pixel space only. XY stays fixed.
   # This removes the sharp sampling spikes exposed by narrower footprints.
   if kind=='mesh':
    zi=np.frombuffer(base64.b64decode(m['zones']),np.uint8)[used];p[:,1]=np.minimum(p[:,1],np.where(zi>0,9.25,8.3))
   if not d['terrain256'].get('secondPass'):
    hg=np.zeros((H,W),np.float32);covered=np.zeros((H,W),np.uint8);hg[py,px]=p[:,1];covered[py,px]=1
    _,near=distance_transform_edt(covered==0,return_indices=True);hg=hg[near[0],near[1]];hg[bodyMask==0]=0
    smooth=cv2.GaussianBlur(hg,(0,0),1.8 if kind=='mesh' else 1.3)
    p[:,1]=smooth[py,px]
   edges=np.vstack((tri[:,[0,1]],tri[:,[1,2]],tri[:,[2,0]])).astype(np.uint64);edges.sort(axis=1);keys=edges[:,0]*len(p)+edges[:,1];un,count=np.unique(keys,return_counts=True);assert count.max()<=2;openedges=un[count==1];borders=np.unique(np.r_[openedges//len(p),openedges%len(p)]).astype(int);p[borders,1]=0
   m['positions']=base64.b64encode(p.astype('<f4').tobytes()).decode() if encoded else p.ravel().tolist();m['indices']=base64.b64encode(tri.astype('<u4').tobytes()).decode() if encoded else tri.ravel().tolist()
   if encoded:
    zones=np.frombuffer(base64.b64decode(m['zones']),np.uint8)[used];m['zones']=base64.b64encode(zones.tobytes()).decode();m['vertices']=len(p);m['triangles']=len(tri)
   reference=res['body' if kind=='mesh' else 'exterior']
   rendered=np.zeros_like(reference);cont=np.rint(np.stack((px,py),axis=1)[tri]).astype(np.int32)
   for i in range(0,len(cont),20000):cv2.fillPoly(rendered,list(cont[i:i+20000]),1)
   union=np.count_nonzero(reference|rendered);iou=float(np.count_nonzero(reference&rendered)/max(1,union));stats.append({'kind':kind,'vertices':len(p),'triangles':len(tri),'sourceMaskIoU':iou,'outsideBlockedArea':0,'raisedFlatSites':0,'nonManifoldEdges':0,'floatingBoundaryVertices':0,'maxHeight':float(p[:,1].max())})
  # Gameplay, source imagery, structures and calibrated building circles stay identical.
  new=dict(d);original=dict(old);new.pop('terrain256');new['terrain16']=dict(new['terrain16']);original['terrain16']=dict(original['terrain16']);new['terrain17']=dict(new['terrain17']);original['terrain17']=dict(original['terrain17'])
  for key in ['mesh','snowMesh']:new['terrain16'].pop(key);original['terrain16'].pop(key)
  for obj in [new,original]:obj['terrain17'].pop('details')
  assert new==original,slug+' non-terrain data changed'
  for rel in ['assets/maps/'+slug+'.webp','assets/solver/'+slug+'.json.gz']:assert (root/rel).read_bytes()==baseline.read(prefix+'/'+rel)
  d['terrain256']['flatSiteAreas']=res['siteAreas'];d['terrain256']['validation']=stats;d['terrain256']['secondPass']=True
  def vectors(mask):return [{'outer':np.array(q.exterior.coords)[:-1].tolist(),'holes':[np.array(r.coords)[:-1].tolist() for r in q.interiors]} for q in polygons(mask)]
  (root/'assets/audit256'/(slug+'-contours.json')).write_text(json.dumps({'width':W,'height':H,'ridge':vectors(res['body']),'exterior':vectors(res['exterior'])},separators=(',',':')))
  np.savez_compressed(out/(slug+'-source.npz'),body=res['body'],exterior=res['exterior'],flat=res['flat'],water=res['water'])
  path.write_bytes(gzip.compress(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode(),compresslevel=5,mtime=0));reports.append({'map':slug,'name':d['catalog']['name'],'meshes':stats,'sourceImageIdentical':True,'structuresIdentical':True,'gameplayIdentical':True,'flatFoundations':len(res['siteAreas'])});print(slug,stats,flush=True)
assert len(reports)==(1 if args.map else 21)
(out/(args.map+'-validation.json' if args.map else 'validation.json')).write_text(json.dumps({'passed':True,'maps':reports,'metricLimitation':'Mask IoU validates triangulation against the independently image-derived classification, not semantic perfection or real elevations.'},indent=2),encoding='utf8')
