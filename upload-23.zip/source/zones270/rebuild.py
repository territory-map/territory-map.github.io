"""Group walking components into gameplay zones without changing navigation.

Native province IDs identify zones on 17 maps; their coarse raster is used
only for component identity, never for boundaries. The four home maps have
no province raster: small enclosed pockets with no exit pass inherit the
surrounding pass-connected region. Keep all pass endpoints in distinct zones.
Run from any directory with Python, numpy, OpenCV and Pillow installed.
"""
from pathlib import Path
import gzip,json,base64
import numpy as np
import cv2
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'analysis/zones270';OUT.mkdir(parents=True,exist_ok=True)
catalog={};reports=[]
for path in sorted((ROOT/'assets/solver').glob('*.gz')):
 d=json.loads(gzip.decompress(path.read_bytes()));n=d['navigation18'];w,h=n['width'],n['height'];a,b,c,e=d['catalog']['bounds']
 labels=np.frombuffer(base64.b64decode(n['regions']),'<u2').reshape(h,w)
 ids=[int(z) for z in np.unique(labels) if z];counts=np.bincount(labels.ravel())
 _,nearest=cv2.distanceTransformWithLabels((labels==0).astype(np.uint8),cv2.DIST_L2,5,labelType=cv2.DIST_LABEL_CCOMP)
 lookup=np.zeros(int(nearest.max())+1,np.uint16);lookup[nearest[labels>0]]=labels[labels>0];filled=lookup[nearest]
 mapping={z:z for z in ids};groups={};confidence={};p=d['province'];method='native-province identity / original navigation contours'
 if p:
  pc=np.asarray(p['cells']).reshape(p['height'],p['width'])
  # Province rows are native Y ascending; navigation rows are Y descending.
  xx=np.clip(np.floor((np.linspace(a,c,w)-p['origin'][0])/p['cellSize']).astype(int),0,p['width']-1)
  yy=np.clip(np.floor((np.linspace(e,b,h)-p['origin'][1])/p['cellSize']).astype(int),0,p['height']-1)
  grid=pc[yy[:,None],xx[None,:]]
  for z in ids:
   v,cnt=np.unique(grid[labels==z],return_counts=True);i=int(np.argmax(cnt));q=int(v[i])
   # King of the Nile stores sparse zero cells inside its forbidden temple
   # provinces (19/20/29). Zero is also a genuine outer province on other maps.
   # Prefer an explicitly forbidden province present in a substantial part of
   # this component over the sparse zero padding, never merge these enclaves.
   forbidden=set(p.get('flagBlocked',[]))|set(p.get('fortressBlocked',[]))
   alternate=[j for j in range(len(v)) if int(v[j]) in forbidden and cnt[j]/cnt.sum()>=.1]
   if q==0 and alternate:i=max(alternate,key=lambda j:cnt[j]);q=int(v[i])
   confidence[z]=float(cnt[i]/cnt.sum());groups.setdefault(q,[]).append(z)
  # A province ID of zero is a valid native zone, not the selection sentinel.
  for group in groups.values():
   for z in group:mapping[z]=min(group)
 else:
  method='pass-boundary components / enclosed no-exit terrain pockets'
  incident=set(sum(n['passes'].values(),[]))
  adjacency={}
  for left,right in [(filled[:,:-1],filled[:,1:]),(filled[:-1,:],filled[1:,:])]:
   mask=left!=right;pairs=np.sort(np.column_stack((left[mask],right[mask])),axis=1)
   pairs,cnt=np.unique(pairs,axis=0,return_counts=True)
   for (s,t),amount in zip(pairs,cnt):
    key=(int(s),int(t));adjacency[key]=adjacency.get(key,0)+int(amount)
  for z in ids:
   if z in incident:continue
   # A large area without recognized exits is ambiguous: never merge silently.
   if counts[z]>w*h*.001:raise ValueError(f'{path.name}: large no-exit region {z}')
   neighbors=[(amount,t if s==z else s) for (s,t),amount in adjacency.items() if z in (s,t) and (t if s==z else s) in incident]
   if not neighbors:raise ValueError(f'{path.name}: no enclosing region for {z}')
   mapping[z]=max(neighbors)[1]
 # Canonical IDs are fixed points, so saved 2.6.0 selections can be migrated
 # idempotently; numerical walking IDs remain untouched everywhere else.
 merged={}
 for z,q in mapping.items():merged.setdefault(q,[]).append(z)
 mapping={z:min(merged[q]) for z,q in mapping.items()}
 conflicts=[k for k,v in n['passes'].items() if len(v)==2 and mapping[v[0]]==mapping[v[1]]]
 if conflicts:raise ValueError(f'{path.name}: merged exit passes: {conflicts}')
 remap=np.zeros(max(ids)+1,np.uint16)
 for z,q in mapping.items():remap[z]=q
 zones=remap[filled];name=d['catalog']['map'];catalog[name]={'regions':mapping,'method':method}
 report={'map':name,'name':d['catalog']['name'],'walkingRegions':len(ids),'zones':len(set(mapping.values())),'groups':{str(q):[z for z,v in mapping.items() if v==q] for q in sorted(set(mapping.values()))},'method':method,'minimumProvinceAgreement':min(confidence.values()) if confidence else None,'passCount':len(n['passes']),'mergedExitPasses':conflicts,'navigationUnchanged':True}
 reports.append(report)
 # Registered audit: zone colour uses the native contours, not province squares.
 small=cv2.resize(zones,(950,round(h/w*950)),interpolation=cv2.INTER_NEAREST)
 base=Image.open(ROOT/'assets/maps'/f'{name}.webp').convert('RGB').resize((small.shape[1],small.shape[0]))
 colors=np.zeros((*small.shape,3),np.uint8)
 for q in np.unique(small):colors[small==q]=np.random.default_rng(int(q)).integers(70,235,size=3)
 overlay=Image.blend(base,Image.fromarray(colors),.3);draw=ImageDraw.Draw(overlay)
 for q in np.unique(small):
  yy,xx=np.nonzero(small==q);i=np.argmin((xx-xx.mean())**2+(yy-yy.mean())**2);draw.text((int(xx[i]),int(yy[i])),str(q),fill='white',stroke_width=2,stroke_fill='black')
 overlay.save(OUT/f'{name}.jpg',quality=88)
 print(report['name'],len(ids),'→',report['zones'],'zones; all pass boundaries preserved',flush=True)
(ROOT/'web/core/zone-catalog270.js').write_text('// Generated by source/zones270/rebuild.py; do not edit navigation masks.\nexport const WAR_ZONE_CATALOG='+json.dumps(catalog,separators=(',',':'))+';\n',encoding='utf8')
(OUT/'inventory.json').write_text(json.dumps({'passed':True,'maps':reports},ensure_ascii=False,indent=2),encoding='utf8')
