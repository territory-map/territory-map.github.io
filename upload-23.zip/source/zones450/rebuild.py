"""Audit all maps and group complete war zones without relaxing navigation.

Native provinces remain authoritative on lost-land maps. Home maps have no
province raster: distinguish textured wall bodies from thin outline fragments,
then join only adjacent fragments with weak wall support and no pass between
them. Reject any union collapsing an exit pass. The inspection measurements
are stored alongside the generated mapping for reproducibility.
"""
from pathlib import Path
import base64, gzip, json, cv2, numpy as np
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'analysis/zones450';OUT.mkdir(parents=True,exist_ok=True)
previous=json.loads((ROOT/'web/core/zone-catalog270.js').read_text().split('=',1)[1].rstrip(';\n'))
reports=[];catalog={}
for path in sorted((ROOT/'assets/data').glob('*.gz')):
 d=json.loads(gzip.decompress(path.read_bytes()));name=d['catalog']['map'];n=d['navigation18'];w,h=n['width'],n['height'];a,b,c,e=d['catalog']['bounds']
 raw=np.frombuffer(base64.b64decode(n['regions']),'<u2').reshape(h,w)
 old={int(k):v for k,v in previous[name]['regions'].items()};parent={q:q for q in set(old.values())}
 def find(q):
  while parent[q]!=q:q=parent[q]
  return q
 pass_edges=[ends for ends in n['passes'].values() if len(ends)==2]
 def merge(s,t):
  s,t=find(s),find(t)
  if s==t:return False
  for left,right in pass_edges:
   zs,zt=find(old[left]),find(old[right])
   if {zs,zt}=={s,t}:raise ValueError(f'{name}: merge would remove a pass boundary {left}/{right}')
  parent[max(s,t)]=min(s,t);return True
 def poly(points):return np.rint([[(x-a)/(c-a)*(w-1),(e-y)/(e-b)*(h-1)] for x,y in points]).astype(np.int32)
 boundary_audit=[];joined=[]
 if d['province'] is None:
  lut=np.zeros(int(raw.max())+1,np.uint16)
  for z,q in old.items():lut[z]=q
  labels=lut[raw]
  _,nearest=cv2.distanceTransformWithLabels((labels==0).astype(np.uint8),cv2.DIST_L2,5,labelType=cv2.DIST_LABEL_CCOMP)
  lookup=np.zeros(int(nearest.max())+1,np.uint16);lookup[nearest[labels>0]]=labels[labels>0];fill=lookup[nearest]
  ridge=np.zeros((h,w),np.uint8)
  for p in d['terrain16']['ridges']:
   cv2.fillPoly(ridge,[poly(p['outer'])],1)
   for hole in p['holes']:cv2.fillPoly(ridge,[poly(hole)],0)
  # Nine native image pixels suppress thin contour strokes; real wall bodies
  # remain. A seven-pixel neighborhood tolerates the filled-mask bisector.
  body=cv2.erode(ridge,np.ones((9,9),np.uint8))
  distance=cv2.distanceTransform(1-body,cv2.DIST_L2,5)
  pairs={}
  for dy,dx in [(0,1),(1,0)]:
   left=fill[:h-dy,:w-dx];right=fill[dy:,dx:];mask=(left!=right)&(left>0)&(right>0)
   ys,xs=np.nonzero(mask);keys=np.minimum(left[mask],right[mask]).astype(int)*65536+np.maximum(left[mask],right[mask])
   for key in np.unique(keys):
    pair=(int(key//65536),int(key%65536));sel=keys==key;pairs.setdefault(pair,[]).append(distance[ys[sel],xs[sel]])
  passpairs={tuple(sorted([old[x] for x in ends])) for ends in pass_edges}
  for pair,values in pairs.items():
   ds=np.concatenate(values);support=float((ds<=7).mean());exit_pass=pair in passpairs
   candidate=len(ds)>100 and support<.65 and not exit_pass
   row={'pair':pair,'boundaryPixels':len(ds),'wallBodySupport':support,'exitPass':exit_pass,'join':candidate};boundary_audit.append(row)
   if candidate and merge(*pair):joined.append(list(pair))
  method='Registered native wall-body support + explicit closed-pass topology; outline fragments grouped'
 else:
  method='Native province identity verified against every explicit pass boundary'
 mapping={z:find(q) for z,q in old.items()}
 assert all(mapping[q]==q for q in set(mapping.values()))
 conflicts=[site for site,ends in n['passes'].items() if len(ends)==2 and mapping[ends[0]]==mapping[ends[1]]]
 assert not conflicts,(name,conflicts)
 # All maps are checked against the complete set of navigation labels and
 # their original exit edges. Collision masks and walking components persist.
 assert set(mapping)==set(int(z) for z in np.unique(raw) if z)
 groups={str(q):[z for z,v in mapping.items() if v==q] for q in sorted(set(mapping.values()))}
 if d['province'] is None:assert len(groups)==10,(name,groups)
 catalog[name]={'regions':mapping,'method':method}
 report={'map':name,'name':d['catalog']['name'],'walkingRegions':len(mapping),'previousZones':len(set(old.values())),'zones':len(groups),'groups':groups,'joinedBorders':joined,'boundaryAudit':boundary_audit,'passCount':len(n['passes']),'collapsedExitPasses':conflicts,'navigationUnchanged':True,'method':method};reports.append(report)
 lut=np.zeros(int(raw.max())+1,np.uint16)
 for z,q in mapping.items():lut[z]=q
 zone=lut[raw]
 _,nearest=cv2.distanceTransformWithLabels((zone==0).astype(np.uint8),cv2.DIST_L2,5,labelType=cv2.DIST_LABEL_CCOMP)
 lookup=np.zeros(int(nearest.max())+1,np.uint16);lookup[nearest[zone>0]]=zone[zone>0];zone=lookup[nearest]
 small=cv2.resize(zone,(1100,round(h/w*1100)),interpolation=cv2.INTER_NEAREST)
 base=Image.open(ROOT/'assets/maps'/f'{name}.webp').convert('RGB').resize((small.shape[1],small.shape[0]))
 colors=np.zeros((*small.shape,3),np.uint8)
 for q in np.unique(small):colors[small==q]=np.random.default_rng(int(q)).integers(70,235,size=3)
 overlay=Image.blend(base,Image.fromarray(colors),.28);draw=ImageDraw.Draw(overlay)
 for q in np.unique(small):
  yy,xx=np.nonzero(small==q);i=np.argmin((xx-xx.mean())**2+(yy-yy.mean())**2);draw.text((int(xx[i]),int(yy[i])),str(q),fill='white',stroke_width=2,stroke_fill='black')
 overlay.save(OUT/f'{name}.jpg',quality=90)
 print(report['name'],report['previousZones'],'->',report['zones'],'zones;',len(n['passes']),'pass boundaries preserved',flush=True)
(ROOT/'web/core/zone-catalog450.js').write_text('// Generated by source/zones450/rebuild.py. Original navigation stays unchanged.\nexport const WAR_ZONE_CATALOG='+json.dumps(catalog,separators=(',',':'))+';\n',encoding='utf8')
(OUT/'inventory.json').write_text(json.dumps({'passed':True,'maps':reports},ensure_ascii=False,indent=2),encoding='utf8')
