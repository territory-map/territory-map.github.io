import assert from 'node:assert/strict';import fs from 'node:fs';import zlib from 'node:zlib';
import {MapModel,newPlan} from '../web/core/model.js';import {solve} from '../web/solver.js';
const width=601,height=401,mask=new Uint8Array(width*height),regions=new Uint16Array(width*height);
for(let y=0;y<height;y++)for(let x=0;x<width;x++){const k=y*width+x;regions[k]=x<300?1:2;if(x>=298&&x<=302)mask[k]=255;}
const data={catalog:{map:'gate-test',nativeMapSize:600,bounds:[0,0,600,400],structureRules:{45:{territoryRadiusInCells:1,claimable:true,collision:{shape:'territory-square',radiusInCells:1}}},buildings:{flag:{limit:500},fortress:{limit:5}},resourceProductionPerHour:{crystal:100}},sites:[{id:'gate',kind:'pass',strongholdType:45,level:4,x:300,y:198}],resources:[],definitions:[],instances:[],terrain15:{hatching:Buffer.from(mask).toString('base64'),hatchingWidth:width,hatchingHeight:height},navigation18:{width,height,regions:Buffer.from(regions.buffer).toString('base64'),passes:{gate:[1,2]}}};
const m=new MapModel(data),p=newPlan('gate-test');p.settings.resourceRadius=1;p.buildings=[{id:'root',kind:'fortress',x:261,y:99,allianceId:'a1'}];m.setPlan(p);
assert.match(m.placementError({kind:'flag',x:315,y:99,allianceId:'a1'}),/Zone/,'2.9: direct jump without own or coalition pass contact is blocked');
assert.match(m.placementError({kind:'fortress',x:350,y:99,allianceId:'a1'}),/Zone gesperrt/,'second fortress cannot bypass gate');
assert.match(m.staticError({kind:'flag',x:297,y:99}),/Wand/,'circle touches hatch edge');
assert.equal(m.canCapture(m.sites[0],'a1'),false,'distant pass is not capturable');
p.capturedPasses.gate='a1';m.setPlan(p);assert.match(m.zoneError({kind:'flag',x:350,y:99,allianceId:'a1'}),/Zone gesperrt/,'forged distant capture does not unlock');delete p.capturedPasses.gate;
p.targets=[{id:'other-side',x:387,y:198}];m.setPlan(p);const routed=solve(m,p,'a1',{budget:20,crystals:false,maxVisits:6000});
assert.equal(routed.failed.length,0);assert.ok(routed.buildings.some(b=>b.x>302),'solver continues after touching gate');assert.ok(routed.buildings.length);
const checked=structuredClone(p);for(const b of routed.buildings){m.setPlan(checked);assert.equal(m.placementError(b),null);checked.buildings.push(b);}m.setPlan(checked);assert.ok(m.canCapture(m.sites[0],'a1'));assert.equal(m.targetReached({siteId:'gate'},'a1'),true);
checked.capturedPasses.gate='a1';m.setPlan(checked);assert.equal(m.zoneError({kind:'flag',x:350,y:198,allianceId:'a1'}),null);assert.ok(m.targetReached({siteId:'gate'},'a1'));
const next=solve(m,checked,'a1',{budget:20,crystals:false,maxVisits:6000});assert.equal(next.failed.length,0);assert.equal(next.buildings.length,0,'already reached target requires no duplicate flags');
delete checked.capturedPasses.gate;m.setPlan(checked);assert.equal(m.zoneError({kind:'flag',x:350,y:198,allianceId:'a1'}),null);const linked=structuredClone(checked);checked.buildings=[checked.buildings[0]];m.setPlan(checked);assert.match(m.zoneError({kind:'flag',x:350,y:198,allianceId:'a1'}),/Zone gesperrt/);checked.buildings=linked.buildings;m.setPlan(checked);
const r={kind:'food',x:100,y:100},contactDistance=m.buildingRadius({kind:'flag'})+m.resourceRadius(r);m.resourceSpatial=new Map([['1:1',[r]]]);assert.match(m.staticError({kind:'flag',x:100+contactDistance,y:100}),/Grundkreise/);assert.equal(m.staticError({kind:'flag',x:100+contactDistance+.001,y:100}),null);checked.settings.resourceRadius=2;m.setPlan(checked);assert.match(m.staticError({kind:'flag',x:111,y:100}),/Grundkreise/);
// Additional real-map cross-zone regression: Shifting Gears.
const real=JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL('../assets/data/LostLand_Map_18_v2.json.gz',import.meta.url)))),rm=new MapModel(real),rp=newPlan(real.catalog.map);// Use a legal fortress position: the former 650/640 point is province-restricted.
rp.buildings=[{id:'fort',kind:'fortress',x:480*6,y:632*6,allianceId:'a1'}];assert.equal(rm.staticError(rp.buildings[0]),null);rm.setPlan(rp);
const blocked=rm.zoneError({kind:'flag',x:650*6,y:545*6,allianceId:'a1'});assert.ok(blocked);assert.ok(rm.routePrerequisite({x:650*6,y:545*6},'a1'));
const result={passed:true,unqualifiedWallJumpBlocked:true,fortressBypassBlocked:true,forgedCaptureBlocked:true,solverUnlocksPassBeforeCrossing:true,solverContinuesAfterCapture:true,resourceTangencyBlocked:true,resourceSettingApplied:true,realMapZones:[rm.groundAccess.region(rp.buildings[0].x,rp.buildings[0].y),rm.groundAccess.region(3900,3270)],approachFlags:routed.buildings.length,afterCaptureFlags:next.buildings.length};
fs.writeFileSync(new URL('./access-v18.json',import.meta.url),JSON.stringify(result,null,2));console.log(result);
