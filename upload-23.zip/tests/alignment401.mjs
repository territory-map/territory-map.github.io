import assert from 'node:assert/strict';
import fs from 'node:fs';import zlib from 'node:zlib';import vm from 'node:vm';
import {MapModel,newPlan,validatePlan} from '../web/core/model.js';
import {resourceSymbolHeight} from '../web/core/resource-size.js';
vm.runInThisContext(fs.readFileSync('web/vendor/three.min.js','utf8'));
const T=globalThis.THREE,{View}=await import('../web/view.js'),{createResourceCards}=await import('../web/reference-art.js');
const data=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/data/Sever_Map_G1_1_v2.json.gz'))),model=new MapModel(data),plan=newPlan(data.catalog.map);
const gold=data.resources.find(q=>q.id===21085),cave=data.landmarks.find(q=>q.id==='caves:11085');
assert.deepEqual([plan.settings.resourceRadius,plan.settings.fortressRadius,plan.settings.caveRadius,plan.settings.villageRadius,plan.settings.flagRadius],[.98,.94,.73,.73,.67]);
let independent=0;
for(const key of ['flagRadius','fortressRadius','resourceRadius','caveRadius','villageRadius']){
 const p=newPlan(plan.map);p.settings[key]=1.23;const loaded=validatePlan(JSON.parse(JSON.stringify(p)),p.map);assert.equal(loaded.version,12);
 for(const k of Object.keys(plan.settings))assert.equal(loaded.settings[k],k===key?1.23:plan.settings[k]);independent++;
}
const old=newPlan(plan.map);old.version=10;Object.assign(old.settings,{flagRadius:.67,fortressRadius:.97,caveRadius:.75,villageRadius:.75});assert.deepEqual(validatePlan(old,old.map).settings,plan.settings);
const sample=q=>{let n=0,blocked=0,r=q.kind==='cave'?model.landmarkRadius(q):model.resourceRadius(q);for(let y=-r;y<r;y+=.1)for(let x=-r;x<r;x+=.1)if(x*x+y*y<r*r){n++;blocked+=Number(model.terrainCollision(q.x+x,q.y+y,0));}return blocked/n;};
const coverage={resource:sample(gold),cave:sample(cave)};assert.equal(coverage.resource,0);assert.equal(coverage.cave,0);
let renderCases=0;
for(const mode of ['2d','3d']){
 const sprite=(entity,node)=>{const s=new T.Sprite(new T.SpriteMaterial());s.position.set(node.x,0,-node.y);s.userData={[entity]:node,size:18,aspect:1.2,left:.17,right:.82,anchor:.04,top:.66};return s;};
 const ore=sprite('resource',gold),landmark=sprite('landmark',cave),group=new T.Group(),card=createResourceCards([gold],new T.Texture({width:64,height:64}),'coin');group.add(card);
 const view=Object.assign(Object.create(View.prototype),{camera:new T.OrthographicCamera(-1,1,1,-1,.1,60000),scene:new T.Scene(),flags:{resources:true},poi:{},mode,scale:.5,w:1280,h:720,tilt:Math.PI/4,azimuth:0,center:new T.Vector3(gold.x,0,-gold.y),model,resourceSolids:group,symbols:[ore,landmark]});view.scene.add(ore,landmark,group);view.updateCamera();
 for(const resourceR of [1,1.23])for(const caveR of [.81,1.1]){
  plan.settings.resourceRadius=resourceR;plan.settings.caveRadius=caveR;model.setPlan(plan);view.updateSprites();
  for(const [s,r]of [[ore,model.resourceRadius(gold)],[landmark,model.landmarkRadius(cave)]]){
   assert.ok(Math.abs(s.scale.y-resourceSymbolHeight(s.userData,r))<1e-9);
   assert.ok(Math.abs(s.center.x-.495)<1e-9);assert.ok(Math.abs(s.center.y-.35)<1e-9);
   assert.ok(Math.hypot((s.userData.right-s.userData.left)*s.scale.x,(s.userData.top-s.userData.anchor)*s.scale.y)<2*r);
  }
  const mat=new T.Matrix4(),pos=new T.Vector3(),quat=new T.Quaternion(),size=new T.Vector3();card.getMatrixAt(0,mat);mat.decompose(pos,quat,size);assert.ok(Math.abs(size.x*18-resourceR*6*2*.92)<1e-5,'resource-card cache refreshes after manual radius change');renderCases++;
 }
}
const result={passed:true,independentSettings:independent,renderCases,coverage,positionsUnchanged:{gold,cave},defaults:newPlan(plan.map).settings};
fs.mkdirSync('analysis/alignment401',{recursive:true});fs.writeFileSync('analysis/alignment401/results.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
