import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {newPlan,validatePlan} from '../web/core/model.js';
import {removeAlliance} from '../web/core/alliances.js';
const p=newPlan('alliance257');p.alliances.push({id:'a2',name:'Test',color:'#ddbb99'});
p.buildings=[{id:'keep',kind:'fortress',allianceId:'a1',x:99,y:99},{id:'drop',kind:'fortress',allianceId:'a2',x:999,y:999}];
p.targets=[{id:'shared',x:900,y:900},{id:'owned',allianceId:'a2',x:909,y:909}];p.annotations=[{id:'drawing',kind:'line',points:[[0,0],[5,5]]}];
p.capturedPasses={one:'a1',two:'a2'};p.settings.solverStartByAlliance={a1:'keep',a2:'drop'};p.routingRootId='drop';p.routingStartId='drop';p.siteEdits={site:{x:1,y:2}};
const before=structuredClone(p);assert.equal(removeAlliance(p,'missing'),null);assert.deepEqual(p,before);
assert.equal(removeAlliance(p,'a2'),'a1');assert.equal(p.buildings.length,1);assert.equal(p.targets.length,1);assert.deepEqual(p.annotations,before.annotations);assert.deepEqual(p.siteEdits,before.siteEdits);assert.deepEqual(p.capturedPasses,{one:'a1'});assert.deepEqual(p.settings.solverStartByAlliance,{a1:'keep'});assert.equal(p.routingRootId,undefined);assert.equal(p.routingStartId,undefined);assert.doesNotThrow(()=>validatePlan(p,p.map));
const single=structuredClone(p);assert.equal(removeAlliance(p,'a1'),null);assert.deepEqual(p,single);
// Exercise the actual UI handler with the same undo transaction as the app.
const source=fs.readFileSync('web/app.js','utf8'),start=source.indexOf("$('#removeAlliance').onclick="),end=source.indexOf("$('#resourceRadius').onchange=",start),elements=new Map(),undo=[],live=structuredClone(before);
let terminated=false;const ctx=vm.createContext({localizedText:(element,source)=>element.textContent=source,plan:live,allianceId:'a2',selected:{id:'drop'},removeAlliance,allianceUI:()=>{},view:{clearMovePreview:()=>{},preview:()=>{}},message:()=>{},change:fn=>{terminated=true;undo.push(structuredClone(live));fn();},$:s=>{if(!elements.has(s))elements.set(s,{});return elements.get(s);}});
vm.runInContext(source.slice(start,end),ctx);elements.get('#removeAlliance').onclick();assert.ok(terminated);assert.equal(ctx.allianceId,'a1');assert.equal(ctx.selected,null);assert.deepEqual(undo[0],before);assert.deepEqual(live,p);assert.equal(elements.get('#solverResult').textContent,'');
console.log('2.5.7: alliance removal, reference cleanup, shared targets and undo snapshot passed');
