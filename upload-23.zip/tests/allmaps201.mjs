import fs from 'node:fs';import zlib from 'node:zlib';import assert from 'node:assert/strict';import {spawnSync} from 'node:child_process';
import {MapModel,newPlan} from '../web/core/model.js';import {solve} from '../web/solver.js';
if(!process.argv[2]){
 const results=[];for(const file of fs.readdirSync('assets/solver').filter(f=>f.endsWith('.gz'))){const p=spawnSync(process.execPath,['--max-old-space-size=768',import.meta.filename,file],{encoding:'utf8',timeout:120000});console.log(file,p.status,p.stdout.trim());assert.equal(p.status,0,p.stderr||p.error?.message);results.push(JSON.parse(p.stdout));}
 fs.writeFileSync('tests/allmaps-v201.json',JSON.stringify({passed:true,maps:results.length,cases:results.length*2,results},null,2));
}else{
 const file=process.argv[2],d=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/solver/'+file))),m=new MapModel(d),kind=d.catalog.buildings.fortress?'fortress':'center-fortress';let root;
 for(let x=999;x<Math.min(5000,d.catalog.nativeMapSize-400)&&!root;x+=54)for(let y=999;y<Math.min(5000,d.catalog.nativeMapSize-400)&&!root;y+=54){const b={id:'root',kind,x,y,allianceId:'a1'};if(m.staticError(b))continue;const region=m.groundAccess.buildingRegion(x,y);if(!region)continue;let valid=true;for(let dx=54;dx<=270;dx+=54)if(m.staticError({kind:'flag',x:x+dx,y,allianceId:'a1'})||m.groundAccess.buildingRegion(x+dx,y)!==region)valid=false;if(valid)root=b;}
 assert.ok(root,'free corridor on '+file);const cases=[];
 for(const enabled of [false,true]){const p=newPlan(d.catalog.map);p.buildings=[root];p.settings.useCrusaderStructures=enabled;p.targets=[{id:'target',x:root.x+265,y:root.y}];const start=performance.now();const result=solve(m,p,'a1',{startId:'root',budget:20,crystals:true,crystalExtra:2,maxVisits:12000,maxNodes:10000});assert.equal(result.failed.length,0,result.reason);const applied=structuredClone(p);for(const b of result.buildings){m.setPlan(applied);assert.equal(m.placementError(b),null);applied.buildings.push(b);}m.setPlan(applied);assert.ok(m.targetReached(p.targets[0],'a1'));cases.push({enabled,ms:Math.round(performance.now()-start),flags:result.buildings.length,crystals:result.gems});}
 console.log(JSON.stringify({map:d.catalog.map,name:d.catalog.name,cases}));
}
