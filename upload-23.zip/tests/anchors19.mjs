import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
vm.runInThisContext(fs.readFileSync(new URL('../web/vendor/three.min.js',import.meta.url),'utf8'));
const T=globalThis.THREE,{View}=await import('../web/view.js');
const references=[{kind:'flag',w:1024,h:1536,bounds:[209,70,809,1478],marked:[509,1252.72]},{kind:'fortress',w:104,h:105,bounds:[22,4,100,87],marked:[71.5,78.7]}];let cases=0;
for(const mode of ['2d','3d'])for(const scale of [.16,.5,2,8])for(const rotation of [0,.5,2])for(const r of references){
 const [left,top,right,bottom]=r.bounds,o=new T.Sprite(new T.SpriteMaterial());o.userData={building:{kind:r.kind},size:34,aspect:r.w/r.h,left:left/r.w,right:right/r.w,top:1-top/r.h,anchor:1-bottom/r.h};o.position.set(200,0,-200);o.material.rotation=rotation;
 const v=Object.assign(Object.create(View.prototype),{camera:new T.OrthographicCamera(-1,1,1,-1,.1,60000),scene:new T.Scene(),center:new T.Vector3(200,0,-200),flags:{},mode,azimuth:0,tilt:Math.PI/4,w:1200,h:800,scale,symbols:[o]});v.scene.add(o);v.updateCamera();v.updateSprites();
 assert.ok(Math.abs(o.center.x*r.w-r.marked[0])<1e-9);assert.ok(Math.abs((1-o.center.y)*r.h-r.marked[1])<1e-9);
 const expectedHeight=1.1*(r.kind==='flag'?6*.94/(300/1536):9*.94/(31/105));assert.ok(o.scale.y>=expectedHeight-1e-8,'art never smaller than 2.3');assert.ok(o.scale.y/scale*(o.userData.top-o.userData.anchor)>=(r.kind==='flag'?34:40)-1e-6,'overview artwork remains readable');
 const group=new T.Group();v.circle(200,200,9,'white',group);for(const y of Array.from(group.children[0].geometry.attributes.position.array).filter((_,i)=>i%3===1))assert.equal(y,0,'circle lies on the same ground plane as the anchor');cases++;
}
const report={passed:true,cases,markedFoundationPoints:references.map(({kind,marked})=>({kind,marked})),circleGroundHeight:0};fs.writeFileSync(new URL('./anchors-v19.json',import.meta.url),JSON.stringify(report,null,2));console.log(report);
