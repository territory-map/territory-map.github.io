import fs from 'node:fs';
globalThis.localStorage={getItem:()=> 'en'};
const {translate}=await import('../web/i18n.js');
const files=fs.readdirSync('web').filter(n=>n.endsWith('.js')&&!['i18n.js','sites18.js'].includes(n)).map(n=>'web/'+n).concat(['web/core/model.js','web/core/war-builder.js','web/core/access18.js']);
const out=[];
for(const file of files){
 for(const m of fs.readFileSync(file,'utf8').matchAll(/(['"])((?:\\.|(?!\1)[^\\\r\n])*)\1/g)){
  const s=m[2];if(!/[äöüß]|\b(?:Flaggen|Kristall|Ziele|Passkontakt|erforderlich|nicht|Suche|Bauten|Allianzcredits)\b/.test(s)||s.includes('import'))continue;
  const t=translate(s);if(/[äöüß]|\b(?:Flaggen|Kristall|Ziele|Passkontakt|erforderlich|nicht|Suche|Bauten|Allianzcredits)\b/.test(t))out.push({file,s,t});
 }
}
console.log(JSON.stringify(out,null,2));
