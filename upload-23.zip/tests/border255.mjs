import assert from 'node:assert/strict';import {restoreLetterPixels} from '../web/border-cleanup255.js';
const w=30,h=20,source=new Uint8ClampedArray(w*h*4),mask=new Uint8ClampedArray(source.length);
for(let y=0;y<h;y++)for(let x=0;x<w;x++){const k=(y*w+x)*4;source.set([x*3,y*7,80,255],k);if(x>=12&&x<=16&&y>=7&&y<=12){mask[k]=255;source[k]=source[k+1]=source[k+2]=0;}}
const corrected=restoreLetterPixels(source,mask,w,h);let restored=0;
for(let k=0;k<source.length;k+=4){if(!mask[k])assert.deepEqual(corrected.slice(k,k+4),source.slice(k,k+4));else{assert.ok(corrected[k+2]>50);restored++;}assert.equal(corrected[k+3],source[k+3]);}
assert.equal(restored,30);console.log({passed:true,unmaskedWallPixelsUnchanged:true,onlyLetterPixelsRestored:restored});
