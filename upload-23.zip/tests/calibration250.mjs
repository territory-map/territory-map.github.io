import assert from 'node:assert/strict';import fs from 'node:fs';import zlib from 'node:zlib';
import {MapModel,G,newPlan,validatePlan} from '../web/core/model.js';import {GroundAccess} from '../web/core/access18.js';
import {FLAG_RADIUS,FORTRESS_RADIUS,RESOURCE_RADIUS} from '../web/core/footprint-calibration.js';
const results=[];
for(const source of ['data','solver']){
 const d=JSON.parse(zlib.gunzipSync(fs.readFileSync(`assets/${source}/Sever_Map_G1_1_v2.json.gz`))),m=new MapModel(d),raster=new GroundAccess(d),x=1524,y=2760;
 const boundary=fn=>{let lo=0,hi=60;for(let i=0;i<55;i++){let r=(lo+hi)/2;if(fn(r))hi=r;else lo=r;}return lo;};
 Object.assign(m.plan.settings,{flagRadius:FLAG_RADIUS/6,fortressRadius:FORTRESS_RADIUS/6,resourceRadius:RESOURCE_RADIUS/6});
 const limit=boundary(r=>m.groundAccess.blocked(x,y,r));
 // Independently measure point-to-edge distance for every native triangle.
 let closest={distance:Infinity};for(const [index,t]of m.triangles.entries())for(let i=0;i<3;i++){
  const ax=t[i*2],ay=t[i*2+1],bx=t[(i*2+2)%6],by=t[(i*2+3)%6],vx=bx-ax,vy=by-ay;
  const u=Math.max(0,Math.min(1,((x-ax)*vx+(y-ay)*vy)/(vx*vx+vy*vy||1))),px=ax+u*vx,py=ay+u*vy,distance=Math.hypot(px-x,py-y);
  if(distance<closest.distance)closest={distance,x:px,y:py,triangle:index};
 }
 assert.ok(Math.abs(limit-closest.distance)<1e-6);
 assert.equal(m.groundAccess.blocked(x,y,FLAG_RADIUS),false);
 assert.equal(m.groundAccess.blocked(x,y,FLAG_RADIUS+.00001),true);
 assert.equal(m.staticError({kind:'flag',x,y}),null);
 const original=FLAG_RADIUS;try{m.plan.settings.flagRadius=(FLAG_RADIUS+.00001)/6;assert.match(m.computeStaticError({kind:'flag',x,y}),/Grundfläche/);}finally{m.plan.settings.flagRadius=original/6;}
 let root;
 for(let dx=-72;dx<=72&&!root;dx+=6)for(let dy=-72;dy<=72&&!root;dy+=6){const p=newPlan(d.catalog.map),b={id:'reference-root',kind:'fortress',x:x+dx,y:y+dy,allianceId:'a1'};if(m.staticError(b))continue;Object.assign(p.settings,{flagRadius:FLAG_RADIUS/6,fortressRadius:FORTRESS_RADIUS/6,resourceRadius:RESOURCE_RADIUS/6});p.buildings=[b];m.setPlan(p);if(!m.placementError({kind:'flag',x,y,allianceId:'a1'}))root=b;}
 assert.ok(root,'real placement with a connected fortress');
 results.push({source,worldCenter:{x,y},gameCenter:{x:x/6,y:y/6},oldRasterLimit:boundary(r=>raster.blocked(x,y,r)),visibleContourLimit:limit,closestContourPoint:closest,storedRadius:FLAG_RADIUS,largerRadiusBlocked:FLAG_RADIUS+.00001,root});
}
assert.equal(FORTRESS_RADIUS,4.427584);assert.equal(RESOURCE_RADIUS,4.585712);
const old=newPlan('test');old.version=6;old.settings.resourceRadius=.531135;assert.ok(Math.abs(validatePlan(old,'test').settings.resourceRadius-.98)<1e-9);
old.settings.resourceRadius=1;assert.equal(validatePlan(old,'test').settings.resourceRadius,.98);
fs.writeFileSync('tests/calibration-v251.json',JSON.stringify({passed:true,results,flagRadiusGame:FLAG_RADIUS/6,fortressRadiusGame:FORTRESS_RADIUS/6,resourceRadiusGame:RESOURCE_RADIUS/6,ratios:{fortress:1.4,resource:1.45}},null,2));console.log(results);
