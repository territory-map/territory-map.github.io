import assert from 'node:assert/strict';
import fs from 'node:fs';import zlib from 'node:zlib';import vm from 'node:vm';
import {MapModel,newPlan,validatePlan,G} from '../web/core/model.js';
import {buildingGameCoordinate,buildPoint} from '../web/core/build-position.js';
import {gameCoordinate} from '../web/presentation17.js';
import {PHOTO_RADII_GAME} from '../web/core/photo-calibration400.js';
const out='analysis/calibration400';fs.mkdirSync(out,{recursive:true});
const coordinates=[];
for(const value of [253.1,253.4,253.499,253.5,253.9]){
 const label=buildingGameCoordinate(value*6);assert.equal(label,value<253.5?253:254);coordinates.push({actual:value,label});
}
assert.equal(buildingGameCoordinate(460.4*6),460);assert.equal(gameCoordinate(253.9*6),253,'map-source coordinate convention remains independent');
const exact=buildPoint(253.5*6,460.4*6);assert.deepEqual(exact,{x:1521,y:2762.4});
const radii=PHOTO_RADII_GAME;
assert.ok(radii.resource>radii.fortress&&radii.fortress>radii.cave&&radii.cave>radii.flag);
assert.equal(radii.cave,radii.village);
const areaComparison=Object.entries(radii).map(([kind,radius])=>({kind,radius,diameter:2*radius,area:Math.PI*radius**2,relativeArea:radius**2/radii.resource**2}));
const maps=[];
for(const file of fs.readdirSync('assets/data').filter(f=>f.endsWith('.gz'))){
 const d=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/data/'+file))),m=new MapModel(d),p=newPlan(d.catalog.map);
 for(const radius of [.05,.67,.97,2,10]){p.settings.fortressRadius=radius;m.setPlan(p);assert.equal(m.buildingRadius({kind:'center-fortress'}),m.buildingRadius({kind:'fortress'}));assert.equal(G.buildingRadius(m.legacy({kind:'center-fortress'})),6*radius);}
 const old=newPlan(d.catalog.map);old.version=9;Object.assign(old.settings,{flagRadius:.7,fortressRadius:.9,villageRadius:.8,caveRadius:.8});
 const upgraded=validatePlan(old,old.map);assert.deepEqual([upgraded.settings.flagRadius,upgraded.settings.fortressRadius,upgraded.settings.resourceRadius,upgraded.settings.villageRadius,upgraded.settings.caveRadius],[.67,.94,.98,.73,.73]);
 Object.assign(old.settings,{flagRadius:2,fortressRadius:3,caveRadius:1.8,villageRadius:1.9});const custom=validatePlan(old,old.map);assert.equal(custom.settings.flagRadius,2);assert.equal(custom.settings.fortressRadius,3);assert.equal(custom.settings.caveRadius,1.8);assert.equal(custom.settings.villageRadius,1.9);
 maps.push(d.catalog.map);
}
assert.equal(maps.length,21);assert.equal(G.buildingRadius({kind:'mainFortress'}),G.buildingRadius({kind:'subFortress'}));
const empty={catalog:{map:'pocket400',nativeMapSize:4000,bounds:[0,0,4000,4000],structureRules:{},buildings:{flag:{limit:500},fortress:{limit:2},'center-fortress':{limit:1}}},sites:[],resources:[],definitions:[],instances:[]};
const m=new MapModel(empty),p=newPlan(empty.catalog.map),fort={id:'root',kind:'fortress',allianceId:'a1',x:252*6,y:460*6};p.buildings=[fort];m.setPlan(p);
assert.match(m.placementError({kind:'flag',allianceId:'a1',x:252*6,y:461*6},{manual:true}),/geplantes Gebäude/,'flag and fortress one game unit apart cannot coexist');
const sum=m.buildingRadius(fort)+m.buildingRadius({kind:'flag'});
assert.ok(G.plannedBuildingCollision(m.legacy(fort),[m.legacy({kind:'flag',x:fort.x+sum,y:fort.y})]),'tangent circles are blocked');
assert.ok(!G.plannedBuildingCollision(m.legacy(fort),[m.legacy({kind:'flag',x:fort.x+sum+.001,y:fort.y})]),'separated circles stay allowed');
// Generic enclosed pocket: each building fits separately, but the maximum
// separation of any two legal centres is less than the sum of their radii.
const width=14,height=16,rf=m.buildingRadius(fort),rflag=m.buildingRadius({kind:'flag'});
const maxSeparation=Math.hypot(width-rf-rflag,height-rf-rflag);
assert.ok(2*rf<Math.min(width,height));assert.ok(maxSeparation<rf+rflag);
let legalPairs=0,individualFits=0;
for(let fy=rf;fy<=height-rf;fy+=.25)for(let fx=rf;fx<=width-rf;fx+=.25){individualFits++;for(let y=rflag;y<=height-rflag;y+=.25)for(let x=rflag;x<=width-rflag;x+=.25)if(!G.plannedBuildingCollision(m.legacy({kind:'fortress',x:fx,y:fy}),[m.legacy({kind:'flag',x,y})]))legalPairs++;}
assert.ok(individualFits);assert.equal(legalPairs,0);
vm.runInThisContext(fs.readFileSync('web/vendor/three.min.js','utf8'));const {View}=await import('../web/view.js'),T=globalThis.THREE;
for(const mode of ['2d','3d'])for(const kind of ['flag','fortress','center-fortress']){const v=Object.assign(Object.create(View.prototype),{model:m,mode,cursorGroup:new T.Group()});v.preview([500.5,500.4],kind,true);const c=v.cursorGroup.children.find(o=>o.geometry?.attributes.position?.count===65);assert.ok(Math.abs(c.geometry.attributes.position.getX(0)-500.5-m.buildingRadius({kind}))<.001);}
const d=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/data/Sever_Map_G1_1_v2.json.gz'))),real=new MapModel(d),stone=d.resources.find(q=>q.id===30969);
const sampleArea=radius=>{let total=0,blocked=0;for(let y=-radius;y<=radius;y+=.2)for(let x=-radius;x<=radius;x+=.2)if(x*x+y*y<radius*radius){total++;if(real.terrainCollision(stone.x+x,stone.y+y,0))blocked++;}return blocked/total;};
const blockedArea=sampleArea(real.resourceRadius(stone)),largerArea=sampleArea(9);
assert.ok(blockedArea>.054&&blockedArea<.112,'native share is within the photographed segmentation interval');assert.ok(largerArea>.3,'larger radius overstates hatch coverage');
// Screenshot location: actual Preparation 1 pocket west of X259/Y461.
// Independently refine centres to 1/24 game unit and check every fortress/flag
// pair; no terrain mask or exceptional forbidden-placement rule is introduced.
const bounds=[250,459,256,462],positions={flag:[],fortress:[]};
for(let y=bounds[1]*6;y<=bounds[3]*6;y+=.25)for(let x=bounds[0]*6;x<=bounds[2]*6;x+=.25)for(const kind of ['flag','fortress']){const b={kind,x,y,allianceId:'a1'};if(!real.staticError(b))positions[kind].push(b);}
let actualLegalPairs=0;for(const f of positions.fortress)for(const b of positions.flag)if(!G.plannedBuildingCollision(real.legacy(f),[real.legacy(b)]))actualLegalPairs++;
assert.ok(positions.fortress.length&&positions.flag.length,'each kind fits separately somewhere');assert.equal(actualLegalPairs,0,'no tested fortress/flag pair fits in the pictured pocket');
for(const language of ['de','en','fr']){globalThis.localStorage={getItem:()=>language};const {translate}=await import('../web/i18n.js?400='+language);const source='Der Baukreis ist frei beweglich. Gebäudekoordinaten werden unter 0,5 abgerundet und ab 0,5 aufgerundet; geprüft wird der genaue Mittelpunkt.';const text=translate(source);if(language!=='de')assert.notEqual(text,source);if(language==='en')assert.match(text,/below 0.5 and up from 0.5/);if(language==='fr')assert.match(text,/sous 0,5 et vers le haut/);}
const report={passed:true,coordinates,actualCentre:exact,areaComparison,maps,fortressEqualsCentral:true,customRadiiPreserved:true,pocket:{width,height,individualFits,legalPairs,maxSeparation,sumOfRadii:sum},realPocket:{map:d.catalog.map,boundsGame:bounds,nativeStep:.25,flagPositions:positions.flag.length,fortressPositions:positions.fortress.length,legalPairs:actualLegalPairs},stone:{id:stone.id,gameRadius:real.resourceRadius(stone)/6,blockedArea,largerRadiusGame:1.5,largerBlockedArea:largerArea,photoEstimateInterval:[.054,.112]},renderModes:['2d','3d']};
fs.writeFileSync(out+'/results.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
