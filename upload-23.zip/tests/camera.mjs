import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import zlib from 'node:zlib';
vm.runInThisContext(fs.readFileSync(new URL('../web/vendor/three.min.js',import.meta.url),'utf8'));
const T=globalThis.THREE,{View}=await import('../web/view.js');
const view=()=>Object.assign(Object.create(View.prototype),{camera:new T.OrthographicCamera(-1,1,1,-1,.1,60000),center:new T.Vector3(),flags:{hatch:true},mode:'2d',azimuth:0,tilt:Math.PI/4,w:1200,h:800,visibility(){this.updateCamera();}});
let cases=0;
for(const file of fs.readdirSync(new URL('../assets/data/',import.meta.url)).filter(f=>f.endsWith('.json.gz'))){
 const data=JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL('../assets/data/'+file,import.meta.url))));
 for(const [w,h] of [[1200,800],[700,1000]]){
  const v=view();Object.assign(v,{w,h,model:{catalog:data.catalog}});v.fit();const originalScale=v.scale;v.setMode('3d');assert.equal(v.scale,originalScale,'Switch keeps central zoom');
  const b=data.catalog.bounds,p=(x,y,z=0)=>new T.Vector3(x,z,-y).project(v.camera);
  assert.ok(Math.abs(p(b[0],b[1]).y-p(b[2],b[1]).y)<1e-12,'Bottom edge horizontal');
  assert.ok(p(b[0],b[3]).y>p(b[0],b[1]).y,'North stays above south');
  const delta=v.camera.position.clone().sub(v.center);assert.equal(delta.x,0);assert.ok(Math.abs(delta.y-delta.z)<1e-8,'45 degree elevation');
  for(const az of [0,.4,1.1]){v.azimuth=az;v.fit();for(const x of [b[0],b[2]])for(const y of [b[1],b[3]])for(const z of [-35,60]){const q=p(x,y,z);assert.ok(Math.abs(q.x)<1&&Math.abs(q.y)<1,'All board corners fit');}}
  v.north();assert.equal(v.azimuth,0);assert.equal(v.tilt,Math.PI/4);
  const lastScale=v.scale;v.setMode('2d');assert.equal(v.scale,lastScale,'Switch back keeps zoom');v.fit();assert.equal(v.scale,originalScale,'2D fit unchanged');
  v.focus(300,400,.7);v.azimuth=.4;v.setMode('3d');assert.equal(v.scale,.7);assert.equal(v.center.x,300);assert.equal(v.center.z,-400);assert.equal(v.azimuth,0);
  cases++;
 }
}
const report={passed:true,mapViewportCases:cases,bottomEdgeHorizontal:true,elevationDegrees:45,northUp:true,projectedFit:true,zoomedPositionPreserved:true};
fs.writeFileSync(new URL('./camera.json',import.meta.url),JSON.stringify(report,null,2));console.log(report);
