import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';import zlib from 'node:zlib';
vm.runInThisContext(fs.readFileSync('web/vendor/three.min.js','utf8'));
const T=globalThis.THREE,{View}=await import('../web/view.js'),{resourceRadius}=await import('../web/core/resource-size.js'),{MapModel,G,newPlan}=await import('../web/core/model.js');
const reports=[];
for(const file of fs.readdirSync('assets/solver').filter(f=>f.endsWith('.gz'))){
 const data=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/solver/'+file))),group=new T.Group(),v=Object.create(View.prototype),circles=data.resources.map(n=>({x:n.x,y:n.y,r:resourceRadius(n)}));
 const lines=v.footprintCircles(circles,'#ffeb98',group),positions=lines.geometry.attributes.position;
 assert.equal(positions.count,circles.length*192);assert.equal(lines.material.depthTest,false);assert.ok(lines.renderOrder>12,'circles remain readable over enlarged artwork');
 for(let i=0;i<circles.length;i++){const c=circles[i];for(let j=0;j<192;j++){const k=i*192+j;assert.equal(positions.getY(k),0);assert.ok(Math.abs(Math.hypot(positions.getX(k)-c.x,-positions.getZ(k)-c.y)-c.r)<.001);}}
 reports.push({map:data.catalog.map,resources:circles.length,allCircleCentresAndRadiiChecked:true});lines.geometry.dispose();lines.material.dispose();
}
// Tangency and overlap for each kind: the same model is used by UI and solver.
const resource={id:'r',kind:'stone',x:200,y:200},data={catalog:{map:'test',nativeMapSize:600,bounds:[0,0,600,600],structureRules:{},buildings:{flag:{limit:100},fortress:{limit:3}}},sites:[],resources:[resource],definitions:[],instances:[]},model=new MapModel(data);
for(const kind of ['flag','fortress','center-fortress']){
 const radius=G.buildingRules[kind==='fortress'?'subFortress':kind==='center-fortress'?'mainFortress':kind].baseClearance,total=radius+model.resourceRadius(resource);
 assert.match(model.staticError({kind,x:200+total,y:200}),/Grundkreise/);
 assert.equal(model.staticError({kind,x:200+total+.001,y:200}),null);
}
fs.writeFileSync('tests/circles-v251.json',JSON.stringify({passed:true,maps:reports,total:reports.reduce((n,r)=>n+r.resources,0),tangencyBlockedForFlagAndBothFortresses:true},null,2));console.log(reports.length,'maps;',reports.reduce((n,r)=>n+r.resources,0),'resource circles verified');
