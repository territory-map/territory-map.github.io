import assert from 'node:assert/strict';
import fs from 'node:fs';
import {MapModel,newPlan,validatePlan,clone} from '../web/core/model.js';
import {coalitionPeers,setCoalition,removeCoalition} from '../web/core/coalitions.js';
import {removeAlliance} from '../web/core/alliances.js';
import {warPairError} from '../web/core/war-builder.js';
import {solve} from '../web/solver.js';
const w=601,h=401,regions=new Uint16Array(w*h),mask=new Uint8Array(w*h);
for(let j=0;j<h;j++)for(let x=0;x<w;x++){regions[j*w+x]=x<300?1:2;if(x>=298&&x<=302)mask[j*w+x]=255;}
const data={catalog:{map:'coalitions290',nativeMapSize:600,bounds:[0,0,600,400],structureRules:{45:{territoryRadiusInCells:1,claimable:true,collision:{shape:'territory-square',radiusInCells:1}}},buildings:{flag:{limit:500},fortress:{limit:5}}},definitions:[],instances:[],sites:[{id:'gate',kind:'pass',strongholdType:45,x:297,y:351}],resources:[],terrain15:{hatching:Buffer.from(mask).toString('base64'),hatchingWidth:w,hatchingHeight:h},navigation18:{width:w,height:h,regions:Buffer.from(regions.buffer).toString('base64'),passes:{gate:[1,2]}}};
const fort=(id,allianceId,x,y)=>({id,kind:'fortress',allianceId,x,y});
const p=newPlan(data.catalog.map);p.alliances.push({id:'a2',name:'Two',color:'#bb4444'},{id:'a3',name:'Three',color:'#eeee00'});p.settings.usePassStructures=false;p.buildings=[fort('root','a1',243,207),fort('contact','a2',225,351)];
const jump={id:'jump',kind:'flag',allianceId:'a1',x:315,y:207},m=new MapModel(data);m.setPlan(p);assert.ok(m.placementError(jump),'without coalition no shared contact');
assert.throws(()=>setCoalition(p,{id:'c',name:'Test',allianceIds:['a1']}),/zwei/);
setCoalition(p,{id:'c',name:'Team',allianceIds:['a1','a2','missing','a2']});m.setPlan(p);assert.equal(m.placementError(jump),null);assert.deepEqual(m.passContactSources(m.sites[0],'a1'),['a2']);assert.equal(m.accessFor('a1').captured.size,0);assert.ok(m.territoryFor('a1').get('12:19')?.allianceId!=='a1','no coalition territory transfer');
assert.equal(warPairError(m,{...p.buildings[0],existingId:'root'},jump,1,2),null);p.settings.allowZoneWalljumps=false;m.setPlan(p);assert.equal(warPairError(m,{...p.buildings[0],existingId:'root'},jump,1,2),null,'tactical war search is independent of solver pass permissions');assert.ok(m.placementError(jump),'automatic planner still requires permission');p.settings.allowZoneWalljumps=true;m.setPlan(p);
const saved=JSON.stringify(p);assert.deepEqual(validatePlan(JSON.parse(saved),p.map).coalitions,p.coalitions);
setCoalition(p,{id:'other',name:'Other',allianceIds:['a2','a3']});assert.ok(!coalitionPeers(p,'a1').has('a3'),'overlapping coalitions are not transitive');
setCoalition(p,{id:'c',name:'Renamed',allianceIds:['a1']});m.setPlan(p);assert.ok(m.placementError(jump));removeCoalition(p,'c');assert.equal(p.alliances.length,3);p.coalitions=JSON.parse(saved).coalitions;
const check=(mutate,allow)=>{const q=clone(p);mutate(q);m.setPlan(q);assert.equal(m.placementError(jump)===null,allow);};
check(q=>q.settings.allowZoneWalljumps=false,false);check(q=>q.buildings=q.buildings.filter(b=>b.id!=='contact'),false);check(q=>q.coalitions[0].allianceIds=['a1'],false);
check(q=>q.buildings[1].x=369,false);check(q=>q.buildings[1]={...q.buildings[1],kind:'flag'},false);check(q=>q.buildings.push({...q.buildings[1],id:'collision'}),false);
const irrelevant=new MapModel({...data,navigation18:{...data.navigation18,passes:{gate:[1,3]}}});irrelevant.setPlan(p);assert.ok(irrelevant.placementError(jump),'a pass to a different destination does not authorize the jump');
check(q=>q.capturedPasses.gate='a1',true); // marker itself is not contact; valid coalition contact still is.
check(q=>{q.capturedPasses.gate='a1';q.buildings.pop();},false);
const removed=clone(p);removeAlliance(removed,'a2');assert.ok(removed.coalitions.every(c=>!c.allianceIds.includes('a2')));
const q=clone(p);q.buildings.push(jump);m.setPlan(q);assert.ok(m.isBuildingActive(jump));q.settings.allowZoneWalljumps=false;m.setPlan(q);assert.ok(m.isBuildingActive(jump),'existing physical bridge survives solver toggle');q.settings.allowZoneWalljumps=true;m.setPlan(q);assert.ok(m.isBuildingActive(jump));q.coalitions=[];m.setPlan(q);assert.ok(m.isBuildingActive(jump),'established fortress connection survives loss of contact');
for(const mode of ['balanced','crystal','build','war']){const q=clone(p);q.targets=[{id:'goal',x:369,y:207}];const before=JSON.stringify(q);const result=solve(m,q,'a1',{budget:8,startId:'root',routeMode:mode,crystalExtra:0,maxMillis:1500});assert.equal(result.failed.length,0,result.reason);assert.equal(JSON.stringify(q),before);for(const b of result.buildings){m.setPlan(q);assert.equal(m.placementError(b),null);q.buildings.push(b);}m.setPlan(q);assert.ok(m.targetReached(q.targets[0],'a1'));assert.ok(result.buildings.length<=8);}
const ownApproach=clone(p);ownApproach.coalitions=[];ownApproach.targets=[{id:'goal',x:369,y:207}];const ownResult=solve(m,ownApproach,'a1',{budget:12,routeMode:'build',maxMillis:3000});assert.equal(ownResult.failed.length,0,'search must establish its own correct-side contact before crossing when no coalition shares contact');for(const b of ownResult.buildings){m.setPlan(ownApproach);assert.equal(m.placementError(b),null);ownApproach.buildings.push(b);}m.setPlan(ownApproach);assert.ok(m.passContactSources(m.sites[0],'a1').includes('a1'));
const blocked=clone(p);blocked.settings.allowZoneWalljumps=false;blocked.targets=[{id:'goal',x:369,y:207}];const r=solve(m,blocked,'a1',{budget:8,routeMode:'build',maxMillis:600});assert.equal(r.failed.length,1);
// Ordinary enabled pass relay is distinct from a direct wall jump.
blocked.settings.usePassStructures=true;blocked.buildings=[fort('root','a1',225,351)];blocked.targets=[{id:'goal',x:387,y:351}];m.setPlan(blocked);const viaPass=solve(m,blocked,'a1',{budget:5,routeMode:'build',maxMillis:1500});assert.equal(viaPass.failed.length,0);
// Same geographical zone does not become a walljump because navigation fragments differ.
const same=new MapModel(data);same.groundAccess.warZoneMapping=new Uint16Array(65536);same.groundAccess.warZoneMapping[1]=same.groundAccess.warZoneMapping[2]=10;const merged=clone(p);merged.coalitions=[];merged.settings.allowZoneWalljumps=false;same.setPlan(merged);assert.equal(same.placementError(jump),null);
fs.mkdirSync('analysis/coalitions290',{recursive:true});fs.writeFileSync('analysis/coalitions290/browser-plan.json',saved);console.log('Coalitions: CRUD, persistence, deletion/revocation, correct side, root validity, collision, non-transitive sharing, no territory transfer, all modes, toggle OFF, ordinary pass relay and geographical zone grouping passed.');
