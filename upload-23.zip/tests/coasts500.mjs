import assert from 'node:assert/strict';
import fs from 'node:fs';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import vm from 'node:vm';
import {GroundAccess} from '../web/core/access18.js';
import {filledZoneRegions,warZoneAt,zoneId,normalizeWarZones} from '../web/core/war-zone-mask.js';
import {zoneWaterAt} from '../web/core/zone-water500.js';
import {WAR_ZONE_CATALOG} from '../web/core/zone-catalog450.js';
import {COAST_CATALOG} from '../web/core/coast-catalog500.js';
vm.runInThisContext(fs.readFileSync('web/vendor/three.min.js','utf8'));
globalThis.localStorage={getItem:()=> 'de'};
const T=globalThis.THREE,{WarLayer}=await import('../web/war-builder-view.js');
const sources=JSON.parse(fs.readFileSync('analysis/coasts500/sources.json'));
assert.equal(sources.maps.length,21);assert.equal(Object.keys(COAST_CATALOG).length,21);
const read=(slug,source)=>JSON.parse(zlib.gunzipSync(fs.readFileSync(`assets/${source}/${slug}.json.gz`)));
const world=(a,i)=>{const [l,b,r,t]=a.bounds,n=a.nav;return [l+(i%n.width)*(r-l)/(n.width-1),t-Math.floor(i/n.width)*(t-b)/(n.height-1)];};
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
// Synthetic coast: water includes a land island. Blocked land must still
// belong to the whole zone; water is neither coloured nor selectable.
const nav={width:7,height:7},regions=new Uint16Array(49);regions[0]=1;regions[3*7+3]=2;
const bits=new Uint8Array(7);for(let y=0;y<7;y++)for(let x=2;x<7;x++){const i=y*7+x;if(i!==24)bits[i>>3]|=128>>(i&7);}
const synthetic={nav,regions,zoneWater:bits,bounds:[0,0,6,6],pixel:(x,y)=>[x,6-y]};
const filled=filledZoneRegions(synthetic);
assert.equal(filled[24],2,'land island retained');assert.equal(filled[7],1,'blocked land remains part of its zone');
assert.equal(warZoneAt(synthetic,3,3,true),2);assert.equal(warZoneAt(synthetic,4,3,true),0);assert.equal(warZoneAt(synthetic,4,3),0);
const results=[];let passes=0;
for(const report of sources.maps){
 const slug=report.map,compact=read(slug,'solver'),full=read(slug,'data');
 const a=new GroundAccess(compact),native=new GroundAccess(full),before=hash(Buffer.from(a.regions.buffer));
 assert.deepEqual(a.zoneWater,native.zoneWater,'full map and compact worker share exclusions');
 assert.equal(hash(a.zoneWater),report.packedSha256,'decoded mask matches native source raster');
 assert.equal(hash(fs.readFileSync(`assets/audit255/${slug}-edge.png`)),report.sourceSeaSha256,'native coastline source unchanged');
 const fill=filledZoneRegions(a),old=filledZoneRegions({...a,zoneWater:null});
 let water=0,removed=0,land=0;
 for(let i=0;i<fill.length;i++){
  if(zoneWaterAt(a,i)){water++;assert.equal(fill[i],0,'water has no zone');if(old[i])removed++;}
  else{assert.equal(fill[i],old[i],'land, walls and complete zone grouping preserved');land++;}
 }
 assert.equal(water,report.waterPixels);assert.equal(removed,water,'4.5 painted these water pixels as zones');
 for(const kind of ['sea','lake'])for(const i of report.samples[kind]){
  assert.equal(warZoneAt(a,...world(a,i),true),0,kind+' cannot select a zone');
  assert.equal(warZoneAt(a,...world(a,i)),0,kind+' cannot be a search zone');
 }
 for(const kind of ['land','wall'])for(const i of report.samples[kind])assert.equal(warZoneAt(a,...world(a,i),true),old[i],kind+' remains selectable');
 for(const edges of Object.values(a.nav.passes)){assert.notEqual(zoneId(a,edges[0]),zoneId(a,edges[1]));passes++;}
 const selected=[...new Set(Object.values(WAR_ZONE_CATALOG[slug].regions))];
 for(const zone of selected)assert.equal(normalizeWarZones(a,{ourZone:zone}).ourZone,zone,'saved zone identity preserved');
 assert.equal(hash(Buffer.from(a.regions.buffer)),before,'gameplay navigation unchanged');
 // Exercise the actual RGBA overlay, rather than merely checking the helper.
 // It is the same scene layer used with the 2D and 3D cameras.
 const view={scene:new T.Scene(),symbols:[],dirty:false},layer=new WarLayer(view);
 const model={groundAccess:a,catalog:compact.catalog};
 for(const mode of ['2d','3d']){
  view.mode=mode;layer.key='';layer.renderZones(model,{visible:true,ourZone:selected[0],enemyZone:selected[1]});
  const pixels=layer.zones.children[0].material.map.image.data,n=a.nav;
  for(const kind of ['sea','lake'])for(const i of report.samples[kind]){
   const pixel=((n.height-1-Math.floor(i/n.width))*n.width+i%n.width)*4;
   assert.equal(pixels[pixel+3],0,mode+' water alpha must be transparent');
  }
  for(const i of report.samples.land){const zone=fill[i],pixel=((n.height-1-Math.floor(i/n.width))*n.width+i%n.width)*4;
   const [x,y]=world(a,i);if(x>=0&&y>=0&&x<=compact.catalog.nativeMapSize&&y<=compact.catalog.nativeMapSize){
    assert.equal(pixels[pixel+3],zone===selected[0]?90:zone===selected[1]?85:0,mode+' land retains its selected colour');
   }
  }
 }
 layer.reset();results.push({map:slug,name:report.name,seaPixels:report.seaPixels,waterPixels:water,removedWaterZonePixels:removed,unchangedLandPixels:land,fullWorkerParity:true,renderModes:['2d','3d']});
 console.log(slug,'PASS',report.seaPixels?'coastal':'inland',water);
}
assert.equal(passes,1102);assert.deepEqual(results.filter(m=>m.seaPixels).map(m=>m.map),['LostLand_Map_19_2','LostLand_Map_20_v2','LostLand_Map_3_2_v2']);
fs.writeFileSync('analysis/coasts500/regression.json',JSON.stringify({passed:true,maps:results,exitPassesPreserved:passes,waterSelectionRejected:true,navigationUnchanged:true,landGroupingUnchanged:true,fullWorkerParity:true,landIslandPreserved:true},null,2));
console.log('5.0: all 21 masks, full/worker parity, transparent 2D/3D overlays, water picking, land islands and 1102 exit passes passed');
