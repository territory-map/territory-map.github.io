import assert from 'node:assert/strict';
import fs from 'node:fs';
import zlib from 'node:zlib';
import {MapModel,newPlan,validatePlan,INACTIVE_TERRITORY,G} from '../web/core/model.js';
import {solve} from '../web/solver.js';
const width=701,height=701,regions=new Uint16Array(width*height),mask=new Uint8Array(width*height);
for(let j=0;j<height;j++)for(let x=0;x<width;x++){const y=700-j,k=j*width+x;regions[k]=y<300?1:2;if(y>=298&&y<=302)mask[k]=255;}
const data={catalog:{map:'connections258',nativeMapSize:700,bounds:[0,0,700,700],structureRules:{45:{territoryRadiusInCells:1,claimable:true,collision:{shape:'territory-square',radiusInCells:1}}},buildings:{flag:{limit:500},fortress:{limit:5}}},sites:[{id:'gate',kind:'pass',strongholdType:45,x:333,y:297}],resources:[{id:'direct-crystal',kind:'crystal',x:225,y:405},{id:'pass-crystal',kind:'crystal',x:405,y:351}],definitions:[],instances:[],terrain15:{hatching:Buffer.from(mask).toString('base64'),hatchingWidth:width,hatchingHeight:height},navigation18:{width,height,regions:Buffer.from(regions.buffer).toString('base64'),passes:{gate:[1,2]}}};
const flag=(id,x,y)=>({id,kind:'flag',allianceId:'a1',x,y});
const root={id:'root',kind:'fortress',allianceId:'a1',x:207,y:261};
const direct=[flag('jump',207,333),flag('direct-2',207,387),flag('direct-3',207,441)];
const branch=[387,441,495,549].map((x,i)=>flag('pass-only-'+i,x,333));
const p=newPlan(data.catalog.map),m=new MapModel(data);
p.buildings=[root,flag('approach',279,261),...direct,...branch];p.capturedPasses.gate='a1';
const cases=[];
for(const enabled of [true,false,true,false]){
 p.settings.usePassStructures=enabled;m.setPlan(p);
 for(const b of p.buildings)assert.equal(m.staticError(b),null,b.id);
 for(const b of [root,p.buildings[1],...direct])assert.ok(m.isBuildingActive(b),b.id+' must remain connected across wall');
 for(const b of branch)assert.equal(m.isBuildingActive(b),enabled,b.id+' depends only on pass');
 assert.equal(m.accessFor('a1').captured.has('gate'),enabled);
 assert.ok(m.accessFor('a1').regions.has(2),'direct flag bridge provides access independently of pass');
 assert.ok(m.resourceCovered(data.resources[0],'a1'));
 assert.equal(m.resourceCovered(data.resources[1],'a1'),enabled);
 assert.equal(m.displayOwnership.get('21:18')?.allianceId,enabled?'a1':INACTIVE_TERRITORY);
 assert.equal(m.territoryFor('a1').has('18:16'),enabled,'disabled pass cannot conduct territory');
 cases.push({passes:enabled,active:p.buildings.filter(b=>m.isBuildingActive(b)).map(b=>b.id),inactive:p.buildings.filter(b=>!m.isBuildingActive(b)).map(b=>b.id)});
}
// Imported plans and shuffled save order derive the same rooted graph.
const saved=JSON.stringify(p),imported=validatePlan(JSON.parse(saved),p.map);
imported.buildings.reverse();m.setPlan(imported);assert.deepEqual([...m.activeBuildingIds].sort(),['approach','direct-2','direct-3','jump','root'].sort());
const deleted=JSON.parse(saved);deleted.buildings=deleted.buildings.filter(b=>b.id!=='jump');m.setPlan(deleted);assert.equal(m.isBuildingActive(direct[1]),false);assert.equal(m.accessFor('a1').regions.has(2),false);
m.setPlan(JSON.parse(saved));assert.ok(m.isBuildingActive(direct[2]),'undo/reload restores independent bridge');
const scoped=JSON.parse(saved);scoped.buildings.push({...root,id:'other-root',x:603,y:99});scoped.routingRootId='other-root';m.setPlan(scoped);assert.ok(m.isBuildingActive(scoped.buildings.at(-1)));assert.ok(direct.every(b=>!m.isBuildingActive(b)),'selected root cannot borrow an isolated fortress chain');
const obstructed=structuredClone(data);obstructed.resources.push({id:'obstruction',kind:'food',x:207,y:333});const invalid=new MapModel(obstructed);invalid.setPlan(JSON.parse(saved));assert.ok(direct.every(b=>!invalid.isBuildingActive(b)),'invalid jump cannot propagate territory');assert.equal(invalid.accessFor('a1').regions.has(2),false);
// The same contact rule permits placing a new valid jump, but blocks remote
// buildings and building circles on the wall. A foreign alliance is no bridge.
const q=JSON.parse(saved);q.buildings=[root];m.setPlan(q);assert.match(m.placementError(direct[0]),/Zone/,'2.9: a direct jump needs relevant pass contact');q.buildings.push(flag('approach',279,261));m.setPlan(q);assert.equal(m.placementError(direct[0]),null);assert.match(m.placementError(flag('remote',495,333)),/Zone gesperrt/);assert.match(m.staticError(flag('wall',207,300)),/Wand/);
q.buildings=[root];q.alliances.push({id:'a2',name:'Other',color:'#ff0000'});q.buildings.push({...direct[0],allianceId:'a2'});m.setPlan(q);assert.equal(m.isBuildingActive(q.buildings[1]),false);assert.equal(m.accessFor('a1').regions.has(2),false);
// Solver uses a retained bridge with passes OFF, and does not resurrect the
// four disconnected pass-only flags or count their resource production.
const routed=JSON.parse(saved);routed.targets=[{id:'further',x:207,y:549}];
const result=solve(m,routed,'a1',{budget:10,startId:'root',crystals:false,maxMillis:3000});assert.equal(result.failed.length,0);assert.equal(result.requiredPasses.length,0);
for(const b of result.buildings){m.setPlan(routed);assert.equal(m.placementError(b),null);routed.buildings.push(b);}m.setPlan(routed);assert.ok(m.targetReached(routed.targets[0],'a1'));assert.ok(result.buildings.every(b=>m.isBuildingActive(b)));assert.ok(branch.every(b=>!m.isBuildingActive(b)));
// Static collision and territory footprints are shared by every 2D/3D map.
// Locate actual valid cross-region contacts, then compare OFF vs ON, deletion
// and restore rather than relying only on an artificial navigation split.
const real=[];
for(const f of fs.readdirSync('assets/solver').filter(f=>f.endsWith('.gz'))){
 const d=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/solver/'+f))),rm=new MapModel(d),rp=newPlan(d.catalog.map);rp.settings.usePassStructures=false;let found;
 for(const s of rm.sites.filter(s=>s.kind==='pass')){
  for(const [dx,dy] of [[66,0],[-66,0],[0,66],[0,-66]]){
   const b={...root,x:s.x+dx,y:s.y+dy};if(rm.staticError(b))continue;rp.buildings=[b];rm.setPlan(rp);const z=rm.groundAccess.buildingRegion(b.x,b.y);
   for(const [jx,jy] of [[54,0],[-54,0],[0,54],[0,-54],[72,0],[-72,0],[0,72],[0,-72],[54,18],[-54,18],[18,54],[18,-54]]){
    const c=flag('jump',b.x+jx,b.y+jy),other=rm.groundAccess.buildingRegion(c.x,c.y);if(!other||other===z||rm.placementError(c))continue;
    rp.buildings.push(c);rm.setPlan(rp);assert.ok(rm.isBuildingActive(c));assert.ok(rm.accessFor('a1').regions.has(other));assert.equal(rm.accessFor('a1').captured.size,0);
    found={pass:s.siteId,root:b,jump:c,regions:[z,other]};rp.buildings=[b];rm.setPlan(rp);assert.equal(rm.accessFor('a1').regions.has(other),false);break;
   }if(found)break;
  }if(found)break;
 }
 real.push({map:d.catalog.map,checked:true,bridge:found||null});
 if(d.catalog.map==='LostLand_Map_18_v2'&&found){const ui=newPlan(d.catalog.map);ui.settings.usePassStructures=false;ui.buildings=[found.root,found.jump];fs.mkdirSync('analysis/solver258',{recursive:true});fs.writeFileSync('analysis/solver258/browser-plan.json',JSON.stringify(ui,null,2));}
}
assert.equal(real.length,21);assert.ok(real.some(r=>r.bridge),'at least one real map has a valid wall jump');
// Exact four-flag pass-only branch on Shifting Gears, alongside an independent
// direct wall jump. This saved fixture is also used for browser verification.
const rd=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/solver/LostLand_Map_18_v2.json.gz'))),rm=new MapModel(rd),ui=newPlan(rd.catalog.map);
ui.settings.flagRadius=3.16256/6;ui.settings.fortressRadius=4.427584/6;ui.settings.resourceRadius=4.585712/6;ui.buildings=[{...root,x:5746,y:4918},flag('jump',5746,4864),flag('pass-only-0',5602,4864),flag('pass-only-1',5602,4918),flag('pass-only-2',5602,4972),flag('pass-only-3',5548,4972)];
for(const on of [true,false,true,false]){ui.settings.usePassStructures=on;rm.setPlan(ui);for(const b of ui.buildings)assert.equal(rm.staticError(b),null,b.id);assert.ok(rm.isBuildingActive(ui.buildings[0]));assert.ok(rm.isBuildingActive(ui.buildings[1]));for(const b of ui.buildings.slice(2))assert.equal(rm.isBuildingActive(b),on,b.id);}
const browserFixture={passed:true,active:[...rm.activeBuildingIds],inactive:ui.buildings.filter(b=>!rm.isBuildingActive(b)).map(b=>b.id)};
fs.writeFileSync('analysis/solver258/browser-plan.json',JSON.stringify(ui,null,2));fs.writeFileSync('analysis/solver258/browser-fixture-check.json',JSON.stringify(browserFixture,null,2));
fs.mkdirSync('analysis/solver258',{recursive:true});fs.writeFileSync('analysis/solver258/connections.json',JSON.stringify({passed:true,cases,solverFlags:result.buildings.length,real},null,2));
console.log('2.5.8: direct wall jump stays active; exactly four pass-only flags turn white; OFF/ON, delete/restore, import, alliance isolation, placement, solver and 21 map checks passed');
