import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';import zlib from 'node:zlib';
import {MapModel,newPlan,G} from '../web/core/model.js';
const cells=(list,aid='a1')=>new Map(list.map(([x,y])=>[x+':'+y,{column:x,row:y,allianceId:aid}]));
const close=(a,b,msg)=>assert.ok(Math.abs(a-b)<1e-8,msg+': '+a+' vs '+b);
let cases=0;
for(const kind of ['food','wood','stone','coin','crystal'])for(const radius of [1.5,3.6,6,30]){
 const r={id:kind,kind,x:18,y:18},one=cells([[0,0]]),two=cells([[0,0],[1,0]]);
 close(G.resourceCoverage(one,r,'a1',Math.min(radius,18)),.25,'corner quarter');
 close(G.resourceCoverage(two,r,'a1',Math.min(radius,18)),.5,'combined half');
 assert.equal(G.countCoveredResources(one,[r],'a1',()=>Math.min(radius,18))[kind],0);
 assert.equal(G.countCoveredResources(two,[r,r],'a1',()=>Math.min(radius,18))[kind],1,'no double count');
 const whole=cells(Array.from({length:16},(_,i)=>[i%4-1,Math.floor(i/4)-1]));close(G.resourceCoverage(whole,r,'a1',radius),1,'whole disk');
 const edge=cells(Array.from({length:8},(_,i)=>[i%4-1,Math.floor(i/4)-1]));
 close(G.resourceCoverage(edge,r,'a1',radius),.5,'exact 50%');
 assert.ok(G.resourceCoverage(edge,{...r,y:18.01},'a1',radius)<.5);
 assert.ok(G.resourceCoverage(edge,{...r,y:17.99},'a1',radius)>.5);cases+=8;
}
// A centre can be inside a square while only a quarter of its circle is owned.
const nearCorner={id:'corner',kind:'crystal',x:18.01,y:18.01};assert.equal(G.countCoveredResources(cells([[1,1]]),[nearCorner],'a1').crystal,0);
// Compare analytic geometry with independent midpoint integration on random rectangles.
let seed=481;const rand=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/2**32);
for(let i=0;i<50;i++){const radius=1+rand()*20,x0=-radius+rand()*2*radius,y0=-radius+rand()*2*radius,x1=x0+rand()*2*radius,y1=y0+rand()*2*radius;let area=0;const step=(x1-x0)/20000;for(let k=0;k<20000;k++){const x=x0+(k+.5)*step;if(Math.abs(x)>=radius)continue;const y=Math.sqrt(radius*radius-x*x);area+=Math.max(0,Math.min(y1,y)-Math.max(y0,-y))*step;}assert.ok(Math.abs(G.circleRectangleArea(0,0,radius,x0,y0,x1,y1)-area)<radius*radius*.00002);}
// Hatch holes no longer cut the territory; the base still cannot touch them.
const width=601,height=401,mask=new Uint8Array(width*height),regions=new Uint16Array(width*height).fill(1);
for(let y=0;y<height;y++)for(let x=298;x<=302;x++){mask[y*width+x]=255;regions[y*width+x]=0;}
for(let y=0;y<height;y++)for(let x=303;x<width;x++)regions[y*width+x]=2;
const data={catalog:{map:'coverage-test',nativeMapSize:600,bounds:[0,0,600,400],structureRules:{},buildings:{flag:{limit:500},fortress:{limit:5}}},sites:[],resources:[],definitions:[],instances:[],terrain15:{hatching:Buffer.from(mask).toString('base64'),hatchingWidth:width,hatchingHeight:height},navigation18:{width,height,regions:Buffer.from(regions.buffer).toString('base64'),passes:{}}};
const model=new MapModel(data),p=newPlan('coverage-test');p.buildings=[{id:'root',kind:'fortress',x:279,y:99,allianceId:'a1'}];model.setPlan(p);assert.equal(model.state.ownership.size,25,'complete fortress square');assert.ok(model.state.ownership.get('16:5'),'wall cell stays coloured');assert.match(model.placementError({kind:'flag',x:315,y:99,allianceId:'a1'}),/Zone/,'2.9: coloured wall cells do not replace required pass contact');assert.match(model.placementError({kind:'flag',x:405,y:99,allianceId:'a1'}),/Zone/,'unconnected far-side flag stays blocked');
vm.runInThisContext(fs.readFileSync(new URL('../web/vendor/three.min.js',import.meta.url),'utf8'));const T=globalThis.THREE,{View}=await import('../web/view.js');
const v=Object.assign(Object.create(View.prototype),{camera:new T.OrthographicCamera(-1,1,1,-1,.1,60000),center:new T.Vector3(),flags:{hatch:true},mode:'3d',scale:1,azimuth:0,tilt:Math.PI/4,w:1200,h:800});v.updateCamera();const project=(x,y)=>new T.Vector3(x,0,-y).project(v.camera);let a=project(0,0),b=project(100,0),c=project(0,100);const distance=v.camera.position.distanceTo(v.center);close((b.x-a.x)*v.w*Math.cos(v.tilt)*distance/(distance+100*Math.sin(v.tilt)),(c.y-a.y)*v.h,'perspective ground scale');assert.ok(v.camera.position.y>0&&v.camera.position.z>0,'relief perspective preserved');
const report={passed:true,coverageCases:cases,numericalCrossChecks:50,halfCircleInclusive:true,combinedFlags:true,centreAloneInsufficient:true,completeTerritory:true,unqualifiedWallJumpBlocked:true,unconnectedZoneStillBlocked:true,perspective3DGround:true};fs.writeFileSync(new URL('./corrections-v181.json',import.meta.url),JSON.stringify(report,null,2));console.log(report);
