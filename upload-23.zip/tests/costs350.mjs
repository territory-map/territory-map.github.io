import assert from 'node:assert/strict';import fs from 'node:fs';import zlib from 'node:zlib';
import {COST_FIELDS,resetBuildingCosts,buildingCostsSinceReset} from '../web/core/cost-accounting350.js';
import {resetAllianceCredits} from '../web/core/credit-accounting330.js';
import {newPlan,validatePlan,legacy,kindToLegacy} from '../web/core/model.js';
import {calculateCostTotals} from '../web/core/costs.js';
import {removeAlliance} from '../web/core/alliances.js';
const zero=Object.fromEntries(COST_FIELDS.map(k=>[k,0]));let checks=0;
for(const file of fs.readdirSync('assets/data').filter(n=>n.endsWith('.gz'))){
 const {catalog}=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/data/'+file)));
 const schedule=Object.fromEntries(Object.entries(catalog.costs).map(([k,v])=>[kindToLegacy[k],v]));
 for(const kind of ['flag','fortress','center-fortress'])for(const tier of catalog.costs[kind]||[]){
  if(!Number.isInteger(tier.from)||tier.from<2||tier.from>500)continue;
  const p=newPlan(catalog.map);p.alliances.push({id:'a2',name:'Other',color:'#abcdef'});
  p.buildings=Array.from({length:tier.from-1},(_,i)=>({id:'old'+i,kind,allianceId:'a1',x:100+i,y:100}));
  p.buildings.push({id:'other',kind,allianceId:'a2',x:200,y:200});
  const before=structuredClone(p),other=calculateCostTotals(p.buildings.map(legacy),schedule,'a2');
  resetBuildingCosts(p,'a1');
  assert.deepEqual(buildingCostsSinceReset(p.buildings.map(legacy),schedule,'a1',p.costAccounting).totals,zero);
  assert.deepEqual(p.buildings,before.buildings);
  assert.deepEqual(buildingCostsSinceReset(p.buildings.map(legacy),schedule,'a2',p.costAccounting).totals,Object.fromEntries(COST_FIELDS.map(k=>[k,other[k]])));
  p.buildings.push({id:'new',kind,allianceId:'a1',x:300,y:300});
  const round=validatePlan(JSON.parse(JSON.stringify(p)),p.map);
  assert.deepEqual(buildingCostsSinceReset(round.buildings.map(legacy),schedule,'a1',round.costAccounting).totals,Object.fromEntries(COST_FIELDS.map(k=>[k,tier.cost[k]??0])),'all six costs retain next full-plan tier');
  resetBuildingCosts(round,'a1');assert.deepEqual(buildingCostsSinceReset(round.buildings.map(legacy),schedule,'a1',round.costAccounting).totals,zero);
  removeAlliance(round,'a1');assert.equal(round.costAccounting.a1,undefined);
  checks++;
 }
}
// Upgrade the 3.3 reset boundary, without losing previous building counts.
const p=newPlan('migration'),schedule={flag:[{from:1,to:1,cost:{credits:10,food:20,wood:30,stone:40,gold:50,crystal:60}},{from:2,to:10,cost:{credits:70,food:80,wood:90,stone:100,gold:110,crystal:120}}]};
p.buildings=[{id:'old',kind:'flag',allianceId:'a1',x:100,y:100}];resetAllianceCredits(p,'a1');p.buildings.push({id:'new',kind:'flag',allianceId:'a1',x:200,y:200});
const migrated=validatePlan(JSON.parse(JSON.stringify(p)),p.map);
assert.deepEqual(buildingCostsSinceReset(migrated.buildings.map(legacy),schedule,'a1',migrated.costAccounting).totals,schedule.flag[1].cost);
const undo=structuredClone(migrated);resetBuildingCosts(migrated,'a1');assert.deepEqual(buildingCostsSinceReset(migrated.buildings.map(legacy),schedule,'a1',migrated.costAccounting).totals,zero);
assert.deepEqual(buildingCostsSinceReset(undo.buildings.map(legacy),schedule,'a1',undo.costAccounting).totals,schedule.flag[1].cost);
assert.equal(buildingCostsSinceReset(p.buildings.map(legacy),{},'a1',{}).unknown,2);
const html=fs.readFileSync('web/index.html','utf8'),css=fs.readFileSync('web/style.css','utf8');
assert.match(html,/<details id="buildingRadiusPanel" class="radius-panel">/);assert.match(html,/<details id="resourceRadiusPanel" class="radius-panel">/);
assert.match(css,/#mapSources>\.radius-panel\{[^}]*padding:10px;[^}]*border:1px solid/);
assert.ok(!html.includes('Baukreisradien (Spielkoordinaten)'));
for(const lang of ['de','en','fr']){
 globalThis.localStorage={getItem:()=>lang};const {translate}=await import('../web/i18n.js?costs350='+lang);
 if(lang==='en'){assert.equal(translate('Kosten zurücksetzen'),'Reset costs');assert.equal(translate('Baukreisradius (Spielkoordinaten)'),'Building circle radius (game coordinates)');}
 else if(lang==='fr'){assert.equal(translate('Kosten zurücksetzen'),'Réinitialiser les coûts');assert.equal(translate('Baukreisradius (Spielkoordinaten)'),'Rayon de construction (coordonnées du jeu)');}
 else assert.equal(translate('Kosten zurücksetzen'),'Kosten zurücksetzen');
}
fs.mkdirSync('analysis/costs350',{recursive:true});fs.writeFileSync('analysis/costs350/cost-checks.json',JSON.stringify({passed:true,maps:21,tierChecks:checks,fields:COST_FIELDS,migration:true,layout:true},null,2));
console.log('3.5: '+checks+' real tiers on 21 maps; all six costs, reset, migration, next-building tiers, independent alliances, persistence and shared radius layout passed.');
