import assert from 'node:assert/strict';
import fs from 'node:fs';import zlib from 'node:zlib';
import {allianceCredits,resetAllianceCredits} from '../web/core/credit-accounting330.js';
import {newPlan,validatePlan,legacy,kindToLegacy} from '../web/core/model.js';
import {calculateCostTotals} from '../web/core/costs.js';
import {removeAlliance} from '../web/core/alliances.js';
let checks=0;
for(const file of fs.readdirSync('assets/data').filter(n=>n.endsWith('.gz'))){
 const {catalog}=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/data/'+file)));
 const schedule=Object.fromEntries(Object.entries(catalog.costs).map(([k,v])=>[kindToLegacy[k],v]));
 for(const kind of ['flag','fortress','center-fortress']){
  const tiers=catalog.costs[kind]||[];
  for(const tier of tiers){
   if(!Number.isInteger(tier.from)||tier.from<2||tier.from>500)continue;
   const p=newPlan(catalog.map);p.alliances.push({id:'a2',name:'Other',color:'#abcdef'});
   p.buildings=Array.from({length:tier.from-1},(_,i)=>({id:'old'+i,kind,allianceId:'a1',x:100+i,y:100}));
   p.buildings.push({id:'other',kind,allianceId:'a2',x:200,y:200});
   const original=structuredClone(p),before=calculateCostTotals(p.buildings.map(legacy),schedule,'a1');
   resetAllianceCredits(p,'a1');
   assert.equal(allianceCredits(p.buildings.map(legacy),schedule,'a1',p.creditAccounting).spent,0);
   assert.equal(allianceCredits(p.buildings.map(legacy),schedule,'a2',p.creditAccounting).spent,tiers[0].cost.credits??0);
   assert.deepEqual(p.buildings,original.buildings);
   p.buildings.push({id:'new',kind,allianceId:'a1',x:300,y:300});
   const round=validatePlan(JSON.parse(JSON.stringify(p)),p.map);
   assert.equal(allianceCredits(round.buildings.map(legacy),schedule,'a1',round.creditAccounting).spent,tier.cost.credits??0);
   assert.equal(calculateCostTotals(round.buildings.map(legacy),schedule,'a1').food,before.food+(tier.cost.food??0));
   assert.equal(allianceCredits(original.buildings.map(legacy),schedule,'a1',original.creditAccounting).spent,before.credits,'undo restores previous sum');
   resetAllianceCredits(round,'a1');assert.equal(allianceCredits(round.buildings.map(legacy),schedule,'a1',round.creditAccounting).spent,0);
   removeAlliance(round,'a1');assert.equal(round.creditAccounting.a1,undefined);
   checks++;
  }
 }
}
const p=newPlan('test');p.creditAccounting={a1:{baselineIds:['a','a',3]},orphan:{baselineIds:['x']}};
assert.deepEqual(validatePlan(p,'test').creditAccounting,{a1:{baselineIds:['a']}});
assert.equal(allianceCredits([{id:'unknown',kind:'flag',allianceId:'a1'}],{},'a1',{}).unknown,1);
assert.ok(checks>100);
fs.mkdirSync('analysis/credits330',{recursive:true});fs.writeFileSync('analysis/credits330/cost-checks.json',JSON.stringify({passed:true,maps:21,tierChecks:checks,stockInput:false},null,2));
console.log('3.3: '+checks+' real tier checks across 21 maps, independent alliances, reset, repeated reset, persistence, undo and unchanged resource costs passed.');
