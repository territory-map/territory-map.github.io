import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';import zlib from 'node:zlib';
vm.runInThisContext(fs.readFileSync(new URL('../web/vendor/three.min.js',import.meta.url),'utf8'));
const T=globalThis.THREE,{View}=await import('../web/view.js');let cases=0,minDepthSteps=Infinity;
const make=(catalog,w,h)=>{const handlers={},v=Object.assign(Object.create(View.prototype),{camera:new T.OrthographicCamera(-1,1,1,-1,.1,60000),center:new T.Vector3(),flags:{},mode:'3d',azimuth:0,tilt:Math.PI/4,w,h,scale:1,model:{catalog},ray:new T.Raycaster(),plane:new T.Plane(new T.Vector3(0,1,0),0),canvas:{getBoundingClientRect:()=>({left:0,top:0,width:w,height:h}),addEventListener:(n,f)=>handlers[n]=f,setPointerCapture(){}},hoverFrame:1});return {v,handlers};};
for(const f of fs.readdirSync('assets/data').filter(f=>f.endsWith('.json.gz'))){const {catalog}=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/data/'+f))),b=catalog.bounds;
 for(const [w,h]of [[1200,800],[2560,1440],[1080,2160]]){const {v,handlers}=make(catalog,w,h);v.fit();
 for(const x of [b[0],b[2]])for(const y of [b[1],b[3]]){const p=new T.Vector3(x,0,-y).project(v.camera);assert.ok(p.z>-1&&p.z<1,'Fit depth clips map');}
 for(const scale of [.16,1,8,25,50])for(const angle of [0,.8,2.4])for(const offset of [0,.45]){v.scale=scale;v.azimuth=angle;v.center.set((b[0]+b[2])/2+(b[2]-b[0])*offset,0,-(b[1]+b[3])/2);v.updateCamera();
 for(const sx of [-.8,0,.8])for(const sy of [-.8,0,.8]){v.ray.setFromCamera(new T.Vector2(sx,sy),v.camera);const ground=v.ray.ray.intersectPlane(v.plane,new T.Vector3()),sea=v.ray.ray.intersectPlane(new T.Plane(new T.Vector3(0,1,0),4),new T.Vector3());assert.ok(ground&&sea);const a=ground.clone().project(v.camera),c=sea.clone().project(v.camera);const steps=(c.z-a.z)/2*(2**24-1);minDepthSteps=Math.min(steps,minDepthSteps);assert.ok(steps>8,'Sea and ground need distinct depth bins: '+steps);}
 v.bind();const px=w*.63,py=h*.64,before=v.point(px,py);handlers.wheel({clientX:px,clientY:py,deltaY:-180,preventDefault(){}});let after=v.point(px,py);assert.ok(Math.hypot(before[0]-after[0],before[1]-after[1])<1e-6);
 handlers.pointerdown({clientX:px,clientY:py,button:0,pointerId:1});handlers.pointermove({clientX:px+75,clientY:py+43});after=v.point(px+75,py+43);assert.ok(Math.hypot(before[0]-after[0],before[1]-after[1])<1e-6);handlers.pointerup({clientX:px+75,clientY:py+43});
 assert.ok(v.camera.near>0&&v.camera.far>v.camera.near);cases++;
 }
 }
}
const {v}=make({bounds:[0,0,7200,7200]},2560,1440);v.scale=50;v.updateCamera();v.camera.near=.1;v.camera.far=120000;v.camera.updateProjectionMatrix();const a=new T.Vector3(0,0,0).project(v.camera),b=new T.Vector3(0,-4,0).project(v.camera);const formerSteps=(b.z-a.z)/2*(2**24-1);assert.ok(formerSteps<1);
const report={passed:true,maps:21,mapCameraInputCases:cases,minSeaGroundDepthSteps:minDepthSteps,formerSeaGroundDepthSteps:formerSteps,anchoredWheelAndPan:true,zoomRange:[.16,50]};fs.writeFileSync('tests/depth-v210.json',JSON.stringify(report,null,2));console.log(report);
