import fs from 'node:fs';
import zlib from 'node:zlib';
import assert from 'node:assert/strict';
const coastMaps=new Set(['LostLand_Map_19_2','LostLand_Map_3_2_v2','LostLand_Map_20_v2']);
let maps=0;
for(const file of fs.readdirSync(new URL('../assets/data/',import.meta.url)).filter(x=>x.endsWith('.gz'))){
 const d=JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL('../assets/data/'+file,import.meta.url))));
 const e=d.terrain16.edge,pixels=Buffer.from(e.rgba,'base64'),n=e.size;
 assert.equal(pixels.length,n*n*4);
 assert.equal(e.hasCoast,coastMaps.has(d.catalog.map));
 assert.equal(e.mountainMaterial,d.catalog.map==='LostLand_Map_10'?'rock':'snow');
 let sea=0,exterior=0;
 for(let y=0;y<n;y++)for(let x=0;x<n;x++){
  const i=(y*n+x)*4;
  if(pixels[i]>127)exterior++;
  if(pixels[i+2]>127)sea++;
  // Area-filtered coastline texels may share coverage (128 + 128 after rounding).
  assert.ok(pixels[i]+pixels[i+2]<=256,'Sea and mountain coverage must not overlap');
  if(x>n*.05&&x<n*.95&&y>n*.05&&y<n*.95)assert.equal(pixels[i],0,'Exterior treatment must not cover interior terrain');
 }
 assert.ok(exterior>1000);
 assert.equal(sea>1000,e.hasCoast);
 maps++;
}
assert.equal(maps,21);
console.log(JSON.stringify({passed:true,maps,coastalVariants:coastMaps.size,seaSeparatedFromMountains:true,interiorUnaffected:true}));
