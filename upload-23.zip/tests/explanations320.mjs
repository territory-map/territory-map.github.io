import assert from 'node:assert/strict';import fs from 'node:fs';
const html=fs.readFileSync('web/index.html','utf8'),app=fs.readFileSync('web/app.js','utf8');
assert.ok((html.match(/class="function-help"/g)||[]).length>=18);
for(const id of ['strict','useCrusaderStructures','usePassStructures','allowZoneWalljumps'])assert.match(html,new RegExp('id="'+id+'"[\\s\\S]*?</label><details class="function-help"[^>]*><summary>Erklärung anzeigen</summary>'));
assert.match(html,/<details class="function-help" id="modeHelp"><summary>Erklärung zum Modus<\/summary><p id="modeHint"/);
assert.ok(!/<details class="function-help"[^>]*open/.test(html),'explanations start closed');
const helpers=[...html.matchAll(/<details class="function-help"[^>]*>[\s\S]*?<\/details>/g)].map(m=>m[0]);
for(const id of ['solverResult','warResult','warPickStatus','targetCount'])assert.ok(!helpers.some(s=>s.includes('id="'+id+'"')),'live feedback remains outside explanations: '+id);
assert.ok(app.includes('Das volle Zusatzflaggenlimit ist verfügbar.'));
for(const lang of ['en','fr']){globalThis.localStorage={getItem:()=>lang};const {translate}=await import('../web/i18n.js?helpers320='+lang);for(const text of ['Erklärung anzeigen','Erklärung zum Modus','Kristall-Korridor'])assert.notEqual(translate(text),text);for(const phase of ['Kristall-Korridor','Kristall-Umwege','Breiter Vorstoß'])assert.ok(!translate(phase+' · 42 Positionen geprüft · 12 Flaggen · 8 Kristalle').includes(phase));}
console.log('3.2: collapsible explanations, accessible native summaries, visible switches/status and translated mode hints passed.');
