// Compatibility entry point. Current renderer regression checks:
import "./features-v15.mjs";
