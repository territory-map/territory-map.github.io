import assert from 'node:assert/strict';
import fs from 'node:fs';
import zlib from 'node:zlib';
import {spawnSync} from 'node:child_process';
import {MapModel,G,newPlan,validatePlan} from '../web/core/model.js';
import {resourceRadius} from '../web/core/resource-size.js';

if(!process.argv[2]){
 assert.equal(G.buildingRules.flag.baseClearance,1.4);
 assert.equal(G.buildingRules.subFortress.baseClearance,2.1);
 assert.equal(G.buildingRules.mainFortress.baseClearance,2.625);
 assert.equal(G.buildingRules.flag.territorySide,54);
 assert.equal(G.buildingRules.subFortress.territorySide,90);
 assert.equal(resourceRadius(null),2.31);
 assert.ok(Math.abs(resourceRadius({collisionRadius:12})-3.08)<1e-9);
 const old=newPlan('test');old.version=4;old.settings.resourceRadius=1.5;
 assert.equal(validatePlan(old,'test').settings.resourceRadius,.385);
 old.settings.resourceRadius=2;
 assert.equal(validatePlan(old,'test').settings.resourceRadius,2);
 old.version=5;old.settings.resourceRadius=1.5;
 assert.equal(validatePlan(old,'test').settings.resourceRadius,1.5);
 const results=[];
 for(const file of fs.readdirSync('assets/solver').filter(f=>f.endsWith('.gz'))){
  const p=spawnSync(process.execPath,[import.meta.filename,file],{encoding:'utf8',timeout:120000});
  assert.equal(p.status,0,p.stderr||p.stdout);const result=JSON.parse(p.stdout);results.push(result);console.log(result.map,result.newBuildableExamples.length);
 }
 assert.equal(results.length,21);
 fs.writeFileSync('tests/footprints-v240.json',JSON.stringify({passed:true,flagScale:1.4/6,fortressScale:1.4/6,migrationChecked:true,territorySizesPreserved:true,maps:results},null,2));
}else{
 const d=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/solver/'+process.argv[2]))),m=new MapModel(d),examples=[];
 let seed=240;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 for(let i=0;i<25000&&examples.length<5;i++){
  const x=30+random()*(d.catalog.nativeMapSize-60),y=30+random()*(d.catalog.nativeMapSize-60);
  const b={kind:'flag',x,y,allianceId:'a1'};
  if(m.staticError(b)!==null)continue;
  if(m.groundAccess.blocked(x,y,6)||m.terrainCollision(x,y,6)){
   assert.ok(!m.groundAccess.blocked(x,y,1.4)&&!m.terrainCollision(x,y,1.4));
   assert.ok(!m.groundAccess.blocked(x,y,.01));
   examples.push({x,y,oldRadiusBlocked:true,newRadiusClear:true});
  }
 }
 assert.equal(examples.length,5,d.catalog.map+' has no confirmed newly buildable edge positions');
 let userReference;
 if(d.catalog.map==='Sever_Map_G1_1_v2'){
  const at=(x,y)=>m.staticError({kind:'flag',x:x*6,y:y*6});
  assert.equal(at(254,460),null);
  assert.ok(m.groundAccess.blocked(254*6,460*6,6)||m.terrainCollision(254*6,460*6,6));
  for(const [x,y]of [[255,460],[254,459],[254,461]])assert.match(at(x,y),/Grundfläche/);
  userReference={gameX:254,gameY:460,newRadiusClear:true,oldRadiusBlocked:true,blockedNeighbours:[[255,460],[254,459],[254,461]]};
 }
 console.log(JSON.stringify({map:d.catalog.map,newBuildableExamples:examples,userReference}));
}
