import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('web/index.html','utf8');
const decode=s=>s.replace(/&amp;/g,'&').replace(/&quot;/g,'"');
const stripped=html.replace(/<(script|style|option|title)\b[^>]*>[\s\S]*?<\/\1>/g,'');
const sources=[...new Set([...stripped.split(/<[^>]*>/).map(s=>decode(s.trim())).filter(Boolean),...Array.from(html.matchAll(/(?:title|aria-label|placeholder)="([^"]+)"/g),m=>decode(m[1]))])];
const neutral=new Set(['⚑','♜','▥','◈','TERRITORY LAB','STANDALONE '+JSON.parse(fs.readFileSync('package.json','utf8')).version,'2D','3D','T Text','◇ Marker','POSITION','X','Y','X — · Y —','N ↑','＋','−','⛶','↶ 15°','15° ↷']);
const results={};
for(const lang of ['de','en','fr']){
 globalThis.localStorage={getItem:()=>lang};const {translate}=await import('../web/i18n.js?test='+lang);
 const untranslated=sources.filter(s=>!neutral.has(s)&&translate(s)===s);
 if(lang==='de')assert.deepEqual(sources.map(translate),sources);else assert.deepEqual(untranslated,[],lang+': untranslated sidebar source');
 const status=translate('92 neue Flaggen. Alle markierten Ziele verbunden. 19 Kristallvorkommen erfasst; 1 von 5 Zusatzflaggen. Suchlimit erreicht; bestes geprüftes Ergebnis.');
 const failed=translate('2 neue Flaggen. 3 Ziel(e) noch nicht erreicht. Route ohne Kristallabzweigungen.');
 const progress=translate('Kristallabzweigungen · 1.234 Positionen geprüft · 42 Flaggen · 19 Kristalle');
 const position=translate('Mittelpunkt X 254.01 / Y 460.1 · Bauradius 3.162566 · Bauen möglich');
 if(lang==='en'){
  assert.equal(status,'92 new flags. All marked targets connected. 19 crystal deposits covered; 1 of 5 extra flags. Search limit reached; best validated result.');
  assert.equal(failed,'2 new flags. 3 targets not yet reached. Route without crystal branches.');
  assert.equal(progress,'Crystal branches · 1.234 positions checked · 42 flags · 19 Crystals');
  assert.equal(position,'Centre X 254.01 / Y 460.1 · Building radius 3.162566 · Placement allowed');
 }else if(lang==='fr'){
  assert.equal(status,'92 nouveaux drapeaux. Tous les objectifs marqués sont reliés. 19 gisements de cristaux couverts ; 1 sur 5 drapeaux supplémentaires. Limite de recherche atteinte ; meilleur résultat vérifié.');
  assert.equal(failed,'2 nouveaux drapeaux. 3 objectifs pas encore atteints. Itinéraire sans embranchements vers les cristaux.');
  assert.equal(progress,'Embranchements vers les cristaux · 1.234 positions vérifiées · 42 drapeaux · 19 Cristaux');
  assert.equal(position,'Centre X 254.01 / Y 460.1 · Rayon de construction 3.162566 · Construction possible');
 }
 results[lang]={sidebarSources:sources.length,status,failed,progress,position};
}
fs.mkdirSync('analysis/solver257',{recursive:true});fs.writeFileSync('analysis/solver257/translations.json',JSON.stringify({passed:true,results},null,2));
console.log('2.5.7: complete sidebar source coverage and numeric solver/placement messages in DE/EN/FR passed');
