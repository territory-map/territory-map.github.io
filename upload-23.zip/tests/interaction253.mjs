import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
import {buildPoint,gameBuildCoordinate} from '../web/core/build-position.js';
import {G,legacy} from '../web/core/model.js';
vm.runInThisContext(fs.readFileSync('web/vendor/three.min.js','utf8'));
const {View}=await import('../web/view.js'),T=globalThis.THREE;
// Ten distinct positions inside a single displayed coordinate and territory cell.
const positions=Array.from({length:10},(_,i)=>buildPoint(1524+i*.07,2760+i*.08));
assert.equal(new Set(positions.map(p=>p.x+':'+p.y)).size,10);
for(const p of positions){assert.equal(gameBuildCoordinate(p.x),254);assert.equal(gameBuildCoordinate(p.y),460);}
const model={data:{resources:[{x:20,y:0},{x:200,y:0}]},resourceRadius:()=>4.585712,buildingRadius:b=>G.buildingRadius(legacy(b))};
for(const mode of ['2d','3d'])for(const kind of ['flag','fortress','center-fortress','horse','select']){
 const v=Object.assign(Object.create(View.prototype),{model,mode,cursorGroup:new T.Group()});
 v.nearbyResourceCircles({x:0,y:0},kind);assert.equal(v.cursorGroup.children.length,['flag','fortress','center-fortress'].includes(kind)?1:0);
 v.clearMovePreview();assert.equal(v.cursorGroup.children.length,0);
}
const view=fs.readFileSync('web/view.js','utf8'),html=fs.readFileSync('web/index.html','utf8');
const planBody=view.slice(view.indexOf(' renderPlan(plan)'),view.indexOf(' text(text'));
assert.ok(!planBody.includes('resourceFootprints'),'no permanent resource rings');
assert.ok(html.indexOf('data-tool="target"')>html.indexOf('Automatische Routenplanung'));
assert.equal(html.match(/data-tool="target"/g).length,1);
fs.writeFileSync('tests/interaction-v253.json',JSON.stringify({passed:true,distinctPositionsInOneCell:10,resourceCirclesOnlyNearConstruction:true,targetInRouteSection:true},null,2));
console.log('Continuous placement, contextual circles and route controls passed');
