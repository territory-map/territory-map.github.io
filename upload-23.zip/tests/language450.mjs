import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {exportWords} from '../web/export18.js';

const source=fs.readFileSync('web/i18n.js','utf8');
const context={localStorage:{getItem:()=> 'de'},result:null};
vm.runInNewContext(source.replace(/\bexport (?=(?:function|const|let|class)\b)/g,'')+';result={dictionary,terms};',context);
const dictionary=context.result.dictionary;
const help='Dorf- und Höhlenkreise gelten nur für Preparation Season 1–4. Der Standardradius beträgt für beide 0,73 und ist damit größer als der Flaggenradius 0,67. Die vorhandenen Kartenpositionen bleiben erhalten.';
const singular='1 neue Flaggen. 1 Ziel(e) noch nicht erreicht. 1 Backup-Flaggen; 1 verbleibende kritische Verbindungen. 1 Positionen geprüft · 1 Flaggen';
const results={};
for(const language of ['de','en','fr']){
 globalThis.localStorage={getItem:()=>language};
 const {translate}=await import('../web/i18n.js?language450='+language);
 for(const [key,values] of Object.entries(dictionary)){
  assert.equal(values.length,2,key);
  assert.ok(values.every(x=>typeof x==='string'&&x.trim()),key);
  assert.doesNotMatch(key,/Gebietquadrate|Bildreduzieren|Planenthält|Neue [XY] Koordinate/);
  assert.equal(translate(key),language==='de'?key:values[language==='en'?0:1],key);
 }
 const shown=translate(help),numeric=translate(singular);
 const html=fs.readFileSync('web/map-audit.html','utf8').replace(/<(script|style|title)\b[^>]*>[\s\S]*?<\/\1>/g,'');
 const staticTexts=[...new Set(html.split(/<[^>]*>/).map(s=>s.trim()).filter(Boolean))];
 if(language!=='de')for(const text of staticTexts)if(!['Deutsch','English','Français','3D · 45°','2D'].includes(text))assert.notEqual(translate(text),text,'map comparison translation: '+text);
 const reportWords=exportWords(language);
 assert.doesNotMatch(reportWords.round,/abgerundet|rounded down|au inférieur/);
 assert.ok(reportWords.round.includes(language==='en'?'0.5':'0,5'));
 if(language==='en'){
  assert.ok(shown.includes('The default radius for both is 0.73'));
  assert.equal(numeric,'1 new flag. 1 target not yet reached. 1 backup flag; 1 remaining critical connection. 1 position checked · 1 flag');
 }else if(language==='fr'){
  assert.ok(shown.includes('Le rayon par défaut est de 0,73 pour les deux'));
  assert.equal(numeric,'1 nouveau drapeau. 1 objectif pas encore atteint. 1 drapeau de secours ; 1 connexion critique restante. 1 position vérifiée · 1 drapeau');
  assert.equal(translate('Automatischer Kriegsbauer'),'Planificateur militaire automatique');
  const pass=translate('Zonen anklicken, um direkte Wandsprünge in beide Richtungen zu finden. Blau: unsere Zone. Rot: gegnerische Zone. Der Pass muss nicht erobert werden.');
  assert.ok(pass.includes('Il n’est pas nécessaire de capturer le passage.'));
 }else assert.equal(numeric,'1 neue Flagge. 1 Ziel noch nicht erreicht. 1 Backup-Flagge; 1 verbleibende kritische Verbindung. 1 Position geprüft · 1 Flagge');
 assert.ok(translate('21 neue Flaggen.').startsWith('21 '));
 assert.ok(!translate('21 neue Flaggen.').endsWith(language==='de'?'Flagge.':language==='en'?'flag.':'drapeau.'));
 results[language]={dictionaryEntries:Object.keys(dictionary).length,help:shown,singular:numeric,exportRounding:reportWords.round,mapComparisonTexts:staticTexts.length};
}
fs.mkdirSync('analysis/zones450',{recursive:true});
fs.writeFileSync('analysis/zones450/languages.json',JSON.stringify({passed:true,results},null,2));
console.log('4.5: complete DE/EN/FR dictionary coverage, radius help, pass meaning and singular/plural status grammar passed.');
