import importlib.util,unittest,time
from pathlib import Path
spec=importlib.util.spec_from_file_location('labserver',Path(__file__).parents[1]/'server.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class LifetimeTest(unittest.TestCase):
 def test_refresh_and_multiple_tabs(self):
  life=m.BrowserLifetime();life.update('one','alive',100);life.update('two','alive',101)
  life.update('one','leave',102);self.assertFalse(life.expired(110))
  life.update('two','leave',111);self.assertFalse(life.expired(113))
  life.update('refresh','alive',114);self.assertFalse(life.expired(120))
  life.update('refresh','leave',121);self.assertFalse(life.expired(126));self.assertTrue(life.expired(127))
 def test_crashed_browser_expires(self):
  life=m.BrowserLifetime();life.update('tab','alive',100);self.assertFalse(life.expired(399));self.assertFalse(life.expired(401));self.assertTrue(life.expired(407))
 def test_startup_grace(self):
  life=m.BrowserLifetime();self.assertFalse(life.expired(life.started+119));self.assertTrue(life.expired(life.started+121))
if __name__=='__main__':unittest.main()
