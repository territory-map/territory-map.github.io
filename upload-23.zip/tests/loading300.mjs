import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
vm.runInThisContext(fs.readFileSync('web/vendor/three.min.js','utf8'));
const {View}=await import('../web/view.js'),T=globalThis.THREE;
let resume;const reliefPending=new Promise(r=>resume=r),coast={texture:new T.Texture(),tint:new T.Color('#123456')};
const v=Object.assign(Object.create(View.prototype),{mapGroup:new T.Group(),textures:new Map(),texture:async()=>new T.Texture({width:2,height:2}),buildTerrain(){},async buildRelief(){await reliefPending;this.terrainMaterial={userData:{coast}};},async buildSites(){},async prepareBuildingArt(){},renderPlan(){},fit(){},visibility(){this.ground.visible=this.groundReady;}});
const load=v.load({catalog:{map:'delayed-load',bounds:[0,0,100,100]},data:{},plan:{alliances:[{color:'#ff0000'}]}});await Promise.resolve();await Promise.resolve();
assert.ok(v.ground);assert.equal(v.ground.visible,false,'do not render shader before asynchronous coast material exists');resume();await load;assert.equal(v.ground.visible,true);const shader={uniforms:{},fragmentShader:'#include <map_fragment>'};v.ground.material.onBeforeCompile(shader);assert.equal(shader.uniforms.edge17.value,coast.texture);assert.equal(shader.uniforms.sea17.value,coast.tint);
// Compiling this map must keep its own coast, even if another map begins loading.
v.terrainMaterial=undefined;const again={uniforms:{},fragmentShader:'#include <map_fragment>'};v.ground.material.onBeforeCompile(again);assert.equal(again.uniforms.edge17.value,coast.texture);console.log('Delayed map load and retained per-material coast uniforms passed.');
