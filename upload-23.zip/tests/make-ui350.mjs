import fs from 'node:fs';import zlib from 'node:zlib';
import {MapModel,newPlan,legacy,kindToLegacy} from '../web/core/model.js';
import {zoneId} from '../web/core/war-zone-mask.js';
const data=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/solver/LostLand_Map_18_v2.json.gz'))),m=new MapModel(data),p=newPlan(data.catalog.map);
let root;
for(let y=570;y<1200&&!root;y+=18)for(let x=666;x<1300&&!root;x+=18){const b={id:'root',kind:'fortress',allianceId:'a1',x,y};m.setPlan(p);if(!m.placementError(b,{manual:true}))root=b;}
if(!root)throw Error('no root');p.buildings.push(root);
let extra;
for(let i=0;i<22;i++){
 m.setPlan(p);let found;
 for(let r=18;r<650&&!found;r+=18)for(let dy=-r;dy<=r&&!found;dy+=18)for(let dx=-r;dx<=r&&!found;dx+=18){const b={id:'flag'+i,kind:'flag',allianceId:'a1',x:root.x+dx,y:root.y+dy};if(!m.placementError(b,{manual:true}))found=b;}
 if(!found)throw Error('no flag');if(i<21)p.buildings.push(found);else extra=found;
}
m.setPlan(p);const zones=Object.values(m.groundAccess.nav.passes).find(a=>a.length===2).map(z=>zoneId(m.groundAccess,z));p.warBuilder={...p.warBuilder,ourZone:zones[0],ourTarget:zones[1],enemyZone:zones[1],enemyTarget:zones[0]};
p.targets=[{id:'goal',x:extra.x,y:extra.y}];p.settings.routeMode='build';p.settings.crystals=false;
fs.mkdirSync('analysis/costs350',{recursive:true});fs.writeFileSync('analysis/costs350/ui-plan.json',JSON.stringify(p));
console.log(JSON.stringify({root,extra,war:p.warBuilder,cost22:data.catalog.costs.flag.find(t=>22>=t.from&&22<=t.to).cost.credits}));

