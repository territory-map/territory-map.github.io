import assert from 'node:assert/strict';
import fs from 'node:fs';import zlib from 'node:zlib';
import {MapModel,newPlan,validatePlan} from '../web/core/model.js';
import {solve} from '../web/solver.js';
const read=slug=>JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL('../assets/data/'+slug+'.json.gz',import.meta.url))));
const results=[];
for(const slug of ['LostLand_Map_18_v2','LostLand_Map_4_2_v2','LostLand_Map_20_v2']){
 const data=read(slug),m=new MapModel(data),p=newPlan(slug);let start;
 for(let x=999;x<4000&&!start;x+=54)for(let y=999;y<4000&&!start;y+=54){const root={id:'root',kind:'fortress',x,y,allianceId:'a1'};if(m.staticError(root))continue;let open=true;for(let dx=54;dx<=216;dx+=54)if(m.staticError({kind:'flag',x:x+dx,y,allianceId:'a1'}))open=false;if(open)start=root;}
 assert.ok(start,'free test corridor');p.buildings=[start];p.targets=[{id:'target',x:start.x+210,y:start.y}];m.setPlan(p);const before=JSON.stringify(p);const r=solve(m,p,'a1',{budget:12,maxVisits:25000});assert.equal(r.failed.length,0,slug);assert.equal(JSON.stringify(p),before);
 for(const b of r.buildings){m.setPlan(p);assert.equal(m.placementError(b),null);p.buildings.push(b);}m.setPlan(p);assert.ok(m.targetReached(p.targets[0],'a1'));
 const short=newPlan(slug);short.buildings=[start];short.targets=p.targets;const fail=solve(m,short,'a1',{budget:1,maxVisits:3000});assert.equal(fail.failed.length,1);assert.equal(fail.buildings.length,0);
 results.push({map:slug,routeFlags:r.buildings.length,budgetLimitRespected:true,start:{x:start.x,y:start.y},target:p.targets[0]});
 const original=data.sites.find(s=>s.source==='official');const altered=newPlan(slug);altered.siteEdits[original.id]={x:1,y:2};m.setPlan(altered);const found=m.sites.find(s=>s.siteId===original.id);assert.equal(found.x,1);assert.equal(found.y,2);assert.notEqual(original.x,1);assert.notEqual(original.y,2);
}
const s=read('LostLand_Map_18_v2');const passes=s.sites.filter(s=>s.kind==='pass');assert.equal(passes.length,52);assert.equal(s.sites.filter(s=>s.kind==='bastion'&&s.source==='official').length,56);
for(const p of passes){assert.equal(p.positionAccuracy,'native-pass-geometry');assert.ok(p.geometryMatch.score>.89);assert.ok(p.referenceObservations.length);assert.ok(p.referenceObservations.every(r=>r.level===p.level));assert.ok(p.direction);}
assert.ok(s.alignmentValidation.control.maxPixels<.55);assert.equal(s.alignmentValidation.control.count,56);
assert.throws(()=>validatePlan({map:'x',alliances:[],buildings:[]},'x'));
const report={passed:true,actualMapRoutes:results,shiftingPasses:52,originalBastions:56,referenceObservations:s.alignmentValidation.sourceObservations,controlMaxPixels:s.alignmentValidation.control.maxPixels};
fs.writeFileSync(new URL('./verification.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
