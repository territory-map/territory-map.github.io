import assert from 'node:assert/strict';import fs from 'node:fs';import zlib from 'node:zlib';
import {buildTerritoryState as original} from '../web/core/geometry.js';
import {buildTerritoryState as indexed} from '../web/core/territory17.js';
import {structures} from '../web/core/model.js';
const normalize=s=>({ownership:[...s.ownership].sort(([a],[b])=>a.localeCompare(b)),owners:[...s.structureOwners].sort(([a],[b])=>a-b)});
let seed=1717;const random=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);
for(let trial=0;trial<600;trial++){
 const sites=Array.from({length:30},(_,i)=>({id:i+1,x:Math.floor(random()*25)*18+9,y:Math.floor(random()*25)*18+9,territoryRadiusInCells:1+Math.floor(random()*3),claimable:random()>.2}));
 const buildings=Array.from({length:35},(_,i)=>({id:String(i),kind:i%7?'flag':'subFortress',allianceId:'a'+Math.floor(random()*3),x:random()*450,y:random()*450}));
 assert.deepEqual(normalize(indexed(buildings,sites)),normalize(original(buildings,sites)),'Capture/exclusion parity '+trial);
}
for(const file of fs.readdirSync(new URL('../assets/data/',import.meta.url)).filter(f=>f.endsWith('.gz'))){
 const d=JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL('../assets/data/'+file,import.meta.url)))),sites=structures(d);
 const buildings=sites.slice(0,12).flatMap((s,i)=>Array.from({length:4},(_,j)=>({id:i+':'+j,kind:j?'flag':'subFortress',allianceId:'a'+i%3,x:s.x-85+j*36,y:s.y+70})));
 assert.deepEqual(normalize(indexed(buildings,sites)),normalize(original(buildings,sites)),d.catalog.map);
}
console.log('Ownership parity: 600 overlapping multi-alliance scenarios and all 21 real maps passed.');
