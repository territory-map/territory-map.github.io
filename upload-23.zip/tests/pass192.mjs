import assert from 'node:assert/strict';import fs from 'node:fs';import zlib from 'node:zlib';
import {MapModel,newPlan} from '../web/core/model.js';
const width=601,height=401,regions=new Uint16Array(width*height);for(let y=0;y<height;y++)for(let x=0;x<width;x++)regions[y*width+x]=x<243?1:x<387?2:3;
const data={catalog:{map:'auto-pass',nativeMapSize:600,bounds:[0,0,600,400],structureRules:{45:{territoryRadiusInCells:1,claimable:true,collision:{shape:'territory-square',radiusInCells:1}}},buildings:{flag:{limit:500},fortress:{limit:5}}},sites:[{id:'gate',kind:'pass',strongholdType:45,x:243,y:207},{id:'gate2',kind:'pass',strongholdType:45,x:387,y:207}],resources:[],definitions:[],instances:[],navigation18:{width,height,regions:Buffer.from(regions.buffer).toString('base64'),passes:{gate:[1,2],gate2:[2,3]}}};
const model=new MapModel(data),p=newPlan(data.catalog.map),fort=(x,y=207)=>({id:'root',kind:'fortress',x,y,allianceId:'a1'}),flag=(x,y=207)=>({id:'flag'+x,kind:'flag',x,y,allianceId:'a1'});
const check=(open)=>{model.setPlan(p);assert.equal(model.accessFor('a1').captured.has('gate'),open);assert.equal(model.state.structureOwners.get(model.sites[0].id),open?'a1':undefined);assert.equal(model.zoneError(flag(300))===null,open);};
p.buildings=[fort(171)];check(true);assert.deepEqual(p.capturedPasses,{},'automatic state never mutates saved plan');
p.buildings=[fort(171,135)];check(false); // Corner contact alone.
p.buildings=[fort(153)];check(false); // Outer frame / one-cell gap.
p.buildings=[fort(117),flag(189)];check(true);
p.buildings=[fort(99),flag(189)];check(false); // Disconnected flag touches pass.
p.buildings=[fort(117),flag(189)];check(true);const saved=JSON.stringify(p);p.buildings.pop();check(false);Object.assign(p,JSON.parse(saved));check(true); // Delete, undo, reload.
p.buildings.push(flag(297),flag(351));model.setPlan(p);assert.ok(model.accessFor('a1').captured.has('gate2'),'second gate opens only through first');assert.equal(model.zoneError(flag(441)),null);
p.buildings=p.buildings.filter(b=>b.x!==189);check(false);assert.equal(model.accessFor('a1').captured.has('gate2'),false,'other-side buildings cannot keep gates open after bridge deletion');
const obstructed=structuredClone(data);obstructed.resources=[{id:'resource',kind:'food',x:189,y:207}];const blocked=new MapModel(obstructed);p.buildings=[fort(117),flag(189)];blocked.setPlan(p);assert.equal(blocked.accessFor('a1').captured.has('gate'),false,'invalid colliding flag cannot capture');
p.buildings=[fort(171),{...fort(315),id:'enemy',allianceId:'a2'}];p.alliances.push({id:'a2',name:'Opponent',color:'#ff0000'});model.setPlan(p);assert.ok(model.accessFor('a1').captured.has('gate'));assert.equal(model.accessFor('a2').captured.has('gate'),true,'each touching alliance has access');assert.equal(model.canCapture(model.sites[0],'a2'),true,'display colour does not block a connected alliance');
const real=[];for(const map of ['LostLand_Map_18_v2','LostLand_Map_20_v2']){const d=JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL('../assets/solver/'+map+'.json.gz',import.meta.url)))),m=new MapModel(d),q=newPlan(map);let fixture;
for(const site of m.sites.filter(s=>s.kind==='pass')){for(const [dx,dy] of [[66,0],[-66,0],[0,66],[0,-66]]){const b=fort(site.x+dx,site.y+dy);if(m.staticError(b))continue;q.buildings=[b];m.setPlan(q);if(m.accessFor('a1').captured.has(site.siteId)){fixture={siteId:site.siteId,building:b,regions:[...m.accessFor('a1').regions]};assert.equal(m.state.structureOwners.get(site.id),'a1');break;}}if(fixture)break;}
assert.ok(fixture,map);const site=m.sites.find(s=>s.siteId===fixture.siteId),rootRegion=m.groundAccess.buildingRegion(fixture.building.x,fixture.building.y);let across;
for(let dx=-126;dx<=126&&!across;dx+=6)for(let dy=-126;dy<=126&&!across;dy+=6){const b={id:'other-side',kind:'flag',allianceId:'a1',x:site.x+dx,y:site.y+dy};if(m.groundAccess.buildingRegion(b.x,b.y)!==rootRegion&&!m.placementError(b))across=b;}
assert.ok(across,'legal connected flag on other side '+map);fixture.otherSideFlag=across;const prior=structuredClone(q);q.buildings.push(across);m.setPlan(q);assert.equal(m.zoneError(across),null);Object.assign(q,prior);
real.push({map,...fixture});fs.writeFileSync(new URL('./pass192-'+map+'.json',import.meta.url),JSON.stringify(q,null,2));}
const report={passed:true,fortressContact:true,flagContact:true,automaticColourAndOpening:true,cornerRejected:true,gapRejected:true,disconnectedRejected:true,collisionRejected:true,deleteUndoReload:true,chainedPasses:true,sharedAccess:true,real};fs.writeFileSync(new URL('./pass-v192.json',import.meta.url),JSON.stringify(report,null,2));console.log(report);

