import assert from 'node:assert/strict';
import fs from 'node:fs';
import zlib from 'node:zlib';
import {MapModel,newPlan,validatePlan} from '../web/core/model.js';
import {solve} from '../web/solver.js';
const width=601,height=401,regions=new Uint16Array(width*height);
for(let y=0;y<height;y++)for(let x=0;x<width;x++)regions[y*width+x]=x<243?1:2;
const rule={territoryRadiusInCells:1,claimable:true,collision:{shape:'territory-square',radiusInCells:1}};
const data={catalog:{map:'passes257',nativeMapSize:600,bounds:[0,0,600,400],structureRules:{45:rule},buildings:{flag:{limit:500},fortress:{limit:5}}},sites:[{id:'gate',kind:'pass',strongholdType:45,x:243,y:207}],resources:[{id:'far-crystal',kind:'crystal',x:315,y:207}],definitions:[],instances:[],navigation18:{width,height,regions:Buffer.from(regions.buffer).toString('base64'),passes:{gate:[1,2]}}};
const p=newPlan(data.catalog.map),m=new MapModel(data);p.buildings=[{id:'root',kind:'fortress',allianceId:'a1',x:171,y:207},{id:'across',kind:'flag',allianceId:'a1',x:297,y:207}];p.capturedPasses.gate='a1';
for(const crusaders of [false,true])for(const enabled of [true,false,true,false]){
 p.settings.useCrusaderStructures=crusaders;p.settings.usePassStructures=enabled;m.setPlan(p);
 assert.equal(m.accessFor('a1').captured.has('gate'),enabled);
 assert.equal(m.accessFor('a1').regions.has(2),enabled);
 assert.equal(m.isBuildingActive(p.buildings[1]),enabled);
 assert.equal(m.territoryFor('a1').has('13:11'),enabled);
 assert.equal(m.covered('a1').crystal||0,enabled?1:0);
 assert.equal(m.canCapture(m.sites[0],'a1'),enabled);
 assert.equal(m.targetReached({siteId:'gate'},'a1'),enabled,'off requires an active flag, not just a fortress');
}
// The relay-only solver case needs a physical wall. Navigation labels alone
// do not block valid flag-territory jumps or a route around a reserved square.
const solid=structuredClone(data),wall=new Uint8Array(width*height);
for(let y=0;y<height;y++)for(let x=216;x<=270;x++)wall[y*width+x]=255;
solid.terrain15={hatching:Buffer.from(wall).toString('base64'),hatchingWidth:width,hatchingHeight:height};
const relayModel=new MapModel(solid);
const results=[];
for(const crystals of [false,true])for(const enabled of [false,true]){
 const q=newPlan(data.catalog.map);q.buildings=[{id:'root',kind:'fortress',allianceId:'a1',x:117,y:207}];q.settings.usePassStructures=enabled;q.settings.crystals=crystals;q.targets=[{id:'far',x:369,y:207}];
 const r=solve(relayModel,q,'a1',{budget:20,startId:'root',crystals,crystalExtra:5,maxMillis:2500});
 assert.equal(r.failed.length,enabled?0:1);if(!enabled){assert.equal(r.buildings.length,0);assert.equal(r.requiredPasses.length,0,'off cannot generate automatic pass prerequisites');}
 const applied=structuredClone(q);for(const b of r.buildings){relayModel.setPlan(applied);assert.equal(relayModel.placementError(b),null);applied.buildings.push(b);}relayModel.setPlan(applied);assert.equal(relayModel.targetReached(q.targets[0],'a1'),enabled);
 results.push({crystals,enabled,flags:r.buildings.length,failed:r.failed.length});
}
// OFF still permits approaching a marked pass with an active flag on our side.
const q=newPlan(data.catalog.map);q.settings.usePassStructures=false;q.buildings=[{id:'root',kind:'fortress',allianceId:'a1',x:117,y:207}];q.targets=[{id:'gate-target',siteId:'gate',x:243,y:207}];
const approached=solve(m,q,'a1',{budget:10,crystals:false,startId:'root',maxMillis:2500});assert.equal(approached.failed.length,0);assert.ok(approached.buildings.length);q.buildings.push(...approached.buildings);m.setPlan(q);assert.ok(m.targetReached(q.targets[0],'a1'));assert.equal(m.accessFor('a1').regions.has(2),false);
const legacy=structuredClone(q);delete legacy.settings.usePassStructures;assert.equal(validatePlan(legacy,q.map).settings.usePassStructures,true);assert.equal(validatePlan(q,q.map).settings.usePassStructures,false);
const maps=[];for(const f of fs.readdirSync('assets/solver').filter(f=>f.endsWith('.gz'))){const d=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/solver/'+f))),m=new MapModel(d),q=newPlan(d.catalog.map);q.settings.usePassStructures=false;m.setPlan(q);assert.ok(m.accessSites.filter(s=>s.kind==='pass').every(s=>s.conductsTerritory===false));maps.push({map:d.catalog.map,passes:m.sites.filter(s=>s.kind==='pass').length});}
fs.mkdirSync('analysis/solver257',{recursive:true});fs.writeFileSync('analysis/solver257/pass-rules.json',JSON.stringify({passed:true,results,approachFlags:approached.buildings.length,maps},null,2));
console.log('2.5.7: independent pass toggle, no zone/production relay, active target approach, solver ON/OFF and 21 maps passed');
