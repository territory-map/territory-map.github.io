import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
vm.runInThisContext(fs.readFileSync(new URL('../web/vendor/three.min.js',import.meta.url),'utf8'));
const T=globalThis.THREE,{View}=await import('../web/view.js');
const {buildingSymbolHeight}=await import('../web/building-anchor19.js');
let cases=0;const ratios=[];
for(const mode of ['2d','3d'])for(const scale of [.16,.5,2,8])for(const azimuth of [0,.4,1.2]){
 const v=Object.assign(Object.create(View.prototype),{camera:new T.OrthographicCamera(-1,1,1,-1,.1,60000),scene:new T.Scene(),center:new T.Vector3(200,0,-200),flags:{},mode,azimuth,tilt:Math.PI/4,w:1200,h:800,scale});v.updateCamera();
 const project=(x,y)=>{const a=new T.Vector3(x,0,-y).project(v.camera);return [a.x*v.w/2,a.y*v.h/2];};
 const center=project(200,200),dx=mode==='3d'?Math.cos(azimuth):1,dy=mode==='3d'?Math.sin(azimuth):0;
 const side=project(200+9*dx,200+9*dy),depth=project(200-9*dy,200+9*dx);
 const a=Math.hypot(side[0]-center[0],side[1]-center[1]),b=Math.hypot(depth[0]-center[0],depth[1]-center[1]);
 assert.ok(Math.abs(a-9/scale)<1e-7);const distance=v.camera.position.distanceTo(v.center),expected=mode==='3d'?Math.SQRT1_2*distance/(distance+9*Math.SQRT1_2):1;assert.ok(Math.abs(b/a-expected)<1e-7);
 const q=new T.Vector3(200+9*dx,0,-(200+9*dy)).project(v.camera),ray=new T.Raycaster();ray.setFromCamera(new T.Vector2(q.x,q.y),v.camera);const hit=ray.ray.intersectPlane(new T.Plane(new T.Vector3(0,1,0),0),new T.Vector3());assert.ok(Math.abs(Math.hypot(hit.x-200,hit.z+200)-9)<1e-7);
 ratios.push({mode,scale,azimuth,axisRatio:b/a});cases++;
}
assert.equal(buildingSymbolHeight({},'flag',6),6*.94/(300/1536));assert.equal(buildingSymbolHeight({},'fortress',9),9*.94/(31/105));
const report={passed:true,projectionCases:cases,exactPhysicalCircle:true,ratios,zoomIndependentBuildingSize:true};fs.writeFileSync(new URL('./perspective-v191.json',import.meta.url),JSON.stringify(report,null,2));console.log(report);
