import assert from 'node:assert/strict';import fs from 'node:fs';import zlib from 'node:zlib';import vm from 'node:vm';
import {MapModel,newPlan,G} from '../web/core/model.js';import {buildPoint,gameBuildCoordinate} from '../web/core/build-position.js';import {gameCoordinate} from '../web/presentation17.js';import {solve} from '../web/solver.js';
vm.runInThisContext(fs.readFileSync('web/vendor/three.min.js','utf8'));const {View}=await import('../web/view.js'),T=globalThis.THREE;
assert.equal(gameCoordinate(254.01*6),254);assert.equal(gameCoordinate(460.1*6),460);
const results=[];
for(const source of ['data','solver']){
 const d=JSON.parse(zlib.gunzipSync(fs.readFileSync(`assets/${source}/Sever_Map_G1_1_v2.json.gz`))),m=new MapModel(d),p=newPlan(d.catalog.map);p.settings.flagRadius=3.16256/6;p.settings.fortressRadius=4.427584/6;p.settings.resourceRadius=4.585712/6;p.buildings=[{id:'root',kind:'fortress',x:1452,y:2700,allianceId:'a1'}];m.setPlan(p);
 for(const [x,y,valid]of [[254,460,true],[255,460,false],[254,461,false],[255,461,false],[255.01,461.1,false],[255.999,461.999,false]]){
  const q=buildPoint(x*6,y*6),b={kind:'flag',allianceId:'a1',...q},error=m.placementError(b);assert.equal(!error,valid,`${source}: ${x}/${y}`);
  assert.ok(Math.abs(q.x-x*6)<=.00501);assert.ok(Math.abs(q.y-y*6)<=.00501);
  for(const mode of ['2d','3d']){const v=Object.assign(Object.create(View.prototype),{model:m,mode,cursorGroup:new T.Group()});v.preview([x*6,y*6],'flag',!error);const circle=v.cursorGroup.children.find(o=>o.geometry?.attributes.position?.count===65);assert.ok(circle);const a=circle.geometry.attributes.position;assert.ok(Math.abs(a.getX(0)-q.x-m.buildingRadius({kind:'flag'}))<.001);assert.ok(Math.abs(a.getZ(0)+q.y)<.001);}
  results.push({source,input:{x,y},centre:{x:q.x/6,y:q.y/6},valid:!error,error});
 }
 // Check the forbidden coordinate bin without quantizing its centre.
 for(let i=0;i<100;i++)for(let j=0;j<100;j++)assert.match(m.staticError({kind:'flag',...buildPoint((255+i/100)*6,(461+j/100)*6)}),/Grundfläche/);
 p.targets=[{id:'target',x:1566,y:2700}];m.setPlan(p);const route=solve(m,p,'a1',{budget:15,crystals:false,maxVisits:12000});assert.equal(route.failed.length,0);
 for(const b of route.buildings){m.setPlan(p);assert.equal(m.placementError(b),null);p.buildings.push(b);}
}
fs.writeFileSync('tests/positions-v253.json',JSON.stringify({passed:true,results,forbiddenCoordinatePointerCases:20000,previewModes:['2d','3d'],solverCoordinatesContinuous:true,radiiUnchangedFrom251:true},null,2));console.log('Exact centres, floor rounding, both previews, forbidden bin and solver passed');
