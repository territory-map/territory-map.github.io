import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {MapModel,newPlan,validatePlan,G} from '../web/core/model.js';
import {DEFAULT_FLAG_RADIUS_GAME,DEFAULT_FORTRESS_RADIUS_GAME} from '../web/core/building-size.js';
import {DEFAULT_RESOURCE_RADIUS_GAME,resourceRadius} from '../web/core/resource-size.js';
import {searchWarJumps,warPairError} from '../web/core/war-builder.js';
import {solve} from '../web/solver.js';
const n=360,w=n+1,labels=new Uint16Array(w*w),mask=new Uint8Array(w*w);
for(let v=0;v<w;v++)for(let x=0;x<w;x++){const y=n-v,i=v*w+x;labels[i]=y<178?1:y>182?2:0;mask[i]=labels[i]?0:255;}
const data={catalog:{map:'radii310',nativeMapSize:n,bounds:[0,0,n,n],structureRules:{},buildings:{flag:{limit:500},fortress:{limit:2},'center-fortress':{limit:1}}},sites:[],resources:[{id:'ore',kind:'crystal',x:225,y:99,collisionRadius:12}],definitions:[],instances:[],terrain15:{hatching:Buffer.from(mask).toString('base64'),hatchingWidth:w,hatchingHeight:w},navigation18:{width:w,height:w,regions:Buffer.from(labels.buffer).toString('base64'),passes:{}}};
const p=newPlan(data.catalog.map),m=new MapModel(data);m.setPlan(p);
assert.equal(m.buildingRadius({kind:'flag'}),DEFAULT_FLAG_RADIUS_GAME*6);
assert.equal(m.buildingRadius({kind:'fortress'}),DEFAULT_FORTRESS_RADIUS_GAME*6);
const candidate={kind:'flag',allianceId:'a1',x:99,y:172};
assert.equal(m.staticError(candidate),null);p.settings.flagRadius=2;m.setPlan(p);assert.match(m.staticError(candidate),/Grundfläche/,'radius change invalidates cached free terrain');
p.settings.flagRadius=DEFAULT_FLAG_RADIUS_GAME;m.setPlan(p);assert.equal(m.staticError(candidate),null);
p.settings.flagRadius=2;p.settings.fortressRadius=3;p.settings.resourceRadius=2;m.setPlan(p);
assert.equal(m.buildingRadius({kind:'flag'}),12);assert.equal(m.buildingRadius({kind:'fortress'}),18);assert.equal(m.buildingRadius({kind:'center-fortress'}),18);
assert.equal(resourceRadius(data.resources[0],p.settings),16,'edited resource radius also scales imported per-resource collision sizes');
const saved=validatePlan(JSON.parse(JSON.stringify(p)),p.map);assert.equal(saved.settings.flagRadius,2);assert.equal(saved.settings.fortressRadius,3);assert.equal(saved.settings.resourceRadius,2);
const other=new MapModel(data);assert.equal(other.buildingRadius({kind:'flag'}),DEFAULT_FLAG_RADIUS_GAME*6,'another model cannot inherit overridden radii');
assert.ok(G.plannedBuildingCollision(m.legacy({kind:'flag',x:99,y:99}),[m.legacy({kind:'fortress',x:128,y:99})]));
assert.ok(!G.plannedBuildingCollision(other.legacy({kind:'flag',x:99,y:99}),[other.legacy({kind:'fortress',x:128,y:99})]));
const tiny=validatePlan({...p,settings:{...p.settings,flagRadius:-1,fortressRadius:Infinity}},p.map);assert.equal(tiny.settings.flagRadius,DEFAULT_FLAG_RADIUS_GAME);assert.equal(tiny.settings.fortressRadius,DEFAULT_FORTRESS_RADIUS_GAME);
// Manual, solver and war search share the changed footprint validator.
const results=[],jumpPositions=[];
for(const flagRadius of [DEFAULT_FLAG_RADIUS_GAME,2]){
 const plan=newPlan(p.map);plan.settings.flagRadius=flagRadius;plan.settings.fortressRadius=2;plan.settings.resourceRadius=1.5;
 plan.buildings=[{id:'root',kind:'fortress',allianceId:'a1',x:63,y:99}];plan.targets=[{id:'goal',x:315,y:99}];
 const before=JSON.stringify(plan),route=solve(m,plan,'a1',{budget:35,routeMode:'build',maxMillis:2000});assert.equal(route.failed.length,0,route.reason);assert.equal(JSON.stringify(plan),before);
 const applied=structuredClone(plan);for(const b of route.buildings){m.setPlan(applied);assert.equal(m.placementError(b),null,'solver uses edited radius on every accepted flag');applied.buildings.push(b);}
 m.setPlan(applied);assert.ok(m.targetReached(plan.targets[0],'a1'));results.push({flagRadius,routeFlags:route.buildings.length});
 const empty=structuredClone(plan);empty.buildings=[];empty.targets=[];empty.settings.allowZoneWalljumps=false;
 const jumps=searchWarJumps(m,empty,[{side:'ours',allianceId:'a1',from:1,to:2}]);for(const q of jumps.directions[0].pairs)assert.equal(warPairError(m,q.source,q.target,1,2),null);
 results.at(-1).jumpPairs=jumps.directions[0].pairs.length;
 jumpPositions.push(JSON.stringify(jumps.directions[0].pairs.map(q=>[q.id,q.kind,q.source.x,q.source.y,q.target.x,q.target.y])));
}
assert.notEqual(jumpPositions[1],jumpPositions[0],'larger circles require different valid source/landing positions');
// Actual rendered circle geometry reflects the radius in both views.
vm.runInThisContext(fs.readFileSync('web/vendor/three.min.js','utf8'));const {View}=await import('../web/view.js'),T=globalThis.THREE;
m.setPlan(p);for(const mode of ['2d','3d']){const view=Object.assign(Object.create(View.prototype),{model:m,mode,cursorGroup:new T.Group()});view.preview([99,99],'flag',true);const circle=view.cursorGroup.children.find(o=>o.geometry?.attributes.position?.count===65);assert.ok(Math.abs(circle.geometry.attributes.position.getX(0)-99-12)<.001);}
// Reset values are the calibrated 3.0 defaults, saved settings are reversible.
p.settings.flagRadius=DEFAULT_FLAG_RADIUS_GAME;p.settings.fortressRadius=DEFAULT_FORTRESS_RADIUS_GAME;p.settings.resourceRadius=DEFAULT_RESOURCE_RADIUS_GAME;m.setPlan(p);
assert.equal(m.buildingRadius({kind:'flag'}),DEFAULT_FLAG_RADIUS_GAME*6);assert.equal(m.buildingRadius({kind:'fortress'}),DEFAULT_FORTRESS_RADIUS_GAME*6);
fs.mkdirSync('analysis/war310',{recursive:true});fs.writeFileSync('analysis/war310/radii.json',JSON.stringify({passed:true,planScoped:true,manualSolverWarShared:true,renderModes:['2d','3d'],results},null,2));
console.log('3.1 per-plan radii: collision caches, metadata resources, solver, war search, 2D/3D circles and calibrated resets passed');
