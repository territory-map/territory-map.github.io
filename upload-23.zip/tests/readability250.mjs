import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
vm.runInThisContext(fs.readFileSync('web/vendor/three.min.js','utf8'));
const T=globalThis.THREE,{View}=await import('../web/view.js'),{createResourceCards}=await import('../web/reference-art.js'),{MapModel,newPlan}=await import('../web/core/model.js'),{resourceSymbolHeight}=await import('../web/core/resource-size.js');
let cases=0;
for(const mode of ['2d','3d'])for(const scale of [.16,.5,2]){
 const node={id:'stone',kind:'stone',x:200,y:200},d={catalog:{map:'test',nativeMapSize:600,bounds:[0,0,600,600],structureRules:{},buildings:{}},sites:[],resources:[node],definitions:[],instances:[]},model=new MapModel(d),plan=newPlan('test');model.setPlan(plan);
 const group=new T.Group(),texture=new T.Texture({width:64,height:64}),card=createResourceCards([node],texture,'stone');group.add(card);
 const sprite=new T.Sprite(new T.SpriteMaterial());sprite.position.set(200,0,-200);sprite.userData={resource:node,size:14,aspect:1,left:0,right:1,anchor:0,top:1};
 const v=Object.assign(Object.create(View.prototype),{camera:new T.OrthographicCamera(-1,1,1,-1,.1,60000),scene:new T.Scene(),flags:{resources:true},poi:{},mode,scale,w:1280,h:720,tilt:Math.PI/4,azimuth:0,center:new T.Vector3(200,0,-200),model,resourceSolids:group,symbols:[sprite]});v.scene.add(sprite,group);v.updateCamera();
 for(const radiusGame of [.7642853333333334,2]){
  plan.settings.resourceRadius=radiusGame;v.updateSprites();
  assert.ok(Math.abs(sprite.scale.y-resourceSymbolHeight(sprite.userData,model.resourceRadius(node))*v.screenYFactor)<1e-9,'2D art fits the selected physical radius');
  const mat=new T.Matrix4();card.getMatrixAt(0,mat);const pos=new T.Vector3(),q=new T.Quaternion(),size=new T.Vector3();mat.decompose(pos,q,size);
  assert.ok(Math.abs(size.x-(radiusGame*6*2*.92/18))<1e-6,'3D card fits the selected physical radius');assert.equal(model.resourceRadius(node),Number((radiusGame*6).toFixed(8)));cases++;
 }
}
fs.writeFileSync('tests/readability-v250.json',JSON.stringify({passed:true,cases,resourceArtworkFitsSelectedRadius:true},null,2));console.log({cases});
