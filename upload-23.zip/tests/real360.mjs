import assert from 'node:assert/strict';import fs from 'node:fs';import zlib from 'node:zlib';
import {MapModel,newPlan} from '../web/core/model.js';import {solve} from '../web/solver.js';
const report={passed:true,maps:[]};
for(const file of fs.readdirSync('assets/solver').filter(f=>f.endsWith('.gz'))){
 const d=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/solver/'+file)));d.landmarks=JSON.parse(fs.readFileSync('assets/landmarks/'+d.catalog.map+'.json'));const m=new MapModel(d),p=newPlan(d.catalog.map);let root=null;
 // Find a modest genuine open-ground leg, independently of old fixture radii.
 const [left,bottom,right,top]=d.catalog.bounds,startX=Math.floor((Math.max(0,left)+400)/18)*18+9,startY=Math.floor((Math.max(0,bottom)+400)/18)*18+9;
 for(let y=startY;y<Math.min(top-200,startY+4000)&&!root;y+=54)for(let x=startX;x<Math.min(right-200,startX+4000)&&!root;x+=54){const b={id:'root',kind:'fortress',allianceId:'a1',x,y},target={id:'goal',x:x+126,y};m.setPlan(p);if(m.staticError(b))continue;const zone=m.groundAccess.geographicalZone(x,y);if(!zone||m.groundAccess.geographicalZone(target.x,target.y)!==zone)continue;p.buildings=[b];m.setPlan(p);if(Array.from({length:7},(_,i)=>x+18+i*18).some(q=>m.groundAccess.geographicalZone(q,y)!==zone||m.staticError({kind:'flag',x:q,y,allianceId:'a1'})))continue;root=b;p.targets=[target];}
 assert.ok(root,d.catalog.map);const rows=[];
 for(const mode of ['balanced','crystal','build','war']){const r=solve(m,p,'a1',{budget:15,startId:'root',routeMode:mode,crystalExtra:0,maxMillis:2000});assert.equal(r.failed.length,0,d.catalog.map+' '+mode+' '+r.reason);const q=structuredClone(p);for(const b of r.buildings){m.setPlan(q);assert.equal(m.placementError(b),null);q.buildings.push(b);}m.setPlan(q);assert.ok(m.targetReached(p.targets[0],'a1'));rows.push({mode,flags:r.buildings.length,ms:r.elapsedMs});}
 report.maps.push({map:d.catalog.map,root,modes:rows});console.log(d.catalog.map,JSON.stringify(rows));
 if(d.catalog.map==='Sever_Map_G1_1_v2'){fs.mkdirSync('analysis/routing360',{recursive:true});fs.writeFileSync('analysis/routing360/browser-plan.json',JSON.stringify(p,null,2));}
}
fs.writeFileSync('analysis/routing360/real-maps.json',JSON.stringify(report,null,2));
