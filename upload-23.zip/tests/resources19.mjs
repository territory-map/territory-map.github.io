import assert from 'node:assert/strict';
import fs from 'node:fs';
import {resourceSymbolHeight,resourceCardScale} from '../web/core/resource-size.js';
import {newPlan,validatePlan,MapModel,G} from '../web/core/model.js';
const flag=G.buildingRadius({kind:'flag'}),fort=G.buildingRadius({kind:'subFortress'}),deposit=5.88,game=deposit/6;
const legacy=newPlan('test');legacy.version=3;legacy.settings.resourceRadius=.6;
assert.equal(validatePlan(legacy,'test').settings.resourceRadius,game);
legacy.settings.resourceRadius=2;assert.equal(validatePlan(legacy,'test').settings.resourceRadius,2);
legacy.version=4;legacy.settings.resourceRadius=.6;assert.equal(validatePlan(legacy,'test').settings.resourceRadius,.6);
const p=newPlan('test');assert.equal(p.settings.resourceRadius,game);
const d={catalog:{map:'test',nativeMapSize:600,bounds:[0,0,600,600],structureRules:{},buildings:{flag:{limit:500},fortress:{limit:5}}},sites:[],resources:['food','wood','stone','coin','crystal'].map((kind,i)=>({id:kind,kind,x:100+i*70,y:100})),definitions:[],instances:[]};
const m=new MapModel(d);m.setPlan(p);
for(const r of d.resources){assert.equal(m.resourceRadius(r),deposit);assert.match(m.staticError({kind:'flag',x:r.x+flag+deposit,y:100}),/Grundkreise/);assert.equal(m.staticError({kind:'flag',x:r.x+flag+deposit+.001,y:100}),null);assert.match(m.staticError({kind:'fortress',x:r.x+fort+deposit,y:100}),/Grundkreise/);}
const terrain=structuredClone(d);terrain.resources=[];const mask=new Uint8Array(601*601);for(let y=0;y<601;y++)mask[y*601+200]=255;terrain.terrain15={hatching:Buffer.from(mask).toString('base64'),hatchingWidth:601,hatchingHeight:601};const tm=new MapModel(terrain);
for(const [kind,radius]of [['flag',flag],['fortress',fort]]){assert.match(tm.staticError({kind,x:199.5-radius,y:100}),/Grundfläche/);assert.equal(tm.staticError({kind,x:199.5-radius-.01,y:100}),null);}
assert.equal(G.plannedBuildingCollision({kind:'flag',x:100,y:100},[{kind:'subFortress',x:100+flag+fort,y:100}]),true);
assert.equal(G.plannedBuildingCollision({kind:'flag',x:100,y:100},[{kind:'subFortress',x:100+flag+fort+.01,y:100}]),false);
let cases=0;for(const radius of [1.5,3.6,9,12,30])for(const aspect of [.7,1,1.3,2])for(const zoom of [.16,.5,1,2.5,8]){const b={left:.1,right:.9,anchor:.05,top:.95,aspect},h=resourceSymbolHeight(b,radius);assert.ok(Math.hypot((b.right-b.left)*aspect*h,(b.top-b.anchor)*h)<=radius*2);assert.ok(Math.abs(resourceCardScale(radius)*18/zoom-radius*2*.92/zoom)<1e-9);cases++;}
const report={passed:true,sizingCases:cases,kinds:5,oldDefaultMigrated:true,customRadiusPreserved:true,flagAndFortressTangencyBlocked:true,zoomIndependent:true,defaultRadiusGameUnits:game};fs.writeFileSync(new URL('./resources-v19.json',import.meta.url),JSON.stringify(report,null,2));console.log(report);
