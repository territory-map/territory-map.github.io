import fs from 'node:fs';import {spawnSync} from 'node:child_process';
const suites=JSON.parse(fs.readFileSync('package.json','utf8')).scripts.test.split(' && ').map(s=>s.replace(/^node /,''));
const results=[];fs.writeFileSync('tests/run-v210.log','');
for(const suite of suites){const p=spawnSync(process.execPath,[suite],{encoding:'utf8',timeout:300000,maxBuffer:8*1024*1024});fs.appendFileSync('tests/run-v210.log',suite+'\n'+p.stdout+p.stderr+'\n');results.push({suite,exitCode:p.status});console.log(suite,p.status);if(p.status!==0){console.log(p.stdout,p.stderr);break;}}
const report={passed:results.length===suites.length&&results.every(x=>x.exitCode===0),results};fs.writeFileSync('tests/suites-v210.json',JSON.stringify(report,null,2));if(!report.passed)process.exitCode=1;
