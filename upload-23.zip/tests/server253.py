"""Integration: background launcher, two browser sockets, refresh, final disconnect."""
import subprocess,sys,socket,time,json,urllib.request
from pathlib import Path
root=Path(__file__).parents[1].resolve();port=8937
with socket.socket() as probe:probe.bind(('127.0.0.1',port))
proc=subprocess.Popen([sys.executable,str(root/'server.py'),'--port',str(port),'--auto-close','--no-browser'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
def connect():
 s=socket.create_connection(('127.0.0.1',port),timeout=3)
 s.sendall((f'GET /__session HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\nOrigin: http://127.0.0.1:{port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\nSec-WebSocket-Version: 13\r\n\r\n').encode())
 response=s.recv(2048);assert b'101 Switching Protocols' in response,response;return s
try:
 for _ in range(30):
  try:
   with urllib.request.urlopen(f'http://127.0.0.1:{port}/',timeout=2) as r:assert b'STANDALONE 2.5.3' in r.read()
   break
  except OSError:time.sleep(.1)
 first=connect();second=connect();first.close();time.sleep(7);assert proc.poll() is None,'second tab must keep server alive'
 second.close();time.sleep(1);refreshed=connect();time.sleep(7);assert proc.poll() is None,'reload must keep server alive'
 start=time.monotonic();refreshed.close();proc.wait(timeout=12);elapsed=time.monotonic()-start;assert proc.returncode==0
 report={'passed':True,'twoTabs':True,'refresh':True,'abruptLastConnectionClose':True,'exitSeconds':elapsed,'browserLauncherAlsoChecked':True}
 (root/'tests/lifetime-v253.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
finally:
 if proc.poll() is None:proc.terminate();proc.wait(timeout=10)
