import fs from 'node:fs';import zlib from 'node:zlib';import assert from 'node:assert/strict';
import {MapModel,newPlan} from '../web/core/model.js';import {solve} from '../web/solver.js';
const d=JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL('../assets/solver/LostLand_Map_18_v2.json.gz',import.meta.url)))),m=new MapModel(d),p=newPlan(d.catalog.map);let root;
for(let radius=0;radius<150&&!root;radius+=6)for(const [dx,dy]of [[radius,0],[-radius,0],[0,radius],[0,-radius]]){const b={id:'root',kind:'fortress',allianceId:'a1',x:1242+dx,y:2532+dy};if(!m.staticError(b))root=b;}
assert.ok(root);p.buildings=[root];p.settings.useCrusaderStructures=true;p.settings.crystals=false;p.settings.crystalExtra=30;
p.targets=['reference:shifting:outer-pass-58','reference:shifting:outer-pass-26','bastions:11011'].map(siteId=>{const s=m.sites.find(s=>s.siteId===siteId);return {id:siteId,siteId,x:s.x,y:s.y};});
fs.writeFileSync(new URL('./shifting-input201.json',import.meta.url),JSON.stringify(p));const start=performance.now();
const result=solve(m,p,'a1',{startId:'root',budget:150,crystals:false,crystalExtra:30,maxVisits:30000,maxNodes:20000},v=>console.log(v));
const applied=structuredClone(p);for(const b of result.buildings){m.setPlan(applied);assert.equal(m.placementError(b),null);applied.buildings.push(b);}m.setPlan(applied);
const report={passed:true,ms:performance.now()-start,root,flags:result.buildings.length,failed:result.failed,reason:result.reason,memoryMB:process.memoryUsage().heapUsed/1048576};fs.writeFileSync(new URL('./shifting-v201.json',import.meta.url),JSON.stringify(report,null,2));console.log(report);
