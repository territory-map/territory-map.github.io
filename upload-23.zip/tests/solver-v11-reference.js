import {MapModel,G,legacy,clone} from '../web/core/model.js?v=20260930.2';
class Heap{
 constructor(){this.a=[];}push(v){const a=this.a;a.push(v);let i=a.length-1;while(i){let p=(i-1)>>1;if(a[p].f<=v.f)break;a[i]=a[p];i=p;}a[i]=v;}pop(){const a=this.a,r=a[0],v=a.pop();if(a.length){let i=0;while(i*2+1<a.length){let j=i*2+1;if(j+1<a.length&&a[j+1].f<a[j].f)j++;if(a[j].f>=v.f)break;a[i]=a[j];i=j;}a[i]=v;}return r;}get length(){return this.a.length;}}
export function solve(model,original,allianceId,{budget=150,crystals=true,maxVisits=180000}={},progress=()=>{}){
 const plan=clone(original),initial=plan.buildings.length,failed=[];model.setPlan(plan);
 if(!plan.buildings.some(b=>b.allianceId===allianceId))return {buildings:[],failed:plan.targets,reason:'Zuerst eine Festung für diese Allianz setzen.'};
 const todo=plan.targets.filter(t=>!model.targetReached(t,allianceId));const free=new Map();let visits=0;
 const targetsPoint=t=>t.siteId?model.sites.find(s=>s.siteId===t.siteId):t;
 const moves=[];for(let x=-3;x<=3;x++)for(let y=-3;y<=3;y++)if((x||y)&&!(Math.abs(x)===3&&Math.abs(y)===3))moves.push([x,y]);
 const crystalCells=new Set(model.data.resources.filter(r=>r.kind==='crystal').map(r=>Math.floor(r.x/18)+':'+Math.floor(r.y/18)));
 const isFree=(x,y)=>{const key=x+':'+y;if(!free.has(key))free.set(key,!model.staticError({kind:'flag',x:x*18+9,y:y*18+9,allianceId},plan.settings.strict));return free.get(key);};
 while(todo.length&&plan.buildings.length-initial<budget){
  todo.sort((a,b)=>{const dist=t=>{const p=targetsPoint(t);return p?Math.min(...plan.buildings.filter(b=>b.allianceId===allianceId).map(b=>Math.hypot(b.x-p.x,b.y-p.y))):Infinity;};return dist(a)-dist(b);});
  const target=todo.shift(),tp=targetsPoint(target);if(!tp){failed.push(target);continue;}if(model.targetReached(target,allianceId))continue;
  const tx=Math.floor(tp.x/18),ty=Math.floor(tp.y/18),radius=target.siteId?(tp.territoryRadiusInCells||2)+2:1;
  const heuristic=(x,y)=>Math.max(0,Math.ceil((Math.max(Math.abs(x-tx),Math.abs(y-ty))-radius)/3));
  const heap=new Heap(),best=new Map(),ownership=model.state.ownership;
  function enqueue(x,y,g,parent){const k=x+':'+y;if(best.has(k)&&best.get(k)<=g)return;if(!isFree(x,y))return;const candidate={kind:'flag',x:x*18+9,y:y*18+9,allianceId};if(!G.hasRequiredTerritoryAvailability(candidate,ownership)||G.plannedBuildingCollision(candidate,model.buildings))return;
   let reward=0;if(crystals)for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++)if(crystalCells.has((x+dx)+':'+(y+dy)))reward++;
   best.set(k,g);heap.push({x,y,g,parent,f:(g+heuristic(x,y))*1000-reward*10+heuristic(x,y)*.001});
  }
  // Seed the frontier from actual owned cells, including captured structures.
  const seeds=new Set();for(const cell of ownership.values())if(cell.allianceId===allianceId)for(let dx=-2;dx<=2;dx++)for(let dy=-2;dy<=2;dy++)if(!(Math.abs(dx)===2&&Math.abs(dy)===2)){const x=cell.column+dx,y=cell.row+dy,k=x+':'+y;if(!seeds.has(k)){seeds.add(k);enqueue(x,y,1,null);}}
  let found=null,local=0;
  while(heap.length&&local<maxVisits){const n=heap.pop();if(best.get(n.x+':'+n.y)!==n.g)continue;local++;visits++;
   if(n.g+plan.buildings.length-initial>budget)continue;
   if(heuristic(n.x,n.y)===0){const path=[];for(let q=n;q;q=q.parent)path.push(q);path.reverse();const before=plan.buildings.length;let good=true;
    for(const q of path){const b={id:'solve-'+before+'-'+q.x+'-'+q.y,kind:'flag',x:q.x*18+9,y:q.y*18+9,allianceId};if(model.placementError(b)){good=false;break;}plan.buildings.push(b);model.setPlan(plan);}
    if(good&&model.targetReached(target,allianceId)){found=path;break;}
    plan.buildings.length=before;model.setPlan(plan);
   }
   for(const [dx,dy]of moves)enqueue(n.x+dx,n.y+dy,n.g+1,n);
   if(local%5000===0)progress({visits,added:plan.buildings.length-initial,remaining:todo.length+1});
  }
  if(!found)failed.push(target);
  progress({visits,added:plan.buildings.length-initial,remaining:todo.length});
 }
 failed.push(...todo);return {buildings:plan.buildings.slice(initial),failed,visits,reason:failed.length?'Nicht alle Ziele innerhalb des Budgets bzw. Suchlimits erreichbar.':'Alle markierten Ziele verbunden.'};
}

