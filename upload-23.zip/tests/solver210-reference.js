import {buildTerritoryState} from '../web/core/territory17.js';
import {MapModel,G,legacy,clone} from '../web/core/model.js?v=20261001.210';
class Heap{
 constructor(){this.a=[];}push(v){const a=this.a;a.push(v);let i=a.length-1;while(i){let p=(i-1)>>1;if(a[p].f<=v.f)break;a[i]=a[p];i=p;}a[i]=v;}pop(){const a=this.a,r=a[0],v=a.pop();if(a.length){let i=0;while(i*2+1<a.length){let j=i*2+1;if(j+1<a.length&&a[j+1].f<a[j].f)j++;if(a[j].f>=v.f)break;a[i]=a[j];i=j;}a[i]=v;}return r;}compact(keep){const retained=this.a.filter(keep);this.a=[];for(const node of retained)this.push(node);}get length(){return this.a.length;}}
function originOwnership(model,baseLength,allianceId){
 baseLength=model.plan.routingBaseLength??baseLength;const startId=model.plan.routingStartId;if(!startId)return model.territoryFor(allianceId);
 if(model.originCache?.epoch===model.planEpoch&&model.originCache.allianceId===allianceId)return model.originCache.ownership;
 const seed=model.plan.buildings.find(b=>b.id===startId),buildings=[seed,...model.plan.buildings.slice(baseLength)].filter(Boolean).map(legacy);
 const sites=model.accessSites.map(s=>s.kind==='pass'?{...s,claimable:model.accessFor(allianceId).captured.has(s.siteId)}:s);
 const ownership=buildTerritoryState(buildings,sites,s=>s.kind==='pass'?model.accessFor(allianceId).captured.has(s.siteId):model.state.structureOwners.get(s.id)===allianceId).ownership;model.originCache={epoch:model.planEpoch,allianceId,ownership};return ownership;
}
function route(model,original,allianceId,{budget=150,crystals=true,maxVisits=90000,maxNodes=45000,order=0,deadline=Infinity}={},progress=()=>{}){
 const plan=clone(original),initial=plan.buildings.length,failed=[],requiredPasses=new Map(),limits={hit:false,peakNodes:0,peakFrontier:0};model.setPlan(plan);
 if(!plan.buildings.some(b=>b.allianceId===allianceId))return {buildings:[],failed:plan.targets,reason:'Zuerst eine Festung für diese Allianz setzen.'};
 if(plan.buildings.some(b=>b.allianceId===allianceId&&(model.staticError(b,plan.settings.strict))))return {buildings:[],failed:plan.targets,reason:'Bestehende Allianzbauten verletzen die Bau- oder Zonenregeln. Diese Positionen zuerst korrigieren.'};
 const todo=plan.targets.filter(t=>!model.targetReached(t,allianceId));const free=new Map();let visits=0;
 const targetsPoint=t=>t.siteId?model.sites.find(s=>s.siteId===t.siteId):t;
 const moves=[];for(let x=-3;x<=3;x++)for(let y=-3;y<=3;y++)if((x||y)&&!(Math.abs(x)===3&&Math.abs(y)===3))moves.push([x,y]);
 const crystalNodes=model.data.resources.filter(r=>r.kind==='crystal'),crystalIndex=new Map();
 for(let i=0;i<crystalNodes.length;i++){const r=crystalNodes[i],key=Math.floor(r.x/64)+':'+Math.floor(r.y/64);if(!crystalIndex.has(key))crystalIndex.set(key,[]);crystalIndex.get(key).push({r,i});}
 const crystalReach=27+Math.max(0,...crystalNodes.map(r=>model.resourceRadius(r)));
 let coveredCrystals=new Set();
 const position=(x,y)=>{const key=x+':'+y;if(!free.has(key)){let found=null;for(const [dx,dy]of [[0,0],[-6,0],[6,0],[0,-6],[0,6],[-6,-6],[6,6],[-6,6],[6,-6]]){const b={kind:'flag',x:x*18+9+dx,y:y*18+9+dy,allianceId};if(!model.staticError(b,plan.settings.strict)&&!G.plannedBuildingCollision(b,model.buildings)){found=b;break;}}free.set(key,found);}return free.get(key);};
 const masks=new Map();
 const cellMask=(x,y)=>{const key=x+':'+y;if(!masks.has(key)){let mask=0n;const cells=G.territoryCells({kind:'flag',x:x*18+9,y:y*18+9}),added=new Set(cells.map(c=>c.column+':'+c.row)),ownership={get(k){return model.state.ownership.get(k)||(added.has(k)?{allianceId}:undefined);}};const cx=x*18+9,cy=y*18+9;for(let bx=Math.floor((cx-crystalReach)/64);bx<=Math.floor((cx+crystalReach)/64);bx++)for(let by=Math.floor((cy-crystalReach)/64);by<=Math.floor((cy+crystalReach)/64);by++)for(const {r,i} of crystalIndex.get(bx+':'+by)||[])if(!coveredCrystals.has(i)&&Math.abs(r.x-cx)<27+model.resourceRadius(r)&&Math.abs(r.y-cy)<27+model.resourceRadius(r)&&model.resourceCovered(r,allianceId,ownership))mask|=1n<<BigInt(i);masks.set(key,mask);}return masks.get(key);};
 const bits=n=>{let c=0;while(n){n&=n-1n;c++;}return c;};
 while(todo.length&&plan.buildings.length-initial<budget){
  if(performance.now()>=deadline){limits.hit=true;break;}
  todo.sort((a,b)=>{const dist=t=>{const p=targetsPoint(t);return p?Math.min(...plan.buildings.filter(b=>b.allianceId===allianceId).map(b=>Math.hypot(b.x-p.x,b.y-p.y))):Infinity;};return order===1?dist(b)-dist(a):order===2?((a.id||'').localeCompare(b.id||'')):dist(a)-dist(b);});
  let target=todo.shift(),requested=target,tp=targetsPoint(target);if(!tp){failed.push(target);continue;}if(model.targetReached(target,allianceId))continue;
  const gate=model.routePrerequisite(tp,allianceId)||(tp.kind==='pass'&&!model.accessFor(allianceId).captured.has(tp.siteId)?tp:null);
  if(gate){requiredPasses.set(gate.siteId,gate);target={id:'approach-'+gate.siteId,siteId:gate.siteId,x:gate.x,y:gate.y,approach:true};tp=gate;if(model.targetReached(target,allianceId))continue;}
  const tx=Math.floor(tp.x/18),ty=Math.floor(tp.y/18),radius=target.siteId?(tp.territoryRadiusInCells||2)+2:1;
  const heuristic=(x,y)=>Math.max(0,Math.ceil((Math.max(Math.abs(x-tx),Math.abs(y-ty))-radius)/3));
  coveredCrystals=new Set(crystalNodes.flatMap((r,i)=>model.resourceCovered(r,allianceId)?[i]:[]));
  const heap=new Heap(),best=new Map(),ownership=model.territoryFor(allianceId),frontier=originOwnership(model,initial,allianceId);
  function enqueue(x,y,g,parent){const k=x+':'+y;if(!best.has(k)&&best.size>=maxNodes){limits.hit=true;return;}const candidate=position(x,y);if(!candidate||model.zoneError(candidate))return;
   if(!G.hasRequiredTerritoryAvailability(candidate,ownership)||G.plannedBuildingCollision(candidate,model.buildings))return;
   // A visually touching square can lose its connecting cells at terrain or
   // a closed zone. Reject that edge during search, not only after reconstructing
   // the cheapest path (which would otherwise hide valid detours to that cell).
   if(parent){const dx=Math.abs(x-parent.x),dy=Math.abs(y-parent.y);if(dx>3||dy>3||(dx===3&&dy===3))return;}
   else if(!G.isConnectedToAlliance(candidate,frontier))return;
   const mask=crystals?((parent?.mask||0n)|cellMask(x,y)):0n,reward=crystals?bits(mask):0,prev=best.get(k);
   if(prev&&(prev.g<g||(prev.g===g&&prev.reward>=reward)))return;
   if(!prev&&best.size>=maxNodes){limits.hit=true;return;}
   const node={x,y,g,parent,mask,reward,length:(parent?.length||0)+(parent?Math.hypot(x-parent.x,y-parent.y):0),f:(g+heuristic(x,y))*1000-Math.min(reward,100)*.5+Math.hypot(x-tx,y-ty)*.01+(parent?.length||0)*.001};best.set(k,node);heap.push(node);if(heap.length>maxNodes*2)heap.compact(q=>best.get(q.x+':'+q.y)===q);limits.peakNodes=Math.max(limits.peakNodes,best.size);limits.peakFrontier=Math.max(limits.peakFrontier,heap.length);
  }
  // Seed the frontier from actual owned cells, including captured structures.
  const seeds=new Set();for(const cell of frontier.values())if(cell.allianceId===allianceId)for(let dx=-2;dx<=2;dx++)for(let dy=-2;dy<=2;dy++)if(!(Math.abs(dx)===2&&Math.abs(dy)===2)){const x=cell.column+dx,y=cell.row+dy,k=x+':'+y;if(!seeds.has(k)){seeds.add(k);enqueue(x,y,1,null);}}
  let found=null,foundFlags=null,foundCost=Infinity,foundGems=-1,foundLength=Infinity,local=0,afterFound=0,goalChecks=0;
  while(heap.length&&local<maxVisits){if((local%64)===0&&performance.now()>=deadline){limits.hit=true;break;}const n=heap.pop();if(best.get(n.x+':'+n.y)!==n)continue;if(n.g+heuristic(n.x,n.y)>foundCost)break;if(foundFlags&&++afterFound>6000)break;local++;visits++;
   if(n.g+plan.buildings.length-initial>budget)continue;
   if(heuristic(n.x,n.y)===0){if(++goalChecks>1200){limits.hit=true;break;}if(foundFlags&&goalChecks>120)break;const path=[];for(let q=n;q;q=q.parent)path.push(q);path.reverse();const before=plan.buildings.length;let good=true;
    for(const q of path){if(performance.now()>=deadline){limits.hit=true;good=false;break;}const b={id:'solve-'+before+'-'+q.x+'-'+q.y,...position(q.x,q.y)};if(model.placementError(b)){good=false;break;}plan.buildings.push(b);model.setPlan(plan);}
    if(good&&model.targetReached(target,allianceId)){
     const gems=model.covered(allianceId).crystal||0;
     if(n.g<foundCost||gems>foundGems||(gems===foundGems&&n.length<foundLength)){found=path;foundFlags=plan.buildings.slice(before);foundCost=n.g;foundGems=gems;foundLength=n.length;}
     plan.buildings.length=before;model.setPlan(plan);if(!crystals)break;continue;
    }
    plan.buildings.length=before;model.setPlan(plan);
   }
   for(const [dx,dy]of moves)enqueue(n.x+dx,n.y+dy,n.g+1,n);
   if(local%1000===0)progress({visits,added:plan.buildings.length-initial,remaining:todo.length+1});
  }
  if(local>=maxVisits)limits.hit=true;
  if(foundFlags){plan.buildings.push(...foundFlags);model.setPlan(plan);if(gate&&!model.targetReached(requested,allianceId))todo.unshift(requested);}else failed.push(requested);free.clear();masks.clear();
  progress({visits,added:plan.buildings.length-initial,remaining:todo.length});
 }
 failed.push(...todo);return {buildings:plan.buildings.slice(initial),failed,requiredPasses:[...requiredPasses.keys()].filter(siteId=>!model.accessFor(allianceId).captured.has(siteId)),visits,search:limits,reason:failed.length?'Nicht alle Ziele innerhalb des Budgets bzw. Suchlimits erreichbar.':'Alle markierten Ziele verbunden.'};
}

// Validate and rebuild from the root each time: pruning cannot break a later branch.
function validPlan(model,base,flags,allianceId,targets,minCrystals=0){
 const p=clone(base),pending=[...flags];model.setPlan(p);let changed=true;
 while(pending.length&&changed){changed=false;for(let i=0;i<pending.length;i++){if(!model.placementError(pending[i])&&G.isConnectedToAlliance(legacy(pending[i]),originOwnership(model,base.buildings.length,allianceId))){p.buildings.push(pending.splice(i--,1)[0]);model.setPlan(p);changed=true;}}}
 if(pending.length||targets.some(t=>!model.targetReached(t,allianceId))||(model.covered(allianceId).crystal||0)<minCrystals)return null;
 return p;
}
export function solve(model,original,allianceId,{budget=150,crystals=true,crystalExtra=5,maxVisits=90000,maxNodes=45000,rootId=null,startId=rootId,maxMillis=20000}={},progress=()=>{}){
 const unscopedOriginal=original,deadline=performance.now()+Math.max(100,Math.min(120000,maxMillis));
 try{
  if(startId){model.setPlan(original);const start=original.buildings.find(b=>b.id===startId&&b.allianceId===allianceId&&(b.kind==='flag'||G.buildingRules[legacy(b).kind]?.root));if(!start)throw Error('Der gewählte Startpunkt ist nicht mehr vorhanden.');if(start.kind==='flag'&&!model.isBuildingActive(start))throw Error('Die gewählte Flagge ist inaktiv. Zuerst wieder mit einer Festung verbinden.');original=clone(original);original.routingStartId=startId;original.routingBaseLength=original.buildings.length;if(G.buildingRules[legacy(start).kind]?.root)original.routingRootId=startId;}
  const options={budget,crystals,maxVisits,maxNodes,deadline};let best=null;
  // Compare different goal orders; shared branches may save whole flags.
  for(let order=0;order<(original.targets.length>1?3:1);order++){if(best&&performance.now()>=deadline)break;
   const r=route(model,original,allianceId,{...options,order},progress),p=clone(original);p.buildings.push(...r.buildings);model.setPlan(p);r.gems=model.covered(allianceId).crystal||0;
   if(!best||r.failed.length<best.failed.length||(r.failed.length===best.failed.length&&(r.buildings.length<best.buildings.length||(r.buildings.length===best.buildings.length&&crystals&&r.gems>best.gems))))best=r;
  }
  const succeeded=[...original.targets.filter(t=>!best.failed.some(f=>f.id===t.id)),...(best.requiredPasses||[]).map(siteId=>({siteId,approach:true}))].filter(t=>{const p=clone(original);p.buildings.push(...best.buildings);model.setPlan(p);return model.targetReached(t,allianceId);});
  let flags=best.buildings;
  // Remove redundant flags, preserving every reached target and crystal gain.
  for(let i=flags.length-1;i>=0;i--){if(performance.now()>=deadline)break;const candidate=flags.filter((_,j)=>j!==i);if(validPlan(model,original,candidate,allianceId,succeeded,crystals?best.gems:0))flags=candidate;}
  let plan=validPlan(model,original,flags,allianceId,succeeded,crystals?best.gems:0)||clone(original);model.setPlan(plan);
  const routeFlags=plan.buildings.length-original.buildings.length;let extra=0;
  // Small explicit allowance: add only a single connected flag that captures a new
  // crystal. No long speculative detours, and never more than the overall budget.
  if(crystals&&best.failed.length===0)while(performance.now()<deadline&&extra<crystalExtra&&plan.buildings.length-original.buildings.length<budget){
   const owned=model.covered(allianceId).crystal||0,candidates=new Map();
   for(const r of model.data.resources)if(r.kind==='crystal'&&!model.resourceCovered(r,allianceId)){
    const cx=Math.floor(r.x/18),cy=Math.floor(r.y/18);for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++){const x=cx+dx,y=cy+dy,key=x+':'+y;if(!candidates.has(key))candidates.set(key,{id:'crystal-'+key,kind:'flag',x:x*18+9,y:y*18+9,allianceId});}
   }
   let winner=null,gain=0;
   for(const b of candidates.values()){if(performance.now()>=deadline)break;
    if(!G.isConnectedToAlliance(b,originOwnership(model,original.buildings.length,allianceId)))continue;if(model.placementError(b))continue;
    const added=new Set(G.territoryCells(b).map(c=>c.column+':'+c.row)),ownership={get(k){return model.state.ownership.get(k)||(added.has(k)?{allianceId}:undefined);}};let captured=0;for(const r of model.data.resources)if(r.kind==='crystal'&&!model.resourceCovered(r,allianceId)&&model.resourceCovered(r,allianceId,ownership))captured++;
    if(captured>gain){gain=captured;winner=b;}
   }
   if(!winner){
    const remaining=Math.min(crystalExtra-extra,budget-(plan.buildings.length-original.buildings.length));if(remaining<2)break;
    const pending=model.data.resources.filter(r=>r.kind==='crystal'&&!model.resourceCovered(r,allianceId)).map(r=>({r,d:Math.min(...plan.buildings.filter(b=>b.allianceId===allianceId).map(b=>Math.hypot(b.x-r.x,b.y-r.y)))})).filter(q=>q.d<(remaining+2)*54).sort((a,b)=>a.d-b.d).slice(0,8);
    let chain=null,ratio=0;for(const {r}of pending){if(performance.now()>=deadline)break;const request=clone(plan);request.targets=[{id:'crystal-target',resourceId:r.id,x:r.x,y:r.y}];const result=route(model,request,allianceId,{budget:remaining,crystals:false,maxVisits:3000,deadline});const candidate=clone(plan);candidate.buildings.push(...result.buildings);model.setPlan(candidate);const increase=(model.covered(allianceId).crystal||0)-owned;model.setPlan(plan);if(!result.failed.length&&increase>0&&increase/result.buildings.length>ratio){chain=result.buildings;ratio=increase/result.buildings.length;}}
    if(!chain)break;plan.buildings.push(...chain);extra+=chain.length;model.setPlan(plan);
   }else{plan.buildings.push(winner);model.setPlan(plan);extra++;}progress({visits:best.visits,added:plan.buildings.length-original.buildings.length,remaining:0});
  }
  flags=plan.buildings.slice(original.buildings.length);const gems=model.covered(allianceId).crystal||0;
  // Final sequential validation is also performed when accepting the proposal.
  return {...best,buildings:flags,gems,routeFlags,crystalFlags:extra,rootId,startId,reachedTargetIds:original.targets.filter(t=>model.targetReached(t,allianceId)).map(t=>t.id),reason:(best.search?.hit?'Suchgrenze erreicht; gültige Teilroute wird angeboten. ': '')+(best.requiredPasses?.length?'Nicht alle Verbindungspässe innerhalb des Budgets bzw. Suchlimits erreicht. ': '')+(best.reason||'Nicht alle Ziele innerhalb des Budgets bzw. Suchlimits erreichbar.')+(crystals?' '+gems+' Kristallvorkommen erfasst; '+extra+' Zusatzflaggen.':'')};
 }finally{model.setPlan(unscopedOriginal);}
}
