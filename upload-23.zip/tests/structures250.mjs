import assert from 'node:assert/strict';import fs from 'node:fs';import zlib from 'node:zlib';import vm from 'node:vm';import crypto from 'node:crypto';
vm.runInThisContext(fs.readFileSync('web/vendor/three.min.js','utf8'));
const T=globalThis.THREE,{View}=await import('../web/view.js'),{structures}=await import('../web/core/model.js'),{siteIcon}=await import('../web/sites18.js'),{siteDisplayPoint}=await import('../web/site-display201.js'),{solidArtBounds}=await import('../web/site-visual220.js');
const art=JSON.parse(fs.readFileSync('tests/site-art250.json'));
for(const [file,a]of Object.entries(art)){assert.equal(crypto.createHash('sha256').update(fs.readFileSync('assets/sprites/'+file)).digest('hex'),a.sha256);a.solidBounds=solidArtBounds(Buffer.from(a.rgba,'base64'),a.width,a.height);}
const maps=[];let cases=0;
for(const file of fs.readdirSync('assets/solver').filter(f=>f.endsWith('.gz'))){
 const d=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/solver/'+file))),sites=structures(d),original=JSON.stringify(d.sites);
 for(const s of sites){const key=siteIcon(s,d.catalog),a=art[key];assert.ok(a?.solidBounds,`${d.catalog.map} missing native art ${key}`);const p=siteDisplayPoint(s);
  assert.equal(p.x,Math.floor(s.x/18)*18+9);assert.equal(p.y,Math.floor(s.y/18)*18+9);
  for(const mode of ['2d','3d'])for(const azimuth of [0,.6]){
   const v=Object.assign(Object.create(View.prototype),{camera:new T.OrthographicCamera(-1,1,1,-1,.1,60000),scene:new T.Scene(),flags:{},mode,scale:.8,w:1280,h:720,tilt:Math.PI/4,azimuth,center:new T.Vector3(p.x+120,0,-p.y+90)});
   const o=new T.Sprite(new T.SpriteMaterial());o.position.set(p.x,0,-p.y);o.userData={site:s,size:s.kind==='pass'?26:30,aspect:a.width/a.height,...a.solidBounds,solidBounds:a.solidBounds};o.material.rotation=-(s.rotation-(d.passRotations?.[s.siteId]??0)||0);v.scene.add(o);v.symbols=[o];v.updateCamera();v.updateSprites();
   const right=new T.Vector3().setFromMatrixColumn(v.camera.matrixWorld,0),up=new T.Vector3().setFromMatrixColumn(v.camera.matrixWorld,1),visible=[],body=a.solidBounds,angle=o.material.rotation,c=Math.cos(angle),sn=Math.sin(angle);
   for(const x of [body.left,body.right])for(const y of [body.anchor,body.top]){const dx=(x-o.center.x)*o.scale.x,dy=(y-o.center.y)*o.scale.y;visible.push(o.position.clone().addScaledVector(right,c*dx-sn*dy).addScaledVector(up,sn*dx+c*dy).project(v.camera));}
   const half=(s.territoryRadiusInCells*2+1)*9,square=[];for(const x of [-half,half])for(const y of [-half,half])square.push(new T.Vector3(p.x+x,.8,-p.y-y).project(v.camera));
   for(const axis of ['x','y']){const mid=points=>(Math.min(...points.map(p=>p[axis]))+Math.max(...points.map(p=>p[axis])))/2;assert.ok(Math.abs(mid(visible)-mid(square))<1e-9,`${d.catalog.map}/${s.siteId}/${mode}: visible art not centred`);}cases++;
  }
 }
 assert.equal(JSON.stringify(d.sites),original);maps.push({map:d.catalog.map,sites:sites.length,kinds:[...new Set(sites.map(s=>s.kind))],sourceTypesPreserved:true});
}
assert.equal(maps.length,21);fs.writeFileSync('tests/structures-v250.json',JSON.stringify({passed:true,projectionCases:cases,totalStructures:maps.reduce((n,m)=>n+m.sites,0),maps},null,2));console.log({cases,maps:maps.length});
