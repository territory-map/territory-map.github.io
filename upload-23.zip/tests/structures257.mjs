import assert from 'node:assert/strict';
import fs from 'node:fs';
import zlib from 'node:zlib';
import {MapModel,newPlan,structures,isCrusaderSite,G} from '../web/core/model.js';
import {solve} from '../web/solver.js';

// Audit every original site with its resolved capture rule, without relying on
// translated display names. Export the inventory to make the setting reviewable.
const inventory=[];
for(const file of fs.readdirSync('assets/solver').filter(f=>f.endsWith('.gz'))){
 const data=JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/solver/'+file)));
 const sites=structures(data),plan=newPlan(data.catalog.map),model=new MapModel(data);
 for(const enabled of [false,true]){
  plan.settings.useCrusaderStructures=enabled;model.setPlan(plan);
  for(const s of model.accessSites){
   const excluded=['pass','bastion','ancient-battlefield'].includes(s.kind)||!s.claimable;
   assert.equal(s.conductsTerritory,enabled||excluded,`${file}: ${s.label} / ${enabled}`);
  }
 }
 const unique=new Map(sites.map(s=>[s.strongholdType+'|'+s.kind+'|'+s.label,{type:s.strongholdType,kind:s.kind,label:s.label,claimable:s.claimable,controlled:isCrusaderSite(s)}]));
 inventory.push({map:data.catalog.map,sites:sites.length,controlled:sites.filter(isCrusaderSite).length,variants:[...unique.values()]});
}
assert.equal(inventory.length,21);

const outcomes=[];
for(const [type,label,kind]of [[29,'Crusader Camp','holy-site'],[30,'Ruined Crusader Fortress','holy-site'],[31,'Hieron of Steel','holy-site'],[33,'Castrum Tempestatis','holy-site'],[33,'Hieron','holy-site'],[82,'Castrum Victoris','holy-site'],[94,'Seth Hieron','holy-site'],[97,'Horus Hieron','holy-site'],[35,'Monastery of the Holy Sword','holy-site'],[38,'Troy','citadel'],[100,'Orléans Guildhall','holy-site'],[126,'Olympian Teleporter (Hades)','duel-tower'],[999,'Future map sanctuary','holy-site']]){
 const rule={territoryRadiusInCells:2,claimable:true,collision:{shape:'territory-square',radiusInCells:2}};
 const data={catalog:{map:'test257',nativeMapSize:1200,bounds:[0,0,1200,1200],structureRules:{[type]:rule},buildings:{flag:{limit:500},fortress:{limit:2}}},sites:[{id:'bridge',kind,strongholdType:type,label,x:243,y:207}],definitions:[],instances:[],resources:[]};
 const counts=[];
 for(const enabled of [false,true]){
  const p=newPlan('test257');p.settings.useCrusaderStructures=enabled;p.buildings=[{id:'root',kind:'fortress',allianceId:'a1',x:99,y:207}];p.targets=[{id:'goal',x:441,y:207}];
  const m=new MapModel(data),r=solve(m,p,'a1',{budget:20,crystals:false,startId:'root',maxMillis:2500});
  assert.equal(r.failed.length,0,label+': route must reach the other side');
  assert.equal(r.search.portalEdges>0,enabled,label+': disabled sites cannot be portal shortcuts');
  const applied=structuredClone(p);
  for(const b of r.buildings){m.setPlan(applied);assert.equal(m.placementError(b),null);applied.buildings.push(b);}
  m.setPlan(applied);assert.ok(m.targetReached(p.targets[0],'a1'));assert.ok(r.buildings.every(b=>m.isBuildingActive(b)));
  assert.equal(m.state.ownership.has('13:11'),enabled,label+': display colour is not usable territory when off');
  counts.push(r.buildings.length);
  // A fortress alone may display a claimed structure, but an OFF target needs
  // contact by an active flag. A flag connected through the far side is inactive.
  const touching=structuredClone(p);touching.targets=[{id:'site-goal',siteId:'bridge',x:243,y:207}];touching.buildings[0].x=171;m.setPlan(touching);
  assert.equal(m.targetReached(touching.targets[0],'a1'),enabled);
  touching.buildings.push({id:'far',kind:'flag',allianceId:'a1',x:315,y:207});m.setPlan(touching);assert.equal(m.isBuildingActive(touching.buildings[1]),enabled);
  touching.buildings.push({id:'near',kind:'flag',allianceId:'a1',x:189,y:135});m.setPlan(touching);assert.ok(m.targetReached(touching.targets[0],'a1'));
 }
 assert.ok(counts[1]<counts[0],label+': off requires a genuine detour');outcomes.push({type,label,offFlags:counts[0],onFlags:counts[1]});
}
for(const kind of ['pass','bastion','ancient-battlefield'])assert.equal(isCrusaderSite({kind,label:'Hieron',claimable:true}),false);
for(const label of ['Ancient Ruins','Altar of Darkness','Altar der Dunkelheit'])assert.equal(isCrusaderSite({kind:'holy-site',label,claimable:true}),false);
fs.mkdirSync('analysis/solver257',{recursive:true});fs.writeFileSync('analysis/solver257/structure-rules.json',JSON.stringify({passed:true,inventory,outcomes},null,2));
console.log('2.5.7: all 21 map inventories and 13 route/detour/target variants passed');
