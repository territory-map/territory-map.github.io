import fs from 'node:fs';import zlib from 'node:zlib';import vm from 'node:vm';import assert from 'node:assert/strict';
vm.runInThisContext(fs.readFileSync(new URL('../web/vendor/three.min.js',import.meta.url),'utf8'));
const {ridgeGeometry,snowGeometry}=await import('../web/terrain16.js');const report=[];
for(const file of fs.readdirSync(new URL('../assets/data/',import.meta.url)).filter(f=>f.endsWith('.gz'))){
 const d=JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL('../assets/data/'+file,import.meta.url)))),t=d.terrain15,b=d.catalog.bounds,mask=Buffer.from(t.hatching,'base64');
 const g=ridgeGeometry(d.terrain16,t,b),snow=snowGeometry(d.terrain16);
 const rawBytes=Buffer.from(d.terrain16.mesh.positions,'base64'),raw=new Float32Array(rawBytes.buffer,rawBytes.byteOffset,rawBytes.byteLength/4),newPoints=g.attributes.position.array;
 for(let i=0;i<raw.length;i+=3){assert.equal(newPoints[i],raw[i],'native horizontal contour');assert.equal(newPoints[i+2],raw[i+2],'native vertical contour');if(raw[i+1]===0)assert.equal(newPoints[i+1],0,'ground contact preserved');}let outside=0,triangleOutside=0,blockedPassVertices=0;
 const passBins=new Map();for(const site of d.sites.filter(s=>s.kind==='pass'))for(let x=Math.floor((site.x-36)/128);x<=Math.floor((site.x+36)/128);x++)for(let y=Math.floor((site.y-36)/128);y<=Math.floor((site.y+36)/128);y++){const key=x+','+y;if(!passBins.has(key))passBins.set(key,[]);passBins.get(key).push(site);}
 for(const geometry of [g,snow]){const p=geometry.attributes.position;
 for(let i=0;i<p.count;i++){
  const x=p.getX(i),y=-p.getZ(i);assert.ok(Number.isFinite(x)&&Number.isFinite(y)&&Number.isFinite(p.getY(i)));
  const ix=Math.max(0,Math.min(t.hatchingWidth-1,Math.round((x-b[0])/(b[2]-b[0])*(t.hatchingWidth-1))));
  const iy=Math.max(0,Math.min(t.hatchingHeight-1,Math.round((b[3]-y)/(b[3]-b[1])*(t.hatchingHeight-1))));
  const n=iy*t.hatchingWidth+ix;if(!(mask[n>>3]&(128>>(n&7))))outside++;
  if(p.getY(i)>.15)for(const pass of passBins.get(Math.floor(x/128)+','+Math.floor(y/128))||[])if(Math.abs(x-pass.x)<(d.terrain230?.passCoreHalfWidth??36)&&Math.abs(y-pass.y)<(d.terrain230?.passCoreHalfWidth??36))blockedPassVertices++;
 }
 }
 for(const geometry of [g,snow]){
  const p=geometry.attributes.position,index=geometry.index,n=index?index.count:p.count;
  for(let i=0;i<n;i+=3){let x=0,y=0;for(let j=0;j<3;j++){const k=index?index.getX(i+j):i+j;x+=p.getX(k)/3;y-=p.getZ(k)/3;}
   const ix=Math.max(0,Math.min(t.hatchingWidth-1,Math.round((x-b[0])/(b[2]-b[0])*(t.hatchingWidth-1)))),iy=Math.max(0,Math.min(t.hatchingHeight-1,Math.round((b[3]-y)/(b[3]-b[1])*(t.hatchingHeight-1))));
   const bit=iy*t.hatchingWidth+ix;if(!(mask[bit>>3]&(128>>(bit&7))))triangleOutside++;
  }
 }
 // Every map has substantial interior cliff networks; an enclosing border hole
 // must not erase these disconnected islands during mesh assembly.
 const pp=g.attributes.position;let interiorVertices=0;for(let i=0;i<pp.count;i++){const x=(pp.getX(i)-b[0])/(b[2]-b[0]),y=(-pp.getZ(i)-b[1])/(b[3]-b[1]);if(x>.05&&x<.95&&y>.05&&y<.95&&pp.getY(i)>1)interiorVertices++;}
 assert.ok(interiorVertices>20000,d.catalog.map+' lost its interior cliff network');
 const r={map:d.catalog.map,interiorVertices,vertices:g.attributes.position.count,snowVertices:snow.attributes.position.count,outside2DHatching:outside,triangleCentresOutside:triangleOutside,blockedPassVertices,nativeHoles:d.terrain16.ridges.reduce((n,p)=>n+p.holes.length,0)};report.push(r);console.log(JSON.stringify(r));g.dispose();snow.dispose();
}
fs.writeFileSync(new URL('./terrain-render-v16.json',import.meta.url),JSON.stringify({passed:report.every(r=>r.outside2DHatching===0&&r.triangleCentresOutside===0&&r.blockedPassVertices===0),maps:report},null,2));
assert.equal(report.length,21);assert.ok(report.every(r=>r.outside2DHatching===0&&r.triangleCentresOutside===0&&r.blockedPassVertices===0));
