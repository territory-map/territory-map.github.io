import assert from 'node:assert/strict';
import fs from 'node:fs';
import zlib from 'node:zlib';
let maps=0,passes=0,raised=0;
for(const file of fs.readdirSync(new URL('../assets/data/',import.meta.url)).filter(f=>f.endsWith('.gz'))){
 const d=JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL('../assets/data/'+file,import.meta.url)))),t=d.terrain15;
 const heights=Buffer.from(t.elevation,'base64'),mask=Buffer.from(t.hatching,'base64');
 assert.equal(heights.length,t.width*t.height);assert.equal(mask.length,Math.ceil(t.hatchingWidth*t.hatchingHeight/8));assert.equal(t.hatchingPacked,true);
 const inside=(x,y)=>{const i=y*t.hatchingWidth+x;return !!(mask[i>>3]&(128>>(i&7)));};
 // Each elevated vertex's adjacent triangle footprint must stay in the 2D mask.
 for(let y=0;y<t.height;y++)for(let x=0;x<t.width;x++){
  if(!heights[y*t.width+x])continue;raised++;
  for(const dx of [-1,0,1])for(const dy of [-1,0,1]){
   const hx=Math.round(Math.max(0,Math.min(t.width-1,x+dx))/(t.width-1)*(t.hatchingWidth-1));
   const hy=Math.round(Math.max(0,Math.min(t.height-1,y+dy))/(t.height-1)*(t.hatchingHeight-1));
   assert.ok(inside(hx,hy),`${file}: raised triangle escapes 2D outline`);
  }
 }
 const [a,b,c,e]=d.catalog.bounds;
 for(const site of d.sites.filter(s=>s.kind==='pass')){
  passes++;
  for(const dx of [-36,-18,0,18,36])for(const dy of [-36,-18,0,18,36]){
   const x=Math.max(0,Math.min(t.width-2,Math.floor((site.x+dx-a)/(c-a)*(t.width-1))));
   const y=Math.max(0,Math.min(t.height-2,Math.floor((e-site.y-dy)/(e-b)*(t.height-1))));
   for(const i of [y*t.width+x,y*t.width+x+1,(y+1)*t.width+x,(y+1)*t.width+x+1])assert.equal(heights[i],0,`${file}: obstructed pass ${site.id}`);
  }
 }
 maps++;
}
assert.equal(maps,21);
console.log(JSON.stringify({passed:true,maps,passes,raisedVerticesChecked:raised,passOpeningsClear:true,triangleFootprintsInside2D:true}));
