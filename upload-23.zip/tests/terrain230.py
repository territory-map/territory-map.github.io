"""Independent mesh topology, water/passage and 2.2.0 preservation audit."""
from pathlib import Path
import argparse, gzip, json, base64, zipfile, hashlib
import numpy as np
import cv2

root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--baseline',type=Path);args=parser.parse_args()
baseline=zipfile.ZipFile(args.baseline) if args.baseline else None
reports=[]
for path in sorted((root/'assets/data').glob('*.gz')):
 d=json.loads(gzip.decompress(path.read_bytes()));slug=d['catalog']['map'];m=d['terrain16']['mesh']
 pos=np.frombuffer(base64.b64decode(m['positions']),'<f4').reshape(-1,3)
 tri=np.frombuffer(base64.b64decode(m['indices']),'<u4').reshape(-1,3)
 assert np.isfinite(pos).all() and tri.max()<len(pos) and m['groundContacts']
 edges=np.vstack((tri[:,[0,1]],tri[:,[1,2]],tri[:,[2,0]])).astype(np.uint64)
 edges.sort(axis=1);keys=edges[:,0]*len(pos)+edges[:,1]
 unique,count=np.unique(keys,return_counts=True);assert count.max()==2
 border=unique[count==1];points=np.unique(np.r_[border//len(pos),border%len(pos)]).astype(int)
 openEdges=int(np.count_nonzero(pos[points,1]>.0001));assert openEdges==0,slug+' floating open edge'
 sm=d['terrain16']['snowMesh'];sp=np.array(sm['positions'],np.float32).reshape(-1,3);si=np.array(sm['indices'],np.uint32).reshape(-1,3)
 # Apply the same boundary grounding used by the runtime exterior renderer.
 sp[np.bincount(si.ravel(),minlength=len(sp))<6,1]=0
 se=np.vstack((si[:,[0,1]],si[:,[1,2]],si[:,[2,0]])).astype(np.uint64);se.sort(axis=1)
 sk,sc=np.unique(se[:,0]*len(sp)+se[:,1],return_counts=True);assert sc.max()==2
 sb=sk[sc==1];sv=np.unique(np.r_[sb//len(sp),sb%len(sp)]).astype(int)
 snowOpen=int(np.count_nonzero(sp[sv,1]>.0001));assert snowOpen==0,slug+' exterior open edge'
 a,b,c,e=d['catalog']['bounds'];t=d['terrain15'];W,H=t['hatchingWidth'],t['hatchingHeight']
 px=np.clip(np.rint((pos[:,0]-a)/(c-a)*(W-1)).astype(int),0,W-1)
 py=np.clip(np.rint((e+pos[:,2])/(e-b)*(H-1)).astype(int),0,H-1)
 blocked=np.unpackbits(np.frombuffer(base64.b64decode(t['hatching']),np.uint8))[:W*H].reshape(H,W)
 raised=pos[:,1]>.15;assert not np.any(raised&(blocked[py,px]==0))
 def raster(poly):return np.rint([[(x-a)/(c-a)*(W-1),(e-y)/(e-b)*(H-1)] for x,y in poly]).astype(np.int32)
 water=np.zeros((H,W),np.uint8);wt=d['terrain17']
 for i,p in enumerate(wt['waterPolygons']):
  cv2.fillPoly(water,[raster(p)],1)
  for hole in wt.get('waterHoles',{}).get(str(i),[]):cv2.fillPoly(water,[raster(hole)],0)
 assert not np.any(raised&(water[py,px]>0))
 passCore=0;shoulders=0;improvedPasses=0
 # Bin vertices spatially for independent checks at every pass.
 order=np.argsort(pos[:,0]);xs=pos[order,0]
 for s in d['sites']:
  if s['kind']!='pass':continue
  ix=order[np.searchsorted(xs,s['x']-43):np.searchsorted(xs,s['x']+43)]
  x,y=abs(pos[ix,0]-s['x']),abs(-pos[ix,2]-s['y'])
  passCore+=int(np.count_nonzero(raised[ix]&(x<18)&(y<18)))
  n=int(np.count_nonzero(raised[ix]&(x<43)&(y<43)&((x>=18)|(y>=18))))
  shoulders+=n;improvedPasses+=n>0
 assert passCore==0
 im=cv2.resize(cv2.imread(str(root/'assets/maps'/f'{slug}.webp')),(W,H))
 desert=im[py,px,2].astype(float)>im[py,px,1]*1.15
 desertRaised=int(np.count_nonzero(desert&raised))
 if slug=='LostLand_Map_9_2_v2':assert desertRaised>150000
 unchanged=None
 if baseline:
  old=json.loads(gzip.decompress(baseline.read(f'Territory-Lab-Standalone-2.2.0/assets/data/{path.name}')))
  # Every non-relief field must be identical, including solver/navigation masks.
  old.pop('terrain16');now={k:v for k,v in d.items() if k not in ['terrain16','terrain230']}
  old['terrain17'].pop('features');now['terrain17']=dict(now['terrain17']);now['terrain17'].pop('features')
  assert old==now,slug+' gameplay or water changed';unchanged=True
  assert baseline.read(f'Territory-Lab-Standalone-2.2.0/assets/maps/{slug}.webp')==(root/'assets/maps'/f'{slug}.webp').read_bytes()
 r={'map':slug,'vertices':len(pos),'triangles':len(tri),'nonManifoldEdges':int(np.count_nonzero(count>2)),'floatingBoundaryVertices':openEdges,'exteriorFloatingBoundaryVertices':snowOpen,'passCoreRaised':passCore,'restoredShoulderVertices':shoulders,'passesWithRestoredShoulders':improvedPasses,'desertRaisedVertices':desertRaised,'gameplayAndSourceImageUnchanged':unchanged}
 reports.append(r);print(json.dumps(r),flush=True)
assert len(reports)==21 and sum(r['passesWithRestoredShoulders'] for r in reports)>100
(root/'tests/topology-v230.json').write_text(json.dumps({'passed':True,'maps':reports},indent=2),encoding='utf8')
