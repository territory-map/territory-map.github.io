import fs from 'node:fs';import zlib from 'node:zlib';import vm from 'node:vm';import assert from 'node:assert/strict';
vm.runInThisContext(fs.readFileSync(new URL('../web/vendor/three.min.js',import.meta.url),'utf8'));
const T=globalThis.THREE,{View}=await import('../web/view.js'),{buildWater}=await import('../web/landscape.js');
const rows=[];
const polygonArea=p=>Math.abs(p.reduce((s,a,i)=>{const b=p[(i+1)%p.length];return s+a[0]*b[1]-b[0]*a[1];},0)/2);
for(const file of fs.readdirSync(new URL('../assets/data/',import.meta.url)).filter(f=>f.endsWith('.gz'))){
 const d=JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL('../assets/data/'+file,import.meta.url))));if(process.argv.includes('--one')&&!d.terrain255)continue;
 assert.ok(d.terrain255,d.catalog.map+' not corrected');
 const v=Object.assign(Object.create(View.prototype),{camera:new T.OrthographicCamera(),center:new T.Vector3(),w:1024,h:768,mode:'3d',scale:4,azimuth:.3,tilt:.8});v.setOrthographicTopDown(true);
 assert.ok(v.camera.isOrthographicCamera);
 for(const x of [d.catalog.bounds[0],d.catalog.bounds[2]])for(const y of [d.catalog.bounds[1],d.catalog.bounds[3]]){
  const ground=new T.Vector3(x,0,-y).project(v.camera),peak=new T.Vector3(x,250,-y).project(v.camera);assert.ok(Math.abs(ground.x-peak.x)<1e-12&&Math.abs(ground.y-peak.y)<1e-12,'Height changes XY projection');
 }
 const water=buildWater(d.terrain17,null,d.terrain255.waterMesh),surface=water.getObjectByName('water-surface'),p=surface?.geometry.attributes.position.array;let actual=0;
 if(p)for(let i=0;i<p.length;i+=9)actual+=Math.abs((p[i+3]-p[i])*(p[i+8]-p[i+2])-(p[i+6]-p[i])*(p[i+5]-p[i+2]))/2;
 const expected=d.terrain255.waterMesh.expectedVectorArea;
 assert.ok(Math.abs(actual-expected)<Math.max(1,expected)*2e-5,d.catalog.map+' water area '+actual+' != '+expected);
 const boundary=water.getObjectByName('shoreline');assert.ok(boundary?.isLineSegments,'Banks must not expand the polygon');
 rows.push({map:d.catalog.map,orthographic:true,waterExpectedArea:expected,waterRenderedArea:actual,ridge:d.terrain255.ridge.vertices,exterior:d.terrain255.exterior.vertices});
 water.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});
}
assert.equal(rows.length,process.argv.includes('--one')?1:21);
fs.writeFileSync(new URL('./terrain255.json',import.meta.url),JSON.stringify({passed:true,maps:rows},null,2));console.log(JSON.stringify({passed:true,maps:rows.length,orthographicHeightInvariance:true,exactWaterArea:true}));
