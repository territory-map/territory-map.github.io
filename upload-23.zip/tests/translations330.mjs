import assert from 'node:assert/strict';import fs from 'node:fs';
const dynamic=[
 'Backup-Verbindungen · 1,234 Positionen geprüft · 42 Flaggen · 19 Kristalle',
 'Nahe Ressourcen · 123 Positionen geprüft · 4 Flaggen',
 'Kristallgruppen · 123 Positionen geprüft · 4 Flaggen',
 'Kristall-Korridor · 123 Positionen geprüft · 4 Flaggen',
 'Route suchen: Der gewählte Startpunkt ist nicht mehr vorhanden.',
 'Kartendaten laden: Kartendaten nicht verfügbar (HTTP 404).',
 'Programm laden: Die Anfrage wurde abgebrochen oder hat das Zeitlimit überschritten.',
 'Suche läuft …','Routenberechnung wird gestartet …','Kartendaten für die Route werden geladen …',
 'Berechnung wird mit geringerem Speicherbedarf wiederholt …',
 'Zonengrenzen werden nach gültigen Wandsprüngen durchsucht …',
 'Geprüfte Sprungpaare: 829 · Kein eroberter Pass oder Passkontakt nötig.',
 'Gespeicherte taktische Sprungpaare: 829 · Baupositionen vor dem Setzen erneut prüfen.',
 '2 neue Flaggen. Alle markierten Ziele verbunden. Route ohne Kristallabzweigungen. 5 Flaggen für den breiten Vorstoß; 3 Backup-Flaggen; 1 verbleibende kritische Verbindungen.',
 '2 neue Flaggen. 3 Ziel(e) noch nicht erreicht. 7 Kristallvorkommen erfasst; 4 von 30 Zusatzflaggen. Suchlimit erreicht; bestes geprüftes Ergebnis.',
 'Die Grundfläche berührt eine Wand oder gesperrtes Gelände.',
 'Zonen-Walljump benötigt aktivierte Freigabe und gültigen eigenen oder Koalitions-Passkontakt.',
 'Allianzcredits zurückgesetzt. Vorhandene Bauten zählen weiterhin für die Baukosten.',
 'Allianzcredits seit dem Zurücksetzen',
 'Allianzcredits für alle vorhandenen Bauten',
 'Preparation Season 1 · Originalposition',
 'PNG konnte nicht erstellt werden.',
 'Die Geländedaten dieser Karte sind unvollständig.'
];
const results={};
for(const lang of ['de','en','fr']){
 globalThis.localStorage={getItem:()=>lang};const {translate,localizedText}=await import('../web/i18n.js?330='+lang);
 results[lang]=dynamic.map(source=>({source,shown:translate(source)}));
 for(const {source,shown} of results[lang]){
  if(lang==='de')assert.equal(shown,source.replace('1 verbleibende kritische Verbindungen','1 verbleibende kritische Verbindung'));
  else{assert.notEqual(shown,source);assert.doesNotMatch(shown,/\b(?:Flaggen|Positionen|geprüft|vorhanden|Suche|Kartendaten|Allianzcredits|benötigt|zurückgesetzt|Vorstoß|erreicht)\b/);}
 }
 const element={textContent:''};localizedText(element,dynamic[0]);assert.equal(element.textContent,translate(dynamic[0]));
}
fs.mkdirSync('analysis/credits330',{recursive:true});fs.writeFileSync('analysis/credits330/translations.json',JSON.stringify({passed:true,results},null,2));
console.log('3.3: dynamic route/jump phases, numeric results, prefixed errors, cost reset and export errors translated in DE/EN/FR.');
