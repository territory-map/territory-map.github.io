import assert from 'node:assert/strict';
import {MapModel,newPlan,G} from '../web/core/model.js';
import {solve} from '../web/solver.js';
import {flagTouchesBastion,symbolSize,recolourBanner} from '../web/terrain16.js';
const data={catalog:{map:'test',nativeMapSize:1000,bounds:[0,0,1000,1000],structureRules:{},buildings:{flag:{limit:500},fortress:{limit:2}}},sites:[],resources:[],definitions:[],instances:[],province:null};
for(const kind of ['food','wood','stone','coin','crystal']){
 const d=structuredClone(data);d.resources=[{id:'resource',kind,x:171,y:99}];const m=new MapModel(d);
 for(const building of ['flag','fortress']){
  assert.match(m.staticError({kind:building,x:171,y:99,allianceId:'a1'}),/Ressourcenpunkt/);
  assert.match(m.staticError({kind:building,x:174,y:99,allianceId:'a1'}),/Ressourcenpunkt/);
  assert.equal(m.staticError({kind:building,x:190,y:99,allianceId:'a1'}),null);
 }
}
const site={id:'bastion',kind:'bastion',x:423,y:99,territoryRadiusInCells:1,claimable:false};
assert.ok(flagTouchesBastion({kind:'flag',x:369,y:99},site,G));
assert.equal(flagTouchesBastion({kind:'flag',x:369,y:153},site,G),false,'A diagonal corner does not connect');
assert.equal(flagTouchesBastion({kind:'flag',x:351,y:99},site,G),false,'One empty cell is not contact');
const d=structuredClone(data);d.sites=[site];d.resources=['food','wood','stone','coin','crystal'].map((kind,i)=>({id:i,kind,x:171+i*54,y:99}));
const m=new MapModel(d),p=newPlan('test'),target={id:'target',siteId:'bastion',x:423,y:99};
p.settings.resourceRadius=1; // Legacy six-world-unit resource radius, now configurable.
p.buildings=[{id:'root',kind:'fortress',x:99,y:99,allianceId:'a1'}];p.targets=[target];m.setPlan(p);
assert.equal(m.targetReached(target,'a1'),false);
const onlyFortress=structuredClone(p);onlyFortress.buildings.push({id:'near',kind:'fortress',x:369,y:99,allianceId:'a1'});m.setPlan(onlyFortress);assert.equal(m.targetReached(target,'a1'),false,'A fortress alone is not the requested flag contact');
const result=solve(m,p,'a1',{budget:20,crystals:false});assert.equal(result.failed.length,0);const checked=structuredClone(p);
for(const b of result.buildings){m.setPlan(checked);assert.equal(m.placementError(b),null);for(const r of d.resources)assert.ok(Math.hypot(b.x-r.x,b.y-r.y)>=7.4);checked.buildings.push(b);}
m.setPlan(checked);assert.equal(m.targetReached(target,'a1'),true);
assert.ok(result.buildings.some(b=>flagTouchesBastion(b,site,G)));
// Full-height banner mask, while stone and gold retain their original pixels.
const pixels=new Uint8ClampedArray([220,0,220,255,80,90,100,255,210,160,20,255,180,10,190,255]);
recolourBanner(pixels,[20,180,230]);assert.ok(pixels[2]>pixels[0]);assert.ok(pixels[14]>pixels[12]);assert.deepEqual([...pixels.slice(4,12)],[80,90,100,255,210,160,20,255]);
assert.ok(symbolSize(30,.3)>30);assert.ok(symbolSize(30,10)/10>=26);assert.ok(symbolSize(30,1)/1>22);
console.log(JSON.stringify({passed:true,resourceKinds:5,manualAndSolverResourceCollision:true,bastionNeedsFlagEdge:true,cornerRejected:true,solverFlags:result.buildings.length,wholeBannerRecoloured:true,structureZoomVisibility:true}));

