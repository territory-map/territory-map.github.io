import assert from 'node:assert/strict';
import fs from 'node:fs';import zlib from 'node:zlib';
import {gameCoordinate,labelOffset} from '../web/presentation17.js';
import {allianceReport} from '../web/export17.js';
import {MapModel,newPlan} from '../web/core/model.js';
assert.equal(gameCoordinate(12.9*6),12);assert.equal(gameCoordinate(13*6),13);assert.equal(gameCoordinate(0),0);
for(const zoom of [.16,.3,1,3,20])assert.equal(labelOffset('below',22,100/zoom),-13,'Label remains two pixels below the visible base');
const d=JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL('../assets/data/LostLand_Map_18_v2.json.gz',import.meta.url))));
const m=new MapModel(d),p=newPlan(d.catalog.map);p.alliances.push({id:'a2',name:'Allianz 2',color:'#ff8090'});
p.buildings=[{id:'1',kind:'fortress',x:999,y:999,allianceId:'a1'},{id:'2',kind:'flag',x:1053,y:999,allianceId:'a1'},{id:'3',kind:'fortress',x:1999,y:1999,allianceId:'a2'},{id:'4',kind:'flag',x:2053,y:1999,allianceId:'a2'}];m.setPlan(p);
const report=allianceReport(m,p);assert.equal(report.length,2);assert.equal(report[0].buildings.length,2);assert.equal(report[1].buildings.length,2);assert.equal(report[0].buildings[0].x,166);assert.ok(report[0].production.length>=4);assert.ok(Object.keys(report[0].costs).length>=4);
let computations=0;const original=m.computeStaticError.bind(m);m.computeStaticError=(...args)=>{if(args[0].x===123&&args[0].y===123)computations++;return original(...args);};
const candidate={kind:'flag',x:123,y:123,allianceId:'a1'};const first=m.staticError(candidate);for(let i=0;i<100;i++){m.setPlan(p);assert.equal(m.staticError(candidate),first);}assert.equal(computations,1);
p.siteEdits[m.sites[0].siteId]={x:123,y:123};m.setPlan(p);m.staticError(candidate);assert.equal(computations,2,'Moving structures invalidates collision cache');
const view=fs.readFileSync(new URL('../web/view.js',import.meta.url),'utf8');assert.ok(!view.includes('this.buildFootprint(b,this.planFootprints)'));assert.ok(view.includes('this.buildFootprint(b,this.cursorGroup'));
const exportCode=fs.readFileSync(new URL('../web/export17.js',import.meta.url),'utf8');assert.ok(exportCode.includes('setViewOffset'));assert.ok(exportCode.includes('finally'));
console.log('v1.7: integer coordinates, base-relative labels, grouped export, cache reuse/invalidation, preview-only footprints passed.');

const costFixture={catalog:{costs:{fortress:[{from:1,to:2,cost:{food:100,credits:10}}],flag:[{from:1,to:1,cost:{food:5}},{from:2,to:100,cost:{food:9}}]},resourceProductionPerHour:{food:100,gold:25,crystal:10}},covered:aid=>aid==='a1'?{food:2,coin:3,crystal:1}:{food:1,coin:0,crystal:2}};
const costPlan={alliances:[{id:'a1',name:'One'},{id:'a2',name:'Two'}],buildings:[{kind:'flag',allianceId:'a1',x:77.4,y:6},{kind:'fortress',allianceId:'a1',x:60,y:60},{kind:'flag',allianceId:'a1',x:90,y:90},{kind:'flag',allianceId:'a2',x:12,y:18}]};
const detailedReport=allianceReport(costFixture,costPlan);assert.deepEqual(detailedReport[0].production.map(p=>p.value),[200,75,10]);assert.equal(detailedReport[0].costs.food,114);assert.equal(detailedReport[1].costs.food,5);assert.equal(detailedReport[0].buildings[0].kind,'fortress');assert.equal(detailedReport[0].buildings[1].x,12);assert.equal(detailedReport[0].costs.unknown,0);console.log('Export: positive hourly production, coin/gold alias, per-alliance tiered costs and fortress/flag ordering passed.');

