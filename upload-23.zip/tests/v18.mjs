import fs from 'node:fs';import zlib from 'node:zlib';import assert from 'node:assert/strict';
import {siteName,siteIcon,passLevel,hasSiteTranslation,lowerArtExtent} from '../web/sites18.js';
import {reportData,exportWorkbook} from '../web/export18.js';
import {MapModel,newPlan,G} from '../web/core/model.js';
const maps=[],unknown=[];
for(const file of fs.readdirSync(new URL('../assets/data/',import.meta.url)).filter(f=>f.endsWith('.gz'))){
 const d=JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL('../assets/data/'+file,import.meta.url))));let passes=0,unresolved=0,ruins=0;
 for(const s of d.sites){
  if(!hasSiteTranslation(s))unknown.push(s.label);
  for(const lang of ['de','en','fr'])assert.ok(siteName(s,lang).length);
  if(s.kind==='pass'){passes++;if(!passLevel(s))unresolved++;else assert.equal(passLevel(s),s.level);}
  if(s.kind==='ancient-battlefield'&&s.strongholdType===39&&!/Ra/.test(s.label||'')){ruins++;assert.equal(siteIcon(s,d.catalog),'holy_land_lod3_darkness.png');}
 }
 maps.push({map:d.catalog.map,passes,unresolved,unifiedRuins:ruins});
}
assert.deepEqual([...new Set(unknown)],[],'All source structure names need translations');
assert.equal(passLevel({level:null,label:'Pass (Stufe offen)'}),null);
const source={userData:{anchor:.35,top:.75,left:.1,right:.9,aspect:2},center:{y:.5},material:{rotation:0}};
assert.ok(Math.abs(lowerArtExtent(source,28)-4.2)<1e-9);
source.material.rotation=Math.PI/2;assert.ok(Math.abs(lowerArtExtent(source,28)-22.4)<1e-9);
const d=JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL('../assets/data/LostLand_Map_18_v2.json.gz',import.meta.url)))),model=new MapModel(d),p=newPlan(d.catalog.map);
// Independent fixture: known ownership cells and tiered costs; viewport must
// retain the second flag's tier when the first flag lies outside the crop.
const fixture={catalog:{name:'Exportprüfung',costs:{flag:[{from:1,to:1,cost:{credits:10}},{from:2,to:10,cost:{credits:30}}],fortress:[{from:1,to:3,cost:{credits:100}}]},resourceProductionPerHour:{food:50,gold:20}},state:{ownership:new Map([['1:1',{allianceId:'a1',column:1,row:1}],['5:5',{allianceId:'a1',column:5,row:5}]])},data:{resources:[{kind:'food',x:20,y:20},{kind:'coin',x:100,y:100}]},covered(allianceId,resources=this.data.resources){return G.countCoveredResources(this.state.ownership,resources,allianceId);}};
const plan={alliances:[{id:'a1',name:'=Demo & Test',color:'#24c3cb'},{id:'a2',name:'Étoile',color:'#dd8098'}],buildings:[{id:'f1',kind:'flag',allianceId:'a1',x:10,y:10},{id:'f2',kind:'flag',allianceId:'a1',x:100,y:100},{id:'fort',kind:'fortress',allianceId:'a1',x:80,y:80}]};
const all=reportData(fixture,plan,'de'),part=reportData(fixture,plan,'en',b=>b.x>50);assert.equal(all[0].costs.credits,140);assert.equal(part[0].costs.credits,130);assert.equal(part[0].buildings.length,2);assert.equal(part[0].buildings[0].kind,'fortress');assert.equal(part[0].buildings[1].number,2);assert.equal(part[0].buildings[1].x,16);assert.equal(part[0].production.find(p=>p.kind==='food').value,0);assert.equal(part[0].production.find(p=>p.kind==='gold').value,20);
for(const lang of ['de','en','fr'])for(const scope of ['map','viewport'])fs.writeFileSync(new URL('./export-v18-'+lang+'-'+scope+'.xlsx',import.meta.url),Buffer.from(await exportWorkbook(fixture,plan,lang,scope==='viewport'?b=>b.x>50:null).arrayBuffer()));
// Optional strict-grid rule is additional to the always-active base rule.
model.groundAccess.blocked=()=>false;model.terrainCollision=()=>false;model.resourceSpatial=new Map();model.sites=[];model.cellCollision=()=>true;
assert.equal(model.computeStaticError({kind:'flag',x:1000,y:1000},false),null);
assert.equal(model.computeStaticError({kind:'flag',x:1000,y:1000},true),'Die Bauzelle ist nicht vollständig frei.');
fs.writeFileSync(new URL('./v18-results.json',import.meta.url),JSON.stringify({passed:true,maps,passTotal:maps.reduce((n,m)=>n+m.passes,0),unknownPasses:maps.reduce((n,m)=>n+m.unresolved,0),xlsxFixtures:6,viewportTierCostsPreserved:true,strictRuleVerified:true},null,2));
console.log('v1.8: all map names, pass metadata, ruin artwork, alpha-bound pass offsets, strict rule, multilingual XLSX and viewport costs passed.');

