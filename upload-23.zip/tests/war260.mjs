import assert from 'node:assert/strict';
import fs from 'node:fs';
import {MapModel,newPlan} from '../web/core/model.js';
import {searchWarJumps,warPairError,warCellIndex} from '../web/core/war-builder.js';
import {displayedWarPairs,warSourceMarkers,warPage,warRequirement,warRequirementLabel} from '../web/core/war-display.js';
function map(n,regionAt){
 const w=n+1,regions=new Uint16Array(w*w),mask=new Uint8Array(w*w);
 for(let row=0;row<w;row++)for(let x=0;x<w;x++){const z=regionAt(x,n-row),i=row*w+x;regions[i]=z;mask[i]=z?0:255;}
 return {catalog:{map:'coverage',nativeMapSize:n,bounds:[0,0,n,n],structureRules:{},buildings:{flag:{limit:500},fortress:{limit:2}}},sites:[],resources:[],definitions:[],instances:[],terrain15:{hatching:Buffer.from(mask).toString('base64'),hatchingWidth:w,hatchingHeight:w},navigation18:{width:w,height:w,regions:Buffer.from(regions.buffer).toString('base64'),passes:{}}};
}
const halfPixelModel={catalog:{nativeMapSize:36},plan:{buildings:[]},groundAccess:{bounds:[16.6,0,19.2,18],nav:{width:3,height:2},regions:Uint16Array.from([0,1,0,0,0,0])}};
assert.ok(warCellIndex(halfPixelModel,new Set([1])).get('1:0')?.zones.has(1),'nearest-neighbour pixel extent may cross a cell edge even though its centre does not');
const small=map(180,(x,y)=>Math.hypot(x-78,y-78)<=4?1:Math.hypot(x-114,y-78)<=4?2:0),m=new MapModel(small),p=newPlan('coverage');

p.settings.flagRadius=3.16256/6;m.setPlan(p);const cells=warCellIndex(m,new Set([1,2]));
assert.ok(cells.get('4:4')?.zones.has(1),'a viable island missed by all nine coarse membership samples is retained');
assert.ok(cells.get('6:4')?.zones.has(2));
const narrow=searchWarJumps(m,p,[{side:'ours',allianceId:'a1',from:1,to:2},{side:'enemy',allianceId:'enemy',from:2,to:1}]);
for(const dir of narrow.directions){assert.ok(dir.pairs.some(q=>q.kind==='flag'),'complete navigation index and refined centres must find a real narrow-strip jump');for(const q of dir.pairs)assert.equal(warPairError(m,q.source,q.target,dir.from,dir.to),null);}
const wide=map(900,(x,y)=>y<448?1:y>452?2:0),model=new MapModel(wide),plan=newPlan('coverage');plan.settings.usePassStructures=false;plan.settings.useCrusaderStructures=false;

const before=JSON.stringify(plan),start=performance.now(),result=searchWarJumps(model,plan,[{side:'ours',allianceId:'a1',from:1,to:2},{side:'enemy',allianceId:'enemy',from:2,to:1}],()=>{},{maxPerKind:1,spacing:10000});
assert.equal(JSON.stringify(plan),before,'search must not place buildings or capture a pass');
for(const dir of result.directions){
 const flags=dir.pairs.filter(q=>warRequirement(q)==='flag'),forts=dir.pairs.filter(q=>warRequirement(q)==='fortress');
 assert.ok(flags.length>80,'old 80-result cap must not hide valid transitions');assert.ok(forts.length>80);
 assert.ok(flags.some(a=>flags.some(b=>a.id!==b.id&&Math.hypot(a.midX-b.midX,a.midY-b.midY)<54)),'old 54-unit thinning removed');
 assert.ok(dir.pairs.some(a=>dir.pairs.some(b=>a.id!==b.id&&a.sourceCell.column===b.sourceCell.column&&a.sourceCell.row===b.sourceCell.row)),'one source cell retains all distinct landing fields');
 const transitions=new Set();for(const q of dir.pairs){const key=JSON.stringify([q.sourceCell,q.targetCell]);assert.ok(!transitions.has(key),'a fortress alternative may not hide a sufficient flag');transitions.add(key);assert.equal(warPairError(model,q.source,q.target,dir.from,dir.to),null);
  if(q.requirement==='fortress')assert.ok(warPairError(model,{...q.source,kind:'flag'},q.target,dir.from,dir.to),'a fortress-required exact source must really fail as a flag');
 }
 // The first and last free source cells, plus every intermediate border sector,
 // survive. No representative-only display reduction is applied to the results.
 const columns=new Set(flags.map(q=>q.sourceCell.column));for(let col=0;col<50;col++)assert.ok(columns.has(col),'missing wall sector '+col);
}
const central=map(180,(x,y)=>y<88?1:y>92?2:0);central.catalog.buildings.fortress.limit=0;central.catalog.buildings['center-fortress']={limit:1};
const centralModel=new MapModel(central),centralPlan=newPlan('coverage');const centralResult=searchWarJumps(centralModel,centralPlan,[{side:'ours',allianceId:'a1',from:1,to:2}]);
assert.ok(centralResult.directions[0].pairs.some(q=>q.kind==='center-fortress'),'an available central fortress must not be ignored when ordinary fortresses are unavailable');
for(const q of centralResult.directions[0].pairs){assert.equal(warPairError(centralModel,q.source,q.target,1,2),null);if(q.kind==='center-fortress')assert.equal(warRequirementLabel(q),'Hauptfestung nötig');}
const all=displayedWarPairs(result),flags=displayedWarPairs(result,'flag'),forts=displayedWarPairs(result,'fortress');assert.equal(flags.length+forts.length,all.length);
assert.equal(warSourceMarkers(all).length,new Set(all.map(q=>[q.side,q.requirement,q.sourceCell.column,q.sourceCell.row].join(':'))).size);
const collected=[];for(let i=0;i<warPage(all).pages;i++)collected.push(...warPage(all,i).items);assert.deepEqual(collected.map(q=>q.id),all.map(q=>q.id));assert.equal(warPage(all,99999).index,warPage(all).pages-1);assert.equal(warPage([],9).index,0);
for(const lang of ['de','en','fr']){globalThis.localStorage={getItem:()=>lang};const {translate:t}=await import('../web/i18n.js?coverage='+lang);if(lang!=='de')for(const key of ['Flagge reicht','Festung nötig','Zielflagge','Hauptfestung nötig','Sprungvorschläge filtern','Vorherige Seite','Positionen geprüft'])assert.notEqual(t(key),key);}
const view=fs.readFileSync('web/war-builder-view.js','utf8');assert.ok(view.includes('T.PointsMaterial')&&view.includes('sizeAttenuation:false'),'building type markers stay screen-sized in both camera modes');assert.ok(view.includes('T.LineSegments'),'complete search is rendered in batches');
fs.mkdirSync('analysis/warbuilder260',{recursive:true});fs.writeFileSync('analysis/warbuilder260/coverage.json',JSON.stringify({passed:true,checks:['full navigation pixel membership','narrow free centres','both directions','no 80 cap','no 54-unit thinning','all landing cells per source','minimal source type','all 50 border sectors','pass-independent collision validation','no plan mutation','lossless pagination','DE EN FR','screen-sized batched symbols'],pairs:all.length,flags:flags.length,fortresses:forts.length,milliseconds:Math.round(performance.now()-start)},null,2));
console.log('2.6.0 complete boundary coverage and required-building classification passed: '+all.length+' pairs');
