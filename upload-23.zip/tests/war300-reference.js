import {G,legacy} from '../web/core/model.js';
import {zoneId,warZoneAt} from '../web/core/war-zone-mask.js';

export {WAR_ZONE_KEYS,warConfig} from '../web/core/war-config.js';
// Navigation labels use the same registered XY bounds as the reference map.
export function zoneInventory(access){
 const out=new Map(),n=access.nav;if(!n)return out;
 const [a,b,c,d]=access.bounds,sx=(c-a)/(n.width-1),sy=(d-b)/(n.height-1);
 for(let v=0;v<n.height;v++)for(let u=0;u<n.width;u++){
  const z=zoneId(access,access.regions[v*n.width+u]);if(!z)continue;
  let q=out.get(z);if(!q)out.set(z,q={id:z,pixels:0,sumX:0,sumY:0,minX:Infinity,minY:Infinity,maxX:-Infinity,maxY:-Infinity});
  const x=a+u*sx,y=d-v*sy;q.pixels++;q.sumX+=x;q.sumY+=y;q.minX=Math.min(q.minX,x);q.maxX=Math.max(q.maxX,x);q.minY=Math.min(q.minY,y);q.maxY=Math.max(q.maxY,y);
 }
 for(const q of out.values()){q.x=q.sumX/q.pixels;q.y=q.sumY/q.pixels;delete q.sumX;delete q.sumY;}
 return out;
}
function ownCells(model,source){
 const ownership=new Map();for(const c of G.territoryCells(legacy(source))){const key=c.column+':'+c.row;if(!model.reservedCells.has(key))ownership.set(key,{...c,allianceId:source.allianceId});}return ownership;
}
export function crossesWall(model,a,b){
 const length=Math.hypot(b.x-a.x,b.y-a.y),steps=Math.max(2,Math.ceil(length/1.5));
 for(let i=1;i<steps;i++)if(model.groundAccess.blocked(a.x+(b.x-a.x)*i/steps,a.y+(b.y-a.y)*i/steps,.01))return true;
 return false;
}
// This is a direct building-to-building bridge. No captured site, pass territory,
// relay or zone-unlock state is allowed to supply the connecting cells.
export function warPairError(model,source,target,from,to,{contact=null}={}){
 const permission=model.walljumpError(source,target);if(permission)return permission;
 if(!from||!to||from===to)return 'Zwei verschiedene Zonen auswählen.';
 if(source.allianceId!==target.allianceId||target.kind!=='flag'||!['flag','fortress','center-fortress'].includes(source.kind))return 'Ungültiges Baupaar.';
 if(warZoneAt(model.groundAccess,source.x,source.y)!==from||warZoneAt(model.groundAccess,target.x,target.y)!==to)return 'Die Bauposition liegt außerhalb der gewählten Zone.';
 for(const b of [source,target]){
  const error=model.staticError(b,model.plan.settings.strict);if(error)return error;
  const other=model.buildings.filter(p=>p.id!==b.existingId);
  if(G.plannedBuildingCollision(legacy(b),other))return 'Hier steht bereits ein geplantes Gebäude.';
  if(!G.hasRequiredTerritoryAvailability(legacy(b),model.state.ownership))return 'Zu viel dieser Fläche gehört einer anderen Allianz.';
 }
 for(const kind of new Set([source.kind,target.kind])){
  const limit=model.catalog.buildings[kind]?.limit??0;
  const existing=model.plan.buildings.filter(b=>b.allianceId===source.allianceId&&b.kind===kind).length;
  const added=[source,target].filter(b=>b.kind===kind&&!b.existingId).length;
  if(existing+added>limit)return 'Gebäudelimit der Allianz erreicht.';
 }
 if(G.plannedBuildingCollision(legacy(target),[legacy(source)]))return 'Die Gebäudegrundkreise berühren sich.';
 if(!model.groundAccess.touchesTerritory(legacy(target),contact||ownCells(model,source),model.sites))return 'Kein direkter Gebietskontakt ohne Pass.';
 if(!crossesWall(model,source,target))return 'Zwischen den Gebäuden liegt keine Wand.';
 return null;
}
function point(model,kind,aid,x,y){
 const b={kind,allianceId:aid,x:Number(x.toFixed(2)),y:Number(y.toFixed(2))};
 const existing=model.plan.buildings.find(p=>p.kind===kind&&p.allianceId===aid&&Math.hypot(p.x-x,p.y-y)<.02);
 if(existing)b.existingId=existing.id;return b;
}
// Index every navigation pixel, rather than a few samples of each territory
// cell. Small valid strips and each disconnected section of a border survive.
export function warCellIndex(model,wanted){
 const access=model.groundAccess,{nav,regions}=access,[a,b,c,d]=access.bounds,n=model.catalog.nativeMapSize;
 const columns=Math.ceil(n/18),rows=columns,bits=new Map([...wanted].map((z,i)=>[z,1<<i])),mask=new Uint8Array(columns*rows);
 // Each label describes its nearest-neighbour pixel rectangle, not only
 // the pixel centre. Include cells reached by its half-pixel extent as well.
 const sx=(c-a)/(nav.width-1),sy=(d-b)/(nav.height-1);
 const xs=Array.from({length:nav.width},(_,u)=>[Math.max(0,Math.floor((a+(u-.5)*sx)/18)),Math.min(columns-1,Math.floor((a+(u+.5)*sx)/18))]);
 for(let v=0;v<nav.height;v++){
  const y=d-v*sy,lo=Math.max(0,Math.floor((y-sy/2)/18)),hi=Math.min(rows-1,Math.floor((y+sy/2)/18));if(lo>hi)continue;const offset=v*nav.width;
  for(let u=0;u<nav.width;u++){const bit=bits.get(zoneId(access,regions[offset+u]));if(!bit)continue;const [left,right]=xs[u];for(let row=lo;row<=hi;row++)for(let x=left;x<=right;x++)mask[row*columns+x]|=bit;}
 }
 const cells=new Map();for(let y=0;y<rows;y++)for(let x=0;x<columns;x++){const bit=mask[y*columns+x];if(bit)cells.set(x+':'+y,{cx:x,cy:y,zones:new Set([...bits].filter(([,b])=>bit&b).map(([z])=>z))});}
 // Existing exact centres must also be considered, including an outermost cell.
 for(const p of model.plan.buildings){const z=warZoneAt(access,p.x,p.y);if(!wanted.has(z))continue;const cx=Math.floor(p.x/18),cy=Math.floor(p.y/18),key=cx+':'+cy;let cell=cells.get(key);if(!cell)cells.set(key,cell={cx,cy,zones:new Set()});cell.zones.add(z);}
 return cells;
}
// One representative per source-cell / landing-cell transition, at the smallest
// legal source building. No spacing filter or result cap hides valid transitions.
// Centres remain continuous in gameplay; unsuccessful pairs are refined on a
// one-native-unit grid (1/6 game coordinate), including the edges of each cell.
export function searchWarJumps(model,plan,directions,onProgress=()=>{},options={}){
 model.setPlan(plan);if(!model.groundAccess.nav)throw Error('Diese Karte enthält keine Zonendaten.');
 const cells=warCellIndex(model,new Set(directions.flatMap(d=>[d.from,d.to]).filter(Boolean)));
 onProgress({phase:'boundary',checked:0});
 const cache=new Map(),contactCache=new Map();let checked=0,transitions=0,lastProgress=0;
 const candidates=(cell,z,kind,aid,refine=false)=>{
  const key=cell.cx+':'+cell.cy+'|'+z+'|'+kind+'|'+aid;let item=cache.get(key);
  if(!item){item={out:[],seen:new Set(),refined:false};cache.set(key,item);}
  const test=(x,y)=>{
   const key=x+':'+y;if(item.seen.has(key))return;item.seen.add(key);checked++;
   if(warZoneAt(model.groundAccess,x,y)!==z)return;
   const q=point(model,kind,aid,x,y),existing=plan.buildings.filter(b=>b.allianceId===aid&&b.kind===kind).length;
   if(!q.existingId&&existing>=(model.catalog.buildings[kind]?.limit??0))return;
   if(model.staticError(q,plan.settings.strict)||G.plannedBuildingCollision(legacy(q),model.buildings.filter(p=>p.id!==q.existingId))||!G.hasRequiredTerritoryAvailability(legacy(q),model.state.ownership))return;
   item.out.push(q);
  };
  if(!item.initial){item.initial=true;
   for(const p of plan.buildings)if(p.kind===kind&&p.allianceId===aid&&Math.floor(p.x/18)===cell.cx&&Math.floor(p.y/18)===cell.cy)test(p.x,p.y);
   for(const oy of [9,3,15])for(const ox of [9,3,15])test(cell.cx*18+ox,cell.cy*18+oy);
  }
  if(refine&&!item.refined){item.refined=true;for(let oy=0;oy<18;oy++)for(let ox=0;ox<18;ox++)test(cell.cx*18+ox,cell.cy*18+oy);}
  return item.out;
 };
 const contactFor=(cell,kind,aid)=>{
  const key=cell.cx+':'+cell.cy+'|'+kind+'|'+aid;let contact=contactCache.get(key);
  if(!contact){contact=ownCells(model,{kind,allianceId:aid,x:cell.cx*18+9,y:cell.cy*18+9});contactCache.set(key,contact);}return contact;
 };
 const results=[];
 for(const [directionIndex,dir]of directions.entries()){
  if(!dir.from||!dir.to||dir.from===dir.to){results.push({...dir,pairs:[],reason:'Zwei verschiedene Zonen auswählen.'});continue;}
  const kinds=['flag',...['fortress','center-fortress'].filter(kind=>model.catalog.buildings[kind])],pairs=[],counts={};
  const find=(cell,other,kind)=>{
   const contact=contactFor(cell,kind,dir.allianceId),landing={kind:'flag',allianceId:dir.allianceId,x:other.cx*18+9,y:other.cy*18+9};
   if(!model.groundAccess.touchesTerritory(legacy(landing),contact,model.sites))return null;
   for(const refine of [false,true]){
    const sources=candidates(cell,dir.from,kind,dir.allianceId,refine),targets=candidates(other,dir.to,'flag',dir.allianceId,refine);
    // Prefer reusing an actual source building, then nearby centres. A refined
    // search still runs when coarse points exist but cannot make this jump.
    const combinations=[];for(const source of sources)for(const target of targets){
     const length=Math.hypot(source.x-target.x,source.y-target.y);
     combinations.push({source,target,length});
    }
    combinations.sort((a,b)=>Number(!!b.source.existingId)-Number(!!a.source.existingId)||a.length-b.length);
    for(const q of combinations)if(!warPairError(model,q.source,q.target,dir.from,dir.to,{contact}))return q;
   }
   return null;
  };
  for(const cell of cells.values()){
   if(!cell.zones.has(dir.from))continue;
   for(let dy=-4;dy<=4;dy++)for(let dx=-4;dx<=4;dx++){
    if(Math.abs(dx)===4&&Math.abs(dy)===4)continue;
    const other=cells.get((cell.cx+dx)+':'+(cell.cy+dy));if(!other?.zones.has(dir.to))continue;
    transitions++;
    for(const kind of kinds){
     if(kind==='flag'&&(Math.abs(dx)>3||Math.abs(dy)>3||(Math.abs(dx)===3&&Math.abs(dy)===3)))continue;
     const q=find(cell,other,kind);if(!q)continue;
     const requirement=kind==='flag'?'flag':'fortress';counts[kind]=(counts[kind]||0)+1;
     pairs.push({...q,kind,requirement,side:dir.side,from:dir.from,to:dir.to,
      sourceCell:{column:cell.cx,row:cell.cy},targetCell:{column:other.cx,row:other.cy},
      midX:(q.source.x+q.target.x)/2,midY:(q.source.y+q.target.y)/2,
      id:dir.side+':'+directionIndex+':'+cell.cx+':'+cell.cy+':'+other.cx+':'+other.cy,
      sourceConnected:q.source.existingId?model.isBuildingActive({id:q.source.existingId}):!model.placementError(q.source)});
     break; // A flag suffices for this transition: do not call a fortress required.
    }
   }
   if(checked-lastProgress>2000){lastProgress=checked;onProgress({phase:'search',checked,transitions,pairs:pairs.length});}
  }
  pairs.sort((a,b)=>a.source.y-b.source.y||a.source.x-b.source.x||a.target.y-b.target.y||a.target.x-b.target.x);
  const passes=model.sites.filter(s=>s.kind==='pass'&&model.groundAccess.edges(s).map(z=>zoneId(model.groundAccess,z)).includes(dir.from)&&model.groundAccess.edges(s).map(z=>zoneId(model.groundAccess,z)).includes(dir.to)).map(s=>s.siteId);
  results.push({...dir,pairs,candidateCells:counts,passes,reason:pairs.length?'':'Keine gültigen Sprungpaare an dieser Zonengrenze gefunden.'});
 }
 return {directions:results,checked,transitions,sampling:{cellSize:18,initialSpacing:6,refinementSpacing:1,spacing:0,maxPerKind:null,allNavigationPixels:true,representativePerCellTransition:true},passCaptureRequired:false};
}
