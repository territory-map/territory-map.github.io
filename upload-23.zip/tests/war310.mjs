import assert from 'node:assert/strict';
import fs from 'node:fs';
import zlib from 'node:zlib';
import {Worker} from 'node:worker_threads';
import {MapModel,newPlan} from '../web/core/model.js';
import {searchWarJumps,warPairError,warConfig} from '../web/core/war-builder.js';
import {searchWarJumps as reference} from './war300-reference.js';
import {displayedWarPairs} from '../web/core/war-display.js';
import {zoneId} from '../web/core/war-zone-mask.js';
const results=[],geometry=r=>r.directions.map(d=>d.pairs.map(q=>({id:q.id,kind:q.kind,source:q.source,target:q.target})).sort((a,b)=>a.id.localeCompare(b.id)));
for(const id of ['LostLand_Map_18_v2', 'Sever_Map_G1_1_v2']){
 const path='assets/solver/'+id+'.json.gz';if(!fs.existsSync(path))continue;
 const data=JSON.parse(zlib.gunzipSync(fs.readFileSync(path))),m=new MapModel(data),p=newPlan(id);
 p.settings.allowZoneWalljumps=false;p.settings.usePassStructures=false;p.settings.useCrusaderStructures=false;
 const edge=Object.values(m.groundAccess.nav.passes).find(z=>z.length===2).map(z=>zoneId(m.groundAccess,z));
 const directions=[{side:'ours',allianceId:'a1',from:edge[0],to:edge[1]},{side:'enemy',allianceId:'__war_enemy__',from:edge[1],to:edge[0]}];
 // Only the historical comparison bypasses its incorrect authorization gate.
 const oldModel=new MapModel(data);oldModel.groundAccess.walljumpError=()=>null;
 let t=performance.now();const old=reference(oldModel,p,directions);const oldMs=performance.now()-t;
 t=performance.now();const current=searchWarJumps(m,p,directions);const newMs=performance.now()-t;
 assert.deepEqual(geometry(current),geometry(old),'optimization preserves every transition, smallest building and chosen position');
 assert.equal(current.passCaptureRequired,false);assert.equal(current.passContactRequired,false);
 assert.ok(current.directions.every(d=>d.pairs.length>0),'both anonymous directions work without any pass contact');
 for(const d of current.directions)for(const q of d.pairs)assert.equal(warPairError(m,q.source,q.target,d.from,d.to),null);
 const ours=displayedWarPairs(current,{ours:true,enemy:false}),enemy=displayedWarPairs(current,{ours:false,enemy:true});assert.ok(ours.length&&enemy.length);assert.ok(ours.every(q=>q.side==='ours'));assert.ok(enemy.every(q=>q.side==='enemy'));assert.equal(ours.length+enemy.length,displayedWarPairs(current).length);assert.equal(displayedWarPairs(current,{ours:false,enemy:false}).length,0);assert.ok(displayedWarPairs(current,{ours:false,enemy:true,fortress:false}).every(q=>q.side==='enemy'&&q.kind==='flag'));
 assert.equal(p.buildings.length,0);assert.deepEqual(p.capturedPasses,{});
 results.push({map:id,oldMs:Math.round(oldMs),newMs:Math.round(newMs),speedup:Number((oldMs/newMs).toFixed(2)),pairs:current.directions.map(d=>d.pairs.length)});
 console.log(JSON.stringify(results.at(-1)));
}
assert.equal(results.length,2);assert.ok(results.reduce((n,r)=>n+r.newMs,0)<results.reduce((n,r)=>n+r.oldMs,0)*.8,'representative real-map searches must improve by at least 20% in total');
assert.ok(!('enemyAlliance' in warConfig({enemyAlliance:'old-alliance'})),'old imported enemy selector is discarded');
const html=fs.readFileSync('web/index.html','utf8'),ui=fs.readFileSync('web/war-builder-ui.js','utf8');
assert.ok(!html.includes('warEnemy')&&!ui.includes('enemyAlliance'));
assert.ok(ui.includes("allianceId:'__war_enemy__'"));
assert.ok(ui.includes('this.cachedWorker=completed')&&ui.includes('this.cachedWorker?.terminate()'),'reuse completed worker; reset releases it');
assert.ok(ui.includes('if(this.result)this.referenceStale=true'),'manual building preserves completed tactical overlays');
for(const lang of ['en','fr']){
 globalThis.localStorage={getItem:()=>lang};const {translate}=await import('../web/i18n.js?war310='+lang);
 assert.notEqual(translate('Kein eroberter Pass oder Passkontakt nötig.'),'Kein eroberter Pass oder Passkontakt nötig.');
}
// Exercise the real classic-worker module twice, then change the plan and map.
const n=180,w=n+1,labels=new Uint16Array(w*w),mask=new Uint8Array(w*w);
for(let v=0;v<w;v++)for(let x=0;x<w;x++){const y=n-v,i=v*w+x;labels[i]=y<88?1:y>92?2:0;mask[i]=labels[i]?0:255;}
const data={catalog:{map:'warm',nativeMapSize:n,bounds:[0,0,n,n],structureRules:{},buildings:{flag:{limit:500},fortress:{limit:2}}},sites:[],resources:[],definitions:[],instances:[],terrain15:{hatching:Buffer.from(mask).toString('base64'),hatchingWidth:w,hatchingHeight:w},navigation18:{width:w,height:w,regions:Buffer.from(labels.buffer).toString('base64'),passes:{}}};
const moduleURL=new URL('../web/war-builder.worker.js',import.meta.url).href;
const wrapper=`const {parentPort,workerData}=require('node:worker_threads');globalThis.self=globalThis;globalThis.postMessage=m=>parentPort.postMessage(m);globalThis.fetch=async url=>({ok:true,json:async()=>url.includes('/landmarks/')?[]:workerData});import(${JSON.stringify(moduleURL)}).then(()=>parentPort.on('message',data=>self.onmessage({data})));`;
const worker=new Worker(wrapper,{eval:true,workerData:data});
const run=(plan)=>new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(Error('worker timed out')),10000);const handler=m=>{if(m.progress)return;clearTimeout(timeout);worker.off('message',handler);if(m.error)reject(Error(m.error));else resolve(m.result);};worker.on('message',handler);worker.once('error',reject);worker.postMessage({plan,directions:[{side:'ours',allianceId:'a1',from:1,to:2}]});});
try{
 const p=newPlan('warm');p.settings.allowZoneWalljumps=false;
 const cold=await run(p),warm=await run(p);assert.equal(cold.timing.reusedMap,false);assert.equal(warm.timing.reusedMap,true);assert.deepEqual(geometry(cold),geometry(warm));
 const edited=structuredClone(p);edited.settings.strict=true;const changed=await run(edited);assert.equal(changed.timing.reusedMap,true);assert.ok(changed.directions[0].pairs.length<cold.directions[0].pairs.length,'warm model applies changed strict settings');
 const resized=structuredClone(p);resized.settings.flagRadius=3;const resizedResult=await run(resized);assert.equal(resizedResult.timing.reusedMap,true);assert.notDeepEqual(geometry(resizedResult),geometry(cold),'real cached worker applies changed flag radii');
 const other=structuredClone(p);other.map='other';assert.equal((await run(other)).timing.reusedMap,false,'map changes rebuild terrain');
 results.push({worker:{coldMs:cold.timing.milliseconds,warmMs:warm.timing.milliseconds,updatedSettings:true,mapChange:true}});
}finally{await worker.terminate();}
fs.mkdirSync('analysis/war310',{recursive:true});fs.writeFileSync('analysis/war310/performance.json',JSON.stringify({passed:true,results},null,2));
console.log('3.1: exhaustive geometric search, no pass prerequisite, anonymous enemy and warm worker verified');
