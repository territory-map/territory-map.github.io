import assert from 'node:assert/strict';
import fs from 'node:fs';import zlib from 'node:zlib';
import {MapModel,newPlan} from '../web/core/model.js';
import {zoneInventory,warCellIndex,warPairError,searchWarJumps} from '../web/core/war-builder.js';
import {filledZoneRegions,zoneId,warZoneAt,normalizeWarZones} from '../web/core/war-zone-mask.js';
import {displayedWarPairs} from '../web/core/war-display.js';
import {WAR_ZONE_CATALOG} from '../web/core/zone-catalog450.js';
const read=name=>JSON.parse(zlib.gunzipSync(fs.readFileSync('assets/solver/'+name+'.json.gz')));
const maps=[];
for(const [name,entry]of Object.entries(WAR_ZONE_CATALOG)){
 const data=read(name),m=new MapModel(data),a=m.groundAccess,n=a.nav;
 const original=Buffer.from(a.regions.buffer).toString('base64');
 assert.equal(original,n.regions,name+' raw walking components unchanged');
 const ids=new Set(Object.values(entry.regions)),inventory=zoneInventory(a);
 assert.deepEqual([...inventory.keys()].sort((a,b)=>a-b),[...ids].sort((a,b)=>a-b));
 for(const [raw,zone]of Object.entries(entry.regions)){
  assert.ok(zone>0);assert.equal(zoneId(a,zone),zone,'canonical zone IDs must be fixed points');
  assert.equal(zoneId(a,Number(raw)),zone);
 }
 for(const [pass,edges]of Object.entries(n.passes))if(edges.length===2)assert.notEqual(zoneId(a,edges[0]),zoneId(a,edges[1]),name+' real exit '+pass);
 // Fill/hit-testing includes land hills, walls and structure relief, while
 // exact construction/navigation arrays are never relaxed by this operation.
 const fill=filledZoneRegions(a);assert.equal(filledZoneRegions(a),fill,'reuse one selection mask');
 const selected=[];
 for(let i=0;i<a.regions.length;i+=137){
  const raw=a.regions[i];if(raw)assert.equal(fill[i],(a.zoneWater?.[i>>3]&(128>>(i&7)))?0:zoneId(a,raw));
  else if(selected.length<3){
   const u=i%n.width,v=Math.floor(i/n.width),[l,b,r,t]=a.bounds;
   const x=l+u*(r-l)/(n.width-1),y=t-v*(t-b)/(n.height-1);
   if(x>=0&&y>=0&&x<=data.catalog.nativeMapSize&&y<=data.catalog.nativeMapSize){
    assert.equal(warZoneAt(a,x,y),0,'blocked ground is not a candidate');
    assert.equal(warZoneAt(a,x,y,true),fill[i],'hatched ground can select its zone');selected.push({x,y,zone:fill[i]});
   }
  }
 }
 assert.equal(Buffer.from(a.regions.buffer).toString('base64'),original,'zone picking must not mutate gameplay navigation');
 assert.equal(warZoneAt(a,-10000,-10000,true),0);
 maps.push({map:name,walkingRegions:Object.keys(entry.regions).length,zones:ids.size,passes:Object.keys(n.passes).length,hatchedSelections:selected});
}
assert.equal(maps.length,21);
// Sparse zero padding must not turn the Nile's separately walled,
// explicitly forbidden temple provinces into the distant outer province.
const nile=WAR_ZONE_CATALOG.LostLand_Map_9_2_v2.regions;
assert.equal(new Set([nile[1],nile[8],nile[19],nile[30]]).size,4);
// User's central Shifting Gears enclosure: upper L, lower L and central
// temple/pocket all have province 16 and ONE outer wall with exit passes.
const data=read('LostLand_Map_18_v2'),m=new MapModel(data),a=m.groundAccess,p=newPlan(data.catalog.map);
for(const fragment of [10,12,13,18])assert.equal(zoneId(a,fragment),10);
assert.equal(zoneId(a,4),4);assert.equal(zoneId(a,5),5);assert.equal(zoneId(a,15),15);assert.equal(zoneId(a,16),16);
const centers={};for(const z of [10,12,13,18]){
 const i=a.regions.findIndex(v=>v===z),u=i%a.nav.width,v=Math.floor(i/a.nav.width),[l,b,r,t]=a.bounds;
 centers[z]=[l+u*(r-l)/(a.nav.width-1),t-v*(t-b)/(a.nav.height-1)];assert.equal(warZoneAt(a,...centers[z],true),10);
}
const old={visible:true,enemyAlliance:'',ourZone:13,ourTarget:10,enemyZone:18,enemyTarget:5},migration=normalizeWarZones(a,old);
assert.equal(migration.ourZone,10);assert.equal(migration.ourTarget,0);assert.equal(migration.enemyZone,0);assert.equal(migration.enemyTarget,5);
assert.deepEqual(normalizeWarZones(a,migration),migration);assert.equal(old.ourZone,13);
const same=searchWarJumps(m,p,[{side:'ours',allianceId:'a1',from:10,to:10}]);assert.equal(same.directions[0].pairs.length,0,'no fake internal zone border jumps');
// The search index must include lower/upper fragments after merging, not
// merely paint them alike. All constituent floor pixels contribute cells.
m.setPlan(p);const cells=warCellIndex(m,new Set([10]));
for(const point of Object.values(centers))assert.ok(cells.get(Math.floor(point[0]/18)+':'+Math.floor(point[1]/18))?.zones.has(10));
const sample={directions:[{pairs:[{id:'f',kind:'flag'},{id:'s',kind:'fortress'},{id:'m',kind:'center-fortress'}]}]};
assert.deepEqual(displayedWarPairs(sample,{flag:true,fortress:false}).map(q=>q.id),['f']);
assert.deepEqual(displayedWarPairs(sample,{flag:false,fortress:true}).map(q=>q.id),['s','m']);
assert.equal(displayedWarPairs(sample,{flag:true,fortress:true}).length,3);
assert.equal(displayedWarPairs(sample,{flag:false,fortress:false}).length,0);
assert.equal(sample.directions[0].pairs.length,3,'filter toggles preserve complete result');
for(const lang of ['en','fr']){
 globalThis.localStorage={getItem:()=>lang};const {translate}=await import('../web/i18n.js?zones270='+lang);
 for(const text of ['Allianzflagge reicht','Allianzfestung benötigt','Keine Sprungart eingeblendet.','Bitte innerhalb der Karte eine Zone anklicken.'])assert.notEqual(translate(text),text);
}
fs.mkdirSync('analysis/zones270',{recursive:true});fs.writeFileSync('analysis/zones270/regression.json',JSON.stringify({passed:true,maps,centralFragments:[10,12,13,18],centralZone:10,centers,filters:['both','flag only','fortress only','neither'],navigationUnchanged:true,legacySelectionsMigrated:true},null,2));
console.log('2.7.0: all 21 zone topologies, all exit passes, hatched selection, central enclosure, migrated plans, complete grouped search and independent filters passed');
