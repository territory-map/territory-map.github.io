import assert from 'node:assert/strict';
import fs from 'node:fs';
import zlib from 'node:zlib';
import {MapModel,newPlan} from '../web/core/model.js';
import {WAR_ZONE_CATALOG} from '../web/core/zone-catalog450.js';
import {WAR_ZONE_CATALOG as previous} from '../web/core/zone-catalog270.js';
import {zoneId,warZoneAt,normalizeWarZones,filledZoneRegions} from '../web/core/war-zone-mask.js';
import {warCellIndex,searchWarJumps,warPairError} from '../web/core/war-builder.js';
const inventory=JSON.parse(fs.readFileSync('analysis/zones450/inventory.json'));
assert.equal(inventory.maps.length,21);assert.ok(inventory.passed);
const read=(slug,source)=>JSON.parse(zlib.gunzipSync(fs.readFileSync(`assets/${source}/${slug}.json.gz`)));
let passCount=0;const maps=[];
for(const [slug,entry] of Object.entries(WAR_ZONE_CATALOG)){
 const d=read(slug,'solver'),full=read(slug,'data');
 assert.equal(d.navigation18.regions,full.navigation18.regions);
 const m=new MapModel(d),a=m.groundAccess,original=Buffer.from(a.regions.buffer).toString('base64');
 for(const [z,q] of Object.entries(entry.regions)){
  assert.equal(zoneId(a,Number(z)),q);assert.equal(zoneId(a,q),q);
  const c=normalizeWarZones(a,{ourZone:Number(z),ourTarget:q,enemyZone:0,enemyTarget:0});assert.equal(c.ourZone,q);assert.equal(c.ourTarget,0);assert.deepEqual(normalizeWarZones(a,c),c);
 }
 for(const ends of Object.values(d.navigation18.passes)){assert.equal(ends.length,2);assert.notEqual(zoneId(a,ends[0]),zoneId(a,ends[1]),slug+' pass boundary preserved');passCount++;}
 const zones=new Set(Object.values(entry.regions));
 if(slug.startsWith('Sever_'))assert.equal(zones.size,10);
 else assert.deepEqual(entry.regions,previous[slug].regions,'native province identity retained');
 assert.equal(Buffer.from(a.regions.buffer).toString('base64'),original,'walking navigation unchanged');
 maps.push({map:slug,zones:zones.size,passes:Object.keys(d.navigation18.passes).length});
}
const groups={Sever_Map_G1_1_v2:[[4,6,8],[5,11,12],[10,14,16,17]],Sever_Map_G1_2_v2:[[4,7,8],[5,6,10],[15,16,18]],Sever_Map_G1_3_v2:[[3,4,14],[5,6,7],[11,12,13]],Sever_Map_G1_4_v2:[[4,5],[6,9,16],[8,11,12,14]]};
for(const [slug,merged] of Object.entries(groups)){
 const d=read(slug,'solver'),m=new MapModel(d),a=m.groundAccess,fill=filledZoneRegions(a),p=newPlan(slug);m.setPlan(p);
 const wanted=new Set(merged.map(g=>zoneId(a,g[0]))),cells=warCellIndex(m,wanted);
 for(const group of merged)for(const raw of group){
  const zone=zoneId(a,group[0]);assert.equal(zoneId(a,raw),zone);
  const i=a.regions.findIndex(v=>v===raw);assert.ok(i>=0);assert.equal(fill[i],zone);
  const u=i%a.nav.width,v=Math.floor(i/a.nav.width),[l,b,r,t]=a.bounds;
  const x=l+u*(r-l)/(a.nav.width-1),y=t-v*(t-b)/(a.nav.height-1);
  assert.equal(warZoneAt(a,x,y),zone);
  assert.ok(cells.get(Math.floor(x/18)+':'+Math.floor(y/18))?.zones.has(zone),'search includes every merged fragment');
 }
 const from=merged[0][0],to=merged[0][1];
 const result=searchWarJumps(m,p,[{side:'ours',allianceId:'a1',from,to}]);
 assert.equal(result.directions[0].from,result.directions[0].to);assert.equal(result.directions[0].pairs.length,0);assert.equal(result.checked,0,'no fake internal jump search');
 assert.match(warPairError(m,{},{},from,to),/verschiedene Zonen/);
}
const result={passed:true,maps,exitPassesChecked:passCount,correctedMaps:Object.keys(groups),mergedFragments:groups,legacySelectionsCanonicalized:true,searchUsesCompleteZones:true,collisionNavigationUnchanged:true};
fs.writeFileSync('analysis/zones450/regression.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
