import fs from 'node:fs';
import {newPlan} from '../web/core/model.js';
const plan=newPlan('LostLand_Map_18_v2');
plan.settings.allowZoneWalljumps=false;plan.settings.usePassStructures=false;plan.settings.useCrusaderStructures=false;
plan.warBuilder={visible:true,ourZone:4,ourTarget:10,enemyZone:10,enemyTarget:4,enemyAlliance:'obsolete'};
fs.mkdirSync('analysis/war310',{recursive:true});fs.writeFileSync('analysis/war310/browser-plan.json',JSON.stringify(plan,null,2));
const populated=JSON.parse(fs.readFileSync('analysis/router300/war-browser-plan.json'));
populated.settings.allowZoneWalljumps=false;populated.settings.usePassStructures=false;populated.settings.useCrusaderStructures=false;populated.capturedPasses={};populated.warBuilder=plan.warBuilder;
fs.writeFileSync('analysis/war310/browser-populated.json',JSON.stringify(populated,null,2));
