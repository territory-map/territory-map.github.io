"""Static-only preview. Intentionally has no JSON rewriting or server API."""
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
import argparse,webbrowser,mimetypes

root=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser()
parser.add_argument('--port',type=int,default=8895)
parser.add_argument('--prefix',default='/territory-lab/')
parser.add_argument('--open',action='store_true')
args=parser.parse_args()
prefix='/'+args.prefix.strip('/')+'/' if args.prefix.strip('/') else '/'
mimetypes.add_type('text/javascript','.js')
mimetypes.add_type('text/javascript','.mjs')

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*a,**kw):super().__init__(*a,directory=str(root),**kw)
    def translate_path(self,path):
        return super().translate_path(path[len(prefix)-1:])
    def do_GET(self):
        if not urlsplit(self.path).path.startswith(prefix):
            if urlsplit(self.path).path==prefix.rstrip('/'):
                self.send_response(301);self.send_header('Location',prefix);self.end_headers();return
            self.send_error(404);return
        super().do_GET()
    def do_HEAD(self):
        if not urlsplit(self.path).path.startswith(prefix):self.send_error(404);return
        super().do_HEAD()
    def log_message(self,fmt,*values):
        if len(values)>1 and str(values[1])!='200':super().log_message(fmt,*values)

server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
url=f'http://127.0.0.1:{server.server_port}{prefix}'
print(url,flush=True)
if args.open:webbrowser.open(url)
try:server.serve_forever()
except KeyboardInterrupt:pass
finally:server.server_close()
