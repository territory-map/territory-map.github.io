import subprocess,json,time, pathlib
root=pathlib.Path('.')
suites=json.loads((root/'package.json').read_text())['scripts']['test'].split(' && ')
node=r'C:/Users/andre/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
out=root/'analysis/router300';out.mkdir(exist_ok=True)
results=[]
with (out/'test-log.txt').open('w',encoding='utf-8') as log:
 for suite in suites:
  start=time.time()
  try:
   r=subprocess.run([node,suite.removeprefix('node ')],capture_output=True,text=True,encoding='utf-8',timeout=180)
   text=r.stdout+r.stderr;ok=r.returncode==0
  except subprocess.TimeoutExpired as e:
   text='TIMEOUT';ok=False
  log.write(suite+'\n'+text+'\n');log.flush()
  item={'suite':suite,'passed':ok,'seconds':round(time.time()-start,2)};results.append(item)
  print(json.dumps(item),flush=True)
 (out/'test-results.json').write_text(json.dumps({'passed':all(r['passed'] for r in results),'suites':results},indent=2),encoding='utf-8')
