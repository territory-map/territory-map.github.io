const {chromium}=require('playwright');
const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const root=path.resolve(__dirname,'..');
const base=process.env.TERRITORY_LAB_URL||'http://127.0.0.1:8895/territory-lab/';
const report={passed:false,errors:[],httpErrors:[],checks:[]};
const write=()=>fs.writeFileSync(path.join(root,'verification/browser-extra-results.json'),JSON.stringify(report,null,2));
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});page.setDefaultTimeout(180000);
 page.on('pageerror',e=>report.errors.push(e.message));page.on('response',r=>{if(r.status()>=400)report.httpErrors.push({url:r.url(),status:r.status()});});
 let solverRequests=0;page.on('request',r=>{if(r.url().includes('/assets/solver/'))solverRequests++;});
 try{
  await page.goto(base);await page.waitForFunction(()=>document.querySelector('#viewport')?.dataset.mapReady);
  const seeded=await page.evaluate(async base=>{
   const {loadJSON}=await import(base+'web/pages-runtime.js'),{MapModel,newPlan}=await import(base+'web/core/model.js');
   const {zoneId}=await import(base+'web/core/war-zone-mask.js'),{warConfig}=await import(base+'web/core/war-builder.js');
   const data=await loadJSON('/assets/solver/LostLand_Map_18_v2.json'),model=new MapModel(data);
   const edge=Object.values(model.groundAccess.nav.passes).find(z=>z.length===2).map(z=>zoneId(model.groundAccess,z));
   const p=newPlan('LostLand_Map_18_v2');p.warBuilder={...warConfig(),ourZone:edge[0],ourTarget:edge[1],enemyZone:edge[1],enemyTarget:edge[0]};
   localStorage.setItem('territory-lab-independent:'+p.map,JSON.stringify(p));return {edge,plan:p};
  },base);
  await page.reload();await page.waitForFunction(()=>document.querySelector('#viewport')?.dataset.mapReady);
  const loadedPlan=await page.evaluate(()=>JSON.parse(localStorage.getItem('territory-lab-independent:LostLand_Map_18_v2')));
  await page.locator('#warBuilder > summary').click();
  await page.locator('#warCalculate').click();await page.locator('#warCancel').click();
  assert.equal(await page.locator('#warCalculate').isEnabled(),true);assert.equal(await page.locator('#warCancel').isVisible(),false);
  report.checks.push('Kriegsbauer abbrechen und erneut starten');
  await page.locator('#warCalculate').click();
  await page.waitForFunction(()=>!document.querySelector('#warCalculate').disabled&&document.querySelector('#warCancel').hidden);
  assert.ok(await page.locator('#warPairs button').count()>0,await page.locator('#warResult').innerText());
  report.war={zones:seeded.edge,result:await page.locator('#warResult').innerText(),visiblePairs:await page.locator('#warPairs button').count()};
  assert.deepEqual(await page.evaluate(()=>JSON.parse(localStorage.getItem('territory-lab-independent:LostLand_Map_18_v2'))),loadedPlan);
  const before=solverRequests;await page.locator('#warCalculate').click();
  await page.waitForFunction(()=>!document.querySelector('#warCalculate').disabled&&document.querySelector('#warCancel').hidden);
  assert.equal(solverRequests,before,'warm cached worker must reuse map');
  await page.locator('#warShowOurs').uncheck();await page.locator('#warShowEnemy').uncheck();assert.equal(await page.locator('#warPairs button').count(),0);
  await page.locator('#warShowOurs').check();assert.ok(await page.locator('#warPairs button').count()>0);
  report.checks.push('Echter Kriegsbauer-Worker, beide Richtungen, Filter, Wiederverwendung und unveränderter Plan');
  await page.screenshot({path:path.join(root,'verification/Kriegsbauer.png')});write();console.log('PASS echter Kriegsbauer');
  for(const version of ['255','256']){
   await page.goto(base+'web/terrain-audit'+version+'.html?localExport=1');await page.waitForLoadState('networkidle');
   await page.locator('#one').click();await page.waitForFunction(()=>document.body.dataset.complete==='1'||document.body.dataset.error);
   assert.equal(await page.locator('body').getAttribute('data-error'),null);
   const pending=page.waitForEvent('download');await page.locator('#export').click();const d=await pending;
   const output=path.join(root,'verification/Terrain-Audit-'+version+'.json');await d.saveAs(output);
   const result=JSON.parse(fs.readFileSync(output,'utf8'));assert.equal(result.maps.length,1);assert.ok(result.maps[0].images);assert.ok(result.maps[0].metrics);
   report.checks.push('Terrain-Prüfung '+version+' und vollständiger Download auch mit localExport=1');write();console.log('PASS Terrain-Prüfung '+version);
  }
  assert.deepEqual(report.errors,[]);assert.deepEqual(report.httpErrors,[]);report.passed=true;write();console.log('EXTRA BROWSER PASS');
 }catch(e){report.failure=e.stack;write();console.error(e);process.exitCode=1;}
 finally{await browser.close();}
})();
