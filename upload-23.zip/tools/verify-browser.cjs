const {chromium}=require('playwright');
const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const root=path.resolve(__dirname,'..');
const base=process.env.TERRITORY_LAB_URL||'http://127.0.0.1:8895/territory-lab/';
const report={passed:false,maps:[],errors:[],httpErrors:[],checks:[]};
const functionsOnly=process.argv.includes('--functions');
if(functionsOnly)report.maps=JSON.parse(fs.readFileSync(path.join(root,'verification/browser-results.json'),'utf8')).maps;
const write=()=>fs.writeFileSync(path.join(root,'verification/browser-results.json'),JSON.stringify(report,null,2));
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const context=await browser.newContext({viewport:{width:1440,height:1000},acceptDownloads:true});
 const page=await context.newPage();page.setDefaultTimeout(180000);
 page.on('pageerror',e=>report.errors.push(e.message));
 page.on('console',msg=>{if(msg.type()==='error')report.errors.push(msg.text());});
 page.on('response',r=>{if(r.status()>=400)report.httpErrors.push({url:r.url(),status:r.status()});});
 const check=(name)=>{report.checks.push(name);write();console.log('PASS '+name);};
 try{
  await page.goto(base);
  await page.waitForFunction(()=>document.querySelector('#viewport')?.dataset.mapReady==='LostLand_Map_18_v2');
  assert.equal(await page.locator('#map option').count(),21);
  check('Startseite, Unteradresse, komprimierte Daten und 21 Kartenauswahlen');
  const maps=JSON.parse(fs.readFileSync(path.join(root,'assets/maps.json'),'utf8')).maps;
  for(const map of functionsOnly?[]:maps){
   if(await page.locator('#map').inputValue()!==map.map){await page.locator('#map').selectOption(map.map);await page.waitForFunction(slug=>document.querySelector('#viewport')?.dataset.mapReady===slug,map.map);}
   await page.waitForLoadState('networkidle');
   assert.equal(await page.locator('#loading').isVisible(),false);
   await page.locator('#mode3').click();await page.waitForTimeout(300);
   assert.match(await page.locator('#mode3').getAttribute('class'),/active/);
   if(map.map==='LostLand_Map_18_v2')await page.screenshot({path:path.join(root,'verification/Ansicht-3D.png')});
   await page.locator('#mode2').click();await page.waitForTimeout(150);
   assert.match(await page.locator('#mode2').getAttribute('class'),/active/);
   if(map.map==='LostLand_Map_18_v2')await page.screenshot({path:path.join(root,'verification/Ansicht-2D.png')});
   report.maps.push({map:map.map,name:map.name,loaded:true,view2D:true,view3D:true});write();console.log('PASS Karte '+map.map);
  }
  // Use the same known free corridor validated by the original maps suite.
  const corridor=JSON.parse(fs.readFileSync(path.join(root,'tests/verification.json'),'utf8')).actualMapRoutes.find(m=>m.map==='LostLand_Map_18_v2');
  const seeded=await page.evaluate(async({base,corridor})=>{
   const {newPlan}=await import(base+'web/core/model.js');
   const p=newPlan(corridor.map);p.buildings=[{id:'test-fort',kind:'fortress',...corridor.start,allianceId:'a1'}];p.targets=[{id:'test-target',x:corridor.target.x,y:corridor.target.y}];p.settings.flagBudget=12;
   localStorage.setItem('territory-lab-independent:'+p.map,JSON.stringify(p));return p;
  },{base,corridor});
  await page.reload();await page.waitForFunction(()=>document.querySelector('#viewport')?.dataset.mapReady==='LostLand_Map_18_v2');
  assert.equal(await page.locator('#budget').inputValue(),'12');
  await page.locator('#solve').click();
  await page.waitForFunction(()=>!document.querySelector('#accept').hidden||(!document.querySelector('#solve').disabled&&document.querySelector('#cancel').hidden));
  assert.equal(await page.locator('#accept').isVisible(),true,await page.locator('#solverResult').innerText());
  await page.locator('#accept').click();
  let plan=await page.evaluate(()=>JSON.parse(localStorage.getItem('territory-lab-independent:LostLand_Map_18_v2')));
  assert.ok(plan.buildings.length>1);assert.equal(plan.targets.length,0);
  check('Echter Solver-Worker lädt .gz, berechnet Route und übernimmt gültige Flaggen');
  await page.locator('#undo').click();
  plan=await page.evaluate(()=>JSON.parse(localStorage.getItem('territory-lab-independent:LostLand_Map_18_v2')));
  assert.equal(plan.buildings.length,1);assert.equal(plan.targets.length,1);
  await page.locator('#redo').click();check('Rückgängig und Wiederholen');
  await page.locator('#addAlliance').click();assert.equal(await page.locator('#alliance option').count(),2);
  await page.locator('#allianceName').fill('Web-Test-Allianz');await page.locator('#allianceName').dispatchEvent('change');
  await page.locator('#createCoalition').click();
  await page.locator('#coalitionName').fill('Web-Test-Koalition');
  for(const checkbox of await page.locator('#coalitionMembers input[type=checkbox]').all())await checkbox.check();
  await page.locator('#coalitionForm button[type=submit]').click();
  check('Allianzen und Koalitionen');
  await page.locator('#language').selectOption('en');await page.locator('#language').selectOption('fr');await page.locator('#language').selectOption('de');
  check('Deutsch, Englisch und Französisch');
  const saved=await page.evaluate(()=>JSON.parse(localStorage.getItem('territory-lab-independent:LostLand_Map_18_v2')));
  const downloadPromise=page.waitForEvent('download');await page.locator('#export').click();const download=await downloadPromise;
  const exportPath=path.join(root,'verification/Browser-Testplan.json');await download.saveAs(exportPath);
  assert.deepEqual(JSON.parse(fs.readFileSync(exportPath,'utf8')),saved);
  await page.locator('#file').setInputFiles(exportPath);
  await page.waitForTimeout(250);
  assert.deepEqual(await page.evaluate(()=>JSON.parse(localStorage.getItem('territory-lab-independent:LostLand_Map_18_v2'))),saved);
  await page.reload();await page.waitForFunction(()=>document.querySelector('#viewport')?.dataset.mapReady==='LostLand_Map_18_v2');
  assert.deepEqual(await page.evaluate(()=>JSON.parse(localStorage.getItem('territory-lab-independent:LostLand_Map_18_v2'))),saved);
  check('Planexport, Planimport und dauerhafte Browserspeicherung');
  await page.locator('.export-menu summary').click();
  for(const [selector,label]of [['#excel','Excel-Gesamtkarte'],['#excelVisible','Excel-Ausschnitt'],['#shotVisible','PNG-Ausschnitt'],['#shot','PNG-Gesamtkarte']]){
   const pending=page.waitForEvent('download');await page.locator(selector).click();const d=await pending;
   const dest=path.join(root,'verification/'+label+(label.startsWith('Excel')?'.xlsx':'.png'));await d.saveAs(dest);assert.ok(fs.statSync(dest).size>100);check(label);
  }
  // Verify actual web worker war search with original warm-cache synthetic map
  // is covered by war310; here confirm real map data and landmarks load online.
  const warData=await page.evaluate(async base=>{
   const {loadJSON}=await import(base+'web/pages-runtime.js');
   const {MapModel,newPlan}=await import(base+'web/core/model.js');
   const {filledZoneRegions}=await import(base+'web/core/war-zone-mask.js');
   const data=await loadJSON('/assets/solver/LostLand_Map_18_v2.json');data.landmarks=await loadJSON('/assets/landmarks/LostLand_Map_18_v2.json');
   const model=new MapModel(data),zones=filledZoneRegions(model.groundAccess);return {sites:model.sites.length,landmarks:data.landmarks.length,zonesType:typeof zones};
  },base);
  assert.ok(warData.sites>0);check('Kriegsbauer-Kartendaten und Strukturen über statisches Hosting');
  for(const file of ['model-review.html','map-audit.html','terrain-audit255.html','terrain-audit256.html','visual-review.html']){
   await page.goto(base+'web/'+file);await page.waitForLoadState('networkidle');
   if(file==='map-audit.html')await page.waitForFunction(()=>document.querySelector('#all')&&!document.querySelector('#all').disabled);
   if(file==='visual-review.html')await page.waitForFunction(()=>document.body.dataset.ready);
   check('Zusatzseite '+file);
  }
  assert.deepEqual(report.httpErrors,[],'Alle Dateipfade müssen erfolgreich laden');
  assert.deepEqual(report.errors,[],'Keine Browser- oder WebGL-Fehler');
  report.passed=true;write();console.log('BROWSER PASS');
 }catch(e){report.failure=e.stack;write();console.error(e);process.exitCode=1;}
 finally{await browser.close();}
})();
