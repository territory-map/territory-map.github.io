import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
process.chdir(root);
const allScripts=JSON.parse(fs.readFileSync('package.json','utf8')).scripts.test.split(' && ').map(s=>s.replace(/^node /,''));
const rerun=process.argv.includes('--failed');
const results=rerun?JSON.parse(fs.readFileSync('verification/core-results.json','utf8')).results:[];
const scripts=rerun?allScripts.filter(s=>results.some(r=>r.test===path.basename(s)&&!r.passed)):allScripts;
fs.mkdirSync('verification',{recursive:true});
for(const script of scripts){
 const started=Date.now(),run=spawnSync(process.execPath,[script],{cwd:root,encoding:'utf8',timeout:240000,maxBuffer:10*1024*1024});
 const name=path.basename(script),passed=run.status===0;
 fs.writeFileSync('verification/'+name+'.log',(run.stdout||'')+(run.stderr||'')+(run.error?'\n'+run.error:''));
 const result={test:name,passed,seconds:Math.round((Date.now()-started)/100)/10},index=results.findIndex(r=>r.test===name);
 if(index<0)results.push(result);else results[index]=result;
 console.log((passed?'PASS ':'FAIL ')+name);
 fs.writeFileSync('verification/core-results.json',JSON.stringify({passed:results.every(r=>r.passed),completed:results.length,total:allScripts.length,results},null,2));
}
console.log(JSON.stringify({passed:results.every(r=>r.passed),tests:results.length,failed:results.filter(r=>!r.passed).map(r=>r.test)}));
if(results.some(r=>!r.passed))process.exitCode=1;
