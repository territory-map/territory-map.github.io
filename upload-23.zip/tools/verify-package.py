"""Check all original assets, required files and the actual Pages size."""
from pathlib import Path
import hashlib,json,re,gzip

root=Path(__file__).resolve().parent.parent
manifest=json.loads((root/'asset-manifest.json').read_text(encoding='utf-8'))
errors=[]
for item in manifest['files']:
    file=root/item['path']
    if not file.is_file():errors.append('Fehlt: '+item['path']);continue
    if file.stat().st_size!=item['bytes']:errors.append('Größe verändert: '+item['path']);continue
    with file.open('rb') as stream:
        digest=hashlib.file_digest(stream,'sha256').hexdigest()
    if digest!=item['sha256']:errors.append('Inhalt verändert: '+item['path'])
maps=json.loads((root/'assets/maps.json').read_text(encoding='utf-8'))['maps']
if len(maps)!=21:errors.append('Es müssen alle 21 Originalkarten vorhanden sein.')
for item in maps:
    slug=item['map']
    required=[f'assets/data/{slug}.json.gz',f'assets/solver/{slug}.json.gz',f'assets/landmarks/{slug}.json',f'assets/maps/{slug}.webp',f'assets/thumbs/{slug}.webp',f'assets/terrain/{slug}-height.png',f'assets/terrain/{slug}-ground.webp']
    required += [f'assets/audit255/{slug}-{kind}' for kind in ('contours.json','edge.png','letters.png','reference.png')]
    required += [f'assets/audit256/{slug}-contours.json']
    for rel in required:
        if not (root/rel).is_file():errors.append('Fehlt: '+rel)
    # Catalog is the first JSON member. Decode just that member, keeping huge
    # resources/instance arrays out of this deployment integrity check.
    with gzip.open(root/f'assets/data/{slug}.json.gz','rt',encoding='utf-8') as stream:
        head=stream.read(524288)
    first=re.match(r'\s*\{\s*"catalog"\s*:\s*',head)
    if not first:errors.append('Kartenkatalog fehlt: '+slug);continue
    catalog,_=json.JSONDecoder().raw_decode(head[first.end():])
    def paths(value):
        if isinstance(value,dict):
            for child in value.values():yield from paths(child)
        elif isinstance(value,list):
            for child in value:yield from paths(child)
        elif isinstance(value,str) and value.startswith('/assets/'):yield value.lstrip('/')
    for rel in paths(catalog):
        if not (root/rel).is_file():errors.append('Katalogdatei fehlt: '+rel)
files=[root/'index.html',root/'.nojekyll']+list(root.glob('LICENSE-*'))
for folder in ('web','assets'):files.extend(p for p in (root/folder).rglob('*') if p.is_file())
size=sum(p.stat().st_size for p in files)
if size>1_000_000_000:errors.append('Veröffentlichung überschreitet 1 GB.')
summary={'passed':not errors,'maps':len(maps),'originalAssets':len(manifest['files']),'originalAssetsUnchanged':not any('verändert' in e or e.startswith('Fehlt:') for e in errors),'publishedBytes':size,'publishedMiB':round(size/1024**2,2),'errors':errors}
(root/'verification').mkdir(exist_ok=True)
(root/'verification/package-results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
if errors:raise SystemExit(1)
