// Restore only detected letter pixels. Map bounds, terrain masks and meshes are
// untouched. Unmasked source pixels remain byte-for-byte identical.
export function restoreLetterPixels(source,mask,width,height){
 const result=new Uint8ClampedArray(source),positions=[];
 for(let i=0;i<width*height;i++)if(mask[i*4]>127)positions.push(i);
 for(const i of positions){
  const x=i%width,y=Math.floor(i/width),sum=[0,0,0];let weight=0;
  for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){
   for(let d=1;d<=40;d++){
    const xx=x+dx*d,yy=y+dy*d;if(xx<0||xx>=width||yy<0||yy>=height)break;
    const k=yy*width+xx;if(mask[k*4]>127)continue;
    const w=1/(d*d);for(let c=0;c<3;c++)sum[c]+=source[k*4+c]*w;weight+=w;break;
   }
  }
  if(weight)for(let c=0;c<3;c++)result[i*4+c]=sum[c]/weight;
 }
 return result;
}
export function cleanBorderTexture(image,letterMask){
 const canvas=document.createElement('canvas');canvas.width=image.width;canvas.height=image.height;const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(image,0,0);
 const masks=document.createElement('canvas');masks.width=image.width;masks.height=image.height;const mc=masks.getContext('2d',{willReadFrequently:true});mc.drawImage(letterMask,0,0);
 const pixels=ctx.getImageData(0,0,canvas.width,canvas.height),mask=mc.getImageData(0,0,canvas.width,canvas.height);
 pixels.data.set(restoreLetterPixels(pixels.data,mask.data,canvas.width,canvas.height));ctx.putImageData(pixels,0,0);return canvas;
}
