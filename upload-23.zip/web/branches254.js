import {buildPoint} from './core/build-position.js';
import {G,clone} from './core/model.js';
import {originOwnership} from './solver-search254.js';
import {route} from './route280.js';
import {fastRoute} from './route-fast280.js';

// A bounded beam over complete, buildable branch networks. The beam retains
// cheap alternatives as well as high-yield ones, so a nearby single deposit does
// not consume the allowance before a more productive multi-flag branch is tried.
export function crystalBranches(model,initial,allianceId,{baseLength,totalCap,deadline,maxVisits,maxNodes},progress=()=>{}){
 const crystals=model.data.resources.filter(r=>r.kind==='crystal');
 const covered=()=>crystals.filter(r=>model.resourceCovered(r,allianceId));
 model.setPlan(initial);let best={plan:clone(initial),gems:covered().length},beam=[best];const seen=new Set(),initialGems=best.gems,initialCount=initial.buildings.length-baseLength;
 const count=s=>s.plan.buildings.length-baseLength;
 const better=(a,b)=>a.gems>b.gems||a.gems===b.gems&&count(a)<count(b);
 function singleChoices(plan,stop){
  model.setPlan(plan);const pending=crystals.filter(r=>!model.resourceCovered(r,allianceId)),frontier=originOwnership(model,baseLength,allianceId),candidates=new Map();
  for(const r of pending){const cx=Math.floor(r.x/18),cy=Math.floor(r.y/18);for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++){const x=cx+dx,y=cy+dy,k=x+':'+y;if(!candidates.has(k))candidates.set(k,{b:{id:'branch-'+plan.buildings.length+'-'+k,kind:'flag',...buildPoint(x*18+9,y*18+9),allianceId},near:[]});candidates.get(k).near.push(r);}}
  const singles=[];for(const {b,near}of candidates.values()){
   if(performance.now()>=stop)break;if(!G.isConnectedToAlliance(b,frontier)||model.placementError(b))continue;
   const cells=new Set(G.territoryCells(b).map(c=>c.column+':'+c.row)),ownership={get(k){return model.state.ownership.get(k)||(cells.has(k)?{allianceId}:undefined);}};
   const gain=near.filter(r=>model.resourceCovered(r,allianceId,ownership)).length;if(gain)singles.push({b,gain});
  }
  return singles.sort((a,b)=>b.gain-a.gain);
 }
 // Establish a complete cheap incumbent before spending time on remote branches.
 // Coverage tests use only resources in the candidate's nine territory cells.
 const greedyStop=Math.min(deadline,performance.now()+Math.max(150,(deadline-performance.now())*.3));
 let greedy=clone(initial);
 while(greedy.buildings.length-baseLength<totalCap&&performance.now()<greedyStop){
  const choices=singleChoices(greedy,greedyStop);let additions=choices.length?[choices[0].b]:null;
  if(!additions){
   model.setPlan(greedy);const remaining=totalCap-(greedy.buildings.length-baseLength),before=covered().length;
   const nearby=crystals.filter(r=>!model.resourceCovered(r,allianceId)).map(r=>({r,d:Math.min(...greedy.buildings.filter(b=>b.allianceId===allianceId).map(b=>Math.hypot(b.x-r.x,b.y-r.y)))})).filter(q=>q.d<(remaining+2)*54).sort((a,b)=>a.d-b.d).slice(0,4);let ratio=0;
   for(const {r}of nearby){if(performance.now()>=greedyStop)break;const request=clone(greedy);request.targets=[{id:'quick-branch-'+r.id,resourceId:r.id,x:r.x,y:r.y}];const result=fastRoute(model,request,allianceId,{budget:remaining,crystals:false,maxVisits:Math.min(maxVisits,3000),maxNodes,deadline:Math.min(greedyStop,performance.now()+350)});if(result.failed.length||!result.buildings.length)continue;const p=clone(greedy);p.buildings.push(...result.buildings);model.setPlan(p);const gain=covered().length-before;if(gain/result.buildings.length>ratio){ratio=gain/result.buildings.length;additions=result.buildings;}}
  }
  if(!additions)break;greedy.buildings.push(...additions);model.setPlan(greedy);const item={plan:clone(greedy),gems:covered().length};if(item.gems<=best.gems&&item.gems<=initialGems)break;if(better(item,best))best=item;
 }
 beam=best.gems>initialGems?[best,{plan:clone(initial),gems:initialGems}]:beam;
 for(let round=0;round<30&&beam.length&&performance.now()<deadline;round++){
  const next=[];
  for(const state of beam){
   if(performance.now()>=deadline)break;const plan=state.plan,remaining=totalCap-count(state);if(remaining<=0)continue;
   model.setPlan(plan);const pending=crystals.filter(r=>!model.resourceCovered(r,allianceId)),frontier=originOwnership(model,baseLength,allianceId),candidates=new Map();
   const offer=p=>{model.setPlan(p);const gems=covered(),signature=gems.map(r=>r.id).sort().join('|')+';'+p.buildings.slice(baseLength).map(b=>Math.floor(b.x/18)+':'+Math.floor(b.y/18)).sort().join(',');if(seen.has(signature))return;seen.add(signature);const item={plan:clone(p),gems:gems.length};if(item.gems<=state.gems||count(item)>totalCap)return;next.push(item);if(better(item,best))best=item;};
   const singles=singleChoices(plan,deadline);for(const {b}of singles.slice(0,5)){const p=clone(plan);p.buildings.push(b);offer(p);}model.setPlan(plan);
   // Evaluate remote clusters even when a one-flag capture is available. Mix
   // proximity and density candidates; group duplicate resource positions.
   const centres=[...frontier.values()].filter(c=>c.allianceId===allianceId);const ranked=pending.map(r=>{let d=Infinity;for(const c of centres)d=Math.min(d,Math.hypot(c.column*18+9-r.x,c.row*18+9-r.y));const density=pending.filter(q=>Math.hypot(q.x-r.x,q.y-r.y)<=90).length;return {r,d,score:d/Math.sqrt(density)};}).filter(q=>q.d<(remaining+2)*54);
   const selected=new Map();for(const q of [...ranked.slice().sort((a,b)=>a.d-b.d).slice(0,3),...ranked.sort((a,b)=>a.score-b.score).slice(0,7)])selected.set(q.r.id,q);
   if(remaining>=2)for(const {r}of selected.values()){
    if(performance.now()>=deadline)break;const request=clone(plan);request.targets=[{id:'branch-target-'+r.id,resourceId:r.id,x:r.x,y:r.y}];
    const result=route(model,request,allianceId,{budget:remaining,crystals:true,maxVisits:Math.min(maxVisits,3500),maxNodes:Math.min(maxNodes,9000),deadline:Math.min(deadline,performance.now()+500)},progress);
    if(!result.failed.length&&result.buildings.length){const p=clone(plan);p.buildings.push(...result.buildings);offer(p);}model.setPlan(plan);
   }
   progress({visits:0,added:count(best),remaining:0,phase:'Kristallabzweigungen',crystals:best.gems});
  }
  next.sort((a,b)=>b.gems-a.gems||count(a)-count(b));const chosen=next.slice(0,2);
  const economical=next.slice().sort((a,b)=>(b.gems-initialGems)/(Math.max(1,count(b)-initialCount))-(a.gems-initialGems)/(Math.max(1,count(a)-initialCount))||count(a)-count(b)).find(s=>!chosen.includes(s));
  if(economical)chosen.push(economical);beam=chosen;
 }
 model.setPlan(best.plan);return best.plan;
}
