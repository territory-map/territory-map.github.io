import {clone} from './core/model.js';
import {route} from './route280.js';
export function cheapResources(model,initial,allianceId,{extraCap,maxPerResource=2,deadline,maxVisits,maxNodes},progress=()=>{}){
 const plan=clone(initial),main=initial.buildings.filter(b=>b.allianceId===allianceId),before=initial.buildings.length;let added=0,round=0;
 while(added<extraCap&&performance.now()<deadline&&round++<12){
  model.setPlan(plan);const candidates=model.data.resources.filter(r=>!model.resourceCovered(r,allianceId)).map(r=>({r,d:Math.min(...main.map(b=>Math.hypot(b.x-r.x,b.y-r.y)))})).filter(q=>q.d<=(maxPerResource+2)*54).sort((a,b)=>a.d-b.d).slice(0,12);
  let best=null,bestScore=0;
  for(const {r}of candidates){if(performance.now()>=deadline)break;model.setPlan(plan);const pending=model.data.resources.filter(r=>!model.resourceCovered(r,allianceId));const request=clone(plan);request.targets=[{id:'cheap-'+r.id,resourceId:r.id,x:r.x,y:r.y}];const result=route(model,request,allianceId,{budget:Math.min(extraCap-added,maxPerResource),crystals:false,maxVisits:Math.min(maxVisits,3000),maxNodes:Math.min(maxNodes,9000),deadline:Math.min(deadline,performance.now()+200)});if(result.failed.length||!result.buildings.length)continue;const q=clone(plan);q.buildings.push(...result.buildings);model.setPlan(q);const gain=pending.filter(r=>model.resourceCovered(r,allianceId)).reduce((s,r)=>s+(r.kind==='crystal'?2:1),0),score=gain/result.buildings.length;if(score>bestScore){bestScore=score;best=result.buildings;}}
  if(!best)break;plan.buildings.push(...best);added=plan.buildings.length-before;progress({phase:'Nahe Ressourcen',visits:0,added,remaining:0});
 }
 model.setPlan(plan);return {plan,added};
}
