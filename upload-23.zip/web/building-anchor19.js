// Asset-local foundation centres, independent of camera and zoom.
// Fortress x = 71.5/104 follows the corrected front-face mark in Unbenannt.png.
export function buildingSpriteAnchor(bounds,kind){
 return {x:kind==='fortress'?.6875:(bounds.left+bounds.right)/2,
 y:bounds.anchor+(bounds.top-bounds.anchor)*(kind==='flag'?.16:.10)};
}
// Artwork scale uses a separate display radius; physical build circles are independent.
// Foundation half-widths measured in the unchanged source textures around the anchors.
export function buildingSymbolHeight(bounds,kind,radius){
 const halfWidth=kind==='flag'?300/1536:kind==='fortress'?31/105:null;
 return halfWidth?radius*.94/halfWidth:radius*3;
}
