// Mutates a plan inside the app's existing undo transaction. Shared targets,
// drawings and map edits have no alliance owner and remain available.
export function removeAlliance(plan,allianceId){
 const index=plan.alliances.findIndex(a=>a.id===allianceId);
 if(index<0||plan.alliances.length<=1)return null;
 const removedIds=new Set(plan.buildings.filter(b=>b.allianceId===allianceId).map(b=>b.id));
 plan.alliances.splice(index,1);
 for(const c of plan.coalitions||[])c.allianceIds=c.allianceIds.filter(id=>id!==allianceId);
 plan.buildings=plan.buildings.filter(b=>b.allianceId!==allianceId);
 plan.targets=(plan.targets||[]).filter(t=>t.allianceId!==allianceId);
 plan.annotations=(plan.annotations||[]).filter(a=>a.allianceId!==allianceId);
 for(const [site,owner]of Object.entries(plan.capturedPasses||{}))if(owner===allianceId)delete plan.capturedPasses[site];
 if(plan.settings.solverStartByAlliance)delete plan.settings.solverStartByAlliance[allianceId];
 if(plan.creditAccounting)delete plan.creditAccounting[allianceId];
 if(plan.costAccounting)delete plan.costAccounting[allianceId];
 for(const key of ['routingRootId','routingStartId'])if(removedIds.has(plan[key]))delete plan[key];
 delete plan.routingBaseLength;
 return plan.alliances[Math.min(index,plan.alliances.length-1)].id;
}
