// Building labels round half up; placement retains sub-coordinate precision.
// Preview, collision, storage and solver share the actual centre, not its label.
export const gameBuildCoordinate=value=>Math.round(value/6)||0;
export const floorGameCoordinate=value=>Math.floor(value/6+1e-9)||0;
export const buildPoint=(x,y)=>({x:Math.round(x*100)/100,y:Math.round(y*100)/100});
// Labels and exports share the same half-up convention; this never moves a building.
export const buildingGameCoordinate=gameBuildCoordinate;
