import {PHOTO_RADII_GAME} from './photo-calibration400.js';
export const DEFAULT_FLAG_RADIUS_GAME=PHOTO_RADII_GAME.flag;
export const DEFAULT_FORTRESS_RADIUS_GAME=PHOTO_RADII_GAME.fortress;
export function normalizeBuildingRadius(value,fallback){
 const n=Number(value);return Number.isFinite(n)&&n>0?Math.max(.05,Math.min(10,n)):fallback;
}
// Physical ground circles only. Territory squares and visual symbols retain
// their established sizes; central and alliance fortresses share one circle.
export function configuredBuildingRadius(kind,settings={}){
 if(kind==='flag')return 6*normalizeBuildingRadius(settings.flagRadius,DEFAULT_FLAG_RADIUS_GAME);
 if(['fortress','subFortress','center-fortress','mainFortress'].includes(kind))return 6*normalizeBuildingRadius(settings.fortressRadius,DEFAULT_FORTRESS_RADIUS_GAME);
 return null;
}
