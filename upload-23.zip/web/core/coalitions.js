// Coalitions share validated pass contact, not territory, production or buildings.
export function coalitionPeers(plan,allianceId){
 const ids=new Set(plan.alliances.map(a=>a.id)),peers=new Set([allianceId]);
 for(const c of plan.coalitions||[])if(c.allianceIds.includes(allianceId))for(const id of c.allianceIds)if(ids.has(id))peers.add(id);
 return peers;
}
export function normalizeCoalitions(value,alliances){
 if(value==null)return [];if(!Array.isArray(value)||value.length>100)throw Error('Ungültige Koalitionen.');
 const valid=new Set(alliances.map(a=>a.id)),seen=new Set();
 return value.map(c=>{if(!c||typeof c.id!=='string'||!c.id||c.id.length>100||seen.has(c.id)||typeof c.name!=='string'||!c.name.trim()||c.name.length>80||!Array.isArray(c.allianceIds)||c.allianceIds.length>32)throw Error('Ungültige Koalitionen.');seen.add(c.id);return {id:c.id,name:c.name.trim(),allianceIds:[...new Set(c.allianceIds.filter(id=>valid.has(id)))]};});
}
export function setCoalition(plan,{id,name,allianceIds}){
 const c=normalizeCoalitions([{id,name,allianceIds}],plan.alliances)[0];plan.coalitions??=[];
 const at=plan.coalitions.findIndex(q=>q.id===id);if(at<0){if(c.allianceIds.length<2)throw Error('Mindestens zwei Allianzen auswählen.');if(plan.coalitions.length>=100)throw Error('Koalitionslimit erreicht.');plan.coalitions.push(c);}else plan.coalitions[at]=c;
 return c;
}
export function removeCoalition(plan,id){plan.coalitions=(plan.coalitions||[]).filter(c=>c.id!==id);}
