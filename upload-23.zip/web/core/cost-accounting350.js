import {buildingCostBreakdown} from './costs.js';
import {normalizeCreditAccounting} from './credit-accounting330.js';

export const COST_FIELDS=['credits','food','wood','stone','gold','crystal'];

export function normalizeCostAccounting(plan){
 // Older plans stored the reset under creditAccounting. Retain that same
 // boundary for all six costs when loading them in the new version.
 return normalizeCreditAccounting({...plan.creditAccounting,...plan.costAccounting},plan.alliances);
}

export function resetBuildingCosts(plan,allianceId){
 plan.costAccounting??=normalizeCostAccounting(plan);
 plan.costAccounting[allianceId]={baselineIds:plan.buildings.filter(b=>b.allianceId===allianceId).map(b=>b.id)};
}

export function buildingCostsSinceReset(buildings,schedule,allianceId,accounting){
 const baseline=new Set(accounting?.[allianceId]?.baselineIds||[]);
 const totals=Object.fromEntries(COST_FIELDS.map(field=>[field,0]));
 let unknown=0;
 // Determine ordinals using the whole plan first; a reset never changes tiers.
 for(const {building,cost} of buildingCostBreakdown(buildings,schedule,allianceId)){
  if(baseline.has(building.id))continue;
  if(!cost){unknown++;continue;}
  for(const field of COST_FIELDS)totals[field]+=cost[field]??0;
 }
 return {totals,unknown,reset:!!accounting?.[allianceId]};
}
