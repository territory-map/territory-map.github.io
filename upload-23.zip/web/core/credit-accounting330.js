import {buildingCostBreakdown} from './costs.js';

// A reset changes the accounting period, never the construction ordinal.
export function normalizeCreditAccounting(value,alliances){
 const result={};
 for(const a of alliances){
  const ids=value?.[a.id]?.baselineIds;
  if(Array.isArray(ids))result[a.id]={baselineIds:[...new Set(ids.filter(id=>typeof id==='string').slice(0,5000))]};
 }
 return result;
}
export function resetAllianceCredits(plan,allianceId){
 plan.creditAccounting??={};
 plan.creditAccounting[allianceId]={baselineIds:plan.buildings.filter(b=>b.allianceId===allianceId).map(b=>b.id)};
}
export function allianceCredits(buildings,schedule,allianceId,accounting){
 const baseline=new Set(accounting?.[allianceId]?.baselineIds||[]);
 let spent=0,unknown=0;
 // Enumerate ALL existing buildings before excluding the reset baseline.
 for(const {building,cost} of buildingCostBreakdown(buildings,schedule,allianceId)){
  if(baseline.has(building.id))continue;
  if(!cost){unknown++;continue;}
  spent+=cost.credits??0;
 }
 return {spent,unknown,reset:!!accounting?.[allianceId]};
}
