// Preparation Season 1, fixed world centre (1524,2760) = game (254,460).
// Exact visible triangle contour: last free radius 3.162568382 world units.
// The old 2.1978 value stopped at a raster pixel outside that contour.
export const FLAG_RADIUS=3.16256;
// Fitted horizontal/vertical ellipse ratios from the user's red circle photos:
// fortress ~1.393/1.397; resource ~1.453/1.453. Round photographic estimates.
export const FORTRESS_TO_FLAG=1.4;
export const RESOURCE_TO_FLAG=1.45;
export const FORTRESS_RADIUS=Number((FLAG_RADIUS*FORTRESS_TO_FLAG).toFixed(8));
export const MAIN_FORTRESS_RADIUS=Number((FORTRESS_RADIUS*1.25).toFixed(8));
export const RESOURCE_RADIUS=Number((FLAG_RADIUS*RESOURCE_TO_FLAG).toFixed(8));
