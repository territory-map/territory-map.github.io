import {normalizeBuildingRadius} from './building-size.js';
import {PHOTO_RADII_GAME} from './photo-calibration400.js';
export const DEFAULT_LANDMARK_RADIUS_GAME=PHOTO_RADII_GAME.cave;
export const hasLandmarkCircles=map=>/^Sever_Map_G1_[1-4]_v2$/.test(map);
// Landmarks have no territory or production. Their independent physical circles
// protect villages/caves during manual placement, routing and tactical search.
export function landmarkRadius(node,settings={}){
 const key=node?.kind==='village'?'villageRadius':node?.kind==='cave'?'caveRadius':null;
 return key?6*normalizeBuildingRadius(settings[key],DEFAULT_LANDMARK_RADIUS_GAME):0;
}
