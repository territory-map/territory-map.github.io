import {landmarkRadius,DEFAULT_LANDMARK_RADIUS_GAME,hasLandmarkCircles} from './landmark-size360.js';
import {configuredBuildingRadius,normalizeBuildingRadius,DEFAULT_FLAG_RADIUS_GAME,DEFAULT_FORTRESS_RADIUS_GAME} from './building-size.js';
import {normalizeCostAccounting} from './cost-accounting350.js';
import {normalizeCreditAccounting} from './credit-accounting330.js';
import {normalizeCoalitions} from './coalitions.js';
import {warConfig} from './war-config.js';
import {resourceRadius as footprintRadius,DEFAULT_RESOURCE_RADIUS_GAME} from './resource-size.js';
import {GroundAccess} from './access18.js';
import {buildTerritoryState} from './territory17.js';
import {flagTouchesBastion} from '../terrain16.js?v=20261002.254';
import * as G from './geometry.js';

import * as C from './costs.js';

export {G,C};

export const UNIT=18;
export const INACTIVE_TERRITORY='__inactive_territory__';
// The saved setting covers capturable territory relays on every map, including
// Hieron, Castrum, sanctuaries and other map-specific names. Never include the
// separately governed passes, bastions and non-capturable ruins/darkness altars.
export function isCrusaderSite(s){
 if(['pass','bastion','ancient-battlefield'].includes(s.kind)||s.claimable===false)return false;
 if(/^(?:Ancient Ruins|Altes Schlachtfeld|Ruinen|Altar of Darkness|Altar der Dunkelheit)$/i.test(s.label||''))return false;
 return s.claimable===true||['holy-site','citadel','duel-center','duel-tower'].includes(s.kind)||[29,30].includes(Number(s.strongholdType))||/crusader|kreuzritter|castrum|hieron/i.test(s.label||'');
}

export const id=()=>crypto.randomUUID();

export const clone=v=>structuredClone(v);

export const worldToScene=(x,y,height=0)=>[x,height,-y];

export const sceneToWorld=p=>[p.x,-p.z];

export const worldToPixel=(x,y,b,size)=>[(x-b[0])/(b[2]-b[0])*size[0],(b[3]-y)/(b[3]-b[1])*size[1]];

export const pixelToWorld=(x,y,b,size)=>[b[0]+x/size[0]*(b[2]-b[0]),b[3]-y/size[1]*(b[3]-b[1])];

export const kindToLegacy={flag:'flag',fortress:'subFortress','center-fortress':'mainFortress',horse:'horse'};

export const legacy=b=>({...b,kind:kindToLegacy[b.kind]||b.kind});

export function newPlan(map){return {version:12,map,coalitions:[],warBuilder:warConfig(),alliances:[{id:'a1',name:'Allianz 1',color:'#24c3cb'}],buildings:[],annotations:[],targets:[],siteEdits:{},capturedPasses:{},settings:{useCrusaderStructures:false,usePassStructures:true,allowZoneWalljumps:true,routeMode:'balanced',crystals:true,strict:false,flagRadius:DEFAULT_FLAG_RADIUS_GAME,fortressRadius:DEFAULT_FORTRESS_RADIUS_GAME,resourceRadius:DEFAULT_RESOURCE_RADIUS_GAME,villageRadius:DEFAULT_LANDMARK_RADIUS_GAME,caveRadius:DEFAULT_LANDMARK_RADIUS_GAME,flagBudget:150,crystalExtra:5,buildDetourLimit:2}};}

export function structures(data,edits={}){

 return data.sites.map((original,index)=>{

  const s={...original,...edits[original.id]};

  const rule=s.kind==='bastion'?{collision:{shape:'territory-square',radiusInCells:1},territoryRadiusInCells:1,claimable:false}:data.catalog.structureRules[String(s.strongholdType)];

  return {...s,...rule,rotation:edits[original.id]?.rotation??data.passRotations?.[original.id]??s.rotation,id:index+1,siteId:s.id,collision:s.collision||rule?.collision||{shape:'territory-square',radiusInCells:2},territoryRadiusInCells:s.territoryRadiusInCells??rule?.territoryRadiusInCells??2,teleportRadiusInCells:s.teleportRadiusInCells??rule?.teleportRadiusInCells??null,claimable:s.claimable??rule?.claimable??(s.kind==='pass'||s.kind==='holy-site'||s.kind==='citadel')};

 });

}

export class MapModel{

 constructor(data){

  this.data=data;this.catalog=data.catalog;this.groundAccess=new GroundAccess(data);this.triangles=[];this.spatial=new Map();this.resourceSpatial=new Map();this.landmarkSpatial=new Map();this.staticCache=new Map();
  for(const r of data.resources){const key=Math.floor(r.x/64)+':'+Math.floor(r.y/64);if(!this.resourceSpatial.has(key))this.resourceSpatial.set(key,[]);this.resourceSpatial.get(key).push(r);}

  for(const node of hasLandmarkCircles(data.catalog.map)?data.landmarks||[]:[]){const key=Math.floor(node.x/64)+':'+Math.floor(node.y/64);if(!this.landmarkSpatial.has(key))this.landmarkSpatial.set(key,[]);this.landmarkSpatial.get(key).push(node);}
  if(data.province){data.province.flagBlocked=new Set(data.province.flagBlocked);data.province.fortressBlocked=new Set(data.province.fortressBlocked);}

  for(const instance of data.instances){const def=data.definitions[instance.mesh];if(!def)continue;

   for(let i=0;i<def.indices.length;i+=3){const t=G.transformedTriangle(def,instance,i),n=this.triangles.length;this.triangles.push(t);

    const xs=[t[0],t[2],t[4]],ys=[t[1],t[3],t[5]];

    for(let x=Math.floor(Math.min(...xs)/128);x<=Math.floor(Math.max(...xs)/128);x++)for(let y=Math.floor(Math.min(...ys)/128);y<=Math.floor(Math.max(...ys)/128);y++){const key=x+':'+y;if(!this.spatial.has(key))this.spatial.set(key,[]);this.spatial.get(key).push(n);}

   }

  }

  // The same native triangles draw the visible hatching. Raster cells must not
  // enlarge these boundaries; retain raster fallback for mask-only legacy maps.
  if(this.triangles.length)this.groundAccess.exactBlocked=(x,y,r,square)=>square?this.cellCollision(x,y):this.terrainCollision(x,y,r);
  this.setPlan(newPlan(data.catalog.map));

 }

 setPlan(plan){this.planEpoch=(this.planEpoch||0)+1;this.allianceTerritories=new Map();this.plan=plan;const edits=JSON.stringify(plan.siteEdits||{});if(this.siteEditsKey!==edits){this.sites=structures(this.data,plan.siteEdits);this.siteEditsKey=edits;this.staticCache.clear();}this.maxResourceRadius=Math.max(0,...this.data.resources.map(r=>this.resourceRadius(r)));this.buildings=plan.buildings.map(b=>this.legacy(b));this.accessCache=null;this.allowZoneWalljumps=plan.settings.allowZoneWalljumps!==false;
  const useCrusaders=plan.settings.useCrusaderStructures===true,usePasses=plan.settings.usePassStructures!==false;
  if(this.accessSitesSource!==this.sites||this.useCrusaders!==useCrusaders||this.usePasses!==usePasses){this.accessSitesSource=this.sites;this.useCrusaders=useCrusaders;this.usePasses=usePasses;this.accessSites=this.sites.map(s=>({...s,claimable:s.kind==='pass'?false:s.claimable,conductsTerritory:s.kind==='pass'?usePasses:useCrusaders||!isCrusaderSite(s)}));}
  this.accessCache=this.groundAccess.accessAll(this);
  this.activeBuildingIds=new Set([...this.accessCache.values()].flatMap(a=>[...(a.connected?.buildingIds||[])]));
  const active=this.buildings.filter(b=>this.activeBuildingIds.has(b.id));
  this.state=buildTerritoryState(active,this.accessSites,(s,aid)=>!this.groundAccess.nav||this.groundAccess.targetRegions(s).some(z=>this.accessFor(aid).regions.has(z)));
  for(const s of this.sites)if(s.kind==='pass'){
   const eligible=plan.alliances.filter(a=>this.accessFor(a.id).captured.has(s.siteId)),owner=eligible.find(a=>a.id===plan.capturedPasses?.[s.siteId])||eligible[0];
   if(owner){this.state.structureOwners.set(s.id,owner.id);for(const c of G.structureTerritoryCells(s))this.state.ownership.set(c.column+':'+c.row,{...c,allianceId:owner.id});}
  }
  // Inactive squares are presentation only: never feed them back into capture,
  // placement, production, target coverage or solver frontier calculations.
  this.displayOwnership=new Map(this.state.ownership);for(const site of this.accessSites)if(site.conductsTerritory===false){const owner=this.state.structureOwners.get(site.id);if(owner)for(const c of G.structureTerritoryCells(site))this.displayOwnership.set(c.column+':'+c.row,{...c,allianceId:owner});}if(this.reservedSites!==this.sites){this.reservedSites=this.sites;this.reservedCells=new Set(this.sites.flatMap(s=>G.structureTerritoryCells(s).map(c=>c.column+':'+c.row)));}const reserved=this.reservedCells;
  for(const b of this.buildings)if(!this.activeBuildingIds.has(b.id))for(const c of G.territoryCells(b)){const key=c.column+':'+c.row;if(!reserved.has(key)&&!this.displayOwnership.has(key))this.displayOwnership.set(key,{...c,allianceId:INACTIVE_TERRITORY});}
 }
 isBuildingActive(b){return this.activeBuildingIds.has(b.id);}

 accessFor(allianceId){this.accessCache??=this.groundAccess.accessAll(this);return this.accessCache.get(allianceId)||{regions:new Set(),captured:new Set(),root:null};}
 zoneError(b){if(!this.groundAccess.nav)return null;const a=this.accessFor(b.allianceId);if(!a.root)return b.kind==='flag'?'Zuerst eine Festung für diese Allianz setzen.':null;return a.regions.has(this.groundAccess.buildingRegion(b.x,b.y))||(b.kind==='flag'&&this.groundAccess.linkAllowed(this,legacy(b),a.connected?.sources||[],a.connected,a.captured))?null:'Zone gesperrt: zuerst den verbindenden Pass von der Festungsseite erobern.';}

 // Each connected alliance can build through a shared pass, regardless of its colour.
 territoryFor(allianceId){if(this.allianceTerritories.has(allianceId))return this.allianceTerritories.get(allianceId);const own=new Map(this.state.ownership);for(const s of this.sites)if(s.kind==='pass'&&this.accessFor(allianceId).captured.has(s.siteId))for(const c of G.structureTerritoryCells(s))own.set(c.column+':'+c.row,{...c,allianceId});this.allianceTerritories.set(allianceId,own);return own;}
 walljumpError(source,target,allianceId=source.allianceId){return this.groundAccess.walljumpError(this,source,target,allianceId);}
 passContactSources(site,allianceId){return this.groundAccess.contactSources(this.plan,site,allianceId);}
 captureError(site,allianceId){if(site.kind==='pass'&&!this.usePasses)return 'Pässe verwenden ist deaktiviert. Der Pass gibt keinen Zugang zum Weiterbauen frei.';const access=this.accessFor(allianceId);return this.groundAccess.captureError(this,site,allianceId,access.regions,access.captured);}
 canCapture(site,allianceId){return !this.captureError(site,allianceId);}
 buildingRadius(b){return configuredBuildingRadius(b.kind,this.plan?.settings)??G.buildingRules[legacy(b).kind].baseClearance;}
 legacy(b){return {...legacy(b),buildRadius:this.buildingRadius(b)};}
 resourceRadius(node){return footprintRadius(node,this.plan?.settings);}
 landmarkRadius(node){return hasLandmarkCircles(this.catalog.map)?landmarkRadius(node,this.plan?.settings):0;}
 routePrerequisite(target,allianceId){return this.groundAccess.prerequisite(this,target,allianceId);}
 passApproached(site,allianceId){
  if(this.usePasses)return this.canCapture(site,allianceId);
  const a=this.accessFor(allianceId);
  return !this.groundAccess.captureError(this,site,allianceId,a.regions,a.captured,a.connected)&&this.buildings.some(b=>b.kind==='flag'&&b.allianceId===allianceId&&this.isBuildingActive(b)&&this.groundAccess.touches(b,site));
 }


 terrainCollision(x,y,r){

  for(let a=Math.floor((x-r)/128);a<=Math.floor((x+r)/128);a++)for(let b=Math.floor((y-r)/128);b<=Math.floor((y+r)/128);b++)for(const n of this.spatial.get(a+':'+b)||[])if(G.circleIntersectsTriangle(x,y,r,this.triangles[n]))return true;

  return false;

 }

 cellCollision(x,y){

  const r=9,seen=new Set();

  for(let a=Math.floor((x-r)/128);a<=Math.floor((x+r)/128);a++)for(let b=Math.floor((y-r)/128);b<=Math.floor((y+r)/128);b++)for(const i of this.spatial.get(a+':'+b)||[]){

    if(seen.has(i))continue;seen.add(i);const t=this.triangles[i],tri=[[t[0],t[1]],[t[2],t[3]],[t[4],t[5]]],box=[[x-r,y-r],[x+r,y-r],[x+r,y+r],[x-r,y+r]];

    const axes=[[1,0],[0,1],...tri.map((p,k)=>[p[1]-tri[(k+1)%3][1],tri[(k+1)%3][0]-p[0]])];

    if(axes.every(([ax,ay])=>{const ts=tri.map(p=>p[0]*ax+p[1]*ay),bs=box.map(p=>p[0]*ax+p[1]*ay);return Math.max(...ts)>=Math.min(...bs)&&Math.max(...bs)>=Math.min(...ts);} ))return true;

  }return false;

 }

 staticError(candidate,strict=false){const key=candidate.kind+'|'+candidate.x+'|'+candidate.y+'|'+strict+'|'+(this.plan?.settings.resourceRadius??DEFAULT_RESOURCE_RADIUS_GAME)+'|'+this.buildingRadius(candidate)+'|'+this.plan?.settings.villageRadius+'|'+this.plan?.settings.caveRadius;if(this.staticCache.has(key))return this.staticCache.get(key);const result=this.computeStaticError(candidate,strict);if(this.staticCache.size>50000)this.staticCache.clear();this.staticCache.set(key,result);return result;}

 computeStaticError(candidate,strict=false){

  const c=this.legacy(candidate),r=this.buildingRadius(candidate),n=this.catalog.nativeMapSize;

  if(c.x-r<0||c.y-r<0||c.x+r>n||c.y+r>n)return 'Außerhalb der bebaubaren Karte.';

  if(G.isProvinceRestricted(this.data.province,c.kind,c.x,c.y))return 'Dieser Gebäudetyp ist in dieser Zone gesperrt.';

  if(this.groundAccess.blocked(c.x,c.y,r)||this.terrainCollision(c.x,c.y,r))return 'Die Grundfläche berührt eine Wand oder gesperrtes Gelände.';

  // Contact (including exact tangency) of the two ground circles is blocked.
  // Source ZIP supplies building radii but no deposit radius: the latter is a
  // labelled, adjustable planning safety radius, independent of sprite/zoom.
  const maxResourceRadius=this.maxResourceRadius;
  for(let x=Math.floor((c.x-r-maxResourceRadius)/64);x<=Math.floor((c.x+r+maxResourceRadius)/64);x++)for(let y=Math.floor((c.y-r-maxResourceRadius)/64);y<=Math.floor((c.y+r+maxResourceRadius)/64);y++)for(const node of this.resourceSpatial.get(x+':'+y)||[])if(Math.hypot(c.x-node.x,c.y-node.y)<=r+this.resourceRadius(node)+1e-7)return 'Die Grundkreise von Gebäude und Ressourcenpunkt berühren sich.';

  const landmarkMax=6*Math.max(this.plan.settings.villageRadius??DEFAULT_LANDMARK_RADIUS_GAME,this.plan.settings.caveRadius??DEFAULT_LANDMARK_RADIUS_GAME);
  for(let x=Math.floor((c.x-r-landmarkMax)/64);x<=Math.floor((c.x+r+landmarkMax)/64);x++)for(let y=Math.floor((c.y-r-landmarkMax)/64);y<=Math.floor((c.y+r+landmarkMax)/64);y++)for(const node of this.landmarkSpatial.get(x+':'+y)||[])if(Math.hypot(c.x-node.x,c.y-node.y)<=r+this.landmarkRadius(node)+1e-7)return 'Die Grundkreise von Gebäude und Dorf oder Höhle berühren sich.';
  if(G.mapStructureCollision(c,this.sites))return 'Die Position liegt im Quadrat einer Kartenstruktur.';

  if(strict){const p=G.snapTerritoryPoint(c.x,c.y);if(this.groundAccess.blocked(p.x,p.y,9,true)||this.cellCollision(p.x,p.y))return 'Die Bauzelle ist nicht vollständig frei.';}
  return null;

 }

 placementError(candidate,{connect=true,manual=false}={}){

  const limit=this.catalog.buildings[candidate.kind]?.limit??0;

  if(this.plan.buildings.filter(b=>b.kind===candidate.kind&&b.allianceId===candidate.allianceId).length>=limit)return 'Gebäudelimit der Allianz erreicht.';

   const c=this.legacy(candidate),e=this.staticError(candidate,this.plan.settings.strict);if(e)return e;
   const zone=manual?null:this.zoneError(candidate);if(zone)return zone;

  if(G.plannedBuildingCollision(c,this.buildings))return 'Hier steht bereits ein geplantes Gebäude.';

  if(connect&&!G.buildingRules[c.kind].root&&!(manual?this.groundAccess.touchesTerritory(c,this.territoryFor(c.allianceId),this.accessSites):this.groundAccess.linkAllowed(this,c,this.accessFor(c.allianceId).connected?.sources||[],{ownership:this.territoryFor(c.allianceId),structureOwners:this.state.structureOwners},this.accessFor(c.allianceId).captured)))return this.groundAccess.touchesTerritory(c,this.territoryFor(c.allianceId),this.accessSites)?'Zonen-Walljump benötigt aktivierte Freigabe und gültigen eigenen oder Koalitions-Passkontakt.':'Die Flagge muss an dein Gebiet anschließen. Zuerst eine Festung setzen.';

  if(!G.hasRequiredTerritoryAvailability(c,this.territoryFor(c.allianceId)))return 'Zu viel dieser Fläche gehört einer anderen Allianz.';

  return null;

 }

 covered(allianceId,resources=this.data.resources){return G.countCoveredResources(this.state.ownership,resources,allianceId,r=>this.resourceRadius(r));}
 resourceCovered(node,allianceId,ownership=this.state.ownership){return G.resourceCoverage(ownership,node,allianceId,this.resourceRadius(node))>=.5-1e-9;}

 targetReached(target,allianceId){

  if(target.siteId){const s=this.sites.find(s=>s.siteId===target.siteId);if(!s)return false;if(s.kind==='pass')return target.approach||!this.usePasses?this.passApproached(s,allianceId):this.accessFor(allianceId).captured.has(s.siteId);if(!this.groundAccess.targetRegions(s).some(z=>this.accessFor(allianceId).regions.has(z)))return false;if(isCrusaderSite(s)&&!this.useCrusaders)return this.buildings.some(b=>b.kind==='flag'&&b.allianceId===allianceId&&this.isBuildingActive(b)&&this.groundAccess.touches(b,s));if(s.kind==='bastion')return this.plan.buildings.some(b=>b.kind==='flag'&&b.allianceId===allianceId&&this.isBuildingActive(b)&&flagTouchesBastion(b,s,G));if(s.claimable)return this.state.structureOwners.get(s.id)===allianceId;const cx=Math.floor(s.x/18),cy=Math.floor(s.y/18),r=(s.territoryRadiusInCells||1)+1;for(let dx=-r;dx<=r;dx++)for(let dy=-r;dy<=r;dy++)if(Math.max(Math.abs(dx),Math.abs(dy))===r&&this.state.ownership.get((cx+dx)+':'+(cy+dy))?.allianceId===allianceId)return true;return false;}

  if(target.resourceId||target.entity==='resource'){const r=this.data.resources.find(r=>r.id===target.resourceId||(!target.resourceId&&Math.hypot(r.x-target.x,r.y-target.y)<.01));return !!r&&this.resourceCovered(r,allianceId);}
  if(this.zoneError({...target,kind:'flag',allianceId}))return false;
  return this.state.ownership.get(Math.floor(target.x/18)+':'+Math.floor(target.y/18))?.allianceId===allianceId;

 }

}

export function validatePlan(plan,map){

 if(!plan||plan.map!==map||!Array.isArray(plan.buildings)||!Array.isArray(plan.alliances))throw Error('Der Plan gehört nicht zu dieser Karte.');

 if(plan.buildings.length>5000||!plan.alliances.length||plan.alliances.length>32)throw Error('Der Plan überschreitet die unterstützte Größe.');

 for(const b of plan.buildings)if(!kindToLegacy[b.kind]||!Number.isFinite(b.x)||!Number.isFinite(b.y)||!plan.alliances.some(a=>a.id===b.allianceId))throw Error('Ungültiges Gebäude im Plan.');

 for(const owner of Object.values(plan.capturedPasses||{}))if(!plan.alliances.some(a=>a.id===owner))throw Error('Ungültige Passzuordnung.');
 for(const a of plan.alliances)if(!/^#[0-9a-f]{6}$/i.test(a.color)||typeof a.name!=='string')throw Error('Ungültige Allianz.');

 for(const t of plan.targets||[])if(!Number.isFinite(t.x)||!Number.isFinite(t.y))throw Error('Ungültiges Ziel.');

 for(const a of plan.annotations||[])if(!Array.isArray(a.points)||a.points.length>10000||a.points.some(p=>!Array.isArray(p)||!p.every(Number.isFinite)))throw Error('Ungültige Zeichnung.');

 for(const v of Object.values(plan.siteEdits||{}))if(!Number.isFinite(v.x)||!Number.isFinite(v.y)||(v.rotation!==undefined&&!Number.isFinite(v.rotation))||(v.level!==undefined&&(!Number.isInteger(v.level)||v.level<1||v.level>99)))throw Error('Ungültige Referenzkorrektur.');

 const settings={...newPlan(map).settings,...plan.settings};
 // Upgrade the former default once; preserve deliberate non-default overrides.
 if((plan.version??0)<4&&(plan.settings?.resourceRadius==null||plan.settings.resourceRadius===.6))settings.resourceRadius=DEFAULT_RESOURCE_RADIUS_GAME;
 if((plan.version??0)<5&&plan.settings?.resourceRadius===1.5)settings.resourceRadius=DEFAULT_RESOURCE_RADIUS_GAME;
 settings.useCrusaderStructures=settings.useCrusaderStructures===true;
 settings.usePassStructures=settings.usePassStructures!==false;
 settings.allowZoneWalljumps=settings.allowZoneWalljumps!==false;
 settings.buildDetourLimit=Math.max(0,Math.min(3,Math.floor(Number(settings.buildDetourLimit??2)||0)));
 settings.routeMode=['balanced','crystal','build','war'].includes(plan.settings?.routeMode)?plan.settings.routeMode:plan.settings?.routeMode==='normal'?'build':(plan.settings?.crystals?'crystal':'build');
 settings.crystals=['balanced','crystal'].includes(settings.routeMode);
 if((plan.version??0)<6&&plan.settings?.resourceRadius===.385)settings.resourceRadius=DEFAULT_RESOURCE_RADIUS_GAME;
 if((plan.version??0)<7&&Math.abs(Number(plan.settings?.resourceRadius)-.531135)<1e-9)settings.resourceRadius=DEFAULT_RESOURCE_RADIUS_GAME;
 if((plan.version??0)<9){
  // Upgrade old factory defaults only; keep deliberate custom values.
  for(const [key,old,next]of [['flagRadius',3.16256/6,DEFAULT_FLAG_RADIUS_GAME],['fortressRadius',4.427584/6,DEFAULT_FORTRESS_RADIUS_GAME],['resourceRadius',4.585712/6,DEFAULT_RESOURCE_RADIUS_GAME]])if(plan.settings?.[key]==null||Math.abs(Number(plan.settings[key])-old)<1e-7)settings[key]=next;
 }
 if((plan.version??0)<10){
  for(const [key,old,next]of [['flagRadius',.7,DEFAULT_FLAG_RADIUS_GAME],['fortressRadius',.9,DEFAULT_FORTRESS_RADIUS_GAME],['villageRadius',.8,DEFAULT_LANDMARK_RADIUS_GAME],['caveRadius',.8,DEFAULT_LANDMARK_RADIUS_GAME]])if(plan.settings?.[key]==null||Math.abs(Number(plan.settings[key])-old)<1e-7)settings[key]=next;
 }
 if((plan.version??0)<11){
  // Only migrate the previous factory defaults, retaining independent overrides.
  for(const [key,old,next]of [['flagRadius',.67,DEFAULT_FLAG_RADIUS_GAME],['fortressRadius',.97,DEFAULT_FORTRESS_RADIUS_GAME],['villageRadius',.75,DEFAULT_LANDMARK_RADIUS_GAME],['caveRadius',.75,DEFAULT_LANDMARK_RADIUS_GAME]])if(plan.settings?.[key]==null||Math.abs(Number(plan.settings[key])-old)<1e-7)settings[key]=next;
 }
 if((plan.version??0)<12){
  for(const [key,old,next]of [['resourceRadius',1,DEFAULT_RESOURCE_RADIUS_GAME],['flagRadius',.71,DEFAULT_FLAG_RADIUS_GAME],['fortressRadius',.96,DEFAULT_FORTRESS_RADIUS_GAME],['villageRadius',.81,DEFAULT_LANDMARK_RADIUS_GAME],['caveRadius',.81,DEFAULT_LANDMARK_RADIUS_GAME]])if(plan.settings?.[key]==null||Math.abs(Number(plan.settings[key])-old)<1e-7)settings[key]=next;
 }
 settings.villageRadius=normalizeBuildingRadius(settings.villageRadius,DEFAULT_LANDMARK_RADIUS_GAME);
 settings.caveRadius=normalizeBuildingRadius(settings.caveRadius,DEFAULT_LANDMARK_RADIUS_GAME);
 settings.resourceRadius=footprintRadius(null,settings)/6;
 settings.flagRadius=normalizeBuildingRadius(settings.flagRadius,DEFAULT_FLAG_RADIUS_GAME);
 settings.fortressRadius=normalizeBuildingRadius(settings.fortressRadius,DEFAULT_FORTRESS_RADIUS_GAME);
 return {...newPlan(map),...plan,version:12,costAccounting:normalizeCostAccounting(plan),creditAccounting:normalizeCreditAccounting(plan.creditAccounting,plan.alliances),coalitions:normalizeCoalitions(plan.coalitions,plan.alliances),warBuilder:warConfig(plan.warBuilder),settings,siteEdits:plan.siteEdits||{}};

}


