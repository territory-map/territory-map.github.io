// Absolute planning radii in game coordinates; see analysis/calibration402.
// Resource and cave: median of three photo pairs, using their known native
// centre separation and a local foreshortening correction. Flag: concentric
// photo-ring ratio. Fortress: user-supplied approximate relative ratio (0.96).
// Village equals cave by user instruction. Each value is rounded and stored
// independently: later changes never rescale another category.
// Photographic estimates, not independently confirmed engine constants.
export const PHOTO_RADII_GAME=Object.freeze({resource:.98,flag:.67,fortress:.94,village:.73,cave:.73});
