// Shared world-space footprint; display zoom never changes physical coverage.
import {PHOTO_RADII_GAME} from './photo-calibration400.js';
// Shared with the fixed-centre flag calibration and measured reference ratios.
// Deposit radius is an adjustable estimate, not a verified client constant.
export const DEFAULT_RESOURCE_RADIUS_GAME=PHOTO_RADII_GAME.resource;
export const DEFAULT_RESOURCE_RADIUS=6*DEFAULT_RESOURCE_RADIUS_GAME;
export function resourceRadius(node,settings={}){
 const value=Number(settings.resourceRadius);
 const selected=6*Math.max(.25,Math.min(5,Number.isFinite(value)&&value>0?value:DEFAULT_RESOURCE_RADIUS_GAME));
 if(Number.isFinite(node?.collisionRadius)&&node.collisionRadius>0)return selected*node.collisionRadius/9;
 return Number(selected.toFixed(8));
}
// Fit the complete visible 2D symbol rectangle inside 92% of the circle diameter.
export function resourceSymbolHeight(bounds,radius){
 const width=Math.max(.01,(bounds.right-bounds.left)*bounds.aspect),height=Math.max(.01,bounds.top-bounds.anchor);
 return radius*2*.92/Math.hypot(width,height);
}
export function resourceCardScale(radius){return radius*2*.92/18;}
