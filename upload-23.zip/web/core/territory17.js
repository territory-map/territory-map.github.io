import {territoryCells,structureTerritoryCells} from './geometry.js';
const prepared=new WeakMap();
function prepare(structures){
 if(prepared.has(structures))return prepared.get(structures);
 const reserved=new Set(),excluded=new Set(),touching=new Map(),cellsById=new Map(),claimable=new Map();
 for(const s of structures){
  if(s.territoryRadiusInCells<=0)continue;const cells=structureTerritoryCells(s);cellsById.set(s.id,cells);
  for(const c of cells){const key=c.column+':'+c.row;reserved.add(key);if(!s.claimable)excluded.add(key);}
  if(!s.claimable)continue;claimable.set(s.id,s);const keys=new Set();
  for(const c of cells)for(const [dx,dy]of [[0,0],[1,0],[-1,0],[0,1],[0,-1]])keys.add((c.column+dx)+':'+(c.row+dy));
  for(const key of keys){if(!touching.has(key))touching.set(key,[]);touching.get(key).push(s.id);}
 }
 const result={reserved,excluded,touching,cellsById,claimable};prepared.set(structures,result);return result;
}
// Reverse cell index: only structures touching newly owned cells need revisiting.
// Building order, first ownership, four-way contact and exclusion rules are unchanged.
export function buildTerritoryState(buildings,structures,canClaim=()=>true){
 const p=prepare(structures),ownership=new Map(),structureOwners=new Map(),eligible=new Map();
 function add(cell,allianceId){const key=cell.column+':'+cell.row;if(ownership.has(key))return;ownership.set(key,{...cell,allianceId});if(!eligible.has(allianceId))eligible.set(allianceId,new Set());for(const id of p.touching.get(key)||[])eligible.get(allianceId).add(id);}
 for(const building of buildings){
  for(const cell of territoryCells(building))if(!p.reserved.has(cell.column+':'+cell.row))add(cell,building.allianceId);
  const pending=eligible.get(building.allianceId);if(!pending)continue;
  while(pending.size){const ids=[...pending].sort((a,b)=>a-b);pending.clear();
   for(const id of ids){if(structureOwners.has(id)||!canClaim(p.claimable.get(id),building.allianceId))continue;structureOwners.set(id,building.allianceId);if(p.claimable.get(id).conductsTerritory===false)continue;for(const cell of p.cellsById.get(id))if(!p.excluded.has(cell.column+':'+cell.row))add(cell,building.allianceId);}
  }
 }
 return {ownership,structureOwners};
}
