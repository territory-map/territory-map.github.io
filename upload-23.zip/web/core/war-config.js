export const WAR_ZONE_KEYS=['ourZone','ourTarget','enemyZone','enemyTarget'];
export function warConfig(value={}){
 const c={visible:value?.visible!==false};
 for(const k of WAR_ZONE_KEYS)c[k]=Number.isInteger(value?.[k])&&value[k]>0&&value[k]<65536?value[k]:0;
 return c;
}
