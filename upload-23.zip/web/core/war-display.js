export const warRequirementLabel=q=>q.kind==='flag'?'Flagge reicht':q.kind==='center-fortress'?'Hauptfestung nötig':'Festung nötig';
// Keep complete search results. Filtering and paging affect presentation only.
export const warRequirement=q=>q.requirement||(q.kind==='flag'?'flag':'fortress');
export const warSourceKey=q=>[q.side,warRequirement(q),q.sourceCell?.column??Math.floor(q.source.x/18),q.sourceCell?.row??Math.floor(q.source.y/18)].join(':');
export function displayedWarPairs(result,filter='all'){
 return (result?.directions||[]).flatMap(d=>d.pairs).filter(q=>typeof filter==='object'?filter[warRequirement(q)]!==false&&filter[q.side]!==false:filter==='all'||warRequirement(q)===filter);
}
export function warSourceMarkers(pairs){
 const markers=new Map();for(const q of pairs)if(!markers.has(warSourceKey(q)))markers.set(warSourceKey(q),q);return [...markers.values()];
}
export function warPage(pairs,page=0,size=40){
 const pages=Math.max(1,Math.ceil(pairs.length/size)),index=Math.max(0,Math.min(pages-1,page));return {index,pages,total:pairs.length,items:pairs.slice(index*size,(index+1)*size)};
}
