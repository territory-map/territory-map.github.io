import {zoneWaterAt} from './zone-water500.js';
const cache=new WeakMap();
// War zones group disconnected terrain pockets. Walking/collision labels stay
// unchanged, so this cannot grant access through a pass or allow a building.
export const zoneId=(access,label)=>access.warZoneMapping?.[label]??label;
export function warZoneAt(access,x,y,allowBlocked=false){
 if(!access.nav)return access.region(x,y);
 const [u,v]=access.pixel(x,y,access.nav.width,access.nav.height);
 if(u<0||v<0||u>=access.nav.width||v>=access.nav.height)return 0;
 const i=v*access.nav.width+u;
 if(zoneWaterAt(access,i))return 0;
 return allowBlocked?filledZoneRegions(access)[i]:zoneId(access,access.regions[i]);
}
export function normalizeWarZones(access,config){
 const out={...config};for(const key of ['ourZone','ourTarget','enemyZone','enemyTarget'])out[key]=zoneId(access,out[key]);
 if(out.ourZone&&out.ourTarget===out.ourZone)out.ourTarget=0;
 if(out.ourZone&&out.enemyZone===out.ourZone)out.enemyZone=0;
 if(out.enemyZone&&out.enemyTarget===out.enemyZone)out.enemyTarget=0;
 return out;
}
export function filledZoneRegions(access){
 if(cache.has(access))return cache.get(access);
 const {width:w,height:h}=access.nav,labels=new Uint16Array(access.regions),distance=new Uint16Array(labels.length);
 if(access.warZoneMapping)for(let i=0;i<labels.length;i++)labels[i]=zoneId(access,labels[i]);
 for(let i=0;i<labels.length;i++)if(!labels[i])distance[i]=65535;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){
  const i=y*w+x;if(!distance[i])continue;
  if(x&&distance[i-1]+1<distance[i]){distance[i]=distance[i-1]+1;labels[i]=labels[i-1];}
  if(y&&distance[i-w]+1<distance[i]){distance[i]=distance[i-w]+1;labels[i]=labels[i-w];}
 }
 for(let y=h-1;y>=0;y--)for(let x=w-1;x>=0;x--){
  const i=y*w+x;if(!distance[i])continue;
  if(x+1<w&&distance[i+1]+1<distance[i]){distance[i]=distance[i+1]+1;labels[i]=labels[i+1];}
  if(y+1<h&&distance[i+w]+1<distance[i]){distance[i]=distance[i+w]+1;labels[i]=labels[i+w];}
 }
 // Fill walls, passes and relief as before, then clip the selection to land.
 // Water must never acquire a zone, even when nearest-zone filling reaches it.
 // The raw navigation/collision labels and complete land-zone groups stay intact.
 if(access.zoneWater)for(let i=0;i<labels.length;i++)if(zoneWaterAt(access,i))labels[i]=0;
 cache.set(access,labels);return labels;
}
