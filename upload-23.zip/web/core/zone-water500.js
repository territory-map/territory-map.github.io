import {COAST_CATALOG} from './coast-catalog500.js';

// A shared generated catalogue keeps full maps and compact worker maps equal.
// The compact maps intentionally omit the expensive native water geometry.
export function zoneWaterMask(data){
 const entry=COAST_CATALOG[data.catalog.map],nav=data.navigation18;
 if(!entry||!nav)return null;
 // Custom/test grids reusing a native map name have a different registration.
 // Never apply that map's mask to unrelated dimensions or world bounds.
 if(entry.width!==nav.width||entry.height!==nav.height||entry.bounds.some((v,i)=>v!==data.catalog.bounds[i]))return null;
 const text=atob(entry.runs),out=new Uint8Array(Math.ceil(nav.width*nav.height/8));
 let offset=0;
 for(let i=0;i<text.length;){
  let count=0,shift=0,byte;
  do{byte=text.charCodeAt(i++);count+=(byte&127)*2**shift;shift+=7;}while(byte&128);
  const value=text.charCodeAt(i++);
  if(!count||!Number.isFinite(value)||offset+count>out.length)throw Error('Invalid war-zone water mask');
  out.fill(value,offset,offset+count);offset+=count;
 }
 if(offset!==out.length)throw Error('Incomplete war-zone water mask');
 return out;
}

export const zoneWaterAt=(access,index)=>!!(access.zoneWater?.[index>>3]&(128>>(index&7)));
