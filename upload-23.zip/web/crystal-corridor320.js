import {G,clone} from './core/model.js';
import {buildPoint} from './core/build-position.js';
import {validPlan} from './solver-search254.js';
import {route} from './route280.js';

// Improve a completed network, including small bends which global waypoint
// trials miss. Every accepted replacement/addition preserves exact deposits,
// targets, initial buildings and sequential construction under the current rules.
export function crystalCorridor(model,base,initial,aid,{totalCap,deadline,mode='crystal',maxVisits,maxNodes},progress=()=>{}){
 const original=model.plan,baseLength=base.buildings.length,crystals=model.data.resources.filter(r=>r.kind==='crystal');
 let best=clone(initial),serial=0,attempts=0,swaps=0,branches=0,pruned=0,rounds=0;
 const usedIds=new Set(initial.buildings.map(b=>b.id));
 const nextId=()=>{let id;do{id='corridor-'+serial++;}while(usedIds.has(id));usedIds.add(id);return id;};
 const count=p=>p.buildings.length-baseLength;
 const covered=()=>crystals.filter(r=>model.resourceCovered(r,aid));
 model.setPlan(base);const originalDeposits=new Set(covered().map(r=>r.id));
 const constraints=deposits=>[...base.targets,...deposits.filter(r=>!originalDeposits.has(r.id)).map(r=>({id:'preserve-'+r.id,resourceId:r.id,x:r.x,y:r.y}))];
 const flags=p=>p.buildings.slice(baseLength);
 const checkpoint=(p,deposits)=>validPlan(model,base,flags(p),aid,constraints(deposits));
 const prune=(p,deposits,stop)=>{
  const required=constraints(deposits);let current=p;
  for(let i=current.buildings.length-1;i>=baseLength&&performance.now()<stop;i--){
   const trial=current.buildings.slice(baseLength).filter((_,j)=>j!==i-baseLength),checked=validPlan(model,base,trial,aid,required);
   if(checked)current=checked;
  }
  return current;
 };
 function anchors(plan,pending,stop){
  model.setPlan(plan);const ownership=model.state.ownership,byCell=new Map();
  for(const r of pending){const cx=Math.floor(r.x/18),cy=Math.floor(r.y/18);for(let dx=-2;dx<=2;dx++)for(let dy=-2;dy<=2;dy++){
   const x=cx+dx,y=cy+dy,k=x+':'+y;let cell=byCell.get(k);if(!cell)byCell.set(k,cell={x,y,near:[]});cell.near.push(r);
  }}
  const out=[];
  for(const {x,y,near}of byCell.values()){
   if(performance.now()>=stop)break;
   const b={id:nextId(),kind:'flag',allianceId:aid,...buildPoint(x*18+9,y*18+9)},cells=new Set(G.territoryCells(b).map(c=>c.column+':'+c.row).filter(k=>!model.reservedCells.has(k)));
   const hypothetical={get(k){return ownership.get(k)||(cells.has(k)?{allianceId:aid}:undefined);}};
   const gain=near.filter(r=>model.resourceCovered(r,aid,hypothetical)).length;if(!gain)continue;
   const nearest=Math.min(...plan.buildings.filter(b=>b.allianceId===aid).map(p=>Math.hypot(p.x-b.x,p.y-b.y)));
   if(nearest>(Math.max(0,totalCap-count(plan))+3)*54)continue;
   // Cell-centre-only sampling misses valid centres beside resources/hatching.
   const positions=[];for(const [dx,dy]of [[9,9],[3,9],[15,9],[9,3],[9,15],[3,3],[15,3],[3,15],[15,15]]){
    const q={...b,...buildPoint(x*18+dx,y*18+dy)};if(!model.staticError(q,plan.settings.strict))positions.push(q);
   }
   if(positions.length)out.push({positions,gain,nearest,score:gain/(1+nearest/54)});
  }
  return out.sort((a,b)=>b.score-a.score||b.gain-a.gain||a.nearest-b.nearest);
 }
 try{
  for(;rounds<(mode==='crystal'?20:8)&&performance.now()<deadline;rounds++){
   model.setPlan(best);const deposits=covered(),gems=deposits.length,pending=crystals.filter(r=>!model.resourceCovered(r,aid));if(!pending.length)break;
   const remaining=totalCap-count(best),choices=anchors(best,pending,Math.min(deadline,performance.now()+500));let improved=null;
   // Try moving an existing new flag first: a bend can collect crystals without
   // spending an additional flag or leaving a permanent branch behind.
   for(const choice of choices.slice(0,mode==='crystal'?48:24)){
    if(performance.now()>=deadline)break;
    for(const q of choice.positions.slice(0,3)){
     if(performance.now()>=deadline)break;
     const nearby=flags(best).filter(b=>b.kind==='flag'&&Math.hypot(b.x-q.x,b.y-q.y)<=72).sort((a,b)=>Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y)).slice(0,3);
     for(const old of nearby){
      if(performance.now()>=deadline)break;attempts++;
      const trial=clone(best);trial.buildings=trial.buildings.filter(b=>b.id!==old.id);trial.buildings.push(q);
      const checked=checkpoint(trial,deposits);if(!checked)continue;model.setPlan(checked);
      if(covered().length>gems){improved=checked;swaps++;break;}
     }
     if(improved)break;
     model.setPlan(best);
     if(remaining>0&&!model.placementError(q)){
      const trial=clone(best);trial.buildings.push(q);model.setPlan(trial);
      const collected=covered();if(collected.length<=gems)continue;
      const checked=checkpoint(trial,deposits);if(checked){improved=checked;branches++;break;}
     }
    }
    if(improved)break;
   }
   if(!improved&&remaining>=0&&performance.now()<deadline){
    model.setPlan(best);const sources=best.buildings.filter(b=>b.allianceId===aid&&model.isBuildingActive(b));
    const ranked=pending.map(r=>{const d=Math.min(...sources.map(s=>Math.hypot(s.x-r.x,s.y-r.y))),density=pending.filter(q=>Math.hypot(r.x-q.x,r.y-q.y)<=90).length;return {r,d,density,score:d/Math.sqrt(density)};}).filter(q=>q.d<(remaining+3)*54);
    const selected=new Map();for(const q of [...ranked.slice().sort((a,b)=>a.d-b.d).slice(0,4),...ranked.sort((a,b)=>a.score-b.score).slice(0,mode==='crystal'?12:6)])selected.set(q.r.id,q);
    let winner=null,winnerRatio=0;
    for(const {r,density}of selected.values()){
     if(performance.now()>=deadline)break;attempts++;
     const request=clone(best);request.targets=[{id:'corridor-via-'+r.id,resourceId:r.id,x:r.x,y:r.y}];
     // Two temporary planning flags allow replacing an old straight segment.
     // Only a pruned, validated result within totalCap may become the incumbent.
     const result=route(model,request,aid,{budget:remaining+2,crystals:false,maxVisits:Math.min(maxVisits,6000),maxNodes:Math.min(maxNodes,10000),deadline:Math.min(deadline,performance.now()+Math.min(450,100+density*35))});
     if(!result.buildings.length)continue;
     const trial=clone(best);trial.buildings.push(...result.buildings);const checked=checkpoint(trial,deposits);if(!checked)continue;model.setPlan(checked);
     const collected=covered(),gain=collected.length-gems;if(gain<=0)continue;
     const reduced=prune(checked,collected,Math.min(deadline,performance.now()+450));if(count(reduced)>totalCap)continue;
     const extra=Math.max(1,count(reduced)-count(best)),ratio=gain/extra;
     if(mode==='balanced'&&ratio<.75)continue;
     if(ratio>winnerRatio||ratio===winnerRatio&&count(reduced)<count(winner)){winner=reduced;winnerRatio=ratio;}
    }
    if(winner){improved=winner;branches++;}
   }
   if(!improved)break;
   model.setPlan(improved);const gained=covered();const reduced=prune(improved,gained,Math.min(deadline,performance.now()+350));pruned+=count(improved)-count(reduced);best=reduced;
   progress({phase:'Kristall-Korridor',visits:attempts,added:count(best),crystals:gained.length,remaining:0});
  }
  return {plan:best,report:{attempts,swaps,branches,pruned,rounds}};
 }finally{model.setPlan(original);}
}
