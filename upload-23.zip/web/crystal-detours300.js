import {clone} from './core/model.js';
import {route} from './route280.js';
import {validPlan} from './solver-search254.js';

// Compare complete routes through dense crystal clusters. Extra flags can be
// spent before reaching a goal, rather than only after completing a direct leg.
export function crystalDetours(model,base,incumbent,aid,{totalCap,deadline,maxVisits,maxNodes,trials=20,mode='balanced'},progress=()=>{}){
 const original=model.plan,baseLength=base.buildings.length;
 let best=clone(incumbent),bestGems=0,bestCount=0,attempts=0;
 const measure=p=>{model.setPlan(p);return model.covered(aid).crystal||0;};
 bestGems=measure(best);bestCount=best.buildings.length-baseLength;
 model.setPlan(base);const resources=model.data.resources.filter(r=>r.kind==='crystal'&&!model.resourceCovered(r,aid));
 const starts=base.buildings.filter(b=>b.allianceId===aid&&model.isBuildingActive(b));
 if(!starts.length||!resources.length)return {plan:best,attempts};
 const goals=base.targets.map(t=>t.siteId?model.sites.find(s=>s.siteId===t.siteId):t).filter(Boolean);
 const distance=(p,points)=>Math.min(...points.map(q=>Math.hypot(p.x-q.x,p.y-q.y)));
 const ranked=resources.map(r=>{
  const start=distance(r,starts),goal=goals.length?distance(r,goals):0;
  const direct=goals.length?Math.min(...starts.map(s=>distance(s,goals))):0;
  const detour=Math.max(0,(start+goal-direct)/54);
  const density=resources.filter(q=>Math.hypot(r.x-q.x,r.y-q.y)<=108).length;
  return {r,detour,score:density/(1+detour*.4)};
 }).filter(q=>q.detour<=totalCap+2).sort((a,b)=>b.score-a.score||a.detour-b.detour||String(a.r.id).localeCompare(String(b.r.id)));
 const groups=[];for(const q of ranked)if(!groups.some(p=>Math.hypot(q.r.x-p.r.x,q.r.y-p.r.y)<108)){
  const nearby=resources.filter(r=>Math.hypot(r.x-q.r.x,r.y-q.r.y)<=54),cx=nearby.reduce((n,r)=>n+r.x,0)/nearby.length,cy=nearby.reduce((n,r)=>n+r.y,0)/nearby.length;
  const centre=[...nearby].sort((a,b)=>Math.hypot(a.x-cx,a.y-cy)-Math.hypot(b.x-cx,b.y-cy))[0];
  groups.push({...q,centre,nearby});if(groups.length>=(mode==='crystal'?24:8))break;
 }
 // Diversity first, then alternative entry/exit points in each cluster.
 const seeds=[...groups.map(q=>({...q,r:q.centre})),...groups,...groups.flatMap(q=>q.nearby.slice(-2).map(r=>({...q,r})))].filter((q,i,a)=>a.findIndex(p=>p.r.id===q.r.id)===i);

 const beam=[{via:[],gems:bestGems}],signatures=new Set();
 try{
  if(mode==='crystal'&&goals.length){
   // A sequence of modest bends can visit many separated deposits. Three
   // independent cluster waypoints cannot describe such a complete main route.
   const start=starts.reduce((a,b)=>distance(a,goals)<distance(b,goals)?a:b),goal=goals.reduce((a,b)=>Math.hypot(a.x-start.x,a.y-start.y)<Math.hypot(b.x-start.x,b.y-start.y)?a:b);
   const vx=goal.x-start.x,vy=goal.y-start.y,len2=vx*vx+vy*vy||1;
   const corridor=groups.map(q=>({...q,projection:((q.centre.x-start.x)*vx+(q.centre.y-start.y)*vy)/len2})).filter(q=>q.projection>=-.15&&q.projection<=1.15);
   const variants=[corridor,corridor.filter(q=>q.detour<=Math.max(3,(totalCap-bestCount)*.6)),groups.slice(0,12)];
   for(const chosen of variants){
    if(performance.now()>=deadline||attempts>=trials)break;
    const via=chosen.slice().sort((a,b)=>a.projection-b.projection).map(q=>q.centre);if(!via.length)continue;attempts++;
    const request=clone(base);request.targets=[...via.map(r=>({id:'corridor-waypoint-'+r.id,resourceId:r.id,x:r.x,y:r.y})),...base.targets];
    const result=route(model,request,aid,{budget:totalCap,crystals:true,order:2,maxVisits:Math.min(maxVisits,12000),maxNodes:Math.min(maxNodes,22000),deadline:Math.min(deadline,performance.now()+1200)});
    const checked=validPlan(model,base,result.buildings,aid,base.targets);if(!checked)continue;
    const gems=measure(checked),count=checked.buildings.length-baseLength;
    if(gems>bestGems||gems===bestGems&&count<bestCount){best=checked;bestGems=gems;bestCount=count;progress({phase:'Kristall-Umwege',visits:attempts,added:count,crystals:gems,remaining:0});}
   }
  }
  for(let depth=0;depth<3&&attempts<trials&&performance.now()<deadline;depth++){
   const next=[];
   for(const parent of beam.slice(0,3))for(const seed of seeds.slice(0,depth?6:12)){
    if(attempts>=trials||performance.now()>=deadline)break;
    if(parent.via.some(r=>r.id===seed.r.id))continue;
    const via=[...parent.via,seed.r],signature=via.map(r=>r.id).join('|');if(signatures.has(signature))continue;signatures.add(signature);attempts++;
    const request=clone(base);request.targets=[...via.map(r=>({id:'detour-'+r.id,resourceId:r.id,x:r.x,y:r.y})),...base.targets];
    const r=route(model,request,aid,{budget:totalCap,crystals:false,order:2,maxVisits:Math.min(maxVisits,16000),maxNodes:Math.min(maxNodes,22000),deadline:Math.min(deadline,performance.now()+900)});
    const p=validPlan(model,base,r.buildings,aid,base.targets);if(!p)continue;
    const gems=measure(p),count=p.buildings.length-baseLength;
    next.push({via,gems,count});
    if(gems>bestGems||gems===bestGems&&count<bestCount){best=p;bestGems=gems;bestCount=count;progress({phase:'Kristall-Umwege',visits:attempts,added:count,crystals:gems,remaining:0});}
   }
   next.sort((a,b)=>b.gems-a.gems||a.count-b.count);beam.splice(0,beam.length,...next.slice(0,3));if(!beam.length)break;
  }
  return {plan:best,attempts};
 }finally{model.setPlan(original);}
}
