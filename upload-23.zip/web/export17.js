import {C,legacy,kindToLegacy} from './core/model.js?v=20261002.254';
import {gameCoordinate} from './presentation17.js';

const names={food:'Nahrung',wood:'Holz',stone:'Stein',gold:'Gold',coin:'Gold',crystal:'Kristall',credits:'Allianzcredits'};
const buildingNames={flag:'Flagge',fortress:'Allianzfestung','center-fortress':'Zentralfestung',horse:'Pferch'};
export function allianceReport(model,plan){
 const schedule=Object.fromEntries(Object.entries(model.catalog.costs).map(([k,v])=>[kindToLegacy[k],v]));
 return plan.alliances.map(a=>{
  const buildings=plan.buildings.filter(b=>b.allianceId===a.id),covered=model.covered(a.id);
  const production=Object.entries(model.catalog.resourceProductionPerHour||{}).map(([kind,rate])=>({name:names[kind]||kind,value:(covered[kind]??covered[kind==='gold'?'coin':kind]??0)*rate}));
  const costs=C.calculateCostTotals(plan.buildings.map(legacy),schedule,a.id);
  return {...a,production,costs,buildings:[...buildings.filter(b=>b.kind!=='flag'),...buildings.filter(b=>b.kind==='flag')].map((b,i)=>({...b,x:gameCoordinate(b.x),y:gameCoordinate(b.y),name:buildingNames[b.kind]||b.kind}))};
 });
}

export async function exportFullMap(view){
 // Wait for newly placed artwork before capturing. Render tiles at full-map scale,
 // independently of the current pan, zoom and device pixel ratio.
 await Promise.all([...view.pendingSprites]);
 const report=allianceReport(view.model,view.plan),format=n=>new Intl.NumberFormat('de-CH',{maximumFractionDigits:0}).format(n);
 const columns=[];
 for(const a of report){
  const lines=[{text:a.name,heading:true},{text:'Produktion / Stunde',heading:true},...a.production.map(p=>({text:p.name+': '+format(p.value)+' / h'})),{text:'Baukosten gesamt',heading:true},...Object.entries(a.costs).filter(([k])=>k!=='unknown').map(([k,v])=>({text:(names[k]||k)+': '+format(v)})),...(a.costs.unknown?[{text:'Nicht bekannte Kosten: '+a.costs.unknown}]:[]),{text:'Gebäude · Spielkoordinaten',heading:true}];
  let flag=0,fort=0;for(const b of a.buildings)lines.push({text:b.name+' '+(b.kind==='flag'?++flag:++fort)+'   X '+b.x+' · Y '+b.y});
  if(!a.buildings.length)lines.push({text:'Keine Gebäude'});
  for(let start=0;start<lines.length;start+=170)columns.push({color:a.color,lines:start?[{text:a.name+' · Fortsetzung',heading:true},...lines.slice(start,start+170)]:lines.slice(0,170)});
 }
 const width=4096,b=view.model.catalog.bounds,c=Math.abs(Math.cos(view.azimuth)),s=Math.abs(Math.sin(view.azimuth)),dx=b[2]-b[0],dy=b[3]-b[1];
 const pw=view.mode==='3d'?c*dx+s*dy:dx,ph=view.mode==='3d'?(s*dx+c*dy)*Math.cos(view.tilt)+100:dy;
 const mapHeight=Math.ceil(width*ph/pw)+120,cols=Math.min(6,Math.max(1,columns.length)),colWidth=width/cols,lineHeight=28,padding=26;
 const bands=[];for(let i=0;i<columns.length;i+=cols)bands.push(columns.slice(i,i+cols));
 const heights=bands.map(band=>Math.max(...band.map(a=>a.lines.length))*lineHeight+padding*2);
 const height=mapHeight+100+heights.reduce((a,b)=>a+b,0),canvas=document.createElement('canvas');
 if(height>32760)throw Error('Der Plan ist für eine einzelne PNG-Datei zu groß. Bitte die Allianzanzahl für den Bildexport reduzieren; der Planexport enthält weiterhin alle Gebäude.');
 canvas.width=width;canvas.height=height;const ctx=canvas.getContext('2d');if(!ctx)throw Error('Bildspeicher konnte nicht angelegt werden.');
 const saved={w:view.w,h:view.h,scale:view.scale,center:view.center.clone(),fit:view.isFitted,ratio:view.renderer.getPixelRatio(),cursor:view.cursorGroup.visible,shadow:view.renderer.shadowMap.enabled};
 try{
  view.w=width;view.h=mapHeight;view.center.set((b[0]+b[2])/2,0,-(b[1]+b[3])/2);view.scale=Math.max(pw/(width-120),ph/(mapHeight-120));view.isFitted=false;view.cursorGroup.visible=false;view.renderer.setPixelRatio(1);view.updateCamera();view.renderer.shadowMap.enabled=false;view.updateSprites();
  for(let y=0;y<mapHeight;y+=1024)for(let x=0;x<width;x+=1024){
   const tw=Math.min(1024,width-x),th=Math.min(1024,mapHeight-y);view.renderer.setSize(tw,th,false);view.camera.setViewOffset(width,mapHeight,x,y,tw,th);view.renderer.render(view.scene,view.camera);ctx.drawImage(view.canvas,x,y,tw,th);
   await new Promise(resolve=>requestAnimationFrame(resolve));
  }
 }finally{
  view.camera.clearViewOffset();view.w=saved.w;view.h=saved.h;view.scale=saved.scale;view.center.copy(saved.center);view.isFitted=saved.fit;view.cursorGroup.visible=saved.cursor;view.renderer.setPixelRatio(saved.ratio);view.renderer.setSize(saved.w,saved.h);view.updateCamera();view.renderer.shadowMap.enabled=saved.shadow;view.updateSprites();view.dirty=true;
 }
 ctx.fillStyle='#14242d';ctx.fillRect(0,mapHeight,width,height-mapHeight);ctx.fillStyle='#ecf4f4';ctx.font='600 30px system-ui';ctx.fillText(view.model.catalog.name+' · Allianzplanung · Territory Lab 1.7',padding,mapHeight+44);ctx.font='20px system-ui';ctx.fillStyle='#bbced2';ctx.fillText('Gesamte Karte · '+(view.mode==='3d'?'3D':'2D')+' · Koordinaten auf ganze Spielkoordinaten aufgerundet',padding,mapHeight+78);
 let top=mapHeight+100;
 for(let band=0;band<bands.length;band++){
  for(let i=0;i<bands[band].length;i++){
   const a=bands[band][i],left=i*colWidth;ctx.fillStyle=a.color;ctx.fillRect(left+padding,top+10,colWidth-padding*2,5);
   a.lines.forEach((line,j)=>{ctx.font=(line.heading?'600 ':'')+'21px system-ui';ctx.fillStyle=line.heading?a.color:'#e8f0f2';ctx.fillText(line.text,left+padding,top+padding+24+j*lineHeight,colWidth-padding*2);});
  }top+=heights[band];
 }
 return new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(Error('PNG konnte nicht erstellt werden.')),'image/png'));
}
