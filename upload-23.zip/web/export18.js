import {C,G,legacy,kindToLegacy} from './core/model.js?v=20261002.254';
import {gameCoordinate} from './presentation17.js';
const words={
 de:{overview:'Allianzübersicht',buildings:'Gebäude',alliance:'Allianz',kind:'Gebäudetyp',number:'Nummer',x:'Spielkoordinate X',y:'Spielkoordinate Y',cost:'Baukosten',production:'Produktion / Stunde',full:'Gesamte Karte',visible:'Sichtbarer Bereich',unknown:'Kosten unbekannt',empty:'Keine Gebäude',source:'Quelle: aktueller Plan und mitgelieferte Kartendaten.',scope:'Bereich: Gebäude nach Sockelposition; Produktion aus Ressourcen im Bereich. Kostenstufen folgen dem gesamten Plan.',round:'Spielkoordinaten sind auf die nächste ganze Zahl gerundet; ab 0,5 wird aufgerundet. Zahlen sind Momentaufnahmen des Plans.',flag:'Flagge',fortress:'Allianzfestung','center-fortress':'Hauptfestung',horse:'Sammelpunkt',food:'Nahrung',wood:'Holz',stone:'Stein',gold:'Gold',coin:'Gold',crystal:'Kristall',credits:'Allianzcredits'},
 en:{overview:'Alliance overview',buildings:'Buildings',alliance:'Alliance',kind:'Building type',number:'Number',x:'Game coordinate X',y:'Game coordinate Y',cost:'Building costs',production:'Production / hour',full:'Entire map',visible:'Visible area',unknown:'Unknown costs',empty:'No buildings',source:'Source: current plan and bundled map data.',scope:'Area: buildings selected by base position; production from resources in the area. Cost tiers follow the entire plan.',round:'Game coordinates are rounded to the nearest whole number; 0.5 rounds up. Numbers are snapshots of the plan.',flag:'Flag',fortress:'Alliance fortress','center-fortress':'Central fortress',horse:'Rally point',food:'Food',wood:'Wood',stone:'Stone',gold:'Gold',coin:'Gold',crystal:'Crystal',credits:'Alliance credits'},
 fr:{overview:'Aperçu des alliances',buildings:'Bâtiments',alliance:'Alliance',kind:'Type de bâtiment',number:'Numéro',x:'Coordonnée X du jeu',y:'Coordonnée Y du jeu',cost:'Coûts de construction',production:'Production / heure',full:'Carte entière',visible:'Zone visible',unknown:'Coûts inconnus',empty:'Aucun bâtiment',source:'Source : plan actuel et données cartographiques incluses.',scope:'Zone : bâtiments selon leur socle ; production des ressources dans la zone. Les paliers de coût suivent le plan entier.',round:'Les coordonnées sont arrondies à l’entier le plus proche ; à partir de 0,5, elles sont arrondies vers le haut. Les nombres représentent un instantané du plan.',flag:'Drapeau',fortress:'Forteresse d’alliance','center-fortress':'Forteresse centrale',horse:'Point de ralliement',food:'Nourriture',wood:'Bois',stone:'Pierre',gold:'Or',coin:'Or',crystal:'Cristal',credits:'Crédits d’alliance'}
};
export const exportWords=lang=>words[lang]||words.de;
export function visibleFilter(view){
 // Freeze the actual camera, including 3D rotation, rather than an axis-aligned
 // approximation of its ground footprint. Never move it for an area report.
 view.updateCamera();const matrix=new THREE.Matrix4().multiplyMatrices(view.camera.projectionMatrix,view.camera.matrixWorldInverse);
 return p=>{const q=new THREE.Vector3(p.x,0,-p.y).applyMatrix4(matrix);return Math.abs(q.x)<=1+1e-7&&Math.abs(q.y)<=1+1e-7&&Math.abs(q.z)<=1+1e-7;};
}
export function reportData(model,plan,lang='de',include=null){
 const t=exportWords(lang),schedule=Object.fromEntries(Object.entries(model.catalog.costs).map(([k,v])=>[kindToLegacy[k],v]));
 return plan.alliances.map(a=>{
  const entries=C.buildingCostBreakdown(plan.buildings.map(legacy),schedule,a.id).filter(e=>!include||include(e.building));
  const costs={credits:0,food:0,wood:0,stone:0,gold:0,crystal:0,unknown:0};
  for(const e of entries)if(e.cost){for(const k of Object.keys(costs))if(k!=='unknown')costs[k]+=e.cost[k]||0;}else costs.unknown++;
  const covered=include?model.covered(a.id,model.data.resources.filter(include)):model.covered(a.id);
  const production=Object.entries(model.catalog.resourceProductionPerHour||{}).map(([kind,rate])=>({kind,name:t[kind]||kind,value:(covered[kind]??covered[kind==='gold'?'coin':kind]??0)*rate}));
  const buildings=entries.map(e=>{const original=plan.buildings.find(b=>b.id===e.building.id);return {...original,number:e.number,cost:e.cost,x:gameCoordinate(e.building.x),y:gameCoordinate(e.building.y),name:t[original.kind]||original.kind};}).sort((a,b)=>(a.kind==='flag')-(b.kind==='flag'));
  return {...a,costs,production,buildings};
 });
}
const xml=s=>String(s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const col=n=>{let s='';for(n++;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;};
const cell=(v,style=0)=>({v,style});
function sheetXML(rows,widths,filter=false,merges=[]){
 const last=col(Math.max(...rows.map(r=>r.length))-1)+rows.length;
 return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><dimension ref="A1:'+last+'"/><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>'+widths.map((w,i)=>'<col min="'+(i+1)+'" max="'+(i+1)+'" width="'+w+'" customWidth="1"/>').join('')+'</cols><sheetData>'+rows.map((r,i)=>'<row r="'+(i+1)+'" ht="'+(i===0?40:24)+'" customHeight="1">'+r.map((item,j)=>{const c=typeof item==='object'?item:cell(item),ref=col(j)+(i+1);return typeof c.v==='number'?'<c r="'+ref+'" s="'+(c.style||1)+'"><v>'+c.v+'</v></c>':'<c r="'+ref+'" s="'+c.style+'" t="inlineStr"><is><t xml:space="preserve">'+xml(c.v??'')+'</t></is></c>';}).join('')+'</row>').join('')+'</sheetData>'+(filter?'<autoFilter ref="A1:'+last+'"/>':'')+(merges.length?'<mergeCells count="'+merges.length+'">'+merges.map(r=>'<mergeCell ref="'+r+'"/>').join('')+'</mergeCells>':'')+'</worksheet>';
}
// Dependency-free, standards-based XLSX container for offline browser export.
// Strings use inlineStr: alliance names beginning with = are never formulas.
export function zipStore(files){
 const encoder=new TextEncoder(),chunks=[],directory=[];let offset=0;
 const table=Uint32Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
 const head=(size,values)=>{const a=new Uint8Array(size),v=new DataView(a.buffer);for(const [p,n,width]of values)(width===2?v.setUint16.bind(v):v.setUint32.bind(v))(p,n,true);return a;};
 for(const [name,text]of Object.entries(files)){
  const n=encoder.encode(name),data=encoder.encode(text);let crc=0xffffffff;for(const b of data)crc=table[(crc^b)&255]^(crc>>>8);crc=(crc^0xffffffff)>>>0;
  const local=head(30,[[0,0x04034b50,4],[4,20,2],[6,0x800,2],[14,crc,4],[18,data.length,4],[22,data.length,4],[26,n.length,2]]);
  const central=head(46,[[0,0x02014b50,4],[4,20,2],[6,20,2],[8,0x800,2],[16,crc,4],[20,data.length,4],[24,data.length,4],[28,n.length,2],[42,offset,4]]);
  chunks.push(local,n,data);directory.push(central,n);offset+=local.length+n.length+data.length;
 }
 const size=directory.reduce((n,a)=>n+a.length,0),count=Object.keys(files).length;
 return new Blob([...chunks,...directory,head(22,[[0,0x06054b50,4],[8,count,2],[10,count,2],[12,size,4],[16,offset,4]])],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
}
export function exportWorkbook(model,plan,lang='de',include=null){
 const t=exportWords(lang),alliances=reportData(model,plan,lang,include),resources=['credits','food','wood','stone','gold','crystal'];
 const rows=[[cell(model.catalog.name+' · '+(include?t.visible:t.full),2)],[t.source],[t.round],...(include?[[t.scope]]:[]),[]];
 const columns=alliances.map((a,i)=>{
  const h=3+i,lines=[[cell(a.name,h),''],[cell(t.production,h),''],...a.production.map(p=>[p.name,p.value]),[cell(t.cost,h),''],...resources.map(k=>[t[k],a.costs[k]]),[t.unknown,a.costs.unknown],[cell(t.buildings,h),''],...a.buildings.map(b=>[b.name+' '+b.number,'X '+b.x+' · Y '+b.y])];
  if(!a.buildings.length)lines.push([t.empty,'']);return lines;
 });
 for(let n=0;n<Math.max(0,...columns.map(c=>c.length));n++)rows.push(columns.flatMap(c=>[...(c[n]||['','']),'']));
 const details=[[t.alliance,t.kind,t.number,t.x,t.y,...resources.map(k=>t.cost+' · '+t[k]),t.unknown].map(v=>cell(v,2))];
 for(const a of alliances)for(const b of a.buildings)details.push([a.name,b.name,b.number,b.x,b.y,...resources.map(k=>b.cost?b.cost[k]||0:'—'),b.cost?0:1]);
 const fonts=['<font><sz val="11"/><name val="Calibri"/><color rgb="FF233A40"/></font>','<font><b/><sz val="12"/><name val="Calibri"/><color rgb="FFFFFFFF"/></font>',...alliances.map(a=>'<font><b/><sz val="12"/><name val="Calibri"/><color rgb="FF'+a.color.slice(1).toUpperCase()+'"/></font>')];
 const styles='<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="'+fonts.length+'">'+fonts.join('')+'</fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF14242D"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="'+(3+alliances.length)+'"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf>'+alliances.map((_,i)=>'<xf numFmtId="0" fontId="'+(2+i)+'" fillId="2" borderId="0" xfId="0"/>').join('')+'</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
 const files={
  '[Content_Types].xml':'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'+[1,2].map(i=>'<Override PartName="/xl/worksheets/sheet'+i+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join('')+'</Types>',
  '_rels/.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
  'xl/workbook.xml':'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="'+xml(t.overview)+'" sheetId="1" r:id="rId1"/><sheet name="'+xml(t.buildings)+'" sheetId="2" r:id="rId2"/></sheets></workbook>',
  'xl/_rels/workbook.xml.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+[1,2].map(i=>'<Relationship Id="rId'+i+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet'+i+'.xml"/>').join('')+'<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>',
  'xl/styles.xml':styles,'xl/worksheets/sheet1.xml':sheetXML(rows,alliances.flatMap(()=>[36,25,4]),false,[1,2,3,...(include?[4]:[])].map(n=>'A'+n+':'+col(Math.max(2,alliances.length*3-1))+n)),
  'xl/worksheets/sheet2.xml':sheetXML(details,[28,30,12,22,22,...resources.map(()=>26),20],true)
 };return zipStore(files);
}

