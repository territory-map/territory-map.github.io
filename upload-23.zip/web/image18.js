export async function exportMapImage(view,visible=false){
 await Promise.all([...view.pendingSprites]);
 const b=view.model.catalog.bounds,c=Math.abs(Math.cos(view.azimuth)),s=Math.abs(Math.sin(view.azimuth)),dx=b[2]-b[0],dy=b[3]-b[1];
 const pw=view.mode==='3d'?c*dx+s*dy:dx,ph=view.mode==='3d'?(s*dx+c*dy)*Math.cos(view.tilt):dy;
 const width=4096,height=visible?Math.round(width*view.h/view.w):Math.ceil(width*ph/pw);
 if(height>32760)throw Error('PNG exceeds 32760 pixels');
 const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;const ctx=canvas.getContext('2d');
 const saved={w:view.w,h:view.h,scale:view.scale,center:view.center.clone(),fit:view.isFitted,ratio:view.renderer.getPixelRatio(),cursor:view.cursorGroup.visible,shadow:view.renderer.shadowMap.enabled};
 try{
  view.w=width;view.h=height;view.scale=visible?saved.scale*saved.w/width:Math.max(pw/(width-120),ph/(height-120));
  if(!visible)view.center.set((b[0]+b[2])/2,0,-(b[1]+b[3])/2);
  view.isFitted=false;view.cursorGroup.visible=false;view.renderer.setPixelRatio(1);view.updateCamera();view.renderer.shadowMap.enabled=false;view.updateSprites();
  for(let y=0;y<height;y+=1024)for(let x=0;x<width;x+=1024){const tw=Math.min(1024,width-x),th=Math.min(1024,height-y);view.renderer.setSize(tw,th,false);view.camera.setViewOffset(width,height,x,y,tw,th);view.renderer.render(view.scene,view.camera);ctx.drawImage(view.canvas,x,y,tw,th);await new Promise(resolve=>requestAnimationFrame(resolve));}
 }finally{
  view.camera.clearViewOffset();view.w=saved.w;view.h=saved.h;view.scale=saved.scale;view.center.copy(saved.center);view.isFitted=saved.fit;view.cursorGroup.visible=saved.cursor;view.renderer.setPixelRatio(saved.ratio);view.renderer.setSize(saved.w,saved.h);view.updateCamera();view.renderer.shadowMap.enabled=saved.shadow;view.updateSprites();view.dirty=true;
 }
 return new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(Error('PNG export failed')),'image/png'));
}
