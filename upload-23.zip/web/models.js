const T=globalThis.THREE;

const materials=new Map();
let surfaceDetail=null;
function detailTexture(){if(surfaceDetail)return surfaceDetail;if(typeof document==='undefined')return null;const cv=document.createElement('canvas');cv.width=cv.height=1024;const ctx=cv.getContext('2d'),px=ctx.createImageData(1024,1024);let seed=137;for(let i=0;i<px.data.length;i+=4){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const v=122+(seed>>>27);px.data[i]=px.data[i+1]=px.data[i+2]=v;px.data[i+3]=255;}ctx.putImageData(px,0,0);surfaceDetail=new T.CanvasTexture(cv);surfaceDetail.wrapS=surfaceDetail.wrapT=T.RepeatWrapping;surfaceDetail.repeat.set(2,2);surfaceDetail.userData.shared=true;return surfaceDetail;}


function mat(color,metal=0){const k=(color?.isColor?color.getHexString():color)+':'+metal;if(!materials.has(k))materials.set(k,new T.MeshStandardMaterial({color,roughness:metal?.36:.68,metalness:metal,flatShading:false,bumpMap:detailTexture(),bumpScale:.035}));materials.get(k).userData.shared=true;return materials.get(k);}

function part(g,geo,color,x,y,z,metal=0){const m=new T.Mesh(geo,mat(color,metal));m.position.set(x,y,z);g.add(m);return m;}

function box(g,w,h,d,c,x=0,y=h/2,z=0){let geo;const b=Math.min(.28,Math.min(w,h,d)*.12);if(b<.07)geo=new T.BoxGeometry(w,h,d);else{const sh=new T.Shape();sh.moveTo(-w/2+b,-h/2+b);sh.lineTo(w/2-b,-h/2+b);sh.lineTo(w/2-b,h/2-b);sh.lineTo(-w/2+b,h/2-b);sh.closePath();geo=new T.ExtrudeGeometry(sh,{depth:d-2*b,bevelEnabled:true,bevelThickness:b,bevelSize:b,bevelSegments:4,steps:1});geo.translate(0,0,-d/2+b);}return part(g,geo,c,x,y,z);}

function tower(g,x,z,r,h){part(g,new T.CylinderGeometry(r,r*1.08,h,8),'#dddac9',x,h/2,z);part(g,new T.CylinderGeometry(r*1.12,r*1.12,1.8,8),'#a4a594',x,h,z);for(let i=0;i<8;i++){let a=i*Math.PI/4;box(g,1.9,2,1.9,'#e4e2d3',x+Math.cos(a)*r,h+1.5,z+Math.sin(a)*r);}}

function roof(g,r,h,x,y,z,color='#648091'){return part(g,new T.ConeGeometry(r,h,4),color,x,y,z);}

function gemGeometry(r,h,seed){const count=6,levels=[0,.48,.77],verts=[],cols=[],palette=['#183be7','#1b72ff','#22b4ff','#78e7ff','#b1f1ff','#3434df'];const rings=levels.map((v,j)=>Array.from({length:count},(_,i)=>{const a=i/count*Math.PI*2+seed;const radial=r*(j===2?.86:1)*(1+.15*Math.sin(i*7+seed));return new T.Vector3(Math.cos(a)*radial,v*h,Math.sin(a)*radial);}));let face=0;function triangle(a,b,c){verts.push(...a.toArray(),...c.toArray(),...b.toArray());const side=face<24?Math.floor((face%12)/2):face-24;const col=new T.Color(palette[side%palette.length]);col.multiplyScalar(face++%2?.96:1.04);for(let k=0;k<3;k++)cols.push(col.r,col.g,col.b);}
 for(let j=0;j<2;j++)for(let i=0;i<count;i++){const n=(i+1)%count;triangle(rings[j][i],rings[j][n],rings[j+1][i]);triangle(rings[j][n],rings[j+1][n],rings[j+1][i]);}const tip=new T.Vector3(r*.3,h,-r*.15);for(let i=0;i<count;i++)triangle(rings[2][i],rings[2][(i+1)%count],tip);const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(verts,3));geo.setAttribute('color',new T.Float32BufferAttribute(cols,3));geo.computeVertexNormals();return geo;}
export function makeCrystal(){const g=new T.Group();part(g,new T.CylinderGeometry(7.5,9,2.5,9),'#777758',0,1.2,0);
 const gemmat=new T.MeshStandardMaterial({vertexColors:true,roughness:.2,metalness:.08,flatShading:true,emissive:'#124cbb',emissiveIntensity:.3});
 for(const [i,x,z,h,r,lean]of [[0,-3,-2,28,5,-.08],[1,-8,3,15,2.9,-.28],[2,5,3,24,4.7,.14],[3,3,-5,22,3.4,.1],[4,-6,-4,17,3,-.18],[5,9,-1,14,2.6,.26]]){const gem=new T.Mesh(gemGeometry(r,h,i*.8),gemmat);gem.position.set(x,2,z);gem.rotation.z=lean;g.add(gem);}
 for(let i=0;i<12;i++){const a=i*2.4;part(g,new T.DodecahedronGeometry(1.5+(i%3)*.3,0),i%2?'#00bfff':'#4edaf1',Math.cos(a)*8,2,Math.sin(a)*8);}
 for(let i=0;i<7;i++){const a=i*1.2;box(g,3.2,1.2,2.1,'#937349',Math.sin(a)*9,2.3,Math.cos(a)*8);}
 const bronze='#b28e4a';box(g,6,1,5,'#675542',-1,2.5,6.5);for(let i=0;i<5;i++)box(g,4.5,.8,1,bronze,6,2+i*.5,4-i*1.5);part(g,new T.CylinderGeometry(2.3,2.5,1.7,12),bronze,-1,5,6.5);part(g,new T.CylinderGeometry(1.9,1.9,.2,16),'#08151a',-1,5.9,6.5);for(const x of [-3.2,1.2])box(g,.7,4,.8,bronze,x,3,6.5);return g;}

// Solid reconstructions of the supplied ROK overview symbols: white stone silhouettes,

// distinct camp/altar/shrine/citadel forms, alliance crest and fortress spire.

const stone='#f2f5f3',edge='#bccbd1',dark='#526779';

function plinth(g,lower,upper,height,y=0){const m=part(g,new T.CylinderGeometry(upper,lower,height,4),stone,0,y+height/2,0);m.rotation.y=Math.PI/4;return m;}

function ring(g,r,y,h){const shape=new T.Shape();shape.absarc(0,0,r,0,Math.PI*2,false);const hole=new T.Path();hole.absarc(0,0,r*.72,0,Math.PI*2,true);shape.holes.push(hole);const geo=new T.ExtrudeGeometry(shape,{depth:h,bevelEnabled:false,curveSegments:16});geo.rotateX(-Math.PI/2);return part(g,geo,stone,0,y,0);}

function windows(g,r,y,count=8){for(let i=0;i<count;i++){const a=i/count*Math.PI*2;const p=box(g,2.2,4,.35,dark,Math.sin(a)*r,y,Math.cos(a)*r);p.rotation.y=a;}}

// Flag reference: dark fluted watchtower, bronze braces, plain rounded standard.

export function makeFlag(color='#269fb7'){

 const g=new T.Group(),slate='#435967',rim='#97a5a6',bronze='#bea26a';

 part(g,new T.CylinderGeometry(3.2,4.3,1.4,8),slate,0,.7,0);

 part(g,new T.CylinderGeometry(1.65,2.4,9.5,8),slate,0,6,0);

 for(let i=0;i<4;i++){const a=i*Math.PI/2+.3,x=Math.sin(a),z=Math.cos(a);const brace=box(g,.55,6,.7,bronze,x*2.1,3.4,z*2.1);brace.rotation.z=-x*.23;brace.rotation.x=z*.23;}

 part(g,new T.CylinderGeometry(3.4,2.5,1.5,10),rim,0,11.2,0);part(g,new T.CylinderGeometry(2.7,2.2,.8,10),bronze,0,12.1,0);

 for(let i=0;i<6;i++){const a=i*Math.PI/3;box(g,1.1,1.5,1.2,rim,Math.sin(a)*2.9,12.4,Math.cos(a)*2.9);}

 part(g,new T.CylinderGeometry(.23,.3,11,8),slate,0,16,0);

 const sh=new T.Shape();sh.moveTo(-3,0);sh.lineTo(3,0);sh.lineTo(3,-5.3);sh.quadraticCurveTo(2.8,-6.8,0,-7.5);sh.quadraticCurveTo(-2.8,-6.8,-3,-5.3);sh.closePath();

 part(g,new T.ExtrudeGeometry(sh,{depth:.24,bevelEnabled:true,bevelThickness:.1,bevelSize:.1,bevelSegments:4,curveSegments:8}),color,0,21.2,.5);

 for(const [x,z]of [[-3,2],[3,2],[-2,-3],[3,-2]])part(g,new T.DodecahedronGeometry(.9),bronze,x,.8,z);return g;

}

function extrudedProfile(g,points,depth,c,z=0,bevel=.5){const sh=new T.Shape(points.map(p=>new T.Vector2(...p)));const geo=new T.ExtrudeGeometry(sh,{depth,bevelEnabled:true,bevelThickness:bevel,bevelSize:bevel,bevelSegments:4,steps:1,curveSegments:12});return part(g,geo,c,0,0,z-depth/2);}

function arcWall(g,r,inner,h,start,end,y=0,c=stone){const sh=new T.Shape();sh.absarc(0,0,r,start,end,false);sh.absarc(0,0,inner,end,start,true);sh.closePath();const geo=new T.ExtrudeGeometry(sh,{depth:h,bevelEnabled:true,bevelSize:.4,bevelThickness:.35,bevelSegments:4,curveSegments:24});geo.rotateX(-Math.PI/2);return part(g,geo,c,0,y,0);}

function taperedPanel(g,w0,w1,h,c,z,y=0){return extrudedProfile(g,[[-w0/2,y],[w0/2,y],[w1/2,y+h],[-w1/2,y+h]],.2,c,z,.05);}

export function makeBuilding(kind,type=0,color='#269fb7'){

 if(kind==='flag')return makeFlag(color);if(kind==='crystal')return makeCrystal();const g=new T.Group();

 if(kind==='pass'){

  // One broad gate, tapered piers and a recessed roof. Match reference P57CTh9LtV.

  extrudedProfile(g,[[-17,1],[-16,13],[-14,14.5],[14,14.5],[16,13],[17,1],[10,1],[8.5,7.5],[7,9],[-7,9],[-8.5,7.5],[-10,1]],7,stone);

  box(g,28,.7,4,edge,0,14.5,0);box(g,26,.3,2.4,dark,0,15,0);

  for(const x of [-13,13]){box(g,2.2,.4,7.8,edge,x,3.3,0);box(g,2.2,.35,7.8,edge,x,6.8,0);}for(const x of [-14,-7,0,7,14])box(g,3.6,2.6,6.8,stone,x,16.3,0);return g;

 }

 if(['fortress','center-fortress','horse'].includes(kind)){

  const c=color||'#269fb7',shade=new T.Color(c).multiplyScalar(.72),light=new T.Color(c).multiplyScalar(1.12);
  box(g,11.5,2,10.5,shade,0,1,0);box(g,10.6,6.8,9.7,c,0,5.1,0);
  part(g,new T.CylinderGeometry(3.2,4.5,8,6),c,0,11,0);part(g,new T.ConeGeometry(3.35,5.8,6),light,0,17.8,0);
  for(const x of [-4.2,4.2])for(const z of [-3.8,3.8]){part(g,new T.CylinderGeometry(1.65,1.35,7,24),c,x,8,z);part(g,new T.CylinderGeometry(1.9,1.75,1.4,24),light,x,11.6,z);part(g,new T.SphereGeometry(1.85,24,16,0,Math.PI*2,0,Math.PI/2),c,x,12,z);}
  for(const x of [-3.4,3.4])box(g,.65,4.6,.3,light,x,3.6,4.95);for(const x of [-2.7,2.7])box(g,.7,1.5,.25,shade,x,7.1,4.94);box(g,2.4,4,.3,shade,0,3.6,4.93);box(g,1.6,1,.25,shade,0,12,3.4);
  if(kind==='center-fortress')g.scale.setScalar(1.2);return g;

 }

 if(kind==='bastion'){plinth(g,7,6,2);box(g,7,9,7,stone,0,6,0);plinth(g,7,0,5,10);box(g,2,4,.2,dark,0,4,3.6);return g;}

 if(kind==='ancient-battlefield'||type===39||type===40){part(g,new T.CylinderGeometry(4,6,2,6),edge,0,1,0);part(g,new T.CylinderGeometry(2.5,3.7,15,5),stone,0,9,0);part(g,new T.ConeGeometry(2.5,5,5),stone,0,19,0);

  for(const a of [0,Math.PI*2/3,Math.PI*4/3]){const wing=new T.Group();wing.rotation.y=a;g.add(wing);extrudedProfile(wing,[[0,12],[3,13],[14,5],[12,5],[5,8],[1,5]],1.1,stone);for(let i=0;i<3;i++){const vane=box(wing,4,.5,.9,edge,5+i*3,10-i*2,.8);vane.rotation.z=-.58;}}return g;}

 if(type===29){plinth(g,10,10,2);plinth(g,6,5,5,2);box(g,7,10,7,stone,0,12,0);box(g,10,2,10,edge,0,18,0);box(g,8,1.5,8,stone,0,19.8,0);return g;}

 if(type===30){plinth(g,12,10,2);plinth(g,10,5.5,18,2);box(g,8,4.5,8,stone,0,22,0);box(g,10,.9,10,edge,0,24.7,0);box(g,3,.2,3,dark,0,25.3,0);

  taperedPanel(g,7,3,12,edge,6.5,3);for(const x of [-5,5]){const buttress=extrudedProfile(g,[[x-1,2],[x+1,2],[x*.6+.7,19],[x*.6-.7,19]],1.1,stone,6);}

  return g;}

 if(type===31||type===32){plinth(g,13,6,17);box(g,12,3,12,stone,0,18,0);box(g,3,.3,3,dark,0,19.6,0);return g;}

 if(kind==='citadel'||type===38){part(g,new T.CylinderGeometry(13,17,10,12),stone,0,5,0);windows(g,14,6,10);ring(g,12,10,3);part(g,new T.CylinderGeometry(8,10,10,12),stone,0,17,0);windows(g,9,17,8);ring(g,8,22,3);part(g,new T.CylinderGeometry(4,6,9,10),stone,0,29,0);windows(g,5,28,6);ring(g,5,33,2);return g;}

 if(type>=33&&type<=37){

  // Hieron: hollow circular shrine, taller rear gallery and a lower front wall.

  part(g,new T.CylinderGeometry(12,14,2,24),stone,0,1,0);arcWall(g,12,8,11,0,Math.PI*2,2);arcWall(g,10.5,7.3,10,0,Math.PI,13);

  for(const a of [-.55,0,.55]){const win=box(g,1.6,3.3,.18,'#263e4b',Math.sin(a)*6.95,19,-Math.cos(a)*6.95);win.rotation.y=-a;}

  for(const a of [-.9,-.3,.3,.9]){const buttress=part(g,new T.CylinderGeometry(1.3,2.1,10,5),stone,Math.sin(a)*11.4,6,Math.cos(a)*11.4);}

  return g;}

 plinth(g,9,6,3);box(g,8,15,8,stone,0,10,0);plinth(g,8,0,7,17);return g;

}

export function makeResource(kind){
 if(kind==='crystal')return makeCrystal();const g=new T.Group(),wood='#8f653f',gold='#d7af50',rock='#85989b';
 part(g,new T.CylinderGeometry(6,7,.9,12),'#768452',0,.45,0);
 if(kind==='wood'){
  for(const [x,z]of [[-3,0],[0,1],[3,0]]){const log=part(g,new T.CylinderGeometry(1.1,1.1,8,9),wood,x,1.9,z);log.rotation.x=Math.PI/2;const end=part(g,new T.CylinderGeometry(.86,.86,.13,9),'#c6a66c',x,1.9,z+4);end.rotation.x=Math.PI/2;}
  box(g,6,4,5,'#665944',0,4,-2);const roof=part(g,new T.ConeGeometry(5,3,4),'#4b6972',0,7.5,-2);roof.rotation.y=Math.PI/4;
  for(const x of [-5,5]){part(g,new T.CylinderGeometry(.7,1,5,7),wood,x,3,-3);part(g,new T.ConeGeometry(3,7,9),'#4c7352',x,7,-3);}
 }else if(kind==='food'){
  box(g,10,.5,9,'#8c7144',0,.9,0);for(let x=-4;x<=4;x+=2)for(let z=0;z<=3;z+=1.5)part(g,new T.SphereGeometry(.65,6,4),'#babd61',x,1.5,z);
  box(g,6,4,4,'#ccb07a',0,3,-3);const roof=part(g,new T.ConeGeometry(4.8,4,4),'#a9653e',0,7,-3);roof.rotation.y=Math.PI/4;part(g,new T.CylinderGeometry(1.7,2,3,10),'#a8814c',4,2,0);box(g,1.5,2,.3,'#504d39',0,2,-.85);
 }else if(kind==='coin'||kind==='gold'){
  for(const [x,z,r]of [[-2,-2,3.8],[2,-3,3],[3,1,2.5]])part(g,new T.DodecahedronGeometry(r,1),'#7e7350',x,r*.7,z);
  for(let i=0;i<9;i++){const a=i*2.4;box(g,1.7,.8,1.1,gold,Math.sin(a)*4,1.6+(i%3)*.6,Math.cos(a)*3);}
  box(g,4.8,3.5,3.5,'#956d3a',-2,2.5,3);box(g,5,.6,4,gold,-2,4.5,3);box(g,1,1,.3,'#ecce77',-2,3,4.9);
 }else if(kind==='village'){
  for(const [x,z]of [[-3,0],[3,-2],[1,3]]){box(g,4.5,4,4,'#bfa071',x,2.5,z);const roof=part(g,new T.ConeGeometry(3.8,4,4),'#d4ad58',x,6,z);roof.rotation.y=Math.PI/4;}part(g,new T.CylinderGeometry(.2,.2,10,6),wood,-5,5,1);
 }else{
  for(const [x,z,r]of [[-2,-2,4.6],[3,-2,3.8],[1,3,2.4],[-4,2,2.3]])part(g,new T.DodecahedronGeometry(r,1),rock,x,r*.65,z);
  if(kind!=='cave'){for(let i=0;i<4;i++)box(g,4,.5,1.2,wood,3,1+i*.55,5-i*1.1);box(g,.5,5,.5,wood,-4,3,3);box(g,3.4,.9,1,'#bdced2',-4,5.5,3);}
 }
 return g;
}
