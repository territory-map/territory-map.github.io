// One root for main pages, nested ES modules and classic worker bootstraps.
const siteRoot=new URL('../',import.meta.url);
export function siteURL(path){
 const text=String(path);
 if(text==='/'||text.startsWith('/assets/')||text.startsWith('/web/'))return new URL(text.slice(1),siteRoot).href;
 return new URL(text,import.meta.url).href;
}

async function jsonBody(response){
 // Lightweight response doubles used by the original calculation tests.
 if(!response.body)return response.json();
 const reader=response.body.getReader(),prefix=[];let bytes=0;
 while(bytes<2){const part=await reader.read();if(part.done)break;if(part.value.length){prefix.push(part.value);bytes+=part.value.length;}}
 const stream=new ReadableStream({
  start(controller){for(const part of prefix)controller.enqueue(part);},
  async pull(controller){try{const part=await reader.read();if(part.done)controller.close();else controller.enqueue(part.value);}catch(error){controller.error(error);}},
  cancel(reason){return reader.cancel(reason);}
 });
 const first=prefix[0]?.[0],second=prefix[0]?.length>1?prefix[0][1]:prefix[1]?.[0];
 // Detect actual bytes, so an HTTP server that already decoded gzip also works.
 if(first!==0x1f||second!==0x8b)return new Response(stream).json();
 if(typeof DecompressionStream==='function')return new Response(stream.pipeThrough(new DecompressionStream('gzip'))).json();
 // Bundled fallback: no CDN, account, installation or external request required.
 await import('./vendor/pako-inflate.js');
 const inflate=new globalThis.pako.Inflate({to:'string'}),compressed=stream.getReader();
 for(;;){const part=await compressed.read();inflate.push(part.value||new Uint8Array(),part.done);if(inflate.err){await compressed.cancel();throw new Error('Kartendaten konnten nicht entpackt werden.');}if(part.done)break;}
 return JSON.parse(inflate.result);
}

export async function loadJSON(path,options={}){
 const url=new URL(siteURL(path));
 if(/\/assets\/(data|solver)\/[^/]+\.json$/.test(url.pathname))url.pathname+='.gz';
 const {signal,timeout=180000,...requestOptions}=options;
 for(let attempt=0;attempt<2;attempt++){
  if(signal?.aborted)throw signal.reason||new DOMException('Abgebrochen','AbortError');
  const controller=new AbortController(),abort=()=>controller.abort(signal.reason);
  signal?.addEventListener('abort',abort,{once:true});
  const timer=setTimeout(()=>controller.abort(new DOMException('Zeitlimit überschritten','AbortError')),timeout);
  let response;
  try{
   response=await fetch(url.href,{...requestOptions,signal:controller.signal});
   if(!response.ok){
    if(attempt===0&&(response.status===429||response.status>=500)){await response.body?.cancel();continue;}
    throw new Error('Datei konnte nicht geladen werden (HTTP '+response.status+'): '+url.pathname.split('/').pop());
   }
   return await jsonBody(response);
  }catch(error){
   // Retry one failed network request. Corrupt JSON/gzip and explicit aborts
   // stay visible instead of silently substituting incomplete or empty data.
   if(attempt===0&&!response&&!controller.signal.aborted&&error?.name==='TypeError')continue;
   throw error;
  }finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}
 }
}
