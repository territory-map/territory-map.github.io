import {floorGameCoordinate} from './core/build-position.js';
// Native site/resource positions stay intact; game labels round down.
export const gameCoordinate=floorGameCoordinate;
export function labelOffset(placement,height,visibleHeight,belowExtent=0){
 return placement==='below'?-(belowExtent+height/2+2):visibleHeight+height/2+4;
}

