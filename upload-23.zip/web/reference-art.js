import {resourceCardScale,resourceRadius} from './core/resource-size.js';
const T=globalThis.THREE;

export const RESOURCE_ART={
 crystal:{file:'crystal.png',height:38,groundY:.80},
 coin:{file:'gold.png',height:29,groundY:.66},
 food:{file:'food.png',height:30,groundY:.68},
 wood:{file:'wood.png',height:29,groundY:.71},
 stone:{file:'stone.png',height:29,groundY:.71}
};

// One draw call per resource type. The actual matrices also drive ray picking.
export function createResourceCards(points,texture,kind){
 const art=RESOURCE_ART[kind],height=18*texture.image.height/texture.image.width;
 const geometry=new T.PlaneGeometry(height*texture.image.width/texture.image.height,height);
 geometry.translate(0,height*((art?.groundY??.8)-.5),0);
 const material=new T.MeshBasicMaterial({map:texture,transparent:true,alphaTest:.045,depthTest:false,depthWrite:false,toneMapped:false,side:T.DoubleSide});
 const mesh=new T.InstancedMesh(geometry,material,points.length);
 mesh.renderOrder=11;mesh.frustumCulled=false;
 mesh.userData={resources:points,kind,poi:kind==='coin'?'gold':kind,artSource:art?.file,baseHeight:height};
 mesh.instanceMatrix.setUsage(T.DynamicDrawUsage);
 return mesh;
}

export function updateResourceCards(group,camera,scale,enabled,poi,screenYFactor=1,radiusFor=resourceRadius,radiusKey=''){
 const key=camera.quaternion.toArray().join(',')+':'+scale+':'+screenYFactor+':'+radiusKey;
 const dummy=new T.Object3D();dummy.quaternion.copy(camera.quaternion);
 for(const mesh of group.children){
  const d=mesh.userData;
  mesh.visible=enabled&&poi[d.poi]!==false&&(d.kind==='crystal'||scale<2.8);
  if(!mesh.visible||d.cameraKey===key)continue;
  d.cameraKey=key;
  d.resources.forEach((r,i)=>{const size=resourceCardScale(radiusFor(r));dummy.scale.set(size,size*screenYFactor,1);dummy.position.set(r.x,0,-r.y);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);});
  mesh.instanceMatrix.needsUpdate=true;mesh.computeBoundingSphere();
 }
}
