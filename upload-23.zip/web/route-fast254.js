import {buildPoint} from './core/build-position.js';
import {G,legacy,clone} from './core/model.js';
import {originOwnership} from './solver-search254.js';
// Fast single-label candidate; the portal-aware search refines this incumbent.
class Heap{
 constructor(){this.a=[];}push(v){const a=this.a;a.push(v);let i=a.length-1;while(i){let p=(i-1)>>1;if(a[p].f<=v.f)break;a[i]=a[p];i=p;}a[i]=v;}pop(){const a=this.a,r=a[0],v=a.pop();if(a.length){let i=0;while(i*2+1<a.length){let j=i*2+1;if(j+1<a.length&&a[j+1].f<a[j].f)j++;if(a[j].f>=v.f)break;a[i]=a[j];i=j;}a[i]=v;}return r;}compact(keep){const retained=this.a.filter(keep);this.a=[];for(const node of retained)this.push(node);}get length(){return this.a.length;}}
export function fastRoute(model,original,allianceId,{budget=150,crystals=true,maxVisits=90000,maxNodes=45000,order=0,deadline=Infinity}={},progress=()=>{}){
 const cacheLimit=Math.max(1000,Math.min(16000,maxNodes));
 const remember=(cache,key,value)=>{if(cache.size>=cacheLimit)cache.clear();cache.set(key,value);};
 const plan=clone(original),initial=plan.buildings.length,failed=[],requiredPasses=new Map(),limits={hit:false,peakNodes:0,peakFrontier:0};model.setPlan(plan);
 if(!plan.buildings.some(b=>b.allianceId===allianceId))return {buildings:[],failed:plan.targets,reason:'Zuerst eine Festung für diese Allianz setzen.'};
 if(plan.buildings.some(b=>b.allianceId===allianceId&&(model.staticError(b,plan.settings.strict))))return {buildings:[],failed:plan.targets,reason:'Bestehende Allianzbauten verletzen die Bau- oder Zonenregeln. Diese Positionen zuerst korrigieren.'};
 const todo=plan.targets.filter(t=>!model.targetReached(t,allianceId));const free=new Map();let visits=0;
 const targetsPoint=t=>t.siteId?model.sites.find(s=>s.siteId===t.siteId):t;
 const moves=[];for(let x=-3;x<=3;x++)for(let y=-3;y<=3;y++)if((x||y)&&!(Math.abs(x)===3&&Math.abs(y)===3))moves.push([x,y]);
 const crystalNodes=model.data.resources.filter(r=>r.kind==='crystal'),crystalIndex=new Map();
 for(let i=0;i<crystalNodes.length;i++){const r=crystalNodes[i],key=Math.floor(r.x/64)+':'+Math.floor(r.y/64);if(!crystalIndex.has(key))crystalIndex.set(key,[]);crystalIndex.get(key).push({r,i});}
 const crystalReach=27+Math.max(0,...crystalNodes.map(r=>model.resourceRadius(r)));
 let coveredCrystals=new Set();
 const position=(x,y)=>{const key=x+':'+y;if(!free.has(key)){let found=null;for(const [dx,dy]of [[9,9],[3,9],[15,9],[9,3],[9,15],[3,3],[15,3],[3,15],[15,15]]){const b={kind:'flag',...buildPoint(x*18+dx,y*18+dy),allianceId};if(!model.staticError(b,plan.settings.strict)&&!model.zoneError(b)&&!G.plannedBuildingCollision(model.legacy(b),model.buildings)){found=b;break;}}remember(free,key,found);}return free.get(key);};
 const masks=new Map(),buildableTerritory=new Map();
 const ownedCells=(x,y)=>{const key=x+':'+y;if(!buildableTerritory.has(key)){const cells=G.territoryCells({kind:'flag',x:x*18+9,y:y*18+9}).filter(c=>!model.reservedCells.has(c.column+':'+c.row));remember(buildableTerritory,key,{cells,keys:new Set(cells.map(c=>c.column+':'+c.row))});}return buildableTerritory.get(key);};
 const edgeConnects=(x,y,parent)=>{const a=ownedCells(x,y),b=ownedCells(parent.x,parent.y);return a.cells.some(c=>[[0,0],[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>b.keys.has((c.column+dx)+':'+(c.row+dy))));};
 const cellMask=(x,y)=>{const key=x+':'+y;if(!masks.has(key)){let mask=0n;const cells=G.territoryCells({kind:'flag',x:x*18+9,y:y*18+9}),added=new Set(cells.map(c=>c.column+':'+c.row)),ownership={get(k){return model.state.ownership.get(k)||(added.has(k)?{allianceId}:undefined);}};const cx=x*18+9,cy=y*18+9;for(let bx=Math.floor((cx-crystalReach)/64);bx<=Math.floor((cx+crystalReach)/64);bx++)for(let by=Math.floor((cy-crystalReach)/64);by<=Math.floor((cy+crystalReach)/64);by++)for(const {r,i} of crystalIndex.get(bx+':'+by)||[])if(!coveredCrystals.has(i)&&Math.abs(r.x-cx)<27+model.resourceRadius(r)&&Math.abs(r.y-cy)<27+model.resourceRadius(r)&&model.resourceCovered(r,allianceId,ownership))mask|=1n<<BigInt(i);remember(masks,key,mask);}return masks.get(key);};
 const bits=n=>{let c=0;while(n){n&=n-1n;c++;}return c;};
 while(todo.length&&plan.buildings.length-initial<budget){
  if(performance.now()>=deadline){limits.hit=true;break;}
  todo.sort((a,b)=>{const dist=t=>{const p=targetsPoint(t);return p?Math.min(...plan.buildings.filter(b=>b.allianceId===allianceId).map(b=>Math.hypot(b.x-p.x,b.y-p.y))):Infinity;};return order===1?dist(b)-dist(a):order===2?((a.id||'').localeCompare(b.id||'')):dist(a)-dist(b);});
  let target=todo.shift(),requested=target,tp=targetsPoint(target);if(!tp){failed.push(target);continue;}if(model.targetReached(target,allianceId))continue;
  if(!model.usePasses&&model.groundAccess.nav&&!model.groundAccess.targetRegions(tp).some(z=>model.accessFor(allianceId).regions.has(z))){failed.push(requested);continue;}
  const gate=model.routePrerequisite(tp,allianceId)||(model.usePasses&&tp.kind==='pass'&&!model.accessFor(allianceId).captured.has(tp.siteId)?tp:null);
  if(gate){requiredPasses.set(gate.siteId,gate);target={id:'approach-'+gate.siteId,siteId:gate.siteId,x:gate.x,y:gate.y,approach:true};tp=gate;if(model.targetReached(target,allianceId))continue;}
  const tx=Math.floor(tp.x/18),ty=Math.floor(tp.y/18),radius=target.siteId?(tp.territoryRadiusInCells||2)+2:1;
  const heuristic=(x,y)=>Math.max(0,Math.ceil((Math.max(Math.abs(x-tx),Math.abs(y-ty))-radius)/3));
  coveredCrystals=new Set(crystalNodes.flatMap((r,i)=>model.resourceCovered(r,allianceId)?[i]:[]));
  const heap=new Heap(),best=new Map(),ownership=model.territoryFor(allianceId),frontier=originOwnership(model,initial,allianceId);
  function enqueue(x,y,g,parent){const k=x+':'+y;if(!best.has(k)&&best.size>=maxNodes){limits.hit=true;return;}const candidate=position(x,y);if(!candidate||model.zoneError(candidate))return;
   if(!G.hasRequiredTerritoryAvailability(candidate,ownership)||G.plannedBuildingCollision(model.legacy(candidate),model.buildings))return;
   // A visually touching square can lose its connecting cells at terrain or
   // a closed zone. Reject that edge during search, not only after reconstructing
   // the cheapest path (which would otherwise hide valid detours to that cell).
   if(parent){const dx=Math.abs(x-parent.x),dy=Math.abs(y-parent.y);if(dx>3||dy>3||(dx===3&&dy===3)||!edgeConnects(x,y,parent))return;}
   else if(!G.isConnectedToAlliance(candidate,frontier))return;
   const mask=crystals?((parent?.mask||0n)|cellMask(x,y)):0n,reward=crystals?bits(mask):0,prev=best.get(k);
   if(prev&&(prev.g<g||(prev.g===g&&prev.reward>=reward)))return;
   if(!prev&&best.size>=maxNodes){limits.hit=true;return;}
   const node={x,y,g,parent,mask,reward,length:(parent?.length||0)+(parent?Math.hypot(x-parent.x,y-parent.y):0),f:(g+heuristic(x,y))*1000-Math.min(reward,100)*.5+Math.hypot(x-tx,y-ty)*.01+(parent?.length||0)*.001};best.set(k,node);heap.push(node);if(heap.length>maxNodes*2)heap.compact(q=>best.get(q.x+':'+q.y)===q);limits.peakNodes=Math.max(limits.peakNodes,best.size);limits.peakFrontier=Math.max(limits.peakFrontier,heap.length);
  }
  // Seed the frontier from actual owned cells, including captured structures.
  const seeds=new Set();for(const cell of frontier.values())if(cell.allianceId===allianceId)for(let dx=-2;dx<=2;dx++)for(let dy=-2;dy<=2;dy++)if(!(Math.abs(dx)===2&&Math.abs(dy)===2)){const x=cell.column+dx,y=cell.row+dy,k=x+':'+y;if(!seeds.has(k)){seeds.add(k);enqueue(x,y,1,null);}}
  let found=null,foundFlags=null,foundCost=Infinity,foundGems=-1,foundLength=Infinity,local=0,afterFound=0,goalChecks=0;
  while(heap.length&&local<maxVisits){if((local%64)===0&&performance.now()>=deadline){limits.hit=true;break;}const n=heap.pop();if(best.get(n.x+':'+n.y)!==n)continue;if(n.g+heuristic(n.x,n.y)>foundCost)break;if(foundFlags&&++afterFound>6000)break;local++;visits++;
   if(n.g+plan.buildings.length-initial>budget)continue;
   if(heuristic(n.x,n.y)===0){if(++goalChecks>1200){limits.hit=true;break;}if(foundFlags&&goalChecks>120)break;const path=[];for(let q=n;q;q=q.parent)path.push(q);path.reverse();const before=plan.buildings.length;let good=true;
    for(const q of path){if(performance.now()>=deadline){limits.hit=true;good=false;break;}const b={id:'solve-'+before+'-'+q.x+'-'+q.y,...position(q.x,q.y)};if(model.placementError(b)){good=false;break;}plan.buildings.push(b);model.setPlan(plan);}
    if(good&&model.targetReached(target,allianceId)){
     const gems=model.covered(allianceId).crystal||0;
     if(n.g<foundCost||gems>foundGems||(gems===foundGems&&n.length<foundLength)){found=path;foundFlags=plan.buildings.slice(before);foundCost=n.g;foundGems=gems;foundLength=n.length;}
     plan.buildings.length=before;model.setPlan(plan);if(!crystals)break;continue;
    }
    plan.buildings.length=before;model.setPlan(plan);
   }
   for(const [dx,dy]of moves)enqueue(n.x+dx,n.y+dy,n.g+1,n);
   if(local%1000===0)progress({visits,added:plan.buildings.length-initial,remaining:todo.length+1});
  }
  if(local>=maxVisits)limits.hit=true;
  if(foundFlags){plan.buildings.push(...foundFlags);model.setPlan(plan);if(gate&&!model.targetReached(requested,allianceId))todo.unshift(requested);}else failed.push(requested);free.clear();masks.clear();
  progress({visits,added:plan.buildings.length-initial,remaining:todo.length});
 }
 failed.push(...todo);return {buildings:plan.buildings.slice(initial),failed,requiredPasses:[...requiredPasses.keys()].filter(siteId=>!model.accessFor(allianceId).captured.has(siteId)),visits,search:limits,reason:failed.length?'Nicht alle Ziele innerhalb des Budgets bzw. Suchlimits erreichbar.':'Alle markierten Ziele verbunden.'};
}

// Validate and rebuild from the root each time: pruning cannot break a later branch.
