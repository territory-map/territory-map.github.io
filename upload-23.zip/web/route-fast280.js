import {route} from './route280.js';
// Fast incumbent and crystal branches share the same reachability and portal rules.
export function fastRoute(model,original,allianceId,options={},progress=()=>{}){return route(model,original,allianceId,{...options,labels:1},progress);}
