import {buildPoint} from './core/build-position.js';
import {G} from './core/model.js';

const coarse=[[9,9],[3,9],[15,9],[9,3],[9,15],[3,3],[15,3],[3,15],[15,15],...[1,5,9,13,17].flatMap(x=>[1,5,9,13,17].map(y=>[x,y]))];
// A cell can contain buildable ground on both sides of a diagonal/narrow wall.
// Keep one legal centre per geographical zone, instead of silently discarding
// the landing side after finding the first centre on the source side.
export function routePositions(model,x,y,allianceId,{avoidBuildings=[],minimumSpacing=0}={}){
 const zones=model.groundAccess.cellZones(x,y),found=new Map();
 if(!zones.size)return [];
 const other=[...model.buildings,...avoidBuildings.map(b=>model.legacy(b))];
 const test=(dx,dy)=>{
  const b={kind:'flag',...buildPoint(x*18+dx,y*18+dy),allianceId},zone=model.groundAccess.geographicalZone(b.x,b.y);
  if(!zone||found.has(zone))return;
  if(model.staticError(b,model.plan.settings.strict)||other.some(q=>minimumSpacing>0&&Math.hypot(b.x-q.x,b.y-q.y)<minimumSpacing)||G.plannedBuildingCollision(model.legacy(b),other))return;
  found.set(zone,{...b,searchZone:zone});
 };
 for(const [dx,dy]of coarse){test(dx,dy);if(found.size===zones.size)break;}
 // Refine unresolved ground on a one-native-unit grid only at zone boundaries.
 // This keeps ordinary open-ground search inexpensive while finding thin strips.
 if(found.size<zones.size&&(zones.size>1||!found.size))for(let dy=0;dy<18;dy++)for(let dx=0;dx<18;dx++){
  test(dx,dy);if(found.size===zones.size)return [...found.values()];
 }
 return [...found.values()];
}
