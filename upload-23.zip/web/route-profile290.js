export const ROUTE_MODES=['balanced','crystal','build','war'];
export function routingProfile(mode,crystalExtra=5){
 mode=mode==='normal'?'build':ROUTE_MODES.includes(mode)?mode:'balanced';
 const configured=Math.max(0,Math.min(30,Math.floor(Number(crystalExtra)||0)));
 return {mode,crystals:mode==='crystal'||mode==='balanced',configuredExtra:configured,crystalExtra:mode==='crystal'||mode==='balanced'?configured:0,backups:mode==='war'};
}
