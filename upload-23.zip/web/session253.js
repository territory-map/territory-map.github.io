// GitHub Pages serves static files. Local Python-server lifecycle tracking is unnecessary.
