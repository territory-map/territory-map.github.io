import {snapTerritoryPoint} from './core/geometry.js';
export const centredSite=s=>['holy-site','pass','bastion','ancient-battlefield','citadel','duel-tower','duel-center'].includes(s?.kind);
// Presentation only: the original site, collision square and territory stay fixed.
export function siteDisplayPoint(s){return centredSite(s)?snapTerritoryPoint(s.x,s.y):{x:s.x,y:s.y};}
export function siteSpriteAnchor(s,art){const bounds=art.solidBounds||art;return centredSite(s)?{x:((bounds.left??0)+(bounds.right??1))/2,y:((bounds.anchor??0)+(bounds.top??1))/2}:null;}
