// Measure the connected building body, excluding detached flecks and dark shadow.
// Source artwork and site coordinates are never changed.
export function solidArtBounds(data,width,height){
 const seen=new Uint8Array(width*height),queue=new Int32Array(width*height);let best=null;
 const solid=i=>data[i*4+3]>128&&Math.max(data[i*4],data[i*4+1],data[i*4+2])>60;
 for(let start=0;start<seen.length;start++){
  if(seen[start]||!solid(start))continue;
  let head=0,tail=1,left=width,right=0,top=height,bottom=0;queue[0]=start;seen[start]=1;
  while(head<tail){const i=queue[head++],x=i%width,y=Math.floor(i/width);left=Math.min(left,x);right=Math.max(right,x);top=Math.min(top,y);bottom=Math.max(bottom,y);
   for(const j of [x?i-1:-1,x+1<width?i+1:-1,y?i-width:-1,y+1<height?i+width:-1])if(j>=0&&!seen[j]&&solid(j)){seen[j]=1;queue[tail++]=j;}
  }
  if(!best||tail>best.area)best={area:tail,left:left/width,right:(right+1)/width,anchor:1-(bottom+1)/height,top:1-top/height};
 }
 return best;
}

// In perspective, the screen midpoint of the unchanged square differs slightly
// from its projected world centre. Compensate only the billboard anchor.
export function centreBastionInSquare(sprite,camera,point,radius){
 const T=globalThis.THREE,base=sprite.position.clone().project(camera),half=(radius*2+1)*9;
 const corners=[];for(const x of [-half,half])for(const y of [-half,half])corners.push(new T.Vector3(point.x+x,.8,-point.y-y).project(camera));
 if(corners.some(p=>p.z<=-1||p.z>=1))return;
 const midX=(Math.min(...corners.map(p=>p.x))+Math.max(...corners.map(p=>p.x)))/2;
 const midY=(Math.min(...corners.map(p=>p.y))+Math.max(...corners.map(p=>p.y)))/2;
 const depth=-sprite.position.clone().applyMatrix4(camera.matrixWorldInverse).z;
 const px=camera.projectionMatrix.elements[0]/(camera.isPerspectiveCamera?depth:1),py=camera.projectionMatrix.elements[5]/(camera.isPerspectiveCamera?depth:1);
 const dx=(midX-base.x)/px,dy=(midY-base.y)/py,a=sprite.material.rotation||0,c=Math.cos(a),s=Math.sin(a);
 sprite.center.x-=(c*dx+s*dy)/sprite.scale.x;sprite.center.y-=(-s*dx+c*dy)/sprite.scale.y;
}
