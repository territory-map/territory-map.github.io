// Presentation only: preserve source IDs, positions, levels and collision rules.
const labels = {
 'Ancient Ruins':['Antike Ruinen','Ancient Ruins','Ruines antiques'],
 'Altes Schlachtfeld':['Antike Ruinen','Ancient Ruins','Ruines antiques'],
 'Crusader Camp':['Kreuzritterlager','Crusader Camp','Camp de croisés'],
 'Kreuzritterlager':['Kreuzritterlager','Crusader Camp','Camp de croisés'],
 'Ruined Crusader Fortress':['Verfallene Kreuzritterfestung','Ruined Crusader Fortress','Forteresse de croisés en ruine'],
 'Kreuzritterfestung':['Kreuzritterfestung','Crusader Fortress','Forteresse des croisés'],
 'Altar of Darkness':['Altar der Dunkelheit','Altar of Darkness','Autel des ténèbres'],
 'Altar of Ashes':['Altar der Asche','Altar of Ashes','Autel des cendres'],
 'Spring of Ra':['Quelle des Ra','Spring of Ra','Source de Râ'],
 'Font of Ra':['Brunnen des Ra','Font of Ra','Fontaine de Râ'],
 'Heiligtum':['Heiligtum','Sanctuary','Sanctuaire'], 'Zitadelle':['Zitadelle','Citadel','Citadelle'],
 'Altar':['Altar','Altar','Autel'], 'Hieron':['Hieron','Hieron','Hiéron'],
 'Sanctum of Courage':['Heiligtum des Mutes','Sanctum of Courage','Sanctuaire du courage'],
 'Sanctum of Hope':['Heiligtum der Hoffnung','Sanctum of Hope','Sanctuaire de l’espoir'],
 'Sanctum of Wind':['Heiligtum des Windes','Sanctum of Wind','Sanctuaire du vent'],
 'Sanctum of Blood':['Heiligtum des Blutes','Sanctum of Blood','Sanctuaire du sang'],
 'Hieron of Steel':['Hieron des Stahls','Hieron of Steel','Hiéron de l’acier'],
 'Hieron of Thorns':['Hieron der Dornen','Hieron of Thorns','Hiéron des épines'],
 'Tempest Sanctuary':['Sturmheiligtum','Tempest Sanctuary','Sanctuaire de la tempête'],
 'Circle of Courage':['Kreis des Mutes','Circle of Courage','Cercle du courage'],
 'Circle of Nature':['Kreis der Natur','Circle of Nature','Cercle de la nature'],
 'Circle of Vitality':['Kreis der Lebenskraft','Circle of Vitality','Cercle de vitalité'],
 'Circle of Defense':['Kreis der Verteidigung','Circle of Defense','Cercle de défense'],
 'Surge Altar':['Altar der Flut','Surge Altar','Autel des flots'],
 'Earth Altar':['Altar der Erde','Earth Altar','Autel de la terre'],
 'Harvest Altar':['Altar der Ernte','Harvest Altar','Autel des moissons'],
 'Flame Altar':['Altar der Flamme','Flame Altar','Autel des flammes'],
 'Storm Altar':['Altar des Sturms','Storm Altar','Autel de la tempête'],
 'Wisdom Altar':['Altar der Weisheit','Wisdom Altar','Autel de la sagesse'],
 'Shrine of Honor':['Schrein der Ehre','Shrine of Honor','Autel de l’honneur'],
 'Shrine of Radiance':['Schrein des Glanzes','Shrine of Radiance','Autel du rayonnement'],
 'Shrine of Order':['Schrein der Ordnung','Shrine of Order','Autel de l’ordre'],
 'Shrine of War':['Schrein des Krieges','Shrine of War','Autel de la guerre'],
 'Monastery of the Holy Sword':['Kloster des heiligen Schwertes','Monastery of the Holy Sword','Monastère de l’épée sacrée'],
 'Monastery of the Sacred Shield':['Kloster des heiligen Schildes','Monastery of the Sacred Shield','Monastère du bouclier sacré'],
 'Monastery of the Divine Mercy':['Kloster der göttlichen Gnade','Monastery of the Divine Mercy','Monastère de la miséricorde divine'],
 'Valiant Sanctuary':['Heiligtum der Tapferkeit','Valiant Sanctuary','Sanctuaire de la vaillance'],
 'Storm Citadel':['Sturmzitadelle','Storm Citadel','Citadelle de la tempête'],
 'Nature Citadel':['Naturzitadelle','Nature Citadel','Citadelle de la nature'],
 'Megalith Citadel':['Megalithzitadelle','Megalith Citadel','Citadelle mégalithique'],
 'Fury Citadel':['Zitadelle des Zorns','Fury Citadel','Citadelle de la fureur'],
 'The Great Ziggurat':['Die große Zikkurat','The Great Ziggurat','La grande ziggourat'],
 'Lost Temple':['Verlorener Tempel','Lost Temple','Temple perdu'],
 'Seth Hieron':['Hieron des Seth','Seth Hieron','Hiéron de Seth'],
 'Horus Hieron':['Hieron des Horus','Horus Hieron','Hiéron d’Horus'],
 'Seth Sanctuary':['Heiligtum des Seth','Seth Sanctuary','Sanctuaire de Seth'],
 'Horus Sanctuary':['Heiligtum des Horus','Horus Sanctuary','Sanctuaire d’Horus'],
 'West Gate':['Westtor','West Gate','Porte ouest'], 'North Gate':['Nordtor','North Gate','Porte nord'], 'East Gate':['Osttor','East Gate','Porte est'],
 'Orléans Guildhall':['Gildenhalle von Orléans','Orléans Guildhall','Hôtel de guilde d’Orléans'],
 'Duel center':['Duellzentrum','Duel Center','Centre des duels'],
 'Olympian Teleporter (Hades)':['Olympischer Teleporter (Hades)','Olympian Teleporter (Hades)','Téléporteur olympien (Hadès)'],
 'Olympian Teleporter (Ares)':['Olympischer Teleporter (Ares)','Olympian Teleporter (Ares)','Téléporteur olympien (Arès)'],
 'Troy':['Troja','Troy','Troie'],
 'Castrum Tempestatis':['Castrum Tempestatis','Castrum Tempestatis','Castrum Tempestatis'],
 'Castrum Victoris':['Castrum Victoris','Castrum Victoris','Castrum Victoris'],
 'Southwell Minster':['Southwell Minster','Southwell Minster','Southwell Minster']
};
export function passLevel(s){const level=Number(s.level);if(Number.isInteger(level)&&level>0)return level;const type={10:1,11:2,15:3,45:4,46:5,47:6,51:7,52:8,53:9,54:10}[s.strongholdType];if(type)return type;const match=(s.label||'').match(/(?:Lvl\.?|Level|Stufe|Pass)\s*(\d+)/i);return match?Number(match[1]):null;}
export function siteName(s,lang='de'){
 const i={de:0,en:1,fr:2}[lang]??0;
 if(s.kind==='pass')return ['Pass','Pass','Passage'][i]+' '+(passLevel(s)??'?');
 if(s.kind==='bastion')return 'Bastion';
 return labels[s.label]?.[i]||s.label||({'holy-site':['Heiligtum','Sanctuary','Sanctuaire'],'ancient-battlefield':labels['Ancient Ruins'],citadel:labels.Zitadelle}[s.kind]?.[i]??s.kind);
}
export function siteIcon(s,catalog){
 // A recovered ruin must use the same artwork as the native Song of Troy ruin.
 if(s.kind==='ancient-battlefield'&&s.strongholdType===39&&!/Ra/.test(s.label||''))return 'holy_land_lod3_darkness.png';
 return s.sprite||catalog.structureIcons[s.strongholdType]||catalog.siteIcons[s.kind];
}
export function hasSiteTranslation(s){return s.kind==='pass'||s.kind==='bastion'||!!labels[s.label];}
export function resourceName(kind,lang='de'){
 const names={food:['Nahrung','Food','Nourriture'],wood:['Holz','Wood','Bois'],stone:['Stein','Stone','Pierre'],coin:['Gold','Gold','Or'],gold:['Gold','Gold','Or'],crystal:['Kristallfeld','Crystal deposit','Gisement de cristal'],Kristallfeld:['Kristallfeld','Crystal deposit','Gisement de cristal']};
 return names[kind]?.[{de:0,en:1,fr:2}[lang]??0]||kind;
}
// Visible lower edge of a billboard after rotation, accounting for transparent padding.
export function lowerArtExtent(source,pixels){
 const u=source.userData,angle=source.material.rotation||0,cy=source.center.y;
 const xs=[(u.left??0)-(source.center.x??.5),(u.right??1)-(source.center.x??.5)],ys=[u.anchor-cy,u.top-cy];
 return Math.max(0,-Math.min(...xs.flatMap(x=>ys.map(y=>Math.sin(angle)*x*u.aspect+Math.cos(angle)*y)))*pixels);
}
