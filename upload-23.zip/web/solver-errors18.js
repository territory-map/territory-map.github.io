export function solverErrorText(error,fallback='Die Routenberechnung wurde unerwartet beendet. Bitte den Plan speichern und die Anwendung neu laden.'){
 const value=typeof error==='string'?error:typeof error?.message==='string'?error.message:typeof error?.error?.message==='string'?error.error.message:'';
 return value.trim()&&!['undefined','null','[object Object]'].includes(value.trim())?value.trim():fallback;
}
