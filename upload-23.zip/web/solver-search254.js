import {buildPoint} from './core/build-position.js';
import {buildTerritoryState} from './core/territory17.js';
import {G,legacy,clone} from './core/model.js';
export function originOwnership(model,baseLength,allianceId){
 baseLength=model.plan.routingBaseLength??baseLength;const startId=model.plan.routingStartId;if(!startId)return model.territoryFor(allianceId);
 if(model.originCache?.epoch===model.planEpoch&&model.originCache.allianceId===allianceId)return model.originCache.ownership;
 const seed=model.plan.buildings.find(b=>b.id===startId);
 // A selected fortress already scopes access to its rooted connected component.
 // Reuse that component, including existing flags and physically captured passes.
 if(seed&&G.buildingRules[legacy(seed).kind]?.root)return model.territoryFor(allianceId);
 const buildings=[seed,...model.plan.buildings.slice(baseLength)].filter(Boolean).map(legacy);
 const sites=model.accessSites.map(s=>s.kind==='pass'?{...s,claimable:model.accessFor(allianceId).captured.has(s.siteId)}:s);
 const ownership=buildTerritoryState(buildings,sites,s=>s.kind==='pass'?model.accessFor(allianceId).captured.has(s.siteId):model.state.structureOwners.get(s.id)===allianceId).ownership;model.originCache={epoch:model.planEpoch,allianceId,ownership};return ownership;
}
// Validate and rebuild from the root each time: pruning cannot break a later branch.
export function validPlan(model,base,flags,allianceId,targets,minCrystals=0){
 const p=clone(base),pending=[...flags];model.setPlan(p);let changed=true;
 while(pending.length&&changed){changed=false;for(let i=0;i<pending.length;i++){if(!model.placementError(pending[i])&&G.isConnectedToAlliance(legacy(pending[i]),originOwnership(model,base.buildings.length,allianceId))){p.buildings.push(pending.splice(i--,1)[0]);model.setPlan(p);changed=true;}}}
 if(pending.length||targets.some(t=>!model.targetReached(t,allianceId))||(model.covered(allianceId).crystal||0)<minCrystals)return null;
 return p;
}
