import {crystalDetours} from './crystal-detours300.js';
import {crystalCorridor} from './crystal-corridor320.js';
import {warFront} from './war-front300.js';
import {routingProfile} from './route-profile290.js';
import {cheapResources} from './build-resources290.js';
import {warBackups} from './war-backups290.js';
import {G,legacy,clone} from './core/model.js';
import {validPlan} from './solver-search254.js';
import {route} from './route280.js';
import {fastRoute} from './route-fast280.js';
import {crystalBranches} from './branches254.js';
export function solve(model,original,allianceId,options={},progress=()=>{}){
 // Preserve the timing/API of older callers that only supply crystals=true.
 if(options.routeMode!=='crystal')return solveNetwork(model,original,allianceId,options,progress);
 const started=performance.now(),duration=Math.max(100,Math.min(120000,options.maxMillis??(options.routeMode==='crystal'?30000:20000))),deadline=started+duration;
 // Establish the same strong baseline as Balanced, then improve that complete
 // network. Refinement can never replace it with a poorer or incomplete route.
 const baseline=solveNetwork(model,original,allianceId,{...options,routeMode:'balanced',maxMillis:duration*.9},progress);
 const base=clone(original),startId=options.startId??options.rootId;if(startId){base.routingStartId=startId;base.routingBaseLength=base.buildings.length;const start=base.buildings.find(b=>b.id===startId);if(start&&G.buildingRules[legacy(start).kind]?.root)base.routingRootId=startId;}
 let plan=clone(base);plan.buildings.push(...baseline.buildings);let corridor=null,attempts=0;
 const maxVisits=options.maxVisits??90000,maxNodes=options.maxNodes??45000,totalCap=baseline.optimization.totalCap;
 try{
  if(!baseline.failed.length&&performance.now()<deadline){
   if(baseline.allowedCrystalExtra>0){
    const saturated=baseline.gems===model.data.resources.filter(r=>r.kind==='crystal').length;
    const detours=crystalDetours(model,base,plan,allianceId,{totalCap,deadline:Math.min(deadline,started+duration*(saturated?.98:.82)),maxVisits,maxNodes,trials:12,mode:'crystal'},progress);plan=detours.plan;attempts=detours.attempts;
   }
   if(performance.now()<deadline){const improved=crystalCorridor(model,base,plan,allianceId,{totalCap,deadline,mode:'crystal',maxVisits,maxNodes},progress);plan=improved.plan;corridor=improved.report;}
  }
  model.setPlan(plan);const flags=plan.buildings.slice(base.buildings.length),gems=model.covered(allianceId).crystal||0,extra=Math.max(0,flags.length-baseline.routeFlags),limited=performance.now()>=deadline;
  return {...baseline,buildings:flags,gems,crystalFlags:extra,savedFlags:Math.max(baseline.savedFlags,baseline.buildings.length-flags.length),routeMode:'crystal',elapsedMs:Math.round(performance.now()-started),reason:(baseline.failed.length?baseline.failed.length+' Ziel(e) noch nicht erreicht. ':'Alle markierten Ziele verbunden. ')+gems+' Kristallvorkommen erfasst; '+extra+' von '+baseline.allowedCrystalExtra+' Zusatzflaggen. '+(limited?'Suchlimit erreicht; bestes geprüftes Ergebnis.':''),optimization:{...baseline.optimization,version:'3.2.0',baselineGems:baseline.gems,baselineFlags:baseline.buildings.length,detourAttempts:baseline.optimization.detourAttempts+attempts,corridor,limited:baseline.optimization.limited||limited}};
 }finally{model.setPlan(original);}
}
function solveNetwork(model,original,allianceId,{budget=150,crystals=true,routeMode=null,crystalExtra=5,maxVisits=90000,maxNodes=45000,rootId=null,startId=rootId,maxMillis=20000}={},progress=()=>{}){
 const profile=routingProfile(routeMode??(crystals?'crystal':'build'),crystalExtra),legacyApi=routeMode==null;
 crystals=profile.crystals;crystalExtra=profile.crystalExtra;const mode=profile.mode;
 const unscopedOriginal=original,started=performance.now(),duration=Math.max(100,Math.min(120000,maxMillis)),deadline=started+duration;
 // Leave time to reuse crystal branches in the complete network, rather than
 // spending the entire search allowance before those branches even exist.
 const buildDeadline=mode==='war'?started+duration*.55:mode==='build'&&!legacyApi?started+duration*.7:crystals&&crystalExtra>0?started+duration*.9:deadline;
 try{
  if(startId){model.setPlan(original);const start=original.buildings.find(b=>b.id===startId&&b.allianceId===allianceId&&(b.kind==='flag'||G.buildingRules[legacy(b).kind]?.root));if(!start)throw Error('Der gewählte Startpunkt ist nicht mehr vorhanden.');if(start.kind==='flag'&&!model.isBuildingActive(start))throw Error('Die gewählte Flagge ist inaktiv. Zuerst wieder mit einer Festung verbinden.');original=clone(original);original.routingStartId=startId;original.routingBaseLength=original.buildings.length;if(G.buildingRules[legacy(start).kind]?.root)original.routingRootId=startId;}
  budget=Math.max(0,Math.min(500,Math.floor(Number(budget)||0)));crystalExtra=crystals?Math.max(0,Math.min(30,Math.floor(Number(crystalExtra)||0))):0;
  const options={budget,crystals:false,war:mode==='war',maxVisits,maxNodes};let best=null,shortest=Infinity;const alternatives=[];
  const orders=original.targets.length>1?3:1;
  const measure=r=>{const p=clone(original);p.buildings.push(...r.buildings);model.setPlan(p);r.gems=model.covered(allianceId).crystal||0;progress({visits:r.visits||0,added:r.buildings.length,remaining:r.failed.length,phase:'Routenvergleich',crystals:r.gems});return r;};
  if(crystals){const r=measure(fastRoute(model,original,allianceId,{...options,crystals:true,deadline:started+duration*.2},progress));alternatives.push(r);best=r;if(!r.failed.length)shortest=r.buildings.length;}
  // First establish a short complete network, then compare crystal-rich networks
  // against the same total allowance. Retain every validated incumbent on timeout.
  for(let attempt=0;attempt<orders*(mode==='war'?2:1);attempt++){
   const order=attempt%orders;
   if(attempt>0&&performance.now()>=started+duration*(crystals?.4:.9))break;
   const r=measure(route(model,original,allianceId,{...options,war:mode==='war'&&attempt>=orders,order,deadline:Math.min(buildDeadline,started+duration*(crystals?.4:1))},progress));alternatives.push(r);
   if(!best||r.failed.length<best.failed.length||r.failed.length===best.failed.length&&r.buildings.length<best.buildings.length)best=r;
   if(!r.failed.length)shortest=Math.min(shortest,r.buildings.length);
  }
  if(crystals)for(let order=0;order<orders;order++){
   if(performance.now()>=started+duration*.45)break;
   const r=measure(route(model,original,allianceId,{...options,crystals:true,order,budget:Math.min(budget,Number.isFinite(shortest)?shortest+crystalExtra:budget),deadline:Math.min(buildDeadline,started+duration*.45,performance.now()+Math.min(1500,duration*.1))},progress));alternatives.push(r);
   if(!r.failed.length)shortest=Math.min(shortest,r.buildings.length);
  }
  best=null;for(const r of alternatives){if(!r.failed.length&&r.buildings.length>Math.min(budget,shortest+crystalExtra))continue;if(!best||r.failed.length<best.failed.length||r.failed.length===best.failed.length&&(!crystals?r.buildings.length<best.buildings.length||(mode==='war'&&r.buildings.length===best.buildings.length&&(r.travel??Infinity)<(best.travel??Infinity)):r.gems>best.gems||r.gems===best.gems&&r.buildings.length<best.buildings.length))best=r;}

  const succeeded=[...original.targets.filter(t=>!best.failed.some(f=>f.id===t.id)),...(best.requiredPasses||[]).map(siteId=>({siteId,approach:true}))].filter(t=>{const p=clone(original);p.buildings.push(...best.buildings);model.setPlan(p);return model.targetReached(t,allianceId);});
  let flags=best.buildings;
  // Remove redundant flags, preserving every reached target and crystal gain.
  for(let i=flags.length-1;i>=0;i--){if(performance.now()>=buildDeadline)break;const candidate=flags.filter((_,j)=>j!==i);if(validPlan(model,original,candidate,allianceId,succeeded,crystals?best.gems:0))flags=candidate;}
  let plan=validPlan(model,original,flags,allianceId,succeeded,crystals?best.gems:0)||clone(original);model.setPlan(plan);
  const routeFlags=Number.isFinite(shortest)?Math.min(shortest,plan.buildings.length-original.buildings.length):plan.buildings.length-original.buildings.length;let extra=Math.max(0,plan.buildings.length-original.buildings.length-routeFlags);
  const totalCap=mode==='war'||mode==='build'?budget:Math.min(budget,routeFlags+crystalExtra);
  let detourAttempts=0,corridorReport=null;
  if(crystals&&!best.failed.length&&crystalExtra>0&&performance.now()<started+duration*(mode==='crystal'?.65:.75)){
   const detours=crystalDetours(model,original,plan,allianceId,{totalCap,deadline:started+duration*(mode==='crystal'?.65:.75),maxVisits,maxNodes,trials:mode==='crystal'?30:24,mode},progress);
   plan=detours.plan;detourAttempts=detours.attempts;model.setPlan(plan);
  }
  if(crystals&&best.failed.length===0&&crystalExtra===0&&performance.now()<started+duration*.82){
   const improved=crystalCorridor(model,original,plan,allianceId,{totalCap,deadline:started+duration*.82,mode,maxVisits,maxNodes},progress);
   plan=improved.plan;corridorReport=improved.report;model.setPlan(plan);
  }
  if(crystals&&best.failed.length===0&&crystalExtra>0&&performance.now()<buildDeadline){
   plan=crystalBranches(model,plan,allianceId,{baseLength:original.buildings.length,totalCap,deadline:buildDeadline,maxVisits,maxNodes},progress);
   model.setPlan(plan);extra=Math.max(0,plan.buildings.length-original.buildings.length-routeFlags);
  }
  flags=plan.buildings.slice(original.buildings.length);const beforeOptimisation=flags.length;
  if(crystals&&best.failed.length===0&&extra>0&&performance.now()<deadline){
   // Preserve the actual deposits, not just an interchangeable crystal count.
   const deposits=model.data.resources.filter(r=>r.kind==='crystal'&&model.resourceCovered(r,allianceId));
   model.setPlan(original);
   const gained=deposits.filter(r=>!model.resourceCovered(r,allianceId)).map(r=>({id:'keep-crystal-'+r.id,resourceId:r.id,x:r.x,y:r.y}));
   const keep=[...succeeded,...gained];model.setPlan(plan);
   // Once branches exist, an earlier direct leg can become redundant.
   const prune=current=>{for(let i=current.length-1;i>=0;i--){if(performance.now()>=deadline)break;const shorter=current.filter((_,j)=>i!==j);const checked=validPlan(model,original,shorter,allianceId,keep);if(checked)current=checked.buildings.slice(original.buildings.length);}return current;};
   flags=prune(flags);
   // Rebuild the same obligations together: crystals become waypoints from
   // which the route may continue, instead of permanent dead-end additions.
   if(gained.length&&flags.length>2&&performance.now()<deadline){
    const request=clone(original);request.targets=keep;
    const rebuilt=route(model,request,allianceId,{budget:Math.min(budget,flags.length-1),crystals:false,maxVisits:Math.min(maxVisits,18000),maxNodes,deadline},progress);
    if(!rebuilt.failed.length&&rebuilt.buildings.length<flags.length){
     const checked=validPlan(model,original,rebuilt.buildings,allianceId,keep);
     if(checked)flags=prune(checked.buildings.slice(original.buildings.length));
    }
   }
   plan=validPlan(model,original,flags,allianceId,keep)||plan;model.setPlan(plan);
  }
  if(crystals&&best.failed.length===0&&plan.buildings.length-original.buildings.length<beforeOptimisation&&plan.buildings.length-original.buildings.length<totalCap&&performance.now()<deadline){plan=crystalBranches(model,plan,allianceId,{baseLength:original.buildings.length,totalCap,deadline,maxVisits,maxNodes},progress);model.setPlan(plan);}
  if(crystals&&best.failed.length===0&&performance.now()<deadline){
   const improved=crystalCorridor(model,original,plan,allianceId,{totalCap,deadline,mode,maxVisits,maxNodes},progress);
   plan=improved.plan;corridorReport={first:corridorReport,final:improved.report};model.setPlan(plan);
  }
  let resourceFlags=0,warReport=null;
  if(mode==='build'&&!legacyApi&&!best.failed.length&&performance.now()<deadline){const r=cheapResources(model,plan,allianceId,{extraCap:Math.min(budget-(plan.buildings.length-original.buildings.length),Math.max(3,Math.floor(routeFlags*.2))),maxPerResource:Math.max(0,Math.min(3,original.settings.buildDetourLimit??2)),deadline,maxVisits,maxNodes},progress);plan=r.plan;resourceFlags=r.added;}
  if(mode==='war'&&!best.failed.length&&performance.now()<deadline){const front=warFront(model,plan,original,allianceId,{budget:Math.max(plan.buildings.length-original.buildings.length,Math.floor(budget*.8)),deadline:Math.min(deadline,started+duration*.7)},progress);plan=front.plan;const r=warBackups(model,plan,original,allianceId,{budget,deadline,maxVisits,maxNodes},progress);plan=r.plan;warReport={...r.report,frontFlags:front.added};}
  model.setPlan(plan);
  flags=plan.buildings.slice(original.buildings.length);const savedFlags=Math.max(0,beforeOptimisation-flags.length),gems=model.covered(allianceId).crystal||0;
  extra=crystals?Math.max(0,flags.length-routeFlags):0;
  const failed=original.targets.filter(t=>!model.targetReached(t,allianceId));
  const limited=performance.now()>=buildDeadline||best.search?.hit||warReport?.limited;
  const reason=(failed.length?failed.length+' Ziel(e) noch nicht erreicht. ':'Alle markierten Ziele verbunden. ')+(crystals?gems+' Kristallvorkommen erfasst; '+extra+' von '+crystalExtra+' Zusatzflaggen. ':'Route ohne Kristallabzweigungen. ')+(warReport?warReport.frontFlags+' Flaggen für den breiten Vorstoß; '+warReport.backupFlags+' Backup-Flaggen; '+warReport.after.criticalFlags+' verbleibende kritische Verbindungen. ':'')+(resourceFlags?resourceFlags+' Zusatzflaggen für nahe Ressourcen. ':'')+(limited?'Suchlimit erreicht; bestes geprüftes Ergebnis.':'');
  return {...best,failed,buildings:flags,gems,routeFlags:Math.min(routeFlags,flags.length),crystalFlags:extra,savedFlags,resourceFlags,warReport,configuredCrystalExtra:profile.configuredExtra,allowedCrystalExtra:profile.crystalExtra,rootId,startId,reachedTargetIds:original.targets.filter(t=>model.targetReached(t,allianceId)).map(t=>t.id),reason,elapsedMs:Math.round(performance.now()-started),routeMode:mode,optimization:{version:'3.2.0',detourAttempts,corridor:corridorReport,candidates:alternatives.length,totalCap,shortestMainFlags:routeFlags,limited}};

 }finally{model.setPlan(unscopedOriginal);}
}


