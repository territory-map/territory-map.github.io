// Classic bootstrap: dependency failures are caught after the message handler is installed.
self.onmessage=async({data})=>{
 let stage='Programm laden';
 try{
  postMessage({stage:'Routenberechnung wird gestartet …'});
  const [{loadJSON},{MapModel},{solve}]=await Promise.all([import('./pages-runtime.js'),import('./core/model.js?v=20261005.500.1'),import('./solver.js?v=20261005.500.1')]);
  stage='Kartendaten laden';postMessage({stage:'Kartendaten für die Route werden geladen …'});
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),180000);
  let map;try{map=await loadJSON('/assets/solver/'+encodeURIComponent(data.plan.map)+'.json',{signal:controller.signal});map.landmarks=await loadJSON('/assets/landmarks/'+encodeURIComponent(data.plan.map)+'.json',{signal:controller.signal});}finally{clearTimeout(timer);}
  stage='Karte vorbereiten';const model=new MapModel(map);
  stage='Route suchen';postMessage({stage:'Suche läuft …'});
  const result=solve(model,data.plan,data.allianceId,data.options,p=>postMessage({progress:p}));postMessage({result});
 }catch(e){postMessage({error:stage+': '+(e?.name==='AbortError'?'Die Anfrage wurde abgebrochen oder hat das Zeitlimit überschritten.':e?.name==='TypeError'?'Die lokalen Kartendaten konnten nicht geladen werden.':e?.name==='SyntaxError'?'Die Kartendaten konnten nicht gelesen werden.':e?.message||String(e)),retryable:stage!=='Route suchen'});}
};
self.onmessageerror=()=>postMessage({error:'Der Plan konnte nicht an die Routenberechnung übergeben werden.'});
