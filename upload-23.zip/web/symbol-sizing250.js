// Display dimensions are independent of all physical build circles.
export const DISPLAY_SCALE=1.1;
export function buildingDisplayRadius(kind){return DISPLAY_SCALE*({flag:6,fortress:9,subFortress:9,'center-fortress':11.25,mainFortress:11.25,horse:3}[kind]??6);}
export function resourceDisplayRadius(node){return DISPLAY_SCALE*(Number.isFinite(node?.collisionRadius)&&node.collisionRadius>0?node.collisionRadius:9);}
