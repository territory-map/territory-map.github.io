import {loadJSON,siteURL} from './pages-runtime.js';
import {View} from './view.js?v=terrain255';
import {MapModel} from './core/model.js?v=20261002.254';
const T=globalThis.THREE,$=id=>document.getElementById(id),v=new View($('engine'));cancelAnimationFrame(v.frame);v.renderer.setPixelRatio(1);
const index=await loadJSON('/assets/maps.json'),captures=[];let busy=false;
$('map').replaceChildren(...index.maps.map(m=>new Option(m.name+' · '+m.season,m.map)));$('map').value='LostLand_Map_9_2_v2';
const loadImage=async url=>{const im=new Image();im.src=siteURL(url);await im.decode();return im;};
function canvas(id,w,h){const cv=$(id);cv.width=w;cv.height=h;return cv.getContext('2d',{willReadFrequently:true});}
function draw(id,image,w,h){const ctx=canvas(id,w,h);ctx.drawImage(image,0,0,w,h);return ctx;}
function geometryScore(reference,actual,w,h){
 const ref=new Uint8Array(w*h),mesh=new Uint8Array(w*h);let union=0,intersection=0,missing=0,extra=0;
 for(let p=0;p<ref.length;p++){const k=p*4;ref[p]=Math.max(reference[k],reference[k+1],reference[k+2])>127?1:0;mesh[p]=Math.max(actual[k],actual[k+1],actual[k+2])>127?1:0;if(ref[p]||mesh[p])union++;if(ref[p]&&mesh[p])intersection++;if(ref[p]&&!mesh[p])missing++;if(mesh[p]&&!ref[p])extra++;}
 function near(mask,x,y){for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const xx=x+dx,yy=y+dy;if(xx>=0&&xx<w&&yy>=0&&yy<h&&mask[yy*w+xx])return true;}return false;}
 const deviation=new ImageData(w,h);let beyondOnePixel=0;
 for(let p=0;p<ref.length;p++){const x=p%w,y=Math.floor(p/w),k=p*4;deviation.data[k+3]=255;if(ref[p]&&!mesh[p]){deviation.data[k]=255;deviation.data[k+1]=200;if(!near(mesh,x,y))beyondOnePixel++;}if(mesh[p]&&!ref[p]){deviation.data[k]=255;deviation.data[k+2]=220;if(!near(ref,x,y))beyondOnePixel++;}}
 return {metrics:{iou:union?intersection/union:1,unionPixels:union,missingPixels:missing,extraPixels:extra,beyondOnePixel,withinOnePixel:union?1-beyondOnePixel/union:1},deviation};
}
async function inspect(slug){
 $('status').textContent='Lade und rendere '+slug+' …';
 const data=await loadJSON('/assets/data/'+slug+'.json'),b=data.catalog.bounds,width=b[2]-b[0],depth=b[3]-b[1],w=Math.round(1024*width/Math.max(width,depth)),h=Math.round(1024*depth/Math.max(width,depth));
 if(!data.terrain255)throw new Error(slug+' wurde noch nicht korrigiert.');
 $('engine').style.width=w+'px';$('engine').style.height=h+'px';v.isFitted=false;v.resize();await v.load(new MapModel(data));v.setMode('3d');v.setOrthographicTopDown(true);v.focus((b[0]+b[2])/2,(b[1]+b[3])/2,Math.max(width/w,depth/h));v.flags.hatch=false;v.flags.territory=false;v.visibility();
 for(const o of v.mapGroup.children)o.visible=o===v.walls;v.planGroup.visible=false;v.cursorGroup.visible=false;v.dirty=false;
 const source=await loadImage('/assets/maps/'+slug+'.webp');draw('native',source,w,h);v.renderer.render(v.scene,v.camera);draw('spatial',v.canvas,w,h);
 const clean=await v.texture('/assets/maps/'+slug+'.webp');for(const [id,image] of [['borderBefore',source],['borderAfter',clean.image]]){const ctx=canvas(id,640,130);ctx.drawImage(image,image.width/2-320,0,640,130,0,0,640,130);}
 const nativePixels=$('native').getContext('2d').getImageData(0,0,w,h),spatialPixels=$('spatial').getContext('2d').getImageData(0,0,w,h),colourDiff=new ImageData(w,h);for(let k=0;k<colourDiff.data.length;k+=4){for(let c=0;c<3;c++)colourDiff.data[k+c]=Math.min(255,Math.abs(nativePixels.data[k+c]-spatialPixels.data[k+c])*3);colourDiff.data[k+3]=255;}canvas('colourDifference',w,h).putImageData(colourDiff,0,0);
 let ctx=draw('overlay',$('native'),w,h);ctx.globalAlpha=.5;ctx.drawImage($('spatial'),0,0);ctx.globalAlpha=1;
 // Rasterize the independent 2D vector boundaries at this exact world scale.
 // Resizing a binary source raster would inflate every outline by half a texel.
 const contours=await loadJSON('/assets/audit255/'+slug+'-contours.json');
 // Compare semantic contours at native resolution, not a reduced overview.
 // Thin source features must not disappear solely through overview antialiasing.
 const mw=contours.width,mh=contours.height,maskScale=Math.max(width/mw,depth/mh),rw=width/maskScale,rh=depth/maskScale,ox=(mw-rw)/2,oy=(mh-rh)/2;
 $('engine').style.width=mw+'px';$('engine').style.height=mh+'px';v.resize();v.focus((b[0]+b[2])/2,(b[1]+b[3])/2,maskScale);
 const refContext=canvas('referenceMask',mw,mh);refContext.fillStyle='#000';refContext.fillRect(0,0,mw,mh);
 function pathRing(path,ring,world=false){for(const [i,p] of ring.entries()){const x=ox+(world?(p[0]-b[0])/width:p[0]/(contours.width-1))*rw,y=oy+(world?(b[3]-p[1])/depth:p[1]/(contours.height-1))*rh;i?path.lineTo(x,y):path.moveTo(x,y);}path.closePath();}
 for(const [key,color] of [['ridge','#ff0000'],['exterior','#00ff00']]){refContext.fillStyle=color;for(const q of contours[key]){const path=new Path2D();pathRing(path,q.outer);for(const hole of q.holes)pathRing(path,hole);refContext.fill(path,'evenodd');}}
 refContext.fillStyle='#0000ff';for(const region of data.terrain255.waterMesh.contours){const path=new Path2D();pathRing(path,region.outer,true);for(const hole of region.holes)pathRing(path,hole,true);refContext.fill(path,'evenodd');}
 const objects=[];v.walls.traverse(o=>{if(o.isMesh||o.isLine){objects.push({o,visible:o.visible,material:o.material});o.visible=false;}});
 const maskMaterials=[];for(const [name,color] of [['native-cliff-contours','#ff0000'],['native-snow-mountains','#00ff00'],['water-surface','#0000ff']]){const o=v.walls.getObjectByName(name);if(!o)continue;const material=new T.MeshBasicMaterial({color,side:T.DoubleSide,toneMapped:false});maskMaterials.push(material);o.visible=true;o.material=material;}
 const bg=v.scene.background,tone=v.renderer.toneMapping,shadow=v.renderer.shadowMap.enabled;v.scene.background=new T.Color('#000');v.renderer.toneMapping=T.NoToneMapping;v.renderer.shadowMap.enabled=false;v.renderer.render(v.scene,v.camera);
 const actualContext=draw('meshMask',v.canvas,mw,mh),score=geometryScore(refContext.getImageData(0,0,mw,mh).data,actualContext.getImageData(0,0,mw,mh).data,mw,mh);canvas('deviation',mw,mh).putImageData(score.deviation,0,0);
 for(const {o,visible,material} of objects){o.visible=visible;o.material=material;}for(const m of maskMaterials)m.dispose();v.scene.background=bg;v.renderer.toneMapping=tone;v.renderer.shadowMap.enabled=shadow;
 const metrics={map:slug,name:data.catalog.name,bounds:b,width:w,height:h,maskWidth:mw,maskHeight:mh,camera:'OrthographicCamera',worldUnitsPerMaskPixel:maskScale,...score.metrics};
 const images=Object.fromEntries(['native','spatial','overlay','referenceMask','meshMask','deviation','borderBefore','borderAfter','colourDifference'].map(id=>[id,$(id).toDataURL('image/png')]));
 captures.push({metrics,images});$('results').textContent=JSON.stringify(captures.map(c=>c.metrics),null,2);const figure=document.createElement('figure'),im=new Image();im.src=images.overlay;const caption=document.createElement('figcaption');caption.textContent=data.catalog.name+' · '+(100*metrics.iou).toFixed(2)+' % Maskenüberdeckung';figure.append(im,caption);$('gallery').append(figure);
 return metrics;
}
async function run(all){if(busy)return;busy=true;$('one').disabled=$('all').disabled=$('export').disabled=true;captures.length=0;$('gallery').replaceChildren();try{for(const m of all?index.maps:[index.maps.find(m=>m.map===$('map').value)]){await inspect(m.map);await new Promise(requestAnimationFrame);}$('status').textContent=captures.length+' Karten orthografisch geprüft. Bilder und Messwerte können gespeichert werden.';$('export').disabled=false;document.body.dataset.complete=String(captures.length);}catch(e){$('status').textContent=e.message;document.body.dataset.error=e.message;throw e;}finally{busy=false;$('one').disabled=$('all').disabled=false;}}
// Static hosting: preserve complete images/measurements through a download.
$('one').onclick=()=>run(false);$('all').onclick=()=>run(true);$('export').onclick=()=>{
 const text=JSON.stringify({version:'2.5.5',comparison:'Registered orthographic rendering; colour differences are not geometry errors.',maps:captures});
 const blob=new Blob([text],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');
 a.href=url;a.download='Terrain-2D-3D-255-Vergleich.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
};
