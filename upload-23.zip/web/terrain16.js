const T=globalThis.THREE;

// One merged mesh, following the native cliff lines and all interior openings.
export function ridgeGeometry(data,hatching,bounds){
 if(data.mesh){
  const decode=(value,Type)=>{const raw=atob(value),bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);return new Type(bytes.buffer);};
  const mesh=data.mesh,g=new T.BufferGeometry(),positions=decode(mesh.positions,Float32Array),indices=decode(mesh.indices,Uint32Array),count=positions.length/3,zones=decode(mesh.zones,Uint8Array);
  // Slender escarpments: a narrower, quiet cap instead of inflated shoulders.
  // Ground contacts, XY contours, holes and pass openings remain exact.
  for(let i=0;i<count&&!mesh.nativeSurface256;i++)if(positions[i*3+1]>.1){
   const x=positions[i*3],z=positions[i*3+2],u=Math.min(1,positions[i*3+1]/(zones[i]?10.8:6.8));
   const cap=(zones[i]?9.25:8.3)+.18*Math.sin(x/87)+.12*Math.cos(z/103);
   positions[i*3+1]=cap*u*u*(3-2*u);
  }
  // Relax the sampled ridge surface without moving its ground-contact vertices upward.
  for(let pass=0;pass<2&&!mesh.nativeSurface256;pass++){
   const sum=new Float32Array(positions.length),weights=new Uint8Array(count);
   for(let i=0;i<indices.length;i+=3){const a=indices[i],b=indices[i+1],c=indices[i+2],ay=positions[a*3+1],by=positions[b*3+1],cy=positions[c*3+1];sum[a*3+1]+=by+cy;sum[b*3+1]+=ay+cy;sum[c*3+1]+=ay+by;weights[a]+=2;weights[b]+=2;weights[c]+=2;}
   for(let i=0;i<count;i++)if(weights[i]&&positions[i*3+1]>.1)positions[i*3+1]=positions[i*3+1]*(zones[i]?.88:.96)+sum[i*3+1]/weights[i]*(zones[i]?.12:.04);
  }
  const faces=new Uint8Array(count);for(const index of indices)faces[index]++;
  if(!mesh.groundContacts)for(let i=0;i<count;i++)if(faces[i]<6)positions[i*3+1]=0;
  g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setIndex(new T.Uint32BufferAttribute(indices,1));g.computeVertexNormals();
  const normal=g.attributes.normal;for(let i=0;i<count;i++){const w=Math.min(1,positions[i*3+1]/1.0),x=normal.getX(i)*w,y=1+(normal.getY(i)-1)*w,z=normal.getZ(i)*w,length=Math.hypot(x,y,z);normal.setXYZ(i,x/length,y/length,z/length);}

  g.setAttribute('uv',new T.Float32BufferAttribute(new Float32Array(count*2),2));
  g.setAttribute('zone16',new T.Uint8BufferAttribute(zones,1));
  g.setAttribute('snow16',new T.Uint8BufferAttribute(new Uint8Array(count),1));g.computeBoundingSphere();return g;
 }

 throw new Error('Die Geländedaten dieser Karte sind unvollständig.');
}

export function symbolSize(size,scale,isStructure=true){
 const minimum=isStructure?22+Math.min(6,Math.max(0,Math.log2(Math.max(1,scale)))*2):8;
 return Math.max(size*(isStructure?1.22:1),scale*minimum);
}

export function flagTouchesBastion(flag,site,G){
 const a=G.territoryBounds(flag),p=G.snapTerritoryPoint(site.x,site.y),r=((site.territoryRadiusInCells??1)*2+1)*9;
 const dx=Math.min(a.maxX,p.x+r)-Math.max(a.minX,p.x-r),dy=Math.min(a.maxY,p.y+r)-Math.max(a.minY,p.y-r);
 return dx>=-1e-7&&dy>=-1e-7&&(dx>1e-7||dy>1e-7);
}

// The banner is authored in magenta; mask by colour, never by canvas height.
export function recolourBanner(bytes,rgb){
 for(let i=0;i<bytes.length;i+=4){
  if(!bytes[i+3])continue;
  const r=bytes[i],g=bytes[i+1],b=bytes[i+2];
  if(r-g>12&&b-g>12&&Math.min(r,b)>35){const light=Math.max(r,b)/255;bytes[i]=Math.round(rgb[0]*light);bytes[i+1]=Math.round(rgb[1]*light);bytes[i+2]=Math.round(rgb[2]*light);}
 }
 return bytes;
}

export function snowGeometry(data){
 const mesh=data.snowMesh||{positions:[],indices:[]},g=new T.BufferGeometry(),indices=mesh.indices.slice();
 if(!mesh.groundContacts)for(let i=0;i<indices.length;i+=3){const a=indices[i+1];indices[i+1]=indices[i+2];indices[i+2]=a;}
 const positions=Float32Array.from(mesh.positions),touches=new Uint8Array(positions.length/3);
 for(const index of indices)touches[index]++;
 // All open mesh borders meet the ground exactly, including concave foothills.
 if(!mesh.groundContacts)for(let i=0;i<touches.length;i++)if(touches[i]<6)positions[i*3+1]=0;
 g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setIndex(indices);g.computeVertexNormals();
 // Blend ground-contact normals into the flat map, avoiding a visible mesh seam.
 const normals=g.attributes.normal;for(let i=0;i<positions.length/3;i++){const w=Math.min(1,positions[i*3+1]/5),n=new T.Vector3(normals.getX(i)*w,1+(normals.getY(i)-1)*w,normals.getZ(i)*w).normalize();normals.setXYZ(i,n.x,n.y,n.z);}
 const count=mesh.positions.length/3;
 g.setAttribute('uv',new T.Float32BufferAttribute(new Float32Array(count*2),2));
 g.setAttribute('zone16',new T.Uint8BufferAttribute(new Uint8Array(count),1));
 g.setAttribute('snow16',new T.Uint8BufferAttribute(new Uint8Array(count).fill(data.edge?.mountainMaterial==='rock'?0:1),1));
 return g;
}

export function detailGeometry(data){
 const decode=(s,Type)=>{const bytes=Uint8Array.from(atob(s),c=>c.charCodeAt(0));return new Type(bytes.buffer);};
 const g=new T.BufferGeometry(),m=data.details,positions=decode(m.positions,Float32Array),indices=decode(m.indices,Uint32Array),count=positions.length/3;
 g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setIndex(new T.Uint32BufferAttribute(indices,1));g.computeVertexNormals();
 for(const name of ['zone16','snow16'])g.setAttribute(name,new T.Float32BufferAttribute(new Float32Array(count),1));
 g.setAttribute('uv',new T.Float32BufferAttribute(new Float32Array(count*2),2));g.computeBoundingSphere();return g;
}

