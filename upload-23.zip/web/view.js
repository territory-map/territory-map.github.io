import {siteURL} from './pages-runtime.js';
import {buildPoint,buildingGameCoordinate} from './core/build-position.js';
import {cleanBorderTexture} from './border-cleanup255.js';
import {buildingDisplayRadius} from './symbol-sizing250.js';
import {solidArtBounds,centreBastionInSquare} from './site-visual220.js';
import {siteDisplayPoint,siteSpriteAnchor,centredSite} from './site-display201.js';
import {buildingSpriteAnchor,buildingSymbolHeight} from './building-anchor19.js';
import {resourceSymbolHeight} from './core/resource-size.js';
import {siteName,siteIcon,passLevel,lowerArtExtent,resourceName} from './sites18.js';
import {gameCoordinate,labelOffset} from './presentation17.js';
import {exportMapImage} from './image18.js';
import {ridgeGeometry,snowGeometry,detailGeometry,symbolSize,recolourBanner} from './terrain16.js?v=20261002.255';
import {G,legacy,worldToScene,sceneToWorld} from './core/model.js?v=20261002.254';

import {RESOURCE_ART,createResourceCards,updateResourceCards} from './reference-art.js?v=20261002.254';
import {buildWater,terrainMaterial} from './landscape.js?v=20261002.255';

const T=globalThis.THREE;

const dispose=o=>o.traverse(v=>{v.geometry?.dispose();if(Array.isArray(v.material))v.material.forEach(m=>m.dispose());if(v.material&&!Array.isArray(v.material)&&!v.material.userData.shared){if(v.material.map?.isCanvasTexture&&!v.material.map.userData.cached)v.material.map.dispose();v.material.dispose();}});

export const poiCategory=s=>s.kind==='pass'?'pass':s.kind==='ancient-battlefield'?'ruins':s.strongholdType===29?'camp':s.strongholdType===30?'crusader-fort':s.kind==='bastion'?'bastion':'holy';

export class View{

 constructor(host,onClick,onMove){

  this.host=host;this.onClick=onClick;this.onMove=onMove;this.mode='2d';this.scale=1;this.tilt=Math.PI/4;this.azimuth=0;this.isFitted=false;this.center=new T.Vector3();this.scene=new T.Scene();this.scene.background=new T.Color('#14242d');

  this.renderer=new T.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});this.renderer.setPixelRatio(Math.min(devicePixelRatio,2));this.renderer.outputColorSpace=T.SRGBColorSpace;this.renderer.setClearColor('#14242d');this.canvas=this.renderer.domElement;this.canvas.tabIndex=0;this.canvas.setAttribute('aria-label','Territory Lab Karte');host.append(this.canvas);

  this.camera=new T.OrthographicCamera(-1,1,1,-1,.1,60000);this.scene.add(new T.HemisphereLight('#e9f7ff','#5c7660',.85));const sun=new T.DirectionalLight('#ffffff',1.4);sun.position.set(-2200,4000,2200);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);sun.shadow.bias=-.0003;sun.shadow.normalBias=.6;sun.shadow.camera.near=1;sun.shadow.camera.far=10000;this.sun=sun;this.scene.add(sun,sun.target);this.renderer.shadowMap.type=T.PCFSoftShadowMap;this.renderer.toneMapping=T.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.1;

  this.mapGroup=new T.Group();this.scene.add(this.mapGroup);this.planGroup=new T.Group();this.scene.add(this.planGroup);this.cursorGroup=new T.Group();this.scene.add(this.cursorGroup);this.ray=new T.Raycaster();this.plane=new T.Plane(new T.Vector3(0,1,0),0);this.textures=new Map();this.tintedTextures=new Map();this.artBounds=new Map();this.pendingSprites=new Set();this.symbols=[];this.poi={};this.language='de';this.showNames=false;this.showTags=true;this.showCoordinates=false;this.hatchByMode={'2d':true,'3d':true};this.flags={hatch:true,squares:true,resources:true,structures:true,territory:true,walls:true,labels:false};

  new ResizeObserver(()=>this.resize()).observe(host);this.bind();this.resize();this.animate=()=>{this.frame=requestAnimationFrame(this.animate);if(this.dirty){this.dirty=false;this.updateSprites();this.renderer.render(this.scene,this.camera);}};this.animate();

 }

 resize(){const r=this.host.getBoundingClientRect();this.w=Math.max(r.width,1);this.h=Math.max(r.height,1);this.renderer.setSize(this.w,this.h);if(this.isFitted&&this.model)this.fit();else this.updateCamera();}

 updateCamera(){
  this.dirty=true;if(!this.camera)return;
  this.camera2D??=this.camera.isOrthographicCamera?this.camera:new T.OrthographicCamera(-1,1,1,-1,.1,120000);
  this.camera3D??=new T.PerspectiveCamera(35,this.w/this.h,.1,120000);
  const orthographic=this.mode==='2d'||this.orthographicTopDown;
  this.camera=this.mode==='3d'&&!orthographic?this.camera3D:this.camera2D;
  const half=this.scale*this.h/2;this.screenYFactor=1;
  const d=!orthographic?half/Math.tan(this.camera.fov*Math.PI/360):14000;
  if(orthographic){this.camera.left=-half*this.w/this.h;this.camera.right=-this.camera.left;this.camera.top=half;this.camera.bottom=-half;this.camera.near=.1;this.camera.far=60000;this.camera.up.set(0,0,-1);this.camera.position.copy(this.center).add(new T.Vector3(0,d,0));}
  else{this.camera.aspect=this.w/this.h;this.camera.up.set(0,1,0);this.camera.position.copy(this.center).add(new T.Vector3(Math.sin(this.azimuth)*d*Math.sin(this.tilt),d*Math.cos(this.tilt),Math.cos(this.azimuth)*d*Math.sin(this.tilt)));}
  // Perspective depth precision must follow the orbit distance. A fixed .1 near
  // plane loses metres at overview zoom and lets the submerged sea plane win.
  if(this.mode==='3d'&&!orthographic){
   this.camera.near=Math.max(.5,d*.05);
   const b=this.model?.catalog?.bounds;let reach=2000;
   if(b)for(const x of [b[0],b[2]])for(const y of [b[1],b[3]])reach=Math.max(reach,Math.hypot(x-this.center.x,-y-this.center.z)+512);
   this.camera.far=Math.max(this.camera.near+2000,d+reach);
  }
  this.camera.lookAt(this.center);this.camera.updateProjectionMatrix();this.camera.updateMatrixWorld();
  if(this.sun){this.renderer.toneMapping=this.mode==='3d'?T.ACESFilmicToneMapping:T.NoToneMapping;this.renderer.shadowMap.enabled=this.mode==='3d'&&this.scale<3.2;this.sun.target.position.copy(this.center);this.sun.position.copy(this.center).add(new T.Vector3(-2200,4000,2200));const span=Math.max(160,half*2);const c=this.sun.shadow.camera;c.left=c.bottom=-span;c.right=c.top=span;c.updateProjectionMatrix();}
 }

 // A geometric comparison must not magnify elevated terrain through perspective.
 setOrthographicTopDown(enabled=true){this.orthographicTopDown=enabled;this.updateCamera();}

 setMode(mode){if(mode===this.mode)return;this.mode=mode;this.flags.hatch=this.hatchByMode?.[mode]??this.flags.hatch;if(mode==='3d'){this.azimuth=0;this.tilt=Math.PI/4;}this.isFitted=false;this.visibility();}

 north(){this.azimuth=0;this.tilt=Math.PI/4;if(this.isFitted&&this.model)this.fit();else this.updateCamera();}

 fit(){
  const b=this.model.catalog.bounds;this.center.set((b[0]+b[2])/2,0,-(b[1]+b[3])/2);const width=b[2]-b[0],depth=b[3]-b[1];
  if(this.mode==='2d'||this.orthographicTopDown)this.scale=Math.max(width/this.w,depth/this.h)*1.07;
  else{
   const tan=Math.tan(35*Math.PI/360),sa=Math.sin(this.azimuth),ca=Math.cos(this.azimuth),st=Math.sin(this.tilt),ct=Math.cos(this.tilt),mx=Math.max(.2,1-64/this.w),my=Math.max(.2,1-100/this.h);let distance=1;
   for(const x of [-width/2,width/2])for(const z of [-depth/2,depth/2])for(const y of [-40,120]){
    const right=ca*x-sa*z,up=-sa*ct*x+st*y-ca*ct*z,towards=sa*st*x+ct*y+ca*st*z;
    distance=Math.max(distance,towards+Math.abs(right)/(tan*this.w/this.h*mx),towards+Math.abs(up)/(tan*my));
   }
   this.scale=distance*tan*2/this.h*1.02;
  }
  this.isFitted=true;this.updateCamera();
 }

 zoom(factor){this.isFitted=false;this.scale=Math.max(.16,Math.min(50,this.scale*factor));this.updateCamera();}

 focus(x,y,scale=1){this.isFitted=false;this.center.set(x,0,-y);this.scale=scale;this.updateCamera();}

 point(clientX,clientY){const r=this.canvas.getBoundingClientRect();this.ray.setFromCamera(new T.Vector2((clientX-r.left)/r.width*2-1,-(clientY-r.top)/r.height*2+1),this.camera);const out=new T.Vector3();return this.ray.ray.intersectPlane(this.plane,out)?sceneToWorld(out):null;}

 bind(){let down=null;

  this.canvas.addEventListener('contextmenu',e=>e.preventDefault());

  this.canvas.addEventListener('pointerdown',e=>{this.canvas.setPointerCapture(e.pointerId);down={x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY,button:e.button,rot:e.button===2||e.altKey,object:!e.altKey&&(e.button===0||e.button===1)&&this.onDragStart?.(this.point(e.clientX,e.clientY),e),moved:false};});

  this.canvas.addEventListener('pointermove',e=>{if(down){if(Math.hypot(e.clientX-down.startX,e.clientY-down.startY)>4)down.moved=true;if(down.moved){if(down.object){this.onDrag?.(this.point(e.clientX,e.clientY));}else if(down.rot&&this.mode==='3d'){this.isFitted=false;this.azimuth-=(e.clientX-down.x)*.006;}else{const a=this.point(down.x,down.y),b=this.point(e.clientX,e.clientY);if(a&&b){this.isFitted=false;this.center.x+=a[0]-b[0];this.center.z-=a[1]-b[1];}}this.updateCamera();}down.x=e.clientX;down.y=e.clientY;}this.hoverPoint=this.point(e.clientX,e.clientY);if(!this.hoverFrame)this.hoverFrame=requestAnimationFrame(()=>{this.hoverFrame=null;this.onMove?.(this.hoverPoint);});});

  this.canvas.addEventListener('pointerup',e=>{if(down?.object&&down.moved)this.onDragEnd?.(this.point(e.clientX,e.clientY));if(down&&!down.moved&&down.button===0)this.onClick?.(this.point(e.clientX,e.clientY),e);down=null;});this.canvas.addEventListener('pointercancel',()=>{if(down?.object)this.clearMovePreview();down=null;});

  this.canvas.addEventListener('dblclick',e=>{this.onDoubleClick?.(this.point(e.clientX,e.clientY),e);});this.canvas.addEventListener('auxclick',e=>e.preventDefault());
  this.canvas.addEventListener('wheel',e=>{e.preventDefault();if(e.shiftKey&&this.editMode&&this.onRotate){this.onRotate(e.deltaY>0?5:-5);return;}const before=this.point(e.clientX,e.clientY);this.zoom(Math.exp(e.deltaY*.0012));const after=this.point(e.clientX,e.clientY);if(before&&after){this.center.x+=before[0]-after[0];this.center.z-=before[1]-after[1];this.updateCamera();}},{passive:false});

 }

 async texture(name){
  if(this.textures.has(name))return this.textures.get(name);
  const p=(async()=>{let t=await new T.TextureLoader().loadAsync(siteURL(name));
   if(name.startsWith('/assets/maps/')&&this.model?.data.terrain255){
    const slug=name.split('/').pop().replace('.webp',''),mask=await new T.TextureLoader().loadAsync(siteURL('/assets/audit255/'+slug+'-letters.png'));
    const image=cleanBorderTexture(t.image,mask.image);t.dispose();mask.dispose();t=new T.CanvasTexture(image);
   }
   t.colorSpace=T.SRGBColorSpace;t.anisotropy=Math.min(16,this.renderer.capabilities.getMaxAnisotropy());return t;
  })();this.textures.set(name,p);return p;
 }

 async load(model){

  if(this.model&&this.model.catalog.map!==model.catalog.map){const terrain=this.model.data.terrain13;for(const previous of ['/assets/maps/'+this.model.catalog.map+'.webp','/assets/audit255/'+this.model.catalog.map+'-edge.png',...(terrain?['/assets/terrain/'+terrain.height,'/assets/terrain/'+terrain.albedo]:[])]){this.textures.get(previous)?.then(t=>t.dispose());this.textures.delete(previous);}}

  this.groundReady=false;this.model=model;dispose(this.mapGroup);this.mapGroup.clear();this.symbols=[];this.bastionSprites=new T.Group();this.mapGroup.add(this.bastionSprites);this.sprites=new T.Group();this.solids=new T.Group();this.areas=new T.Group();this.mapGroup.add(this.sprites,this.solids,this.areas);

  const b=model.catalog.bounds,w=b[2]-b[0],h=b[3]-b[1],tex=await this.texture('/assets/maps/'+model.catalog.map+'.webp');

  const groundMaterial=new T.MeshBasicMaterial({map:tex});this.groundStyle={value:0};

  // Continuous native map coordinates; detected border letters are restored on load.
  groundMaterial.onBeforeCompile=s=>{s.uniforms.groundTexel250={value:new T.Vector2(1/tex.image.width,1/tex.image.height)};s.uniforms.terrainStyle=this.groundStyle;s.uniforms.edge17={value:groundMaterial.userData.coast.texture};s.uniforms.sea17={value:groundMaterial.userData.coast.tint};s.fragmentShader='uniform vec2 groundTexel250; uniform float terrainStyle; uniform sampler2D edge17; uniform vec3 sea17;\n'+s.fragmentShader;s.fragmentShader=s.fragmentShader.replace('#include <map_fragment>',`#ifdef USE_MAP

    vec2 p=vMapUv;
    vec4 sampledDiffuseColor=texture2D(map,p);vec3 localAverage=(texture2D(map,p+vec2(groundTexel250.x,0)).rgb+texture2D(map,p-vec2(groundTexel250.x,0)).rgb+texture2D(map,p+vec2(0,groundTexel250.y)).rgb+texture2D(map,p-vec2(0,groundTexel250.y)).rgb)*.25;sampledDiffuseColor.rgb=mix(sampledDiffuseColor.rgb,clamp(sampledDiffuseColor.rgb+clamp((sampledDiffuseColor.rgb-localAverage)*.4,vec3(-.035),vec3(.035)),0.,1.),terrainStyle);sampledDiffuseColor.rgb=mix(sampledDiffuseColor.rgb,sampledDiffuseColor.rgb*vec3(.98,1.12,1.04),terrainStyle);vec3 edge=texture2D(edge17,p).rgb*terrainStyle;float shade=dot(sampledDiffuseColor.rgb,vec3(.21,.72,.07));sampledDiffuseColor.rgb=mix(sampledDiffuseColor.rgb,vec3(.32,.34,.33)*(.65+shade),edge.r);sampledDiffuseColor.rgb=mix(sampledDiffuseColor.rgb,vec3(.82,.88,.92)*(.55+.45*shade),edge.g);sampledDiffuseColor.rgb=mix(sampledDiffuseColor.rgb,sea17,edge.b);diffuseColor*=sampledDiffuseColor;

    #endif`);};

  const ground=new T.Mesh(new T.PlaneGeometry(w,h),groundMaterial);ground.rotation.x=-Math.PI/2;ground.position.set((b[0]+b[2])/2,-.1,-(b[1]+b[3])/2);this.ground=ground;ground.visible=false;this.mapGroup.add(ground);

  const shadow=new T.Mesh(new T.PlaneGeometry(w,h),new T.ShadowMaterial({opacity:.24,transparent:true,depthWrite:false}));shadow.rotation.x=-Math.PI/2;shadow.position.copy(ground.position);shadow.position.y=.05;shadow.receiveShadow=true;this.mapGroup.add(shadow);this.shadowGround=shadow;this.buildTerrain();await this.buildRelief();groundMaterial.userData.coast=this.terrainMaterial.userData.coast;this.groundReady=true;await this.buildSites();await this.prepareBuildingArt(model.plan.alliances[0]?.color);this.renderPlan(model.plan);this.fit();this.visibility();

 }

 buildTerrain(){

  const pos=[];for(const t of this.model.triangles)for(let i=0;i<6;i+=2)pos.push(t[i],.3,-t[i+1]);

  const geom=new T.BufferGeometry();geom.setAttribute('position',new T.Float32BufferAttribute(pos,3));

  const hatch=new T.ShaderMaterial({transparent:true,depthWrite:false,depthTest:false,side:T.DoubleSide,uniforms:{},vertexShader:'varying vec2 p;void main(){p=position.xz;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',fragmentShader:'varying vec2 p;void main(){float stripe=step(.56,fract((p.x-p.y)/9.0));gl_FragColor=vec4(.13,.19,.19,.12+stripe*.24);}'});

  this.hatch=new T.Mesh(geom,hatch);this.hatch.renderOrder=1;this.mapGroup.add(this.hatch);

  this.walls=new T.Group();this.mapGroup.add(this.walls);
 }

 async buildRelief(){
  const d=this.model.data.terrain13,b=this.model.catalog.bounds,w=b[2]-b[0],h=b[3]-b[1];if(!d)return;
  const terrain=this.model.data.terrain15;
  const [albedo,nativeMap]=await Promise.all([this.texture('/assets/terrain/'+d.albedo),this.texture('/assets/maps/'+this.model.catalog.map+'.webp')]);
  const referenceEdge=this.model.data.terrain255?await this.texture('/assets/audit255/'+this.model.catalog.map+'-edge.png'):null;
  if(referenceEdge)referenceEdge.colorSpace=T.NoColorSpace;
  const material=terrainMaterial(albedo,terrain,nativeMap,b,this.model.data.terrain16.edge,referenceEdge);this.terrainMaterial=material;
  const flat=new T.PlaneGeometry(w,h);flat.rotateX(-Math.PI/2);flat.translate((b[0]+b[2])/2,0,-(b[1]+b[3])/2);flat.setAttribute('zone16',new T.Float32BufferAttribute(new Float32Array(4),1));flat.setAttribute('snow16',new T.Float32BufferAttribute(new Float32Array(4),1));
  const floor=new T.Mesh(flat,material);floor.receiveShadow=true;this.walls.add(floor);
  const geo=ridgeGeometry(this.model.data.terrain16,terrain,b),relief=new T.Mesh(geo,material);relief.receiveShadow=true;relief.castShadow=true;relief.name='native-cliff-contours';this.walls.add(relief);
  const snow=new T.Mesh(snowGeometry(this.model.data.terrain16),material);snow.receiveShadow=true;snow.castShadow=true;snow.name='native-snow-mountains';this.walls.add(snow);
  if(this.model.data.terrain17&&!this.model.data.terrain256){const detail=new T.Mesh(detailGeometry(this.model.data.terrain17),material);detail.name='native-monument-contours';detail.receiveShadow=true;this.walls.add(detail);}this.walls.add(buildWater(this.model.data.terrain17||terrain,material.userData.coast,this.model.data.terrain255?.waterMesh));
  const board=new T.Mesh(new T.BoxGeometry(w,32,h),new T.MeshStandardMaterial({color:'#344b3e',roughness:.9}));board.position.set((b[0]+b[2])/2,-19,-(b[1]+b[3])/2);this.walls.add(board);
  const water=new T.Mesh(new T.PlaneGeometry(w,h),new T.MeshStandardMaterial({color:'#3c879b',roughness:.2,metalness:.16}));water.rotation.x=-Math.PI/2;water.position.set((b[0]+b[2])/2,-4,-(b[1]+b[3])/2);water.receiveShadow=true;this.walls.add(water);
 }


 pick(clientX,clientY){this.point(clientX,clientY);const roots=this.mode==='3d'?[this.sprites,this.resourceSolids,this.planSprites]:[this.sprites,this.planSprites];for(const hit of this.ray.intersectObjects(roots.filter(Boolean),true)){let o=hit.object,visible=true;for(let v=o;v;v=v.parent)if(!v.visible)visible=false;if(!visible)continue;if(o.userData.resources&&hit.instanceId!==undefined)return {...o.userData.resources[hit.instanceId],entity:'resource'};while(o){if(o.userData.resource)return {...o.userData.resource,entity:'resource'};if(o.userData.site)return {...o.userData.site,entity:'site'};if(o.userData.building)return {...o.userData.building,entity:'building'};o=o.parent;}}return null;}

 siteVisualType(s){const icon=s.sprite||this.model.catalog.structureIcons[s.strongholdType]||'';if(/Church/i.test(icon))return 33;if(/Cathedral/i.test(icon))return 34;if(/kingdomfort/i.test(icon))return 30;if(/camp/i.test(icon))return 29;if(/hall/i.test(icon))return 31;if(/darkness/i.test(icon))return 39;if(/holycity/i.test(icon))return 38;return s.strongholdType;}

 siteRotation(s){return s.rotation??this.model.data.passRotations?.[s.siteId??s.id]??(s.direction?Math.atan2(s.direction.x,s.direction.y):0);}

 clearMovePreview(){dispose(this.cursorGroup);this.cursorGroup.clear();this.dirty=true;}

 movePreview(s,p){this.clearMovePreview();if(!p)return;if(s.entity==='building'){const q=buildPoint(...p);p=[q.x,q.y];this.circle(q.x,q.y,this.model.buildingRadius(s),'#a9f8d6',this.cursorGroup);this.nearbyResourceCircles(q,s.kind);}const color='#a9f8d6';

  const radii=s.entity==='site'?[s.territoryRadiusInCells,s.teleportRadiusInCells].filter(Number.isFinite):[G.buildingRules[legacy(s).kind].territorySide/36-.5];

  for(const radius of radii){const q=G.snapTerritoryPoint(...p),half=(radius*2+1)*9;this.line([[q.x-half,q.y-half],[q.x+half,q.y-half],[q.x+half,q.y+half],[q.x-half,q.y+half],[q.x-half,q.y-half]],color,1,this.cursorGroup,1);}

  const source=this.symbols.find(o=>s.entity==='site'?o.userData.site?.siteId===s.siteId:o.userData.building?.id===s.id);if(source){const ghost=new T.Sprite(source.material.clone());ghost.material.opacity=.7;ghost.position.set(p[0],1,-p[1]);ghost.scale.copy(source.scale);ghost.center.copy(source.center);ghost.renderOrder=20;this.cursorGroup.add(ghost);}

 }

 async sprite(key,x,y,size,group=this.sprites,colour=null,flagOnly=false){
  if(!key)return;const task=this.makeSprite(key,x,y,size,group,colour,flagOnly);this.pendingSprites.add(task);try{return await task;}finally{this.pendingSprites.delete(task);}
 }
 async prepareBuildingArt(colour){
  // Prepare image bounds and tints while the map is loading. The detached
  // destination intentionally creates no visible sprites or plan objects.
  const detached=new T.Group();await Promise.all(Object.keys(this.model.catalog.buildings).map(kind=>this.sprite(kind==='flag'?'/assets/reference-art/flag.png':this.model.catalog.buildingIcons[kind],0,0,32,detached,colour,kind==='flag')));
 }
 async makeSprite(key,x,y,size,group,colour,flagOnly){
  const url=key.startsWith('/')?key:'/assets/sprites/'+key;let t;try{t=await this.texture(url);}catch{return;}
  if(!this.artBounds.has(url)){
   const cv=document.createElement('canvas');cv.width=t.image.width;cv.height=t.image.height;const ctx=cv.getContext('2d');ctx.drawImage(t.image,0,0);const data=ctx.getImageData(0,0,cv.width,cv.height).data;let bottom=0,top=cv.height,left=cv.width,right=0;
   for(let y=0;y<cv.height;y++)for(let x=0;x<cv.width;x++)if(data[(y*cv.width+x)*4+3]>48){bottom=Math.max(bottom,y);top=Math.min(top,y);left=Math.min(left,x);right=Math.max(right,x);}
   this.artBounds.set(url,{solidBounds:solidArtBounds(data,cv.width,cv.height),anchor:1-(bottom+1)/cv.height,top:1-top/cv.height,left:left/cv.width,right:(right+1)/cv.width});
  }
  if(colour){const cacheKey=url+'|'+colour+'|'+flagOnly;if(!this.tintedTextures.has(cacheKey)){
   const cv=document.createElement('canvas');cv.width=t.image.width;cv.height=t.image.height;const ctx=cv.getContext('2d');ctx.drawImage(t.image,0,0);const px=ctx.getImageData(0,0,cv.width,cv.height),col=new T.Color(colour).convertLinearToSRGB();
   if(flagOnly)recolourBanner(px.data,[col.r*255,col.g*255,col.b*255]);else for(let k=0;k<px.data.length;k+=4){const lum=Math.max(px.data[k],px.data[k+1],px.data[k+2])/255;px.data[k]=col.r*255*lum;px.data[k+1]=col.g*255*lum;px.data[k+2]=col.b*255*lum;}
   ctx.putImageData(px,0,0);const tinted=new T.CanvasTexture(cv);tinted.colorSpace=T.SRGBColorSpace;tinted.userData.cached=true;this.tintedTextures.set(cacheKey,tinted);
  }t=this.tintedTextures.get(cacheKey);}
  // A plan can change while its first image is loading. Discard obsolete jobs.
  if(!group.parent&&group!==this.sprites)return;
  const m=new T.SpriteMaterial({map:t,depthTest:false,transparent:true,toneMapped:false}),o=new T.Sprite(m);o.position.set(x,0,-y);o.renderOrder=10;o.userData={size,aspect:t.image.width/t.image.height,...this.artBounds.get(url)};group.add(o);this.symbols.push(o);this.dirty=true;return o;
 }

 async buildSites(){

  dispose(this.sprites);this.sprites.clear();dispose(this.bastionSprites);this.bastionSprites.clear();dispose(this.solids);this.solids.clear();this.symbols=this.symbols.filter(o=>o.parent===this.planSprites);const {catalog,data}=this.model;

  const jobs=[];for(const s of this.model.sites){const key=siteIcon(s,catalog),point=siteDisplayPoint(s);jobs.push(this.sprite(key,point.x,point.y,s.kind==='pass'?26:30).then(o=>{if(o){o.userData.poi=poiCategory(s);o.userData.site=s;o.userData.artSource=key;o.material.rotation=-(s.rotation-(data.passRotations?.[s.siteId]??0)||0);}}));}
  for(const l of data.landmarks||[])jobs.push(this.sprite(catalog.siteIcons[l.kind],l.x,l.y,18).then(o=>{if(o){o.userData.poi=l.kind;o.userData.landmark=l;}}));
  this.resourceSprites=new T.Group();this.resourceSolids=new T.Group();this.sprites.add(this.resourceSprites);this.solids.add(this.resourceSolids);
  for(const kind of [...new Set(data.resources.map(r=>r.kind))]){
    const points=data.resources.filter(r=>r.kind===kind),art=RESOURCE_ART[kind];
    const url=art?'/assets/reference-art/'+art.file:'/assets/sprites/'+catalog.siteIcons[kind];
    jobs.push(this.texture(url).then(texture=>{this.resourceSolids.add(createResourceCards(points,texture,kind));}));
  }
  for(const r of data.resources)jobs.push(this.sprite(catalog.siteIcons[r.kind],r.x,r.y,14,this.resourceSprites).then(o=>{if(o){o.userData.poi=r.kind==='coin'?'gold':r.kind;o.userData.resource=r;}}));
  await Promise.all(jobs);this.updateSiteColours();this.visibility();

 }

 line(points,color='#eff9fa',opacity=1,group=this.areas,height=.8){const geom=new T.BufferGeometry().setFromPoints(points.map(p=>new T.Vector3(p[0],height,-p[1])));const m=new T.Line(geom,new T.LineBasicMaterial({color,transparent:true,opacity,depthTest:false}));m.renderOrder=5;group.add(m);return m;}

 rect(r,color,alpha,group=this.areas,height=.4){const m=new T.Mesh(new T.PlaneGeometry(r.maxX-r.minX,r.maxY-r.minY),new T.MeshBasicMaterial({color,transparent:true,opacity:alpha,depthWrite:false,side:T.DoubleSide}));m.rotation.x=-Math.PI/2;m.position.set((r.minX+r.maxX)/2,height,-(r.minY+r.maxY)/2);group.add(m);return m;}

 segments(segments,color,opacity,group,height=.8){
  const positions=[];for(const s of segments)positions.push(s.x1,height,-s.y1,s.x2,height,-s.y2);
  const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(positions,3));const lines=new T.LineSegments(g,new T.LineBasicMaterial({color,transparent:true,opacity,depthTest:false}));lines.renderOrder=5;group.add(lines);return lines;
 }
 rectangles(rectangles,color,opacity,group){
  const positions=[];for(const r of rectangles)for(const [x,y]of [[r.minX,r.minY],[r.maxX,r.minY],[r.maxX,r.maxY],[r.minX,r.minY],[r.maxX,r.maxY],[r.minX,r.maxY]])positions.push(x,.4,-y);
  const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(positions,3));const m=new T.Mesh(g,new T.MeshBasicMaterial({color,transparent:true,opacity,depthWrite:false,side:T.DoubleSide}));group.add(m);return m;
 }

 renderPlan(plan){

  this.plan=plan;this.updateTerrainOwnership();this.updateSiteColours();dispose(this.areas);this.areas.clear();dispose(this.planGroup);this.planGroup.clear();this.planSprites=new T.Group();this.planSolids=new T.Group();this.planFootprints=new T.Group();this.planGroup.add(this.planSprites,this.planSolids,this.planFootprints);this.symbols=this.symbols.filter(s=>s.parent!==null&&s.parent!==this.previousPlanSprites);this.previousPlanSprites=this.planSprites;

  this.squares=new T.Group();this.territories=new T.Group();this.areas.add(this.squares,this.territories);

  const boundaryKey=JSON.stringify(this.poi);if(this.boundarySites!==this.model.sites||this.boundaryKey!==boundaryKey){this.boundarySites=this.model.sites;this.boundaryKey=boundaryKey;const sites=this.model.sites.filter(s=>this.poi[poiCategory(s)]!==false);this.siteBoundaries=[['territoryRadiusInCells',.75],['teleportRadiusInCells',.3]].map(([key,alpha])=>({alpha,lines:G.buildStructureBoundarySegments(sites,key)}));}
  for(const {alpha,lines}of this.siteBoundaries)this.segments(lines,'#eaf2ef',alpha,this.squares);
  for(const [aid,overview]of G.buildTerritoryOverviewsFromOwnership(this.model.displayOwnership||this.model.state.ownership)){
   const inactive=aid==='__inactive_territory__',color=inactive?'#ffffff':plan.alliances.find(a=>a.id===aid)?.color||'#24c3cb';this.rectangles(overview.fillRects,color,inactive?.2:.3,this.territories).userData.terrainFill=true;this.segments(overview.boundarySegments,color,inactive?.65:1,this.territories,1);
  }

  for(const b of plan.buildings){const color=plan.alliances.find(a=>a.id===b.allianceId)?.color;this.sprite(b.kind==='flag'?'/assets/reference-art/flag.png':this.model.catalog.buildingIcons[b.kind],b.x,b.y,b.kind==='flag'?32:34,this.planSprites,color,b.kind==='flag').then(o=>{if(o){o.userData.building=b;o.renderOrder=12;o.material.rotation=-(b.rotation||0);}});}


  for(const b of plan.buildings)this.footprintCircles([{x:b.x,y:b.y,r:this.model.buildingRadius(b)}],plan.alliances.find(a=>a.id===b.allianceId)?.color||'#ffffff',this.planFootprints);

  for(const [i,t]of plan.targets.entries()){
   const target=t.siteId?this.model.sites.find(s=>s.siteId===t.siteId):t;if(!target)continue;
   const radius=Math.max(28,(target.territoryRadiusInCells||1)*18*.95),ring=new T.Mesh(new T.RingGeometry(.66,1,128),new T.MeshBasicMaterial({color:'#ff49d4',transparent:true,opacity:.64,depthTest:false,depthWrite:false,side:T.DoubleSide}));
   ring.rotation.x=-Math.PI/2;ring.position.set(siteDisplayPoint(target).x,1.5,-siteDisplayPoint(target).y);ring.renderOrder=12;ring.userData.targetRadius=radius;ring.scale.setScalar(radius);this.areas.add(ring);
   const label=this.text((i+1)+'. '+(target.kind?siteName(target,this.language):(t.entity==='resource'?resourceName(t.label,this.language):(t.label||({de:'Ziel',en:'Target',fr:'Objectif'}[this.language])))),[siteDisplayPoint(target).x,siteDisplayPoint(target).y],'#ff78df',this.areas,radius+12,'above');label.userData.targetLabel=true;
  }

  for(const a of plan.annotations||[]){if(a.kind==='text')this.text(a.text,a.points[0],a.color);else if(a.kind==='arrow'){this.line(a.points,a.color,1,this.areas);const [p,q]=a.points,ang=Math.atan2(q[1]-p[1],q[0]-p[0]),r=20;this.line([[q[0]-Math.cos(ang-.45)*r,q[1]-Math.sin(ang-.45)*r],q,[q[0]-Math.cos(ang+.45)*r,q[1]-Math.sin(ang+.45)*r]],a.color,1,this.areas);}else if(a.kind==='circle')this.circle(a.points[0][0],a.points[0][1],Math.hypot(a.points[1][0]-a.points[0][0],a.points[1][1]-a.points[0][1]),a.color,this.areas);else if(a.points.length>1)this.line(a.points,a.color,1,this.areas);else this.circle(a.points[0][0],a.points[0][1],12,a.color,this.areas);}

  this.labelsGroup=new T.Group();this.areas.add(this.labelsGroup);

  if(this.showNames)for(const s of this.model.sites)if(this.poi[poiCategory(s)]!==false)this.text(s.kind==='pass'?String(passLevel(s)??'?'):siteName(s,this.language),[siteDisplayPoint(s).x,siteDisplayPoint(s).y],'#ecf5f6',this.labelsGroup,s.kind==='pass'?18:24,'below');

  for(const b of plan.buildings){const a=plan.alliances.find(a=>a.id===b.allianceId),parts=[];if(this.showTags&&b.kind!=='flag')parts.push(a?.name||'');if(this.showCoordinates)parts.push('X '+buildingGameCoordinate(b.x)+' · Y '+buildingGameCoordinate(b.y));if(parts.length)this.text(parts.join('\n'),[b.x,b.y],a?.color||'#eaf3f4',this.labelsGroup,b.kind==='flag'?28:36,'above');}

  this.visibility();

  // Commit a placement as soon as its cached artwork is ready. Waiting only for
  // the animation loop can leave an old preview onscreen in throttled tabs.
  const epoch=this.planRenderEpoch=(this.planRenderEpoch||0)+1;
  Promise.all([...this.pendingSprites]).then(()=>{
   if(epoch!==this.planRenderEpoch||!this.renderer?.render)return;
   this.updateSprites();this.renderer.render(this.scene,this.camera);this.dirty=false;
  });

 }

 updateSiteColours(){for(const sprite of this.sprites.children){const s=sprite.userData.site;if(s){const owner=this.model.state.structureOwners.get(s.id);sprite.material.color.set(this.plan?.alliances.find(a=>a.id===owner)?.color||'#ffffff');}}for(const g of this.solids.children){const s=g.userData.site;if(!s)continue;const owner=this.model.state.structureOwners.get(s.id),colour=this.plan?.alliances.find(a=>a.id===owner)?.color||null;if(g.userData.ownerColour===colour)continue;g.userData.ownerColour=colour;g.traverse(o=>{if(!o.isMesh)return;o.userData.baseMaterial??=o.material;if(o.material!==o.userData.baseMaterial)o.material.dispose();if(colour){o.material=o.userData.baseMaterial.clone();o.material.userData={};o.material.color.multiply(new T.Color(colour));}else o.material=o.userData.baseMaterial;});}}

 updateTerrainOwnership(){
  const m=this.terrainMaterial;if(!m)return;
  const n=Math.ceil(this.model.catalog.nativeMapSize/18),pixels=new Uint8Array(n*n*4),colours=new Map(this.plan.alliances.map(a=>[a.id,new T.Color(a.color)]));
  colours.set('__inactive_territory__',new T.Color('#ffffff'));
  for(const cell of (this.model.displayOwnership||this.model.state.ownership).values()){
   if(cell.column<0||cell.row<0||cell.column>=n||cell.row>=n)continue;const c=colours.get(cell.allianceId);if(!c)continue;const i=(cell.row*n+cell.column)*4;pixels.set([Math.round(c.r*255),Math.round(c.g*255),Math.round(c.b*255),cell.allianceId==='__inactive_territory__'?170:255],i);
  }
  m.userData.territory.value.dispose();const tex=new T.DataTexture(pixels,n,n,T.RGBAFormat);tex.minFilter=tex.magFilter=T.NearestFilter;tex.needsUpdate=true;m.userData.territory.value=tex;m.userData.territorySize.value=n*18;
 }

 text(text,p,color,group=this.areas,height=2,placement='above'){
  this.labelTextures??=new Map();const cacheKey=String(text)+'|'+color;let cached=placement==='below'?this.labelTextures.get(cacheKey):null;
  if(!cached){const lines=String(text).split('\n'),c=document.createElement('canvas'),ctx=c.getContext('2d');ctx.font='600 24px system-ui';const width=Math.ceil(Math.max(...lines.map(line=>ctx.measureText(line).width)))+28;
  c.width=width;c.height=44*lines.length;ctx.font='600 24px system-ui';ctx.fillStyle='#14232eef';ctx.beginPath();ctx.roundRect(0,0,width,c.height,12);ctx.fill();ctx.strokeStyle='#91bac44a';ctx.lineWidth=2;ctx.stroke();ctx.textAlign='center';ctx.textBaseline='middle';
  lines.forEach((line,i)=>{ctx.fillStyle=color;ctx.fillText(line,width/2,23+i*44);});
  const texture=new T.CanvasTexture(c);texture.colorSpace=T.SRGBColorSpace;cached={texture,width:width*.48,pixelHeight:22*lines.length};if(placement==='below'){texture.userData.cached=true;this.labelTextures.set(cacheKey,cached);}}
  const m=new T.SpriteMaterial({map:cached.texture,depthTest:false,transparent:true,toneMapped:false});m.userData.owned=true;const sprite=new T.Sprite(m);sprite.renderOrder=30;sprite.userData.label={p:[...p],height,placement,width:cached.width,pixelHeight:cached.pixelHeight};group.add(sprite);return sprite;
 }



 footprintCircles(circles,color,group){
  const segments=[];
  for(const {x,y,r}of circles)for(let i=0;i<96;i++){const a=i*Math.PI/48,b=(i+1)*Math.PI/48;segments.push({x1:x+Math.cos(a)*r,y1:y+Math.sin(a)*r,x2:x+Math.cos(b)*r,y2:y+Math.sin(b)*r});}
  const lines=this.segments(segments,color,.95,group,0);lines.renderOrder=18;lines.userData.circles=circles;return lines;
 }
 circle(x,y,r,c,group){return this.line(Array.from({length:65},(_,i)=>[x+Math.cos(i/64*Math.PI*2)*r,y+Math.sin(i/64*Math.PI*2)*r]),c,1,group,0).renderOrder=19;}

 buildFootprint(b,group,color='#e4ffff'){

  const bounds=G.territoryBounds(legacy(b));const half=this.model.buildingRadius(b);

  const outline=r=>this.line([[r.minX,r.minY],[r.maxX,r.minY],[r.maxX,r.maxY],[r.minX,r.maxY],[r.minX,r.minY]],color,.85,group,1.3);

  outline(bounds);const cell=G.snapTerritoryPoint(b.x,b.y);outline({minX:cell.x-9,minY:cell.y-9,maxX:cell.x+9,maxY:cell.y+9});

  const l=Math.max(2,half*.7);this.line([[b.x-l,b.y],[b.x+l,b.y]],color,1,group,1.4);this.line([[b.x,b.y-l],[b.x,b.y+l]],color,1,group,1.4);

 }

 nearbyResourceCircles(q,kind){if(!['flag','fortress','center-fortress','subFortress','mainFortress'].includes(kind))return;const radius=this.model.buildingRadius({kind});for(const node of this.model.data.resources)if(Math.hypot(node.x-q.x,node.y-q.y)<radius+this.model.resourceRadius(node)+18)this.circle(node.x,node.y,this.model.resourceRadius(node),'#fff0ac',this.cursorGroup);for(const node of this.model.data.landmarks||[])if(this.model.landmarkRadius(node)>0&&Math.hypot(node.x-q.x,node.y-q.y)<radius+this.model.landmarkRadius(node)+18)this.circle(node.x,node.y,this.model.landmarkRadius(node),'#fff0ac',this.cursorGroup);}
 preview(p,kind,valid){this.clearMovePreview();if(!p||!kind)return;const q=buildPoint(...p),b={kind,...q},color=valid?'#36ed79':'#ff4040';this.rect(G.territoryBounds(legacy(b)),color,.23,this.cursorGroup,1.2);this.buildFootprint(b,this.cursorGroup,color);const radius=this.model.buildingRadius(b);this.circle(q.x,q.y,radius,color,this.cursorGroup);this.nearbyResourceCircles(q,kind);}

 visibility(){if(!this.sprites)return;const three=this.mode==='3d';if(this.shadowGround)this.shadowGround.visible=three&&!this.flags.walls;if(this.groundStyle)this.groundStyle.value=three?1:0;this.sprites.visible=true;this.solids.visible=three;this.hatch.visible=this.flags.hatch;if(this.terrainMaterial){this.terrainMaterial.userData.hatch.value=0;this.terrainMaterial.userData.territoryVisible.value=this.flags.territory?1:0;}this.walls.visible=three&&this.flags.walls;this.ground.visible=this.groundReady!==false&&(!three||!this.flags.walls);this.bastionSprites.visible=three&&this.flags.structures&&this.poi.bastion!==false;this.squares&&(this.squares.visible=this.flags.squares&&this.scale<3.2);this.territories&&(this.territories.visible=this.flags.territory);this.planSprites&&(this.planSprites.visible=true);this.planSolids&&(this.planSolids.visible=three);this.resourceSprites&&(this.resourceSprites.visible=!three&&this.flags.resources);this.resourceSolids&&(this.resourceSolids.visible=this.flags.resources);for(const o of this.solids.children)if(o!==this.resourceSolids)o.visible=this.flags.structures&&this.poi[o.userData.poi]!==false;for(const o of this.sprites.children)if(o!==this.resourceSprites)o.visible=this.flags.structures&&this.poi[o.userData.poi]!==false;for(const o of this.resourceSprites?.children||[])o.visible=this.poi[o.userData.poi]!==false;for(const o of this.resourceSolids?.children||[])o.visible=this.poi[o.userData.poi]!==false;for(const child of this.territories?.children||[])if(child.userData.terrainFill)child.visible=!(three&&this.flags.walls);this.updateCamera();}

 buildingPixelScale(o){if(!this.camera.isPerspectiveCamera)return this.scale;const depth=-o.position.clone().applyMatrix4(this.camera.matrixWorldInverse).z;return Math.max(.001,depth)*2*Math.tan(this.camera.fov*Math.PI/360)/this.h;}
 updateSprites(){if(this.cliffDetails)this.cliffDetails.visible=false;if(this.labelsGroup)this.labelsGroup.visible=true;if(this.planFootprints)this.planFootprints.visible=this.scale<3.2;if(this.resourceFootprints){this.resourceFootprints.visible=this.flags.resources;for(const o of this.resourceFootprints.children)o.visible=this.poi[o.userData.poi]!==false;}if(this.squares)this.squares.visible=this.flags.squares&&this.scale<3.2;
  for(const o of this.symbols){const n=o.userData.building?Math.max(buildingSymbolHeight(o.userData,o.userData.building.kind,buildingDisplayRadius(o.userData.building.kind)),this.buildingPixelScale(o)*(o.userData.building.kind==='flag'?34:40)/Math.max(.1,o.userData.top-o.userData.anchor)):o.userData.resource?resourceSymbolHeight(o.userData,this.model.resourceRadius(o.userData.resource)):o.userData.landmark&&this.model.landmarkRadius(o.userData.landmark)>0?resourceSymbolHeight(o.userData,this.model.landmarkRadius(o.userData.landmark)):symbolSize(o.userData.size,this.scale,!!(o.userData.site||o.userData.building));o.scale.set(n*o.userData.aspect,n*this.screenYFactor,1);const anchor=o.userData.building?buildingSpriteAnchor(o.userData,o.userData.building.kind):siteSpriteAnchor(o.userData.site,o.userData);o.center.set(anchor?.x??((o.userData.resource||o.userData.landmark)?(o.userData.left+o.userData.right)/2:.5),anchor?.y??((o.userData.site&&o.userData.site.kind!=='pass')?o.userData.anchor:((o.userData.resource||o.userData.landmark)?(o.userData.anchor+o.userData.top)/2:.5)));if(centredSite(o.userData.site))centreBastionInSquare(o,this.camera,siteDisplayPoint(o.userData.site),o.userData.site.territoryRadiusInCells??1);}
  if(this.resourceSolids)updateResourceCards(this.resourceSolids,this.camera,this.scale,this.flags.resources,this.poi,this.screenYFactor,node=>this.model.resourceRadius(node),this.model.plan.settings.resourceRadius);
  const sources=new Map(this.symbols.filter(s=>s.userData.site||s.userData.building).map(s=>[s.position.x+'|'+s.position.z,s]));const up=new T.Vector3().setFromMatrixColumn(this.camera.matrixWorld,1);this.scene.traverse(o=>{if(o.userData.targetRadius)o.scale.setScalar(Math.max(o.userData.targetRadius,this.scale*21));const l=o.userData.label;if(!l)return;const source=sources.get(l.p[0]+'|'+(-l.p[1]));const pixels=source?source.scale.y/(this.scale*this.screenYFactor):0;const extent=source?Math.max(0,(source.userData.top-source.center.y)*pixels):0;const offset=o.userData.targetLabel?Math.max(l.height-12,this.scale*21)/this.scale+(l.pixelHeight||22)/2+5:labelOffset(l.placement,l.pixelHeight||22,extent,source?.userData.site?lowerArtExtent(source,pixels):0);o.position.set(l.p[0],0,-l.p[1]);o.position.addScaledVector(up,offset*this.scale*this.screenYFactor);o.scale.set(l.width*this.scale,(l.pixelHeight||22)*this.scale*this.screenYFactor,1);});
  if(this.resourceSprites)this.resourceSprites.visible=this.mode==='2d'&&this.flags.resources&&this.scale<2.8;
 }


 async exportImage(visible=false){return exportMapImage(this,visible);}

 screenshot(){const ratio=this.renderer.getPixelRatio();this.renderer.setPixelRatio(Math.max(ratio,Math.min(3,3840/this.w)));this.renderer.render(this.scene,this.camera);const png=this.canvas.toDataURL('image/png');this.renderer.setPixelRatio(ratio);this.dirty=true;return png;}

}


