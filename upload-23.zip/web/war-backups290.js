import {clone,legacy} from './core/model.js';
import {route} from './route280.js';
import {validPlan} from './solver-search254.js';
// Measure real disconnections with the same rooted access/capture model used by
// rendering. Losing a flag can also revoke a pass or camp, not just a graph edge.
export function networkRisk(model,plan,allianceId,targets=plan.targets,deadline=Infinity){
 model.setPlan(plan);const flags=plan.buildings.filter(b=>b.kind==='flag'&&b.allianceId===allianceId&&model.isBuildingActive(b)),reached=targets.filter(t=>model.targetReached(t,allianceId)),risks=[];let complete=true;
 for(const removed of flags){if(performance.now()>=deadline){complete=false;break;}const q=clone(plan);q.buildings=q.buildings.filter(b=>b.id!==removed.id);model.setPlan(q);const lost=flags.filter(b=>b.id!==removed.id&&!model.isBuildingActive(b)),goals=reached.filter(t=>!model.targetReached(t,allianceId));if(lost.length||goals.length)risks.push({removed,lost,goals,score:lost.length+goals.length*12});}
 model.setPlan(plan);return {risks:risks.sort((a,b)=>b.score-a.score),score:risks.reduce((n,r)=>n+r.score,0),criticalFlags:risks.length,complete};
}
export function warBackups(model,initial,base,allianceId,{budget,deadline,maxVisits,maxNodes},progress=()=>{}){
 let plan=clone(initial),risk=networkRisk(model,plan,allianceId,base.targets,deadline),before={criticalFlags:risk.criticalFlags,score:risk.score,complete:risk.complete},added=0,attempts=0;const tried=new Set();
 while(risk.complete&&risk.risks.length&&plan.buildings.length-base.buildings.length<budget&&performance.now()<deadline&&attempts++<20){
  const critical=risk.risks.find(r=>!tried.has(r.removed.id));if(!critical)break;tried.add(critical.removed.id);
  const missing=clone(plan);missing.buildings=missing.buildings.filter(b=>b.id!==critical.removed.id);
  // Target the nearest disconnected section, so the backup forms a local loop
  // around the vulnerable connection rather than another remote main route.
  const detached=[...critical.lost].sort((a,b)=>Math.hypot(a.x-critical.removed.x,a.y-critical.removed.y)-Math.hypot(b.x-critical.removed.x,b.y-critical.removed.y));
  const target=detached[0]||critical.goals[0];if(!target)continue;missing.targets=[{id:'backup-'+critical.removed.id,x:target.x,y:target.y,...(target.siteId?{siteId:target.siteId}:{})}];
  if(missing.routingStartId===critical.removed.id){model.setPlan(missing);missing.routingStartId=model.accessFor(allianceId).root?.id;}
  const remaining=budget-(plan.buildings.length-base.buildings.length);
  const r=route(model,missing,allianceId,{budget:Math.min(remaining,8),crystals:false,war:true,minimumSpacing:30,avoidBuildings:[critical.removed],maxVisits:Math.min(maxVisits,6000),maxNodes:Math.min(maxNodes,12000),deadline:Math.min(deadline,performance.now()+600)});
  if(r.failed.length||!r.buildings.length)continue;
  const renamed=r.buildings.map((b,i)=>({...b,warRole:'backup',id:'backup-'+attempts+'-'+i+'-'+b.id}));
  const candidate=validPlan(model,plan,renamed,allianceId,base.targets);if(!candidate)continue;
  const next=networkRisk(model,candidate,allianceId,base.targets,deadline);if(!next.complete||next.score>=risk.score)continue;
  plan=candidate;added+=renamed.length;risk=next;tried.clear();progress({phase:'Backup-Verbindungen',visits:attempts,added,remaining:risk.criticalFlags});
 }
 model.setPlan(plan);return {plan,report:{backupFlags:added,before,after:{criticalFlags:risk.criticalFlags,score:risk.score,complete:risk.complete},attempts,limited:performance.now()>=deadline||!risk.complete}};
}
