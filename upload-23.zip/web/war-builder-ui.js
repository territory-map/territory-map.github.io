import {siteURL} from './pages-runtime.js';
import {warConfig,WAR_ZONE_KEYS} from './core/war-builder.js';
import {displayedWarPairs,warSourceMarkers,warSourceKey,warRequirement,warRequirementLabel,warPage} from './core/war-display.js';
import {WarLayer} from './war-builder-view.js';
import {warZoneAt,normalizeWarZones} from './core/war-zone-mask.js';
import {translate as t} from './i18n.js';
const $=s=>document.querySelector(s);
const zoneText=z=>z?t('Zone')+' '+z:t('Nicht gewählt');
const position=b=>'X '+Number((b.x/6).toFixed(3))+' / Y '+Number((b.y/6).toFixed(3));
export class WarBuilder {
 constructor({view,getModel,getPlan,getAlliance,change,setTool}){
  Object.assign(this,{view,getModel,getPlan,getAlliance,change,setTool});this.layer=new WarLayer(view);this.pending=null;this.worker=null;this.cachedWorker=null;this.epoch=0;this.filter={flag:true,fortress:true,ours:true,enemy:true};this.page=0;
  for(const [key,id]of [['flag','warShowFlags'],['fortress','warShowFortresses'],['ours','warShowOurs'],['enemy','warShowEnemy']])$('#'+id).onchange=e=>{this.filter[key]=e.target.checked;this.page=0;this.selected=null;this.layer.renderPairs(this.result,null,this.filter);this.list();};
  $('#warPrevious').onclick=()=>{this.page--;this.list();};$('#warNext').onclick=()=>{this.page++;this.list();};
  for(const button of document.querySelectorAll('[data-war-zone]'))button.onclick=()=>{if(!getModel())return;this.pending=button.dataset.warZone;setTool('war-zone');this.status();};
  $('#warCalculate').onclick=()=>this.calculate();$('#warCancel').onclick=()=>{this.cancel();this.setResultStatus('Suche abgebrochen. Plan unverändert.');};
  $('#warClear').onclick=()=>{if(!getPlan())return;this.setTool('select');this.stopPick();change(()=>{getPlan().warBuilder=warConfig();});this.reset();};
  $('#warVisible').onchange=e=>{if(!getPlan())return;change(()=>{getPlan().warBuilder={...warConfig(getPlan().warBuilder),visible:e.target.checked};});};
 }
 cancel(){this.progress=null;this.epoch++;this.worker?.terminate();this.worker=null;$('#warCancel').hidden=true;$('#warCalculate').disabled=false;}
 reset(){this.cancel();this.cachedWorker?.terminate();this.cachedWorker=null;this.stopPick();this.result=null;this.referenceStale=false;this.page=0;this.fingerprint='';this.selected=null;this.layer.reset();$('#warPairs').replaceChildren();this.setResultStatus('');}
 stopPick(){this.pending=null;this.status();}
 status(){for(const button of document.querySelectorAll('[data-war-zone]'))button.classList.toggle('active',button.dataset.warZone===this.pending);
  const labels={ourZone:'Unsere eigene Zone auf der Karte anklicken.',ourTarget:'Unsere Angriffszone auf der Karte anklicken.',enemyZone:'Die eigene Zone des Gegners auf der Karte anklicken.',enemyTarget:'Die Angriffszone des Gegners auf der Karte anklicken.'};
  const c=warConfig(this.getPlan()?.warBuilder),ready=(c.ourZone&&c.ourTarget&&c.ourZone!==c.ourTarget)||(c.enemyZone&&c.enemyTarget&&c.enemyZone!==c.enemyTarget);
  $('#warPickStatus').textContent=t(labels[this.pending]||(ready?'Zonen gewählt. Jetzt Wandsprünge suchen.':'Zuerst eigene Zone und Angriffszone auswählen.'));
 }
 pick(p){if(!this.pending)return false;const model=this.getModel(),z=warZoneAt(model.groundAccess,p[0],p[1],true);
  if(!z){$('#warPickStatus').textContent=t('Bitte eine Landzone auf der Karte anklicken.');return true;}
  const key=this.pending,c=warConfig(this.getPlan().warBuilder);
  if((key==='ourZone'&&z===c.enemyZone)||(key==='enemyZone'&&z===c.ourZone)){ $('#warPickStatus').textContent=t('Unsere und gegnerische Zone müssen verschieden sein.');return true;}
  this.pending=null;this.change(()=>this.getPlan().warBuilder={...c,[key]:z});this.setTool('select');return true;
 }
 refresh(){const model=this.getModel(),plan=this.getPlan();if(!model||!plan)return;
  plan.warBuilder=normalizeWarZones(model.groundAccess,warConfig(plan.warBuilder));
  const c=warConfig(plan.warBuilder),fingerprint=JSON.stringify({map:plan.map,aid:this.getAlliance(),c:{...c,visible:undefined},buildings:plan.buildings,alliances:plan.alliances,siteEdits:plan.siteEdits,settings:plan.settings,capturedPasses:plan.capturedPasses});
  // Keep the completed search as a tactical reference while editing the plan.
  // In-flight workers are cancelled; placements are always checked afresh.
  if(this.fingerprint!==fingerprint){this.cancel();if(this.result)this.referenceStale=true;this.fingerprint=fingerprint;}
  for(const k of WAR_ZONE_KEYS)$('#war-'+k).textContent=zoneText(c[k]);$('#warVisible').checked=c.visible;
  $('#warShowFlags').checked=this.filter.flag;$('#warShowFortresses').checked=this.filter.fortress;$('#warShowOurs').checked=this.filter.ours;$('#warShowEnemy').checked=this.filter.enemy;
  this.layer.renderZones(model,c);this.layer.renderPairs(this.result,this.selected,this.filter);this.status();this.renderResultStatus();this.list();
 }
 setResultStatus(source){this.resultMessage=source;this.renderResultStatus();}
 renderResultStatus(){if(this.worker&&this.progress&&!this.result){$('#warResult').textContent=t('Positionen geprüft')+': '+this.progress.checked;return;}const count=this.result?.directions.reduce((n,d)=>n+d.pairs.length,0);$('#warResult').textContent=this.result?t(this.referenceStale?'Gespeicherte taktische Sprungpaare':'Geprüfte Sprungpaare')+': '+count+' · '+t(this.referenceStale?'Baupositionen vor dem Setzen erneut prüfen.':'Kein eroberter Pass oder Passkontakt nötig.'):t(this.resultMessage||'');}
 selectPair(q,focus=true){this.selected=q.id;const pairs=displayedWarPairs(this.result,this.filter);this.page=Math.floor(pairs.findIndex(p=>p.id===q.id)/40);
  if(focus)this.view.focus(q.midX,q.midY,.6);this.layer.renderPairs(this.result,this.selected,this.filter);this.list();
 }
 selectAt(p){
  if(!this.result||!warConfig(this.getPlan()?.warBuilder).visible||!$('#warBuilder').open)return false;
  const pairs=displayedWarPairs(this.result,this.filter),markers=warSourceMarkers(pairs);let best=null,distance=Math.max(4,this.view.scale*13);
  for(const q of markers){const d=Math.hypot(q.source.x-p[0],q.source.y-p[1]);if(d<distance){distance=d;best=q;}}
  if(!best)return false;
  const alternatives=pairs.filter(q=>warSourceKey(q)===warSourceKey(best)),i=alternatives.findIndex(q=>q.id===this.selected);
  this.selectPair(alternatives[(i+1)%alternatives.length],false);return true;
 }
 list(){const list=$('#warPairs');list.replaceChildren();const pairs=displayedWarPairs(this.result,this.filter),page=warPage(pairs,this.page);this.page=page.index;
  $('#warPaging').hidden=!this.result;$('#warPrevious').disabled=page.index===0;$('#warNext').disabled=page.index+1>=page.pages;
  $('#warPage').textContent=t('Seite')+' '+(page.index+1)+' / '+page.pages+' · '+pairs.length;
  if(!this.result)return;
  if(!pairs.length){const p=document.createElement('p');p.className='muted';p.textContent=t((!this.filter.flag&&!this.filter.fortress)||(!this.filter.ours&&!this.filter.enemy)?'Keine Sprungart eingeblendet.':'Keine gültigen Sprungpaare an dieser Zonengrenze gefunden.');list.append(p);}
  for(const [i,q]of page.items.entries()){const b=document.createElement('button');b.dataset.side=q.side;b.dataset.pair=q.id;b.dataset.requirement=warRequirement(q);b.classList.toggle('active',q.id===this.selected);
   b.textContent=(page.index*40+i+1)+'. '+t(q.side==='ours'?'Unsere Angriffe':'Gegnerische Angriffe')+' · '+t(warRequirementLabel(q))+'\n'+position(q.source)+' → '+position(q.target)+'\n'+t(q.sourceConnected?'Ausgangsposition ist im aktuellen Plan bebaubar.':'Anschluss auf der Ausgangsseite erforderlich.');
   b.onclick=()=>this.selectPair(q);list.append(b);
  }
 }
 calculate(){const model=this.getModel(),plan=this.getPlan();if(!model||!plan)return;const c=warConfig(plan.warBuilder),directions=[];
  if(c.ourZone&&c.ourTarget&&c.ourZone!==c.ourTarget)directions.push({side:'ours',allianceId:this.getAlliance(),from:c.ourZone,to:c.ourTarget});
  if(c.enemyZone&&c.enemyTarget&&c.enemyZone!==c.enemyTarget)directions.push({side:'enemy',allianceId:'__war_enemy__',from:c.enemyZone,to:c.enemyTarget});
  if(!directions.length){this.setResultStatus('Zwei verschiedene Zonen auswählen.');return;}
  this.setTool('select');this.stopPick();this.cancel();this.result=null;this.referenceStale=false;this.page=0;this.layer.renderPairs(null);this.list();$('#warPairs').replaceChildren();const epoch=this.epoch;
  $('#warCalculate').disabled=true;$('#warCancel').hidden=false;this.setResultStatus('Zonengrenzen werden nach gültigen Wandsprüngen durchsucht …');
  try{this.worker=this.cachedWorker||new Worker(siteURL('/web/war-builder.worker.js?v=20261005.500.1'));this.cachedWorker=null;
   this.worker.onmessage=({data})=>{if(epoch!==this.epoch)return;if(data.progress){this.progress=data.progress;this.renderResultStatus();return;}
    const completed=this.worker;this.worker=null;$('#warCalculate').disabled=false;$('#warCancel').hidden=true;
    if(data.error){completed.terminate();this.setResultStatus(data.error);return;}this.cachedWorker=completed;
    this.result=data.result;this.referenceStale=false;this.selected=null;this.renderResultStatus();this.page=0;this.layer.renderPairs(this.result,null,this.filter);this.list();
   };
   this.worker.onerror=e=>{e.preventDefault();if(epoch!==this.epoch)return;this.cancel();this.setResultStatus('Die Sprungsuche wurde unterbrochen. Bitte erneut versuchen.');};
   this.worker.onmessageerror=()=>{this.cancel();this.setResultStatus('Der Plan konnte nicht an den Kriegsbauer übergeben werden.');};
   this.worker.postMessage({plan:structuredClone(plan),directions});
  }catch(e){this.cancel();this.setResultStatus('Die Sprungsuche wurde unterbrochen. Bitte erneut versuchen.');}
 }
}
