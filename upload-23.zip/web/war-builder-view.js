import {filledZoneRegions} from './core/war-zone-mask.js';
import {G,legacy} from './core/model.js';
import {buildingGameCoordinate} from './core/build-position.js';
import {translate as t} from './i18n.js';
import {displayedWarPairs,warSourceMarkers,warRequirement,warRequirementLabel} from './core/war-display.js';
const T=globalThis.THREE;
const colours={ours:'#4c9eff',enemy:'#fa6868'};
function clear(group){group.traverse(o=>{o.geometry?.dispose();if(o.material){if(!o.material.userData.warShared)o.material.map?.dispose();o.material.dispose();}});group.clear();}
export class WarLayer {
 constructor(view){this.view=view;this.group=new T.Group();view.scene.add(this.group);this.zones=new T.Group();this.pairs=new T.Group();this.group.add(this.zones,this.pairs);}
 reset(){this.view.symbols=this.view.symbols.filter(o=>!o.userData.warPreview);clear(this.zones);clear(this.pairs);this.key='';this.maskSource=null;this.filled=null;this.view.dirty=true;}
 renderZones(model,config){
  this.group.visible=config.visible;const nav=model.groundAccess.nav;if(!nav)return;
  const key=model.catalog.map+'|'+config.ourZone+'|'+config.enemyZone;if(key===this.key){this.view.dirty=true;return;}
  this.key=key;clear(this.zones);
  if(!config.ourZone&&!config.enemyZone){this.view.dirty=true;return;}
  const pixels=new Uint8Array(nav.width*nav.height*4),regions=this.maskSource===model.groundAccess?this.filled:(this.filled=filledZoneRegions(model.groundAccess));this.maskSource=model.groundAccess;
  for(let y=0;y<nav.height;y++)for(let x=0;x<nav.width;x++){
   const z=regions[y*nav.width+x],i=((nav.height-1-y)*nav.width+x)*4;
   const [a,b,c,d]=model.catalog.bounds,wx=a+x*(c-a)/(nav.width-1),wy=d-y*(d-b)/(nav.height-1);if(wx<0||wy<0||wx>model.catalog.nativeMapSize||wy>model.catalog.nativeMapSize)continue;
   if(config.ourZone&&z===config.ourZone)pixels.set([70,142,255,90],i);
   else if(config.enemyZone&&z===config.enemyZone)pixels.set([255,46,72,85],i);
  }
  const texture=new T.DataTexture(pixels,nav.width,nav.height,T.RGBAFormat);texture.colorSpace=T.SRGBColorSpace;texture.minFilter=texture.magFilter=T.NearestFilter;texture.needsUpdate=true;
  const [a,b,c,d]=model.catalog.bounds,mesh=new T.Mesh(new T.PlaneGeometry(c-a,d-b),new T.MeshBasicMaterial({map:texture,transparent:true,depthTest:false,depthWrite:false,side:T.DoubleSide,toneMapped:false}));
  mesh.rotation.x=-Math.PI/2;mesh.position.set((a+c)/2,.16,-(b+d)/2);mesh.renderOrder=6;this.zones.add(mesh);this.view.dirty=true;
 }
 renderPairs(results,selected,filter='all'){
  clear(this.pairs);this.view.symbols=this.view.symbols.filter(o=>!o.userData.warPreview);const view=this.view,all=displayedWarPairs(results,filter);
  // Batch the entire border into a handful of draw calls. No marker count cap.
  // Screen-sized source symbols remain legible at overview zoom in 2D and 3D.
  for(const side of ['ours','enemy']){
   const pairs=all.filter(q=>q.side===side),colour=colours[side],segments=[];
   const add=(a,b)=>segments.push(a.x,2,-a.y,b.x,2,-b.y);
   for(const q of pairs){const {source,target}=q;add(source,target);const angle=Math.atan2(target.y-source.y,target.x-source.x),r=5;
    for(const a of [-.5,.5])add(target,{x:target.x-Math.cos(angle+a)*r,y:target.y-Math.sin(angle+a)*r});
   }
   if(segments.length){const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(segments,3));const lines=new T.LineSegments(geometry,new T.LineBasicMaterial({color:colour,transparent:true,opacity:selected?.22:.45,depthTest:false,depthWrite:false,toneMapped:false}));lines.renderOrder=20;this.pairs.add(lines);}
   for(const requirement of ['flag','fortress']){
    const markers=warSourceMarkers(pairs.filter(q=>warRequirement(q)===requirement));if(!markers.length)continue;
    const canvas=document.createElement('canvas');canvas.width=canvas.height=64;const ctx=canvas.getContext('2d');
    ctx.fillStyle='#101e27';ctx.strokeStyle=colour;ctx.lineWidth=5;
    ctx.beginPath();if(requirement==='flag')ctx.arc(32,32,28,0,Math.PI*2);else{ctx.moveTo(32,2);ctx.lineTo(62,32);ctx.lineTo(32,62);ctx.lineTo(2,32);ctx.closePath();}ctx.fill();ctx.stroke();
    ctx.fillStyle='#ffffff';ctx.strokeStyle='#ffffff';ctx.lineWidth=4;
    if(requirement==='flag'){ctx.beginPath();ctx.moveTo(22,49);ctx.lineTo(22,15);ctx.stroke();ctx.beginPath();ctx.moveTo(24,16);ctx.lineTo(47,16);ctx.lineTo(42,25);ctx.lineTo(47,33);ctx.lineTo(24,33);ctx.closePath();ctx.fill();}
    else{ctx.font='48px Georgia, serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('♜',32,34);}
    const texture=new T.CanvasTexture(canvas);texture.colorSpace=T.SRGBColorSpace;
    const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(markers.flatMap(q=>[q.source.x,2,-q.source.y]),3));
    const symbols=new T.Points(geometry,new T.PointsMaterial({map:texture,size:requirement==='flag'?22:26,sizeAttenuation:false,transparent:true,depthTest:false,depthWrite:false,toneMapped:false,alphaTest:.1}));symbols.renderOrder=25;this.pairs.add(symbols);
   }
  }
  const q=all.find(q=>q.id===selected);
  if(q){const color=colours[q.side],group=new T.Group();this.pairs.add(group);view.line([[q.source.x,q.source.y],[q.target.x,q.target.y]],color,1,group,3).renderOrder=27;
   for(const [i,p]of [q.source,q.target].entries()){
    view.circle(p.x,p.y,view.model.buildingRadius(p),color,group);view.rect(G.territoryBounds(legacy(p)),color,.16,group,2);view.buildFootprint(p,group,color);
    view.sprite(p.kind==='flag'?'/assets/reference-art/flag.png':view.model.catalog.buildingIcons[p.kind],p.x,p.y,34,group,color,p.kind==='flag').then(o=>{if(o){o.userData.warPreview=true;o.userData.building=p;o.renderOrder=28;o.material.opacity=.9;o.material.userData.warShared=true;view.dirty=true;}});
    const type=i===0?t(warRequirementLabel(q)):t('Zielflagge');
    const label=type+'\nX '+buildingGameCoordinate(p.x)+' · Y '+buildingGameCoordinate(p.y);view.text(label,[p.x,p.y],color,group,20,'above').renderOrder=30;
   }
  }
  view.dirty=true;
 }
}
