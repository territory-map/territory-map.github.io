let cachedModel=null,cachedMap=null;
self.onmessage=async({data})=>{
 try{
  const start=performance.now(),reusedMap=cachedMap===data.plan.map&&!!cachedModel;
  const [{loadJSON},{MapModel},{searchWarJumps}]=await Promise.all([import('./pages-runtime.js'),import('./core/model.js?v=20261005.500.1'),import('./core/war-builder.js?v=20261005.500.1')]);
  if(!reusedMap){
   const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),180000);
   let map;try{map=await loadJSON('/assets/solver/'+encodeURIComponent(data.plan.map)+'.json',{signal:controller.signal});map.landmarks=await loadJSON('/assets/landmarks/'+encodeURIComponent(data.plan.map)+'.json',{signal:controller.signal});}finally{clearTimeout(timer);}
   cachedModel=new MapModel(map);cachedMap=data.plan.map;
  }
  const result=searchWarJumps(cachedModel,data.plan,data.directions,p=>postMessage({progress:p}));
  result.timing={milliseconds:Math.round(performance.now()-start),reusedMap};postMessage({result});
 }catch(e){postMessage({error:e?.name==='AbortError'?'Die Anfrage wurde abgebrochen oder hat das Zeitlimit überschritten.':e?.name==='TypeError'?'Die lokalen Kartendaten konnten nicht geladen werden.':e?.name==='SyntaxError'?'Die Kartendaten konnten nicht gelesen werden.':e?.message||String(e)});}
};
self.onmessageerror=()=>postMessage({error:'Der Plan konnte nicht an den Kriegsbauer übergeben werden.'});
