import {clone,legacy,G} from './core/model.js';

// A broad front follows the actual successful advance, including its bends.
// All lateral flags still need free ground and a real rooted territory edge.
export function warFront(model,initial,base,aid,{budget,deadline},progress=()=>{}){
 const plan=clone(initial),main=plan.buildings.slice(base.buildings.length).filter(b=>b.allianceId===aid),own=base.buildings.filter(b=>b.allianceId===aid),points=[...own,...main],candidates=new Map();let added=0;
 if(!main.length)return {plan,added};
 for(const b of main){
  const near=points.filter(q=>q!==b&&Math.hypot(q.x-b.x,q.y-b.y)>18).sort((a,c)=>Math.hypot(a.x-b.x,a.y-b.y)-Math.hypot(c.x-b.x,c.y-b.y)).slice(0,2);
  for(const q of near){const d=Math.hypot(b.x-q.x,b.y-q.y),nx=(b.y-q.y)/d,ny=-(b.x-q.x)/d;
   for(const offset of [-72,-54,54,72])for(const t of [0,.5]){
    const x=(b.x+(q.x-b.x)*t)+nx*offset,y=(b.y+(q.y-b.y)*t)+ny*offset;
    const cell=G.snapTerritoryPoint(x,y),key=cell.x+':'+cell.y;candidates.set(key,{id:'front-'+key,kind:'flag',allianceId:aid,x:cell.x,y:cell.y,warRole:'front'});
   }
  }
 }
 const maxAdded=Math.min(Math.max(0,budget-main.length),Math.max(4,main.length*2));
 model.setPlan(plan);let changed=true;
 while(changed&&added<maxAdded&&performance.now()<deadline){
  changed=false;
  const neighbours=b=>plan.buildings.filter(q=>q.allianceId===aid&&Math.hypot(q.x-b.x,q.y-b.y)<78).length;
  const sorted=[...candidates.entries()].sort((a,b)=>neighbours(b[1])-neighbours(a[1]));
  for(const [key,b]of sorted){
   if(added>=maxAdded||performance.now()>=deadline)break;
   if(plan.buildings.some(q=>Math.hypot(b.x-q.x,b.y-q.y)<30))continue;
   if(model.placementError(b))continue;
   plan.buildings.push(b);model.setPlan(plan);candidates.delete(key);added++;changed=true;
  }
 }
 progress({phase:'Breiter Vorstoß',visits:candidates.size,added,remaining:0});return {plan,added};
}
